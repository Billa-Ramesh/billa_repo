// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IssuesTable.java

package oracle.hub.tf.dropgenerator.gui;

import javax.swing.tree.DefaultMutableTreeNode;
import oracle.hub.tf.dropgenerator.core.BomEntryError;
import org.netbeans.swing.outline.RowModel;

class IssuesRowModel
    implements RowModel
{
    public static final class Column extends Enum
    {

        public static Column[] values()
        {
            return (Column[])$VALUES.clone();
        }

        public static Column valueOf(String name)
        {
            return (Column)Enum.valueOf(oracle/hub/tf/dropgenerator/gui/IssuesRowModel$Column, name);
        }

        public String toString()
        {
            return displayName;
        }

        public static final Column TYPE;
        public static final Column DETAIL;
        private final String displayName;
        private static final Column $VALUES[];

        static 
        {
            TYPE = new Column("TYPE", 0, "Issue type");
            DETAIL = new Column("DETAIL", 1, "Detail");
            $VALUES = (new Column[] {
                TYPE, DETAIL
            });
        }

        private Column(String s, int i, String display)
        {
            super(s, i);
            displayName = display;
        }
    }


    IssuesRowModel()
    {
    }

    public Class getColumnClass(int column)
    {
        return types[column];
    }

    public int getColumnCount()
    {
        return Column.values().length;
    }

    public String getColumnName(int column)
    {
        return Column.values()[column].toString();
    }

    public Object getValueFor(Object node, int column)
    {
        if(!(node instanceof DefaultMutableTreeNode))
            return null;
        DefaultMutableTreeNode n = (DefaultMutableTreeNode)node;
        if(n.getUserObject().getClass().equals(oracle/hub/tf/dropgenerator/core/BomEntryError))
        {
            BomEntryError error = (BomEntryError)n.getUserObject();
            if(Column.DETAIL.ordinal() == column)
                return error.toString();
            if(Column.TYPE.ordinal() == column)
                return error.getErrorType();
        }
        return null;
    }

    public boolean isCellEditable(Object arg0, int arg1)
    {
        return false;
    }

    public void setValueFor(Object obj, int i, Object obj1)
    {
    }

    private final Class types[] = {
        java/lang/String, java/lang/String, java/lang/String
    };
    public static double columnWidths[] = {
        250D, 190D, 1.0D
    };

}
