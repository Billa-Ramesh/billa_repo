// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DirectoryChooserDialog.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.text.*;

class FilteredDocument extends PlainDocument
{

    FilteredDocument()
    {
        chars = new HashSet();
        disallowedMode = false;
    }

    public void setDisallowedMode(boolean mode)
    {
        disallowedMode = mode;
    }

    public void addChars(Set c)
    {
        chars.addAll(c);
        buildPattern();
    }

    public void addChar(char c)
    {
        chars.add(Character.valueOf(c));
        buildPattern();
    }

    public void setPattern(Pattern p)
    {
        charsPattern = p;
    }

    private void buildPattern()
    {
        StringBuilder regex = new StringBuilder("[");
        Iterator i$ = chars.iterator();
        do
        {
            if(!i$.hasNext())
                break;
            Character c = (Character)i$.next();
            regex.append(c);
            if(c.charValue() == '\\')
                regex.append(c);
        } while(true);
        regex.append("]");
        charsPattern = Pattern.compile(regex.toString());
    }

    public void insertString(int offs, String str, AttributeSet a)
        throws BadLocationException
    {
        if(str == null)
            return;
        Matcher regexMatcher = charsPattern.matcher(str);
        if(!disallowedMode && regexMatcher.matches() || disallowedMode && !regexMatcher.find())
            super.insertString(offs, str, a);
    }

    private static final long serialVersionUID = 1L;
    private Set chars;
    private Pattern charsPattern;
    private boolean disallowedMode;
}
