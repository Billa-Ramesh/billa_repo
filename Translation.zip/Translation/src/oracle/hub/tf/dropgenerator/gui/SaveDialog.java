// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DirectoryChooserDialog.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.Dimension;
import java.io.File;
import java.util.Iterator;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            DirectoryChooserDialog, JButtonGroup, VobDocument, NumericDocument, 
//            DropGeneratorWindow

class SaveDialog extends DirectoryChooserDialog
{

    public SaveDialog(DropGeneratorWindow parent, File dir, boolean hf, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dt)
    {
        super(parent, "Save drop", dir);
        productTextField = new JTextField(20);
        groupTextField = new JTextField(20);
        versionTextField = new JTextField(20);
        moduleTextField = new JTextField(20);
        dropTextField = new JTextField();
        formsVersionButtons = new JButtonGroup();
        hasForms = false;
        widest = 0;
        hasForms = hf;
        productTextField.setDocument(new VobDocument());
        groupTextField.setDocument(new VobDocument());
        versionTextField.setDocument(new VobDocument());
        dropTextField.setDocument(new NumericDocument());
        moduleTextField.setDocument(new VobDocument());
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, 1));
        JPanel productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, 0));
        JLabel productLabel = new JLabel("* Product: ", 4);
        widest = productLabel.getPreferredSize().width <= widest ? widest : productLabel.getPreferredSize().width;
        productPanel.add(productLabel);
        productPanel.add(Box.createHorizontalStrut(4));
        productPanel.add(productTextField);
        productPanel.setBorder(new EmptyBorder(0, 0, 5, 0));
        JPanel groupPanel = new JPanel();
        groupPanel.setLayout(new BoxLayout(groupPanel, 0));
        JLabel groupLabel = new JLabel("Group:", 4);
        widest = groupLabel.getPreferredSize().width <= widest ? widest : groupLabel.getPreferredSize().width;
        groupPanel.add(groupLabel);
        groupPanel.add(Box.createHorizontalStrut(4));
        groupPanel.add(groupTextField);
        groupPanel.setBorder(new EmptyBorder(0, 0, 5, 0));
        JPanel versionPanel = new JPanel();
        versionPanel.setLayout(new BoxLayout(versionPanel, 0));
        JLabel versionLabel = new JLabel("* Version:", 4);
        widest = versionLabel.getPreferredSize().width <= widest ? widest : versionLabel.getPreferredSize().width;
        versionPanel.add(versionLabel);
        versionPanel.add(Box.createHorizontalStrut(4));
        versionPanel.add(versionTextField);
        versionPanel.setBorder(new EmptyBorder(0, 0, 5, 0));
        JPanel modulePanel = new JPanel();
        JLabel moduleLabel = new JLabel("Module:", 4);
        if(dt.equals(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UA))
        {
            modulePanel.setLayout(new BoxLayout(modulePanel, 0));
            widest = moduleLabel.getPreferredSize().width <= widest ? widest : moduleLabel.getPreferredSize().width;
            modulePanel.add(moduleLabel);
            modulePanel.add(Box.createHorizontalStrut(4));
            modulePanel.add(moduleTextField);
            modulePanel.setBorder(new EmptyBorder(0, 0, 5, 0));
        }
        JPanel dropPanel = new JPanel();
        dropPanel.setLayout(new BoxLayout(dropPanel, 0));
        JLabel dropLabel = new JLabel("* Drop nr:", 4);
        widest = dropLabel.getPreferredSize().width <= widest ? widest : dropLabel.getPreferredSize().width;
        dropPanel.add(dropLabel);
        dropPanel.add(Box.createHorizontalStrut(4));
        dropPanel.add(dropTextField);
        dropTextField.setToolTipText("Only numbers allowed!");
        dropPanel.setBorder(new EmptyBorder(0, 0, 5, 0));
        JPanel formsVersionPanel = new JPanel();
        JLabel formsVersionLabel = new JLabel("* Forms version:", 4);
        if(hasForms)
        {
            JRadioButton forms6 = new JRadioButton(oracle.hub.tf.dropgenerator.core.DropGenerator.FormsVersion.R11.name);
            JRadioButton forms10 = new JRadioButton(oracle.hub.tf.dropgenerator.core.DropGenerator.FormsVersion.R12.name);
            formsVersionButtons.add(forms6);
            formsVersionButtons.add(forms10);
            formsVersionPanel.setLayout(new BoxLayout(formsVersionPanel, 0));
            widest = formsVersionLabel.getPreferredSize().width <= widest ? widest : formsVersionLabel.getPreferredSize().width;
            formsVersionPanel.add(formsVersionLabel);
            formsVersionPanel.add(Box.createHorizontalStrut(4));
            formsVersionPanel.add(forms6);
            formsVersionPanel.add(forms10);
            formsVersionPanel.add(Box.createHorizontalGlue());
            formsVersionPanel.setBorder(new EmptyBorder(0, 0, 5, 0));
        }
        widest++;
        productLabel.setPreferredSize(new Dimension(widest, productLabel.getPreferredSize().height));
        groupLabel.setPreferredSize(new Dimension(widest, groupLabel.getPreferredSize().height));
        versionLabel.setPreferredSize(new Dimension(widest, versionLabel.getPreferredSize().height));
        moduleLabel.setPreferredSize(new Dimension(widest, moduleLabel.getPreferredSize().height));
        dropLabel.setPreferredSize(new Dimension(widest, dropLabel.getPreferredSize().height));
        formsVersionLabel.setPreferredSize(new Dimension(widest, formsVersionLabel.getPreferredSize().height));
        panel.add(productPanel);
        panel.add(versionPanel);
        panel.add(dropPanel);
        panel.add(groupPanel);
        if(dt.equals(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UA))
            panel.add(modulePanel);
        if(hasForms)
            panel.add(formsVersionPanel);
        panel.setBorder(BorderFactory.createTitledBorder("Drop information"));
        innerPanel.add(panel, "North");
        pack();
    }

    public void setProductName(String s)
    {
        productTextField.setText(s);
    }

    public void setProductGroup(String s)
    {
        groupTextField.setText(s);
    }

    public void setProductModule(String s)
    {
        moduleTextField.setText(s);
    }

    public void setProductVersion(String s)
    {
        versionTextField.setText(s);
    }

    public void setProductDrop(int n)
    {
        dropTextField.setText(Integer.toString(n));
    }

    public void setFormsVersion(oracle.hub.tf.dropgenerator.core.DropGenerator.FormsVersion formsVersion)
    {
        if(formsVersion == null)
            return;
        Iterator i$ = formsVersionButtons.getButtons().iterator();
        do
        {
            if(!i$.hasNext())
                break;
            AbstractButton b = (AbstractButton)i$.next();
            if(!b.getText().equals(formsVersion.name))
                continue;
            b.setSelected(true);
            break;
        } while(true);
    }

    protected void OKAction()
    {
        String errorMessage = "The following problems have been detected:\n";
        boolean error = false;
        if(getProduct().isEmpty())
        {
            error = true;
            errorMessage = (new StringBuilder()).append(errorMessage).append("* Product name field is compulsory.\n").toString();
        }
        if(getVersion().isEmpty())
        {
            error = true;
            errorMessage = (new StringBuilder()).append(errorMessage).append("* Version field is compulsory.\n").toString();
        }
        if(getDrop() < 0)
        {
            error = true;
            errorMessage = (new StringBuilder()).append(errorMessage).append("* Drop number field is compulsory.\n").toString();
        }
        if(hasForms && getFormsVersion() == null)
        {
            error = true;
            errorMessage = (new StringBuilder()).append(errorMessage).append("* You must choose the correct form files version contained within this drop.\n").toString();
        }
        if(error)
        {
            JOptionPane.showMessageDialog(this, errorMessage);
            return;
        }
        if(!groupTextField.getText().equals(groupTextField.getText().toLowerCase()) || !versionTextField.getText().equals(versionTextField.getText().toLowerCase()))
            JOptionPane.showMessageDialog(this, "Please be aware that spaces and uppercase letters in group and version fields are not supported.\nThese will be converted to lowercase in the generated drop filename.");
        action = 0;
        setVisible(false);
    }

    public void setVisible(boolean value)
    {
        if(super.getSelectedDir().getName().equals(getGroup()))
            setProductGroup("");
        if(getDrop() <= 0)
            dropTextField.setText("");
        super.setVisible(value);
    }

    public String getProduct()
    {
        return productTextField.getText().replaceAll(" ", "").toLowerCase();
    }

    public String getGroup()
    {
        return groupTextField.getText().replaceAll(" ", "").toLowerCase();
    }

    public String getVersion()
    {
        return versionTextField.getText().replaceAll(" ", "").toLowerCase();
    }

    public String getModule()
    {
        return moduleTextField.getText().replaceAll(" ", "").toLowerCase();
    }

    public int getDrop()
    {
        int drop = -1;
        try
        {
            drop = Integer.parseInt(dropTextField.getText().trim());
        }
        catch(NumberFormatException e) { }
        return drop;
    }

    public oracle.hub.tf.dropgenerator.core.DropGenerator.FormsVersion getFormsVersion()
    {
        AbstractButton selected = formsVersionButtons.getSelected();
        return selected != null ? oracle.hub.tf.dropgenerator.core.DropGenerator.FormsVersion.valueFor(selected.getText()) : null;
    }

    private static final long serialVersionUID = 1L;
    private JTextField productTextField;
    private JTextField groupTextField;
    private JTextField versionTextField;
    private JTextField moduleTextField;
    private JTextField dropTextField;
    private JButtonGroup formsVersionButtons;
    boolean hasForms;
    private int widest;
}
