// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockComboBox.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            BlockComboBoxRenderer

public class BlockComboBox extends JComboBox
{

    BlockComboBox(Object fileTypes[])
    {
        super(fileTypes);
        elements = new ArrayList();
        comboRenderer = new BlockComboBoxRenderer(getRenderer());
        setRenderer(comboRenderer);
    }

    BlockComboBox()
    {
        elements = new ArrayList();
        comboRenderer = new BlockComboBoxRenderer(getRenderer());
        setRenderer(comboRenderer);
    }

    private void makeVectorData()
    {
        int separator = 0;
        DefaultComboBoxModel model = (DefaultComboBoxModel)getModel();
        model.removeAllElements();
        for(int i = 0; i < elements.size(); i++)
        {
            TreeSet innerData = (TreeSet)elements.get(i);
            for(Iterator i$ = innerData.iterator(); i$.hasNext();)
            {
                AbstractFileType type = (AbstractFileType)i$.next();
                addItem(type);
                separator++;
            }

            if(i + 1 < elements.size())
                comboRenderer.addSeparator(separator);
        }

    }

    public void addElements(Set newElements)
    {
        elements.add(new TreeSet(newElements));
        makeVectorData();
    }

    private static final long serialVersionUID = 1L;
    private BlockComboBoxRenderer comboRenderer;
    private ArrayList elements;
}
