// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LanguageTokensDialog.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.SwingWorker;
import oracle.hub.tf.dropgenerator.core.Bom;
import oracle.hub.tf.dropgenerator.core.BomEntry;
import oracle.hub.tf.dropgenerator.core.DropGenerator;
import oracle.hub.tf.dropgenerator.core.LanguageTokens;
import oracle.hub.tf.dropgenerator.core.TargetFile;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            JButtonGroup, OutputFileDocument, LanguageTokensHelpDialog, DropGeneratorWindow, 
//            FilesTable, FilesTableModel, Util

public class LanguageTokensDialog extends JDialog
{
    private class ApplyActionListener
        implements ActionListener
    {

        public void actionPerformed(ActionEvent e)
        {
            final FilesTableModel model = filesTable.getModel();
            int selectedRowCount = filesTable.getSelectedRowCount();
            if(selectedRowCount == 0)
            {
                JOptionPane.showMessageDialog(DropGeneratorWindow.getFrames()[0], "You must select at least one row!");
                return;
            }
            if(e.getActionCommand().equals(Operation.Reset.toString()))
            {
                op = Operation.Reset;
            } else
            {
                Iterator i$ = LanguageTokensDialog.groupOperation.getButtons().iterator();
                do
                {
                    if(!i$.hasNext())
                        break;
                    AbstractButton b = (AbstractButton)i$.next();
                    if(b.isSelected())
                        op = (Operation)Enum.valueOf(oracle/hub/tf/dropgenerator/gui/LanguageTokensDialog$Operation, b.getText());
                } while(true);
            }
            (new SwingWorker() {

                protected Void doInBackground()
                    throws Exception
                {
                    int arr$[] = filesTable.getSelectedRows();
                    int len$ = arr$.length;
                    for(int i$ = 0; i$ < len$; i$++)
                    {
                        int row = arr$[i$];
                        BomEntry b = model.getEntry(filesTable.convertRowIndexToModel(row));
                        String result = b.getTarget().toString();
                        String filename = result.contains("/") ? result.substring(result.lastIndexOf('/') + 1) : result;
                        String path = result.contains("/") ? result.substring(0, result.lastIndexOf('/') + 1) : "";
                        if(op == Operation.Reset)
                        {
                            path = b.getName();
                            filename = "";
                        } else
                        if(op == Operation.Insert)
                            filename = (new StringBuilder()).append(filename.substring(0, b.getName().lastIndexOf('.'))).append(LanguageTokensDialog.txtTokenPrefix.getText()).append(LanguageTokensDialog.cmbToken.getSelectedItem()).append(filename.substring(filename.lastIndexOf('.'))).toString();
                        else
                        if(op == Operation.Replace)
                        {
                            if(LanguageTokensDialog.cbxDirectoryName.isSelected())
                                if(path.length() == 0 && b.getSourcePathRelative().contains(LanguageTokensDialog.txtReplace.getText()))
                                    path = Util.replacePathComponents(b.getSourcePathRelative(), LanguageTokensDialog.txtReplace.getText(), (new StringBuilder()).append(LanguageTokensDialog.txtTokenPrefix.getText()).append(LanguageTokensDialog.cmbToken.getSelectedItem()).toString());
                                else
                                if(path.contains(LanguageTokensDialog.txtReplace.getText()))
                                    path = Util.replacePathComponents(path, LanguageTokensDialog.txtReplace.getText(), (new StringBuilder()).append(LanguageTokensDialog.txtTokenPrefix.getText()).append(LanguageTokensDialog.cmbToken.getSelectedItem()).toString());
                                else
                                    DropGenerator.logger.log(Level.INFO, "{0} does not contain the search string ''{1}'' within its path", new Object[] {
                                        b.getSourceRelative(), LanguageTokensDialog.txtReplace.getText()
                                    });
                            if(LanguageTokensDialog.cbxFileName.isSelected())
                                filename = filename.replaceAll(LanguageTokensDialog.txtReplace.getText(), (new StringBuilder()).append(LanguageTokensDialog.txtTokenPrefix.getText()).append(LanguageTokensDialog.cmbToken.getSelectedItem()).toString());
                            if(!path.isEmpty() && !path.endsWith("/"))
                                path = (new StringBuilder()).append(path).append('/').toString();
                        }
                        b.setTarget((new StringBuilder()).append(path).append(filename).toString());
                    }

                    model.getBom().write();
                    return null;
                }

                protected void done()
                {
                    model.fireTableRowsUpdated(filesTable.getSelectedRows()[0], filesTable.getSelectedRows()[filesTable.getSelectedRows().length - 1]);
                    filesTable.repaint();
                }

                protected volatile Object doInBackground()
                    throws Exception
                {
                    return doInBackground();
                }

                final FilesTableModel val$model;
                final ApplyActionListener this$1;

                
                {
                    this$1 = ApplyActionListener.this;
                    model = filestablemodel;
                    super();
                }
            }
).execute();
        }

        Operation op;
        final LanguageTokensDialog this$0;

        private ApplyActionListener()
        {
            this$0 = LanguageTokensDialog.this;
            super();
        }

    }

    public static final class Operation extends Enum
    {

        public static Operation[] values()
        {
            return (Operation[])$VALUES.clone();
        }

        public static Operation valueOf(String name)
        {
            return (Operation)Enum.valueOf(oracle/hub/tf/dropgenerator/gui/LanguageTokensDialog$Operation, name);
        }

        public static final Operation Insert;
        public static final Operation Replace;
        public static final Operation Reset;
        private static final Operation $VALUES[];

        static 
        {
            Insert = new Operation("Insert", 0);
            Replace = new Operation("Replace", 1);
            Reset = new Operation("Reset", 2);
            $VALUES = (new Operation[] {
                Insert, Replace, Reset
            });
        }

        private Operation(String s, int i)
        {
            super(s, i);
        }
    }


    public LanguageTokensDialog(Window parent, FilesTable ft)
    {
        super(parent, "Language token settings");
        setResizable(false);
        filesTable = ft;
        ApplyActionListener apply = new ApplyActionListener();
        btnApply.addActionListener(apply);
        btnReset.addActionListener(apply);
        btnClose.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
            }

            final LanguageTokensDialog this$0;

            
            {
                this$0 = LanguageTokensDialog.this;
                super();
            }
        }
);
        GroupLayout pnlOperationLayout = new GroupLayout(pnlOperation);
        pnlOperation.setLayout(pnlOperationLayout);
        pnlOperationLayout.setHorizontalGroup(pnlOperationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(pnlOperationLayout.createSequentialGroup().addContainerGap().addGroup(pnlOperationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(radioInsert).addGroup(pnlOperationLayout.createSequentialGroup().addComponent(radioReplace).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(txtReplace, -2, -1, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(lblWithin).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addGroup(pnlOperationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(cbxFileName).addComponent(cbxDirectoryName)))).addContainerGap(-1, 32767)));
        pnlOperationLayout.setVerticalGroup(pnlOperationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(pnlOperationLayout.createSequentialGroup().addContainerGap().addComponent(radioInsert).addGap(18, 18, 18).addGroup(pnlOperationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(radioReplace).addComponent(txtReplace, -2, -1, -2).addComponent(lblWithin).addComponent(cbxDirectoryName)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(cbxFileName).addContainerGap(-1, 32767)));
        lblTokenInfo.addMouseListener(new MouseListener() {

            public void mouseClicked(MouseEvent e)
            {
                LanguageTokensDialog.languageTokensHelp.setVisible(true);
            }

            public void mouseEntered(MouseEvent e)
            {
                LanguageTokensDialog.lblTokenInfo.setCursor(new Cursor(12));
            }

            public void mouseExited(MouseEvent mouseevent)
            {
            }

            public void mousePressed(MouseEvent mouseevent)
            {
            }

            public void mouseReleased(MouseEvent mouseevent)
            {
            }

            final LanguageTokensDialog this$0;

            
            {
                this$0 = LanguageTokensDialog.this;
                super();
            }
        }
);
        cmbToken.setModel(new DefaultComboBoxModel(LanguageTokens.getColumnNames().toArray()));
        GroupLayout pnlTokenSettingsLayout = new GroupLayout(pnlTokenSettings);
        pnlTokenSettings.setLayout(pnlTokenSettingsLayout);
        pnlTokenSettingsLayout.setHorizontalGroup(pnlTokenSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(pnlTokenSettingsLayout.createSequentialGroup().addContainerGap().addGroup(pnlTokenSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING).addComponent(lblToken).addComponent(lblTokenPrefix)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addGroup(pnlTokenSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(txtTokenPrefix, -2, -1, -2).addGroup(pnlTokenSettingsLayout.createSequentialGroup().addComponent(cmbToken, -2, -1, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(lblTokenInfo))).addContainerGap(19, 32767)));
        pnlTokenSettingsLayout.setVerticalGroup(pnlTokenSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(pnlTokenSettingsLayout.createSequentialGroup().addContainerGap().addGroup(pnlTokenSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(lblTokenPrefix).addComponent(txtTokenPrefix, -2, -1, -2)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addGroup(pnlTokenSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(lblToken).addComponent(cmbToken, -2, -1, -2).addComponent(lblTokenInfo)).addContainerGap(-1, 32767)));
        GroupLayout layout = new GroupLayout(getContentPane());
        setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(pnlOperation, -1, -1, 32767).addComponent(pnlTokenSettings, -1, -1, 32767).addGroup(layout.createSequentialGroup().addGap(130, 130, 130).addComponent(btnClose).addGap(18, 18, 18).addComponent(btnReset).addGap(18, 18, 18).addComponent(btnApply))).addContainerGap()));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(pnlOperation, -2, -1, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(pnlTokenSettings, -2, -1, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(btnApply).addComponent(btnReset).addComponent(btnClose)).addContainerGap(-1, 32767)));
        pack();
        setLocationRelativeTo(getParent());
        setLocation(getLocation().x + (getParent().getWidth() - getWidth()) / 2, getLocation().y + (getParent().getHeight() - getHeight()) / 2);
    }

    public void setVisible(boolean b)
    {
        if(!b)
        {
            radioInsert.setSelected(true);
            cbxDirectoryName.setSelected(false);
            cbxDirectoryName.setEnabled(false);
            cbxFileName.setSelected(false);
            cbxFileName.setEnabled(false);
            txtReplace.setText("");
            txtReplace.setEnabled(false);
            txtTokenPrefix.setText("");
            cmbToken.setSelectedIndex(0);
        }
        super.setVisible(b);
    }

    private static final long serialVersionUID = 1L;
    private final FilesTable filesTable;
    private static final JButton btnApply = new JButton("Apply");
    private static final JButton btnClose = new JButton("Close");
    private static final JButton btnReset;
    private static final JCheckBox cbxDirectoryName = new JCheckBox("directory names");
    private static final JCheckBox cbxFileName = new JCheckBox("file names");
    private static final JComboBox cmbToken;
    private static final JLabel lblToken = new JLabel("Token:");
    private static final JLabel lblTokenInfo;
    private static final JLabel lblTokenPrefix = new JLabel("Token prefix:");
    private static final JLabel lblWithin = new JLabel("within");
    private static final JPanel pnlOperation;
    private static final JPanel pnlTokenSettings;
    private static final JButtonGroup groupOperation;
    private static final JRadioButton radioInsert;
    private static final JRadioButton radioReplace;
    private static final JTextField txtReplace;
    private static final JTextField txtTokenPrefix;
    private static final JDialog languageTokensHelp = new LanguageTokensHelpDialog(DropGeneratorWindow.getWindows()[0]);

    static 
    {
        lblTokenInfo = new JLabel("<html><u>Token information</u></html>");
        lblTokenInfo.setIcon(new ImageIcon(oracle/hub/tf/dropgenerator/gui/LanguageTokensDialog.getResource("help.png")));
        lblTokenInfo.setForeground(new Color(51, 51, 255));
        btnReset = new JButton(Operation.Reset.toString());
        radioInsert = new JRadioButton(Operation.Insert.toString());
        radioReplace = new JRadioButton(Operation.Replace.toString());
        groupOperation = new JButtonGroup();
        groupOperation.add(radioInsert);
        groupOperation.add(radioReplace);
        txtReplace = new JTextField();
        txtReplace.setPreferredSize(new Dimension(40, 20));
        txtTokenPrefix = new JTextField(3);
        txtTokenPrefix.setDocument(new OutputFileDocument());
        cmbToken = new JComboBox();
        cmbToken.setPreferredSize(new Dimension(55, 20));
        pnlOperation = new JPanel();
        pnlOperation.setBorder(BorderFactory.createTitledBorder("Operation"));
        pnlTokenSettings = new JPanel();
        pnlTokenSettings.setBorder(BorderFactory.createTitledBorder("Token settings"));
        radioInsert.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                LanguageTokensDialog.txtReplace.setEnabled(false);
                LanguageTokensDialog.cbxDirectoryName.setEnabled(false);
                LanguageTokensDialog.cbxFileName.setEnabled(false);
            }

        }
);
        radioReplace.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                LanguageTokensDialog.txtReplace.setEnabled(true);
                LanguageTokensDialog.cbxDirectoryName.setEnabled(true);
                LanguageTokensDialog.cbxFileName.setEnabled(true);
            }

        }
);
        radioInsert.doClick();
    }









}
