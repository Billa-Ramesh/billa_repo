// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VersionChecker.java

package oracle.hub.tf.dropgenerator.gui;

import java.io.*;
import java.net.*;
import java.util.concurrent.Callable;
import oracle.hub.tf.dropgenerator.core.Util;

class CheckLatestVersion
    implements Callable
{

    CheckLatestVersion()
    {
    }

    public String call()
        throws IOException, URISyntaxException
    {
        URLConnection updateConnection = (new URL("http://translation.oraclecorp.com/dropgenerator")).openConnection(Util.findProxy(new URI("http://translation.oraclecorp.com/dropgenerator")));
        BufferedReader in = new BufferedReader(new InputStreamReader(updateConnection.getInputStream()));
        String latestVersion = in.readLine().trim();
        in.close();
        return latestVersion;
    }

    public volatile Object call()
        throws Exception
    {
        return call();
    }
}
