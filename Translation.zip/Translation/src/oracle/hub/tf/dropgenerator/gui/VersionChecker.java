// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VersionChecker.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import java.util.concurrent.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import net.miginfocom.swing.MigLayout;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            DirectoryChooserDialog, DropGeneratorWindow, DownloadLatest, DetailsDialog, 
//            CheckLatestVersion

public class VersionChecker
{
    class DownloadDialog extends JDialog
        implements PropertyChangeListener
    {

        public int getAction()
        {
            return action;
        }

        protected void OKAction()
        {
            download = new DownloadLatest(latestVersion);
            progressMonitor = new ProgressMonitor(DropGeneratorWindow.getFrames()[0], "Downloading new version...", "", 0, 100);
            progressMonitor.setProgress(0);
            download.addPropertyChangeListener(this);
            download.execute();
            File tempDownloadedFile;
            try
            {
                tempDownloadedFile = (File)download.get();
            }
            catch(InterruptedException e1)
            {
                DropGenerator.logger.severe("Download interrupted!");
                return;
            }
            catch(ExecutionException e1)
            {
                DropGenerator.logger.severe("Download interrupted!");
                return;
            }
            if(!tempDownloadedFile.exists() || tempDownloadedFile.length() == 0L)
            {
                DropGenerator.logger.severe("Download unsuccessful, aborting.");
                return;
            }
            tempDownloadedFile.deleteOnExit();
            File destinationDir = VersionChecker.showSaveDialog();
            if(destinationDir == null)
            {
                return;
            } else
            {
                File destinationFile = new File((new StringBuilder()).append(destinationDir.getAbsolutePath()).append(File.separatorChar).append("dropgenerator-").append(latestVersion).append(".jar").toString());
                tempDownloadedFile.renameTo(destinationFile);
                DropGenerator.logger.log(Level.INFO, "Successfully saved to: {0}", destinationFile);
                JOptionPane.showMessageDialog(DropGeneratorWindow.getFrames()[0], (new StringBuilder()).append("Please use the latest version you downloaded to: ").append(destinationFile).append("\nThis version will now be disabled.").toString());
                return;
            }
        }

        public void setVisible(boolean visible)
        {
            if(visible)
            {
                action = 2;
                setLocationRelativeTo(getParent());
            }
            super.setVisible(visible);
        }

        public void propertyChange(PropertyChangeEvent evt)
        {
            if("progress".equals(evt.getPropertyName()))
            {
                progressMonitor.setProgress(((Integer)evt.getNewValue()).intValue());
                if((progressMonitor.isCanceled() || download.isDone()) && progressMonitor.isCanceled())
                {
                    download.cancel(true);
                    DropGenerator.logger.info("Download cancelled by user.");
                }
            }
        }

        private static final long serialVersionUID = 1L;
        private JTextPane textPane;
        private int action;
        final VersionChecker this$0;

        DownloadDialog()
        {
            this$0 = VersionChecker.this;
            super(DropGeneratorWindow.getFrames()[0], "Download latest version", true);
            textPane = new JTextPane();
            setDefaultCloseOperation(0);
            MigLayout ml = new MigLayout("ins 10, wrap 2");
            JPanel panel = new JPanel(ml);
            getContentPane().add(panel);
            Font font = new Font((new JLabel()).getFont().getFamily(), 0, 12);
            Font fontBold = new Font((new JLabel()).getFont().getFamily(), 1, 12);
            JLabel curVerText = new JLabel("Your version:");
            curVerText.setFont(font);
            JLabel curVer = new JLabel(DropGeneratorWindow.version);
            curVer.setFont(fontBold);
            JLabel latestVerText = new JLabel("Latest version:");
            latestVerText.setFont(font);
            JLabel latestVer = new JLabel(latestVersion);
            latestVer.setFont(fontBold);
            panel.add(new JLabel(), "span 2, height 5");
            JLabel newVersionLbl = new JLabel("New version found!");
            newVersionLbl.setFont(new Font(newVersionLbl.getFont().getFamily(), 1, 16));
            panel.add(newVersionLbl, "span 2");
            panel.add(new JLabel(), "span 2, height 10");
            DetailsDialog.addSeparator(panel, "Version information");
            panel.add(curVerText, "align right");
            panel.add(curVer);
            panel.add(latestVerText, "align right");
            panel.add(latestVer);
            textPane.setEditable(false);
            textPane.setText("Loading release information...");
            try
            {
                textPane.setPage("http://translation.oraclecorp.com/dropgenerator_release.htm");
            }
            catch(IOException e)
            {
                return;
            }
            textPane.addHyperlinkListener(new HyperlinkListener() {

                public void hyperlinkUpdate(HyperlinkEvent evt)
                {
                    if(evt.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ACTIVATED)
                        try
                        {
                            Desktop.getDesktop().browse(evt.getURL().toURI());
                        }
                        catch(Exception e)
                        {
                            Logger.getLogger("dropgen").log(Level.SEVERE, "Invalid URL: {0}", e.getMessage());
                        }
                }

                final VersionChecker val$this$0;
                final DownloadDialog this$1;


// JavaClassFileOutputException: Invalid index accessing method local variables table of <init>
            }
);
            panel.add(new JLabel(), "span 2, height 10");
            DetailsDialog.addSeparator(panel, "Release information");
            panel.add(new JScrollPane(textPane), (new StringBuilder()).append("width ").append((getParent().getWidth() / 5) * 3).append(", height ").append((getParent().getHeight() / 5) * 2).append(", span 2").toString());
            JPanel btnPanel = new JPanel();
            JButton download = new JButton("Download now");
            download.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e)
                {
                    OKAction();
                }

                final VersionChecker val$this$0;
                final DownloadDialog this$1;


// JavaClassFileOutputException: Invalid index accessing method local variables table of <init>
            }
);
            btnPanel.add(download);
            JButton quit = new JButton("Quit");
            quit.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e)
                {
                    System.exit(0);
                }

                final VersionChecker val$this$0;
                final DownloadDialog this$1;


// JavaClassFileOutputException: Invalid index accessing method local variables table of <init>
            }
);
            btnPanel.add(quit);
            panel.add(btnPanel, "skip 1, align right");
            pack();
            setLocationRelativeTo(getParent());
            setResizable(false);
        }
    }


    public VersionChecker()
    {
        latestVersion = "";
    }

    public void startupCheck()
    {
        (new Thread(new Runnable() {

            public void run()
            {
                Future newVersion = VersionChecker.pool.submit(new CheckLatestVersion());
                try
                {
                    latestVersion = (String)newVersion.get();
                }
                catch(InterruptedException e) { }
                catch(ExecutionException e) { }
                showDownloadConfirmationDialog();
            }

            final VersionChecker this$0;

            
            {
                this$0 = VersionChecker.this;
                super();
            }
        }
)).start();
    }

    public void checkLatest()
    {
        (new Thread(new Runnable() {

            public void run()
            {
                DropGenerator.logger.info("Checking for available updates...");
                Future newVersion = VersionChecker.pool.submit(new CheckLatestVersion());
                try
                {
                    latestVersion = (String)newVersion.get();
                    DropGenerator.logger.log(Level.INFO, "Latest version is {0}", latestVersion);
                    if(!VersionChecker.needsUpdate(latestVersion, DropGenerator.version))
                    {
                        JOptionPane.showMessageDialog(DropGeneratorWindow.getFrames()[0], "There are no updates available at the moment.", "TF Drop Generator", 1);
                        return;
                    }
                }
                catch(InterruptedException e)
                {
                    return;
                }
                catch(ExecutionException e)
                {
                    if(e.getCause() instanceof UnknownHostException)
                        DropGenerator.logger.severe("Could not connect to update server");
                    return;
                }
                showDownloadConfirmationDialog();
            }

            final VersionChecker this$0;

            
            {
                this$0 = VersionChecker.this;
                super();
            }
        }
)).start();
    }

    protected static boolean needsUpdate(String latestVersion, String currentVersion)
    {
        if(latestVersion == null || latestVersion.length() == 0 || latestVersion.equals(currentVersion) || currentVersion.contains("-SNAPSHOT"))
            return false;
        StringTokenizer latest = new StringTokenizer(latestVersion, ".");
        for(StringTokenizer current = new StringTokenizer(currentVersion, "."); latest.hasMoreTokens() || current.hasMoreTokens();)
        {
            Integer currentComponent;
            try
            {
                currentComponent = Integer.valueOf(current.hasMoreTokens() ? Integer.parseInt(current.nextToken()) : 0);
            }
            catch(NumberFormatException e)
            {
                DropGenerator.logger.log(Level.SEVERE, "Could not parse portion of version number: {0}", e.getMessage());
                return false;
            }
            Integer latestComponent;
            try
            {
                latestComponent = Integer.valueOf(latest.hasMoreTokens() ? Integer.parseInt(latest.nextToken()) : 0);
            }
            catch(NumberFormatException e)
            {
                DropGenerator.logger.log(Level.INFO, "Remote version number is malformed: {0}", e.getMessage());
                return false;
            }
            if(latestComponent.intValue() > currentComponent.intValue())
                return true;
        }

        return false;
    }

    public void showDownloadConfirmationDialog()
    {
        if(!needsUpdate(latestVersion, DropGenerator.version))
        {
            return;
        } else
        {
            DownloadDialog downloadDialog = new DownloadDialog();
            downloadDialog.setVisible(true);
            return;
        }
    }

    public static File showSaveDialog()
    {
        DirectoryChooserDialog saveDialog = new DirectoryChooserDialog(DropGeneratorWindow.getWindows()[0], "Destination directory", null);
        saveDialog.setVisible(true);
        if(saveDialog.getAction() == 2 || !saveDialog.isValidDir())
            return null;
        else
            return saveDialog.getSelectedDir();
    }

    public static final String portalURL = "http://translation.oraclecorp.com/";
    private static ExecutorService pool = Executors.newFixedThreadPool(1);
    private SwingWorker download;
    private ProgressMonitor progressMonitor;
    private String latestVersion;








}
