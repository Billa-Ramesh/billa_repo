// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VersionChecker.java

package oracle.hub.tf.dropgenerator.gui;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingWorker;
import oracle.hub.tf.dropgenerator.core.DropGenerator;
import oracle.hub.tf.dropgenerator.core.Util;

class DownloadLatest extends SwingWorker
{

    DownloadLatest(String latestVersion)
    {
        this.latestVersion = latestVersion;
        try
        {
            tempFile = File.createTempFile("dropgenerator", "tempdl");
        }
        catch(IOException e)
        {
            DropGenerator.logger.severe("Could not create temporary file, aborting download.");
        }
    }

    protected File doInBackground()
        throws Exception
    {
        downloadLatest(tempFile);
        return tempFile;
    }

    private void downloadLatest(File destination)
    {
        URL JARLocation;
        try
        {
            JARLocation = new URL((new StringBuilder()).append("http://translation.oraclecorp.com/dropgenerator-").append(latestVersion).append(".jar").toString());
        }
        catch(MalformedURLException e)
        {
            DropGenerator.logger.finest("Cannot update due to malformed dropgenerator download URL");
            return;
        }
        downloadJar(JARLocation, destination);
    }

    private void downloadJar(URL sourceURL, File destination)
    {
        DropGenerator.logger.log(Level.INFO, "Downloading {0}", sourceURL.getFile().substring(1));
        HttpURLConnection sourceConnection = null;
        try
        {
            sourceConnection = (HttpURLConnection)sourceURL.openConnection(Util.findProxy(sourceURL.toURI()));
        }
        catch(MalformedURLException exc)
        {
            throw new RuntimeException("Configured URL caused a MalformedURLException: ", exc);
        }
        catch(URISyntaxException e)
        {
            DropGenerator.logger.severe("Unable to download, malformed URL");
            return;
        }
        catch(IOException e)
        {
            DropGenerator.logger.severe("Unable to download, could not connect");
            return;
        }
        sourceConnection.setRequestProperty("Accept-Encoding", "zip, jar");
        try
        {
            sourceConnection.connect();
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not open connection to {0}", sourceConnection.getURL());
            return;
        }
        BufferedInputStream inputStream;
        try
        {
            inputStream = new BufferedInputStream(sourceConnection.getInputStream());
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not get input stream from {0}", sourceConnection.getURL());
            return;
        }
        BufferedOutputStream fileWriter;
        try
        {
            fileWriter = new BufferedOutputStream(new FileOutputStream(destination));
        }
        catch(FileNotFoundException e)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not write file to {0}", destination);
            return;
        }
        byte buffer[] = new byte[16384];
        int totalRead = 0;
        double totalSize = sourceConnection.getContentLength();
        setProgress(0);
        try
        {
            do
            {
                int bytesRead;
                if((bytesRead = inputStream.read(buffer)) == -1)
                    break;
                fileWriter.write(buffer, 0, bytesRead);
                if(totalSize > 0.0D)
                {
                    totalRead += bytesRead;
                    setProgress((int)(((double)totalRead / totalSize) * 100D));
                }
            } while(true);
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.SEVERE, "Error during saving file to {0}", destination);
            return;
        }
        try
        {
            inputStream.close();
            fileWriter.flush();
            fileWriter.close();
        }
        catch(IOException e) { }
        sourceConnection.disconnect();
    }

    protected volatile Object doInBackground()
        throws Exception
    {
        return doInBackground();
    }

    private final String latestVersion;
    private File tempFile;
}
