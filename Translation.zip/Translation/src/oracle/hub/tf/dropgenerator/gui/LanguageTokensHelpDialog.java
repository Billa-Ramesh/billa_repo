// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LanguageTokensHelpDialog.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Window;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;
import oracle.hub.tf.dropgenerator.core.LanguageTokens;

public class LanguageTokensHelpDialog extends JDialog
{
    private static class TokensTableModel extends AbstractTableModel
    {

        public Class getColumnClass(int columnIndex)
        {
            return java/lang/String;
        }

        public String getColumnName(int column)
        {
            return column < LanguageTokens.getColumnNames().size() ? (String)LanguageTokens.getColumnNames().get(column) : "";
        }

        public int getColumnCount()
        {
            return LanguageTokens.getColumnNames().size();
        }

        public int getRowCount()
        {
            return LanguageTokens.getCsvData().size();
        }

        public Object getValueAt(int rowIndex, int columnIndex)
        {
            String line[] = (String[])LanguageTokens.getCsvData().get(rowIndex);
            if(columnIndex >= line.length)
                return "";
            else
                return line[columnIndex];
        }

        private static final long serialVersionUID = 1L;

        private TokensTableModel()
        {
        }

    }


    public LanguageTokensHelpDialog(Window parent)
    {
        super(parent, "Language token list");
        JTable tokensTable = new JTable(new TokensTableModel());
        TableColumn firstCol = tokensTable.getColumnModel().getColumn(0);
        firstCol.setResizable(false);
        firstCol.setMinWidth(100);
        firstCol.setPreferredWidth(115);
        Font font = tokensTable.getFont();
        tokensTable.getTableHeader().setFont(font.deriveFont(1));
        getContentPane().add(new JScrollPane(tokensTable));
        TableRowSorter sorter = new TableRowSorter((TokensTableModel)tokensTable.getModel());
        tokensTable.setRowSorter(sorter);
        sorter.toggleSortOrder(0);
        sorter.sort();
        Toolkit toolkit = getToolkit();
        Dimension screenDimension = toolkit.getScreenSize();
        int width = (5 * screenDimension.width) / 7;
        int height = (5 * screenDimension.height) / 7;
        setSize(width, height);
        setLocationRelativeTo(parent);
    }

    private static final long serialVersionUID = 1L;
}
