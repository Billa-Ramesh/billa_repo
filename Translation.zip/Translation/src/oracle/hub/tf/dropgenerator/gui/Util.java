// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Util.java

package oracle.hub.tf.dropgenerator.gui;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

public class Util
{

    public Util()
    {
    }

    public static String getExtension(File f)
    {
        return getExtension(f.getName());
    }

    public static String getExtension(String s)
    {
        String ext = "";
        int i = s.lastIndexOf('.');
        if(i >= 0)
            ext = s.substring(i + 1);
        return ext.toLowerCase();
    }

    public static String stripExtension(File f)
    {
        return stripExtension(f.getName());
    }

    public static String stripExtension(String str)
    {
        if(str == null)
            return null;
        int pos = str.lastIndexOf(".");
        if(pos == -1)
            return str;
        else
            return str.substring(0, pos);
    }

    public static List getPathComponents(File path)
    {
        ArrayList components = new ArrayList();
        components.add(path.getName());
        while((path = path.getParentFile()) != null) 
            components.add(path.getName());
        Collections.reverse(components);
        return components;
    }

    public static String[] getResourceListing(String path)
    {
        Class clazz = oracle/hub/tf/dropgenerator/gui/Util;
        URL dirURL = clazz.getResource(path);
        if(dirURL != null && dirURL.getProtocol().equals("file"))
            try
            {
                return (new File(dirURL.toURI())).list();
            }
            catch(URISyntaxException e)
            {
                DropGenerator.logger.log(Level.SEVERE, "Could not convert given path [{0}] to URI: {1}", new Object[] {
                    path, e.getMessage()
                });
            }
        if(dirURL == null)
        {
            String me = (new StringBuilder()).append(clazz.getName().replace(".", "/")).append(".class").toString();
            dirURL = clazz.getClassLoader().getResource(me);
        }
        if(dirURL.getProtocol().equals("jar"))
        {
            String jarPath = dirURL.getPath().substring(5, dirURL.getPath().indexOf("!"));
            JarFile jar = null;
            try
            {
                jar = new JarFile(URLDecoder.decode(jarPath, "UTF-8"));
            }
            catch(UnsupportedEncodingException e)
            {
                DropGenerator.logger.log(Level.SEVERE, "Unsupported encoding {0}", e.getMessage());
            }
            catch(IOException e)
            {
                DropGenerator.logger.log(Level.SEVERE, "Could not list the contents of JAR folder {0}{1}", new Object[] {
                    path, e.getMessage()
                });
            }
            Enumeration entries = jar.entries();
            Set result = new HashSet();
            do
            {
                if(!entries.hasMoreElements())
                    break;
                String name = ((JarEntry)entries.nextElement()).getName();
                if(name.startsWith(path))
                {
                    String entry = name.substring(path.length());
                    int checkSubdir = entry.indexOf("/");
                    if(checkSubdir >= 0)
                        entry = entry.substring(0, checkSubdir);
                    result.add(entry);
                }
            } while(true);
            return (String[])result.toArray(new String[result.size()]);
        } else
        {
            throw new UnsupportedOperationException((new StringBuilder()).append("Cannot list files for URL ").append(dirURL).toString());
        }
    }

    public static String replacePathComponents(String s, String match, String replacement)
    {
        File f = new File(s);
        List components = getPathComponents(f);
        if(components.isEmpty())
            return "";
        int index;
        while((index = components.indexOf(match)) != -1) 
            components.set(index, replacement);
        return oracle.hub.tf.dropgenerator.core.Util.join(components, '/');
    }

    public static final Pattern vobAllowed = Pattern.compile("[\\p{Digit}\\p{Lower}_\\.]+");
    public static final Pattern numericAllowed = Pattern.compile("[\\p{Digit}]+");
    public static final Pattern vobDisallowed = Pattern.compile("[^\\p{Digit}\\p{Lower}_\\.]");
    public static final Pattern outputFileDisallowed = Pattern.compile("[*|\"<>?:\\\\]");
    public static final String removeMessage = "Error removed";

}
