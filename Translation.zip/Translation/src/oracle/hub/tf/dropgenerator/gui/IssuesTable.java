// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IssuesTable.java

package oracle.hub.tf.dropgenerator.gui;

import au.com.bytecode.opencsv.CSVWriter;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import oracle.hub.tf.dropgenerator.core.*;
import org.bushe.swing.event.annotation.AnnotationProcessor;
import org.netbeans.swing.outline.*;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            IssuesTreeModel, IssuesRowModel, MyImageIcon, DropGeneratorWindow, 
//            FilesTable, LogTable

public class IssuesTable extends Outline
{
    private class RenderData
        implements RenderDataProvider
    {

        public Color getBackground(Object o)
        {
            return null;
        }

        public String getDisplayName(Object o)
        {
            if(o instanceof DefaultMutableTreeNode)
            {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)o;
                if(node.getUserObject() instanceof Level)
                {
                    Level level = (Level)node.getUserObject();
                    String name = (new StringBuilder()).append("Warnings (").append(node.getChildCount()).append(")").toString();
                    if(level == Level.SEVERE)
                        name = (new StringBuilder()).append("Errors (").append(node.getChildCount()).append(")").toString();
                    return name;
                }
            }
            return null;
        }

        public Color getForeground(Object o)
        {
            return Color.black;
        }

        public Icon getIcon(Object o)
        {
            if(o instanceof DefaultMutableTreeNode)
            {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)o;
                if(node.getUserObject() instanceof Level)
                {
                    Level level = (Level)node.getUserObject();
                    if(level == Level.WARNING)
                        return LogTable.warningIcon;
                    else
                        return LogTable.errorIcon;
                }
            }
            return null;
        }

        public String getTooltipText(Object o)
        {
            if(!(o instanceof DefaultMutableTreeNode))
                return null;
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)o;
            if(node.getUserObject() instanceof BomEntryError)
                return ((BomEntryError)node.getUserObject()).getEntry().getSourceRelative();
            else
                return null;
        }

        public boolean isHtmlDisplayName(Object o)
        {
            return false;
        }

        final IssuesTable this$0;

        private RenderData()
        {
            this$0 = IssuesTable.this;
            super();
        }

    }

    static class WrapCellRenderer extends DefaultTableCellRenderer
    {

        public Component getTableCellRendererComponent(JTable table, Object obj, boolean isSelected, boolean hasFocus, int row, int column)
        {
            String msg = (String)obj;
            JPanel container = new JPanel();
            BoxLayout layout = new BoxLayout(container, 0);
            container.setLayout(layout);
            JTextArea error = new JTextArea(msg);
            error.setOpaque(true);
            error.setLineWrap(true);
            error.setWrapStyleWord(true);
            error.setFont((new JLabel()).getFont());
            TableColumn col = table.getColumnModel().getColumn(column);
            error.setSize(col.getWidth(), 0xf423f);
            error.setBorder(BorderFactory.createEmptyBorder(4, 5, 5, 5));
            if(error.getText().length() > 0 && error.getPreferredSize().height != table.getRowHeight(row))
                table.setRowHeight(row, error.getPreferredSize().height);
            error.setBackground(isSelected ? new Color(0xb8cfe5) : table.getBackground());
            return error;
        }

        private static final long serialVersionUID = 1L;

        WrapCellRenderer()
        {
        }
    }

    private class CustomOutlineCellRenderer extends DefaultOutlineCellRenderer
    {

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            DefaultTableCellRenderer c = (DefaultOutlineCellRenderer)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if(value instanceof DefaultMutableTreeNode)
            {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)value;
                if(node.getUserObject() instanceof BomEntryError)
                {
                    BomEntryError error = (BomEntryError)node.getUserObject();
                    JLabel label = new JLabel((new StringBuilder()).append("<html><u>").append(error.getEntry().getName()).append("</u></html>").toString());
                    label.setForeground(Color.blue);
                    label.setOpaque(true);
                    label.setBackground(isSelected ? new Color(0xb8cfe5) : table.getBackground());
                    label.setBorder(BorderFactory.createEmptyBorder(0, c.getInsets().left - 5, 0, 0));
                    label.setIcon(error.getLevel() != Level.WARNING ? IssuesTable.itemErrorIcon : IssuesTable.itemWarningIcon);
                    return label;
                }
            }
            c.setForeground(Color.black);
            return c;
        }

        private static final long serialVersionUID = 1L;
        final IssuesTable this$0;

        private CustomOutlineCellRenderer()
        {
            this$0 = IssuesTable.this;
            super();
        }

    }

    private class FileShortcutListener extends MouseAdapter
    {

        public void mousePressed(MouseEvent me)
        {
            isPopupTrigger = me.isPopupTrigger();
        }

        public void mouseClicked(MouseEvent mouseevent)
        {
        }

        public void mouseReleased(MouseEvent me)
        {
            performAction(me);
        }

        private void performAction(MouseEvent me)
        {
            if(isPopupTrigger || me.isPopupTrigger())
            {
                int row = rowAtPoint(me.getPoint());
                if(getSelectedRow() != row)
                    setRowSelectionInterval(row, row);
                popupMenu.show(IssuesTable.this, me.getX(), me.getY());
            } else
            {
                int col = columnAtPoint(me.getPoint());
                if(col != 0 || !getCursor().equals(Cursor.getPredefinedCursor(12)))
                    return;
                int row = rowAtPoint(me.getPoint());
                Object o = getValueAt(row, 0);
                if(!(o instanceof DefaultMutableTreeNode))
                    return;
                Object node = ((DefaultMutableTreeNode)o).getUserObject();
                if(node instanceof BomEntryError)
                {
                    BomEntryError error = (BomEntryError)node;
                    path = null;
                    visitAllNodes((DefaultMutableTreeNode)directoryTree.getModel().getRoot(), (new File(error.getEntry().getUri())).getParentFile());
                    directoryTree.setSelectionPath(path);
                    filesTable.scrollToEntry(error.getEntry(), error);
                }
            }
            me.consume();
        }

        public void visitAllNodes(DefaultMutableTreeNode node, File searchElement)
        {
            if(node.getUserObject().equals(searchElement))
                path = new TreePath(node.getPath());
            if(node.getChildCount() >= 0)
            {
                DefaultMutableTreeNode n;
                for(Enumeration e = node.children(); e.hasMoreElements() && path == null; visitAllNodes(n, searchElement))
                    n = (DefaultMutableTreeNode)e.nextElement();

            }
        }

        private TreePath path;
        private boolean isPopupTrigger;
        final IssuesTable this$0;

        private FileShortcutListener()
        {
            this$0 = IssuesTable.this;
            super();
        }

    }


    public IssuesTable(FilesTable ft, JTree directoryTree)
    {
        filesTable = ft;
        this.directoryTree = directoryTree;
        AnnotationProcessor.process(treeModel);
        org.netbeans.swing.outline.OutlineModel outlineModel = DefaultOutlineModel.createOutlineModel(treeModel, new IssuesRowModel(), false, "File");
        setRootVisible(false);
        setModel(outlineModel);
        setSelectionMode(0);
        setRenderDataProvider(new RenderData());
        setGridColor(new Color(0xebe8da));
        selectionBackground = new Color(0xb8cfe5);
        setDefaultRenderer(java/lang/Object, new CustomOutlineCellRenderer());
        getColumnModel().getColumn(IssuesRowModel.Column.DETAIL.ordinal() + 1).setCellRenderer(new WrapCellRenderer());
        addMouseListener(new FileShortcutListener());
        JMenuItem copyError = new JMenuItem("Copy error");
        copyError.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                int row = getSelectedRow();
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)getValueAt(row, 0);
                if(node.getUserObject() instanceof BomEntryError)
                {
                    BomEntryError error = (BomEntryError)node.getUserObject();
                    StringSelection ss = new StringSelection((new StringBuilder()).append(error.getEntry().getSourceRelative()).append(",").append(error.getErrorType()).append(",").append(error.getMessage()).toString());
                    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
                }
            }

            final IssuesTable this$0;

            
            {
                this$0 = IssuesTable.this;
                super();
            }
        }
);
        JMenuItem saveErrors = new JMenuItem("Export all issues to CSV");
        saveErrors.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                exportIssues();
            }

            final IssuesTable this$0;

            
            {
                this$0 = IssuesTable.this;
                super();
            }
        }
);
        popupMenu.add(copyError);
        popupMenu.add(saveErrors);
    }

    private void exportIssues()
    {
        TreeSet issues = new TreeSet(treeModel.getInsertedNodes());
        if(issues.isEmpty())
        {
            JOptionPane.showMessageDialog(DropGeneratorWindow.getWindows()[0], "No issues to export!");
            return;
        }
        String fileLocation = (new StringBuilder()).append(DropGenerator.getImportDir()).append(File.separator).append("issues.csv").toString();
        BufferedWriter writer;
        try
        {
            writer = new BufferedWriter(new FileWriter(fileLocation));
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not create issue log file at given location ({0}). Is the file already open? Operation aborted", fileLocation);
            JOptionPane.showMessageDialog(DropGeneratorWindow.getWindows()[0], (new StringBuilder()).append("Could not create issue log file at given location (").append(fileLocation).append("). Is the file already open? Operation aborted").toString());
            return;
        }
        CSVWriter csvWriter = new CSVWriter(writer);
        csvWriter.writeNext(new String[] {
            "Severity", "File", "Issue type", "Issue details"
        });
        ArrayList csvData = new ArrayList();
        for(Iterator i$ = issues.iterator(); i$.hasNext(); csvWriter.writeNext((String[])csvData.toArray(new String[csvData.size()])))
        {
            BomEntryError issue = (BomEntryError)i$.next();
            csvData.clear();
            csvData.add(issue.getLevel().toString());
            csvData.add(issue.getEntry().getSourceRelative());
            csvData.add(issue.getErrorType().toString());
            csvData.add(issue.getMessage());
        }

        try
        {
            writer.close();
        }
        catch(IOException e) { }
        JOptionPane.showMessageDialog(DropGeneratorWindow.getWindows()[0], (new StringBuilder()).append("Issue log successfully saved to: ").append(fileLocation).toString());
        DropGenerator.logger.log(Level.INFO, "Issue log saved in: {0}", fileLocation);
    }

    public void selectEntry(BomEntry e)
    {
        TreePath path = new TreePath(treeModel.getPathTo(e));
        expandPath(path);
        int visibleRows = getModel().getRowCount();
        for(int row = 0; row < visibleRows; row++)
        {
            Object userObject = ((DefaultMutableTreeNode)(DefaultMutableTreeNode)getModel().getValueAt(row, 0)).getUserObject();
            if(!(userObject instanceof BomEntryError))
                continue;
            BomEntryError error = (BomEntryError)userObject;
            if(!error.getEntry().equals(e))
                continue;
            setRowSelectionInterval(row, row);
            Rectangle target = getCellRect(row, 0, true);
            Rectangle visible = getVisibleRect();
            if(target.y > visible.y)
                target.y += visible.height / 2;
            else
                target.y -= visible.height / 2;
            scrollRectToVisible(target);
            break;
        }

    }

    protected void processMouseMotionEvent(MouseEvent e)
    {
        int col = columnAtPoint(e.getPoint());
        if(col == 0)
        {
            int row = rowAtPoint(e.getPoint());
            if(!(getValueAt(row, col) instanceof DefaultMutableTreeNode))
            {
                setCursor(Cursor.getDefaultCursor());
                return;
            }
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)getValueAt(row, col);
            if(!(node.getUserObject() instanceof BomEntryError))
            {
                setCursor(Cursor.getDefaultCursor());
                return;
            }
            BomEntryError error = (BomEntryError)node.getUserObject();
            Rectangle rec = getCellRect(row, col, false);
            Component comp = getComponentAt(e.getPoint());
            int x = rec.x + 30;
            int width = x + itemWarningIcon.getIconWidth() + comp.getFontMetrics(comp.getFont()).stringWidth(error.getEntry().getName());
            if(e.getPoint().x > x && e.getPoint().x < width)
                setCursor(Cursor.getPredefinedCursor(12));
            else
                setCursor(Cursor.getDefaultCursor());
        } else
        {
            setCursor(Cursor.getDefaultCursor());
        }
        super.processMouseMotionEvent(e);
    }

    public void clear()
    {
        clearSelection();
        treeModel.clear();
    }

    private static final long serialVersionUID = 1L;
    public static final Icon itemWarningIcon = new MyImageIcon(oracle/hub/tf/dropgenerator/gui/IssuesTable.getResource("issues-warning.gif"));
    public static final Icon itemErrorIcon = new MyImageIcon(oracle/hub/tf/dropgenerator/gui/IssuesTable.getResource("issues-error.gif"));
    private final IssuesTreeModel treeModel = new IssuesTreeModel(new DefaultMutableTreeNode());
    private final FilesTable filesTable;
    private final JTree directoryTree;
    private final JPopupMenu popupMenu = new JPopupMenu();





}
