// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JButtonGroup.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.*;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;

public class JButtonGroup extends ButtonGroup
{

    public JButtonGroup()
    {
    }

    public AbstractButton getSelected()
    {
        for(Enumeration e = getElements(); e.hasMoreElements();)
        {
            AbstractButton b = (AbstractButton)e.nextElement();
            if(b.getModel() == getSelection())
                return b;
        }

        return null;
    }

    public List getButtons()
    {
        List myButtons = new ArrayList();
        for(Enumeration e = getElements(); e.hasMoreElements(); myButtons.add(e.nextElement()));
        return Collections.unmodifiableList(myButtons);
    }

    private static final long serialVersionUID = 1L;
}
