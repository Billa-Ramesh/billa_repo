// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DirectoryChooserDialog.java

package oracle.hub.tf.dropgenerator.gui;

import directorychooser.JDirectoryChooser;
import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

public class DirectoryChooserDialog extends JDialog
    implements KeyListener, ContainerListener
{

    public DirectoryChooserDialog(Window parent, String title, File dir)
    {
        super(parent, title, java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        action = 2;
        txtCurrentPath = new JTextField(20);
        cancelButton = new JButton("Cancel");
        okButton = new JButton("OK");
        if(dir != null && dir.isDirectory())
        {
            directoryChooser = new JDirectoryChooser(dir);
            directoryChooser.setSelectedFile(dir);
            txtCurrentPath.setText(dir.getAbsolutePath());
            okButton.setEnabled(true);
        } else
        {
            directoryChooser = new JDirectoryChooser();
            okButton.setEnabled(false);
        }
        directoryChooser.setControlButtonsAreShown(false);
        setDefaultCloseOperation(1);
        innerPanel = new JPanel(new BorderLayout());
        JPanel dirChooserPanel = new JPanel();
        dirChooserPanel.setLayout(new BoxLayout(dirChooserPanel, 1));
        dirChooserPanel.add(directoryChooser);
        JPanel pathPanel = new JPanel();
        pathPanel.setLayout(new BoxLayout(pathPanel, 0));
        pathPanel.add(new JLabel("Path:"));
        pathPanel.add(Box.createHorizontalStrut(4));
        pathPanel.add(txtCurrentPath);
        pathPanel.setBorder(BorderFactory.createEmptyBorder(5, 7, 5, 5));
        dirChooserPanel.add(pathPanel);
        innerPanel.add(dirChooserPanel, "Center");
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, 0));
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(okButton);
        buttonPanel.add(Box.createHorizontalStrut(4));
        buttonPanel.add(cancelButton);
        buttonPanel.add(Box.createHorizontalStrut(4));
        JComponent contentPane = (JComponent)getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(innerPanel, "Center");
        contentPane.add(buttonPanel, "South");
        contentPane.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
        pack();
        cancelButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                cancelAction();
            }

            final DirectoryChooserDialog this$0;

            
            {
                this$0 = DirectoryChooserDialog.this;
                super();
            }
        }
);
        okButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                OKAction();
            }

            final DirectoryChooserDialog this$0;

            
            {
                this$0 = DirectoryChooserDialog.this;
                super();
            }
        }
);
        directoryChooser.addPropertyChangeListener(new PropertyChangeListener() {

            public void propertyChange(PropertyChangeEvent event)
            {
                String property = event.getPropertyName();
                if(property.equals("SelectedFileChangedProperty"))
                {
                    File file = (File)event.getNewValue();
                    if(file != null && !file.getName().startsWith("::{"))
                        txtCurrentPath.setText(file.getAbsolutePath());
                    else
                        txtCurrentPath.setText("");
                }
            }

            final DirectoryChooserDialog this$0;

            
            {
                this$0 = DirectoryChooserDialog.this;
                super();
            }
        }
);
        txtCurrentPath.getDocument().addDocumentListener(new DocumentListener() {

            public void changedUpdate(DocumentEvent e)
            {
                check();
            }

            public void insertUpdate(DocumentEvent e)
            {
                check();
            }

            public void removeUpdate(DocumentEvent e)
            {
                check();
            }

            private void check()
            {
                txtCurrentPath.setBackground(isValidDir() ? Color.WHITE : Color.PINK);
                okButton.setEnabled(isValidDir());
            }

            final DirectoryChooserDialog this$0;

            
            {
                this$0 = DirectoryChooserDialog.this;
                super();
            }
        }
);
        addKeyAndContainerListenerRecursively(this);
    }

    public boolean isValidDir()
    {
        return getSelectedDir().isDirectory() && (new File(txtCurrentPath.getText())).isDirectory();
    }

    public File getSelectedDir()
    {
        return new File(txtCurrentPath.getText());
    }

    public void OKEnabled(boolean enabled)
    {
        okButton.setEnabled(enabled);
    }

    private void addKeyAndContainerListenerRecursively(Component c)
    {
        c.removeKeyListener(this);
        c.addKeyListener(this);
        if(c instanceof Container)
        {
            Container cont = (Container)c;
            cont.removeContainerListener(this);
            cont.addContainerListener(this);
            Component children[] = cont.getComponents();
            for(int i = 0; i < children.length; i++)
                addKeyAndContainerListenerRecursively(children[i]);

        }
    }

    private void removeKeyAndContainerListenerRecursively(Component c)
    {
        c.removeKeyListener(this);
        if(c instanceof Container)
        {
            Container cont = (Container)c;
            cont.removeContainerListener(this);
            Component children[] = cont.getComponents();
            for(int i = 0; i < children.length; i++)
                removeKeyAndContainerListenerRecursively(children[i]);

        }
    }

    public int getAction()
    {
        return action;
    }

    protected void OKAction()
    {
        action = 0;
        setVisible(false);
    }

    private void cancelAction()
    {
        action = 2;
        setVisible(false);
    }

    public void setVisible(boolean visible)
    {
        if(visible)
        {
            action = 2;
            setLocationRelativeTo(getParent());
        }
        super.setVisible(visible);
    }

    public void keyPressed(KeyEvent e)
    {
        int code = e.getKeyCode();
        if(code == 27)
            cancelAction();
        else
        if(code == 10)
            OKAction();
    }

    public void keyReleased(KeyEvent keyevent)
    {
    }

    public void keyTyped(KeyEvent keyevent)
    {
    }

    public void componentAdded(ContainerEvent e)
    {
        addKeyAndContainerListenerRecursively(e.getChild());
    }

    public void componentRemoved(ContainerEvent e)
    {
        removeKeyAndContainerListenerRecursively(e.getChild());
    }

    private static final long serialVersionUID = 1L;
    protected int action;
    protected JDirectoryChooser directoryChooser;
    protected JPanel innerPanel;
    private JTextField txtCurrentPath;
    private JButton cancelButton;
    private JButton okButton;



}
