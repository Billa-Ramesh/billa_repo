// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DirectoryChooserDialog.java

package oracle.hub.tf.dropgenerator.gui;

import directorychooser.JDirectoryChooser;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import net.miginfocom.swing.MigLayout;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            DirectoryChooserDialog, JButtonGroup

class OpenDialog extends DirectoryChooserDialog
{

    public OpenDialog(java.awt.Window parent, String title, File dir)
    {
        super(parent, title, dir);
        dropTypeButtons = new JButtonGroup();
        directoryChooser.addPropertyChangeListener(new PropertyChangeListener() {

            public void propertyChange(PropertyChangeEvent event)
            {
                String property = event.getPropertyName();
                if(property.equals("SelectedFileChangedProperty"))
                {
                    dropTypeButtons.clearSelection();
                    File currentDir = (File)event.getNewValue();
                    if(currentDir == null || !currentDir.isDirectory())
                        return;
                    boolean uiBom = (new File((new StringBuilder()).append(currentDir.getAbsolutePath()).append(File.separator).append(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UI).append(".bom").toString())).exists();
                    boolean uaBom = (new File((new StringBuilder()).append(currentDir.getAbsolutePath()).append(File.separator).append(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UA).append(".bom").toString())).exists();
                    if(uiBom && !uaBom)
                        setDropType(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UI);
                    else
                    if(!uiBom && uaBom)
                        setDropType(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UA);
                }
            }

           
        }
);
        JRadioButton dropTypeUI = new JRadioButton(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UI.name);
        JRadioButton dropTypeUA = new JRadioButton(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UA.name);
        dropTypeButtons.add(dropTypeUI);
        dropTypeButtons.add(dropTypeUA);
        JPanel panel = new JPanel();
        panel.setLayout(new MigLayout());
        JLabel typeLabel = new JLabel("Drop type:", 4);
        panel.add(typeLabel, "cell 0 0");
        panel.add(dropTypeUI, "cell 1 0");
        panel.add(dropTypeUA, "cell 1 1");
        innerPanel.add(panel, "South");
        pack();
    }

    protected void OKAction()
    {
        String errorMessage = "The following problems have been detected:\n";
        boolean error = false;
        if(dropTypeButtons.getSelected() == null)
        {
            error = true;
            errorMessage = (new StringBuilder()).append(errorMessage).append("* You have to pick the drop type.\n").toString();
        }
        if(error)
        {
            JOptionPane.showMessageDialog(this, errorMessage);
            return;
        } else
        {
            action = 0;
            setVisible(false);
            return;
        }
    }

    public void setDropType(oracle.hub.tf.dropgenerator.core.DropGenerator.DropType type)
    {
        Iterator i$ = dropTypeButtons.getButtons().iterator();
        do
        {
            if(!i$.hasNext())
                break;
            AbstractButton b = (AbstractButton)i$.next();
            if(!b.getText().equals(type.name))
                continue;
            b.setSelected(true);
            break;
        } while(true);
    }

    public oracle.hub.tf.dropgenerator.core.DropGenerator.DropType getDropType()
    {
        return oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.valueFor(dropTypeButtons.getSelected().getText());
    }

    private JButtonGroup dropTypeButtons;
    private static final long serialVersionUID = 1L;

}
