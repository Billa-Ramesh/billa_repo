// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LogTable.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.table.AbstractTableModel;

class LogTableModel extends AbstractTableModel
{

    LogTableModel()
    {
        values = new ArrayList();
    }

    public void addRow(JLabel l)
    {
        values.add(l);
        fireTableRowsInserted(values.size(), values.size());
    }

    public void clear()
    {
        int listsize = values.size();
        values.clear();
        fireTableRowsDeleted(0, listsize);
    }

    public int getColumnCount()
    {
        return 1;
    }

    public int getRowCount()
    {
        return values.size();
    }

    public Object getValueAt(int row, int column)
    {
        return values.get(row);
    }

    private static final long serialVersionUID = 1L;
    private ArrayList values;
}
