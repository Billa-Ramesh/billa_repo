// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DropGeneratorWindow.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.Insets;
import javax.swing.*;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            LogTable

public class ToolBarButton extends JButton
{

    public ToolBarButton(Icon icon)
    {
        super(icon);
        setMargin(margins);
        setVerticalTextPosition(3);
        setHorizontalTextPosition(0);
    }

    public ToolBarButton(String icon, String text)
    {
        this(((Icon) (new ImageIcon((icon)))));
        setText(text);
    }

    public ToolBarButton(String icon) {
    	 this(((Icon) (new ImageIcon((icon)))));
         //setText(text);
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = 1L;
    private static final Insets margins = new Insets(3, 3, 3, 3);

}
