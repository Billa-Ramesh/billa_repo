// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockComboBox.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.*;
import javax.swing.*;

abstract class BlockComboBoxRendererAbstract
    implements ListCellRenderer
{

    public BlockComboBoxRendererAbstract(ListCellRenderer delegate)
    {
        separatorPanel = new JPanel(new BorderLayout());
        separator = new JSeparator(0);
        _flddelegate = delegate;
        separator.setBackground(Color.red);
        separator.setForeground(Color.red);
    }

    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
        Component comp = _flddelegate.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if(index != -1 && addSeparatorAfter(list, value, index))
        {
            separatorPanel.removeAll();
            separatorPanel.add(comp, "Center");
            separatorPanel.add(separator, "South");
            return separatorPanel;
        } else
        {
            return comp;
        }
    }

    protected abstract boolean addSeparatorAfter(JList jlist, Object obj, int i);

    private ListCellRenderer _flddelegate;
    private JPanel separatorPanel;
    private JSeparator separator;
}
