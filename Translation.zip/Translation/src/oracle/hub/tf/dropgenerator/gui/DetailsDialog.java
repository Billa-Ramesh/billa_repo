// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DetailsDialog.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.text.*;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.StyleSheet;
import net.miginfocom.swing.MigLayout;
import oracle.hub.tf.dropgenerator.core.*;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            FileTypeComboBoxListener, DropGeneratorWindow, FilesTable, FilesTableModel, 
//            Util

public class DetailsDialog extends JDialog
    implements TableModelListener
{
    class TokenDocument extends HTMLDocument
    {
        private class OutputFileDocumentFilter extends DocumentFilter
        {

            public void insertString(javax.swing.text.DocumentFilter.FilterBypass fb, int offset, String string, AttributeSet attr)
                throws BadLocationException
            {
                if(string == null)
                    return;
                if(isValid(string))
                    super.insertString(fb, offset, string, attr);
            }

            public void replace(javax.swing.text.DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException
            {
                if(text == null)
                    return;
                if(isValid(text))
                    super.replace(fb, offset, length, text, attrs);
            }

            private boolean isValid(String str)
            {
                return !Util.outputFileDisallowed.matcher(str).find() && !str.contains("\n") && !str.contains("\t");
            }

            final TokenDocument this$1;

            private OutputFileDocumentFilter()
            {
                this$1 = TokenDocument.this;
                super();
            }

        }


        protected void insertUpdate(javax.swing.text.AbstractDocument.DefaultDocumentEvent chng, AttributeSet attr)
        {
            super.insertUpdate(chng, attr);
            try
            {
                updateTableAndBom(getText(0, getLength()));
            }
            catch(BadLocationException e) { }
            markTokens();
        }

        protected void postRemoveUpdate(javax.swing.text.AbstractDocument.DefaultDocumentEvent chng)
        {
            super.postRemoveUpdate(chng);
            try
            {
                updateTableAndBom(getText(0, getLength()));
            }
            catch(BadLocationException e) { }
            markTokens();
        }

        private void updateTableAndBom(String text)
        {
            DetailsDialog.currentEntry.setTarget(text);
            DetailsDialog.example.setText(DetailsDialog.currentEntry.getTarget().toStringReplaced());
            DetailsDialog.ft.setOutputFile(text);
        }

        private void markTokens()
        {
            int docLength = getLength();
            setCharacterAttributes(0, docLength, getStyle("body"), true);
            Matcher regexMatcher = null;
            try
            {
                regexMatcher = TargetFile.tokenPattern.matcher(getText(0, docLength));
            }
            catch(BadLocationException e) { }
            do
            {
                if(!regexMatcher.find())
                    break;
                String token = regexMatcher.group();
                if(token.length() != 2 || token.charAt(1) != '%')
                {
                    int start = regexMatcher.start();
                    int end = regexMatcher.end();
                    if(end >= start)
                        setCharacterAttributes(start, end - start, tokenStyle, true);
                }
            } while(true);
        }

        private static final long serialVersionUID = 1L;
        private final Style tokenStyle = addStyle("Red", getStyle("body"));
        final DetailsDialog this$0;

        public TokenDocument(String bodyStyle)
        {
            this$0 = DetailsDialog.this;
            super();
            getStyleSheet().addRule(bodyStyle);
            StyleConstants.setForeground(tokenStyle, Color.red);
            StyleConstants.setBold(tokenStyle, true);
            setDocumentFilter(new OutputFileDocumentFilter());
        }
    }


    private DetailsDialog()
    {
        super(DropGeneratorWindow.getWindows()[0], "File details", java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        tokens.setDocument(new TokenDocument(bodyRule));
    }

    public static void showEntry(FilesTable filesTable)
    {
        if(me == null)
        {
            me = new DetailsDialog();
            me.getContentPane().add(panel);
            ft = filesTable;
            ft.getModel().addTableModelListener(me);
            TreeSet allTypes = new TreeSet();
            allTypes.add(AbstractFileType.EMPTY_FILETYPE);
            oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dt = ft.getModel().getBom().getDropType();
            allTypes.addAll(FileTypes.getTypesAll(dt));
            AbstractFileType type;
            for(Iterator i$ = allTypes.iterator(); i$.hasNext(); filetype.addItem(type))
                type = (AbstractFileType)i$.next();

        }
        me.pack();
        loadEntry();
        me.setLocationRelativeTo(me.getParent());
        me.setVisible(true);
    }

    private static void loadNextEntry()
    {
        int currentRow = ft.getSelectedRow();
        int nextRow = currentRow + 1;
        if(currentRow >= 0 && nextRow < ft.getRowCount())
        {
            ft.setRowSelectionInterval(nextRow, nextRow);
            loadEntry();
        }
    }

    private static void loadPreviousEntry()
    {
        int currentRow = ft.getSelectedRow();
        int prevRow = currentRow - 1;
        if(currentRow >= 0 && prevRow >= 0)
        {
            ft.setRowSelectionInterval(prevRow, prevRow);
            loadEntry();
        }
    }

    private static void loadEntry()
    {
        int row = ft.getSelectedRow();
        currentEntry = ft.getModel().getEntry(ft.convertRowIndexToModel(row));
        src.setText(currentEntry.getSourceRelative());
        loadIncluded(row);
        ActionListener arr$[] = filetype.getActionListeners();
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            ActionListener l = arr$[i$];
            filetype.removeActionListener(l);
        }

        filetype.addActionListener(new FileTypeComboBoxListener(ft, currentEntry));
        filetype.setSelectedItem(currentEntry.getFileType());
        tokens.setText(currentEntry.getTarget().toStringPretty());
        example.setText(currentEntry.getTarget().toStringReplaced());
        me.setSize(new Dimension(me.getSize().width, me.getPreferredSize().height));
    }

    private static void loadIncluded(int row)
    {
        included.setEnabled(ft.getModel().isCellEditable(ft.convertRowIndexToModel(row), FilesTableModel.Column.INCLUDED.ordinal()));
        included.setSelected(((Boolean)ft.getModel().getValueAt(ft.convertRowIndexToModel(row), FilesTableModel.Column.INCLUDED.ordinal())).booleanValue());
    }

    public static void addSeparator(Container panel, String text)
    {
        JLabel l = new JLabel(text, 10);
        l.setForeground(LABEL_COLOR);
        panel.add(l, "gapbottom 1, span, split 2, aligny center");
        panel.add(new JSeparator(), "gapleft rel, growx");
    }

    public void tableChanged(TableModelEvent e)
    {
        loadIncluded(e.getFirstRow());
    }

    private static final long serialVersionUID = 1L;
    static final Color LABEL_COLOR = new Color(0, 70, 213);
    private static final Font font;
    private static final String bodyRule;
    private static DetailsDialog me;
    private static final JPanel panel;
    private static final JTextArea src;
    private static final JCheckBox included;
    private static final JComboBox filetype;
    private static final JTextPane tokens;
    private static final JTextPane example;
    private static FilesTable ft = null;
    private static BomEntry currentEntry;

    static 
    {
        font = UIManager.getFont("Label.font");
        bodyRule = (new StringBuilder()).append("body { font-family: ").append(font.getFamily()).append("; ").append("font-size: ").append(font.getSize()).append("pt; }").toString();
        MigLayout ml = new MigLayout("ins 10, wrap 3, fill", "[paragraph, shrink 0, grow 0]0[align right, pref!]8[200:400:]", "[]");
        panel = new JPanel(ml);
        addSeparator(panel, "General info");
        src = new JTextArea();
        src.setBorder(BorderFactory.createEmptyBorder());
        src.setLineWrap(true);
        src.setFont(font);
        src.setBackground(UIManager.getColor("Label.background"));
        src.setEditable(false);
        panel.add(new JLabel((new StringBuilder()).append(FilesTableModel.Column.SOURCEFILE.toString()).append(":").toString()), "skip, h 24:24:");
        panel.add(src, "growx, wmin 200, wrap");
        included = new JCheckBox();
        included.setBorder(BorderFactory.createEmptyBorder());
        included.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                if(!(e.getSource() instanceof JCheckBox))
                {
                    return;
                } else
                {
                    JCheckBox checkBox = (JCheckBox)e.getSource();
                    DetailsDialog.ft.updateIncluded(checkBox.isSelected());
                    return;
                }
            }

        }
);
        panel.add(new JLabel((new StringBuilder()).append(FilesTableModel.Column.INCLUDED.toString()).append(":").toString()), "skip, h 24:24:");
        panel.add(included, "wrap");
        filetype = new JComboBox();
        panel.add(new JLabel((new StringBuilder()).append(FilesTableModel.Column.FILETYPE.toString()).append(":").toString()), "skip, h 24:24:");
        panel.add(filetype, "wrap 15");
        addSeparator(panel, "Language token configuration");
        tokens = new JTextPane();
        tokens.setContentType("text/html");
        tokens.setBorder((new JTextField()).getBorder());
        panel.add(new JLabel((new StringBuilder()).append(FilesTableModel.Column.OUTPUTFILE.toString()).append(":").toString()), "skip, h 24:24:");
        panel.add(tokens, "growx, wmin 200");
        example = new JTextPane();
        example.setEditable(false);
        example.setContentType("text/html");
        ((HTMLDocument)example.getDocument()).getStyleSheet().addRule(bodyRule);
        example.setBorder((new JTextField()).getBorder());
        panel.add(new JLabel((new StringBuilder()).append(FilesTableModel.Column.OUTPUTSAMPLE.toString()).append(":").toString()), "skip, h 24:24:");
        panel.add(example, "growx, wmin 200, wrap 15px");
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                DetailsDialog.me.setVisible(false);
            }

        }
);
        JButton prev = new JButton("Previous");
        prev.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                DetailsDialog.loadPreviousEntry();
            }

        }
);
        JButton next = new JButton("Next");
        next.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                DetailsDialog.loadNextEntry();
            }

        }
);
        panel.add(prev, "span 2, split");
        panel.add(next);
        panel.add(closeButton, "skip 1, align right, tag finish");
    }






}
