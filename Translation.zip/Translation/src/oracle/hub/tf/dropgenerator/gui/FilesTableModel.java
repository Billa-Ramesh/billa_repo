// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FilesTableModel.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.Collections;
import java.util.List;
import javax.swing.SwingWorker;
import javax.swing.table.AbstractTableModel;
import oracle.hub.tf.dropgenerator.core.*;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

public class FilesTableModel extends AbstractTableModel
{
    public static final class Column extends Enum
    {

        public static Column[] values()
        {
            return (Column[])$VALUES.clone();
        }

        public static Column valueOf(String name)
        {
            return (Column)Enum.valueOf(oracle/hub/tf/dropgenerator/gui/FilesTableModel$Column, name);
        }

        public String toString()
        {
            return displayName;
        }

        public static final Column INCLUDED;
        public static final Column FILETYPE;
        public static final Column SOURCEFILE;
        public static final Column OUTPUTFILE;
        public static final Column OUTPUTSAMPLE;
        private final String displayName;
        final boolean editable;
        final Class clazz;
        boolean visible;
        final String toolTip;
        private static final Column $VALUES[];

        static 
        {
            INCLUDED = new Column("INCLUDED", 0, "Included", true, java/lang/Boolean, false, "Determines if the file will be added to the generated kit");
            FILETYPE = new Column("FILETYPE", 1, "File Type", true, oracle/hub/tf/dropgenerator/core/filetype/AbstractFileType, false, "File's corresponding translation filetype");
            SOURCEFILE = new Column("SOURCEFILE", 2, "Source File", false, java/lang/String, false, "Source file within the currently opened location");
            OUTPUTFILE = new Column("OUTPUTFILE", 3, "Language tokens", true, java/lang/String, false, "Language replacement tokens to be used for build out translated files");
            OUTPUTSAMPLE = new Column("OUTPUTSAMPLE", 4, "Output example", false, java/lang/String, false, "Example of built out filename, after the language tokens have been replaced with German codes.");
            $VALUES = (new Column[] {
                INCLUDED, FILETYPE, SOURCEFILE, OUTPUTFILE, OUTPUTSAMPLE
            });
        }

        private Column(String s, int i, String display, boolean canEdit, Class c, boolean v, String tt)
        {
            super(s, i);
            displayName = display;
            editable = canEdit;
            clazz = c;
            visible = v;
            toolTip = tt;
        }
    }


    public FilesTableModel()
    {
    }

    public Class getColumnClass(int c)
    {
        return Column.values()[c].clazz;
    }

    public boolean isCellEditable(int rowIndex, int columnIndex)
    {
        if(rowIndex >= bom.size())
            return false;
        BomEntry b = bom.get(rowIndex);
        if(columnIndex == Column.INCLUDED.ordinal())
            return b.isValid();
        else
            return Column.values()[columnIndex].editable;
    }

    public int getColumnCount()
    {
        Column cols[] = Column.values();
        int visible = 0;
        Column arr$[] = cols;
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            Column c = arr$[i$];
            if(c.visible)
                visible++;
        }

        return visible;
    }

    public String getColumnName(int column)
    {
        return Column.values()[column].toString();
    }

    public int getRowCount()
    {
        return bom != null ? bom.size() : 0;
    }

    public Object getValueAt(int row, int column)
    {
        BomEntry b = getEntry(row);
        if(b == null)
            return "";
        if(Column.INCLUDED.ordinal() == column)
        {
            if(b.getFileType().getKey().equals("formreference"))
                return Boolean.valueOf(true);
            if(!isCellEditable(row, column))
                return Boolean.valueOf(false);
            else
                return Boolean.valueOf(b.isActive());
        }
        if(Column.SOURCEFILE.ordinal() == column)
            return b.getSourceRelative();
        if(Column.OUTPUTFILE.ordinal() == column)
            return b.getTarget();
        if(Column.FILETYPE.ordinal() == column)
            return b.getFileType();
        if(Column.OUTPUTSAMPLE.ordinal() == column)
            return b.getTarget().toStringReplaced();
        else
            return "";
    }

    public void setValueAt(Object aValue, int row, int column)
    {
        if(column == Column.INCLUDED.ordinal())
        {
            BomEntry entry = getEntry(row);
            entry.setActive(((Boolean)aValue).booleanValue());
            if(getBom().getDropType() == oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.UA && Util.isArchive(entry.getUri()))
                fireTableDataChanged();
        } else
        if(column == Column.OUTPUTFILE.ordinal())
        {
            String val = (String)aValue;
            if(val == null)
                val = "";
            getEntry(row).setTarget(val);
        }
        fireTableRowsUpdated(row, row);
        (new SwingWorker() {

            protected Void doInBackground()
                throws Exception
            {
                bom.write();
                return null;
            }

            protected volatile Object doInBackground()
                throws Exception
            {
                return doInBackground();
            }

            final FilesTableModel this$0;

            
            {
                this$0 = FilesTableModel.this;
                super();
            }
        }
).execute();
    }

    public void addRows(List indices)
    {
        Collections.sort(indices);
        int first = ((Integer)indices.get(0)).intValue();
        int last = ((Integer)indices.get(indices.size() - 1)).intValue();
        if(first <= last && last < bom.size())
            fireTableRowsInserted(first, last);
    }

    public BomEntry getEntry(int row)
    {
        return bom.get(row);
    }

    public void setBom(Bom b)
    {
        bom = b;
    }

    public Bom getBom()
    {
        return bom;
    }

    private static final long serialVersionUID = 1L;
    private Bom bom;

}
