// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ApplyDefaultSettingsDialog.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.ListDataListener;

public class ApplyDefaultSettingsDialog extends JPanel
{

    public ApplyDefaultSettingsDialog()
    {
        initComponents();
    }

    public void setCurrentSetting(String current)
    {
        lblCurrentSetting.setText(current);
    }

    private void initComponents()
    {
        jComboBox1 = new JComboBox();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        lblCurrentSetting = new JLabel();
        jComboBox1.setModel(defaultSettingsModel);
        jLabel1.setText("Predefined settings:");
        jLabel2.setText("Current setting:");
        lblCurrentSetting.setText("None");
        GroupLayout layout = new GroupLayout(this);
        setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING).addComponent(jLabel2).addComponent(jLabel1)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jComboBox1, 0, 143, 32767).addComponent(lblCurrentSetting)).addContainerGap()));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(jLabel1).addComponent(jComboBox1, -2, -1, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(jLabel2).addComponent(lblCurrentSetting)).addContainerGap(-1, 32767)));
    }

    protected static final ComboBoxModel defaultSettingsModel = new ComboBoxModel() {

        public void setSelectedItem(Object anItem)
        {
            selected = preconfigured.indexOf(anItem);
        }

        public Object getSelectedItem()
        {
            return preconfigured.get(selected);
        }

        public int getSize()
        {
            return preconfigured.size();
        }

        public Object getElementAt(int index)
        {
            return preconfigured.get(index);
        }

        public void addListDataListener(ListDataListener listdatalistener)
        {
        }

        public void removeListDataListener(ListDataListener listdatalistener)
        {
        }

        private final ArrayList preconfigured = new ArrayList() {

            final _cls1 this$0;

                    
                    {
                        this$0 = _cls1.this;
                        super();
                        add("");
                        add("Hyperion");
                    }
        }
;
        private int selected;

            
            {
                selected = 0;
            }
    }
;
    private JComboBox jComboBox1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel lblCurrentSetting;

}
