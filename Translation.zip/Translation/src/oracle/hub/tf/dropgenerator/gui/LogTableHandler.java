// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LogTable.java

package oracle.hub.tf.dropgenerator.gui;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.*;
import oracle.hub.tf.dropgenerator.core.BomEntryError;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            LogTable

class LogTableHandler extends Handler
{

    public LogTableHandler(LogTable log)
    {
        this.log = log;
        setFormatter(new SimpleFormatter());
    }

    public static String now()
    {
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        return dateFormat.format(date);
    }

    public void publish(LogRecord arg0)
    {
        if(arg0.getParameters() != null && (arg0.getParameters()[0] instanceof BomEntryError))
            return;
        String message = getFormatter().formatMessage(arg0);
        if(!message.startsWith("["))
            message = (new StringBuilder()).append("[").append(now()).append("] ").append(message).toString();
        if(arg0.getParameters() != null && (arg0.getParameters()[0] instanceof Boolean))
            log.addRow(arg0.getLevel(), message, ((Boolean)arg0.getParameters()[0]).booleanValue());
        else
            log.addRow(arg0.getLevel(), message, false);
    }

    public void close()
        throws SecurityException
    {
    }

    public void flush()
    {
    }

    private LogTable log;
}
