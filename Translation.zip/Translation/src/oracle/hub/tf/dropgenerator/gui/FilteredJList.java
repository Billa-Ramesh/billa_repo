// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FilteredJList.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

public final class FilteredJList extends JList
{
    class FilterField extends JTextField
        implements DocumentListener
    {

        public void changedUpdate(DocumentEvent e)
        {
            ((FilterModel)getModel()).refilter();
        }

        public void insertUpdate(DocumentEvent e)
        {
            ((FilterModel)getModel()).refilter();
        }

        public void removeUpdate(DocumentEvent e)
        {
            ((FilterModel)getModel()).refilter();
        }

        final FilteredJList this$0;

        public FilterField()
        {
            this$0 = FilteredJList.this;
            super();
            getDocument().addDocumentListener(this);
        }
    }

    private class FilterModel extends AbstractListModel
    {

        public Object getElementAt(int index)
        {
            if(index < filterItems.size())
                return filterItems.get(index);
            else
                return null;
        }

        public int getSize()
        {
            return filterItems.size();
        }

        public void addElement(Object o)
        {
            items.add(o);
            refilter();
        }

        public JTextField getFilterField()
        {
            return filterField;
        }

        private void refilter()
        {
            filterItems.clear();
            String term = getFilterField().getText();
            for(int i = 0; i < items.size(); i++)
                if(items.get(i).toString().toLowerCase().indexOf(term.toLowerCase(), 0) != -1)
                    filterItems.add(items.get(i));

            fireContentsChanged(this, 0, getSize());
        }

        ArrayList items;
        ArrayList filterItems;
        final FilteredJList this$0;


        public FilterModel()
        {
            this$0 = FilteredJList.this;
            super();
            items = new ArrayList();
            filterItems = new ArrayList();
        }

        public FilterModel(ArrayList items)
        {
            this();
            this.items = items;
            refilter();
        }
    }


    public FilteredJList(ArrayList items)
    {
        filterField = new FilterField();
        setModel(new FilterModel(items));
    }

    public void setModel(ListModel m)
    {
        if(!(m instanceof FilterModel))
        {
            throw new IllegalArgumentException();
        } else
        {
            super.setModel(m);
            return;
        }
    }

    public JTextField getFilterField()
    {
        return filterField;
    }

    public void addItem(Object o)
    {
        ((FilterModel)getModel()).addElement(o);
    }

    private FilterField filterField;

}
