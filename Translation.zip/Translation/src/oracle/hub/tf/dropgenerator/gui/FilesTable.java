// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FilesTable.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import net.miginfocom.swing.MigLayout;
import oracle.hub.tf.dropgenerator.core.Bom;
import oracle.hub.tf.dropgenerator.core.BomEntry;
import oracle.hub.tf.dropgenerator.core.BomEntryError;
import oracle.hub.tf.dropgenerator.core.DropGenerator;
import oracle.hub.tf.dropgenerator.core.FileTypes;
import oracle.hub.tf.dropgenerator.core.TargetFile;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            FilesTableModel, MyImageIcon, OutputFileDocument, BlockComboBox, 
//            FileTypeComboBoxListener, DropGeneratorWindow, IssuesTable, ToolBarToggleButton, 
//            Util, FilteredJList, DetailsDialog

public final class FilesTable extends JTable
    implements TableModelListener
{
    private class PickFileTypePanel extends JPanel
    {

        public AbstractFileType getSelectedType()
        {
            return (AbstractFileType)list.getSelectedValue();
        }

        private final FilteredJList list;
        final FilesTable this$0;

        PickFileTypePanel()
        {
            this$0 = FilesTable.this;
            super(new MigLayout("ins 5, wrap 2, fill", "[right][center]"));
            ArrayList possibilities = new ArrayList();
            possibilities.add(AbstractFileType.EMPTY_FILETYPE);
            possibilities.addAll(FileTypes.getTypesAll(getModel().getBom().getDropType()));
            list = new FilteredJList(possibilities);
            list.setSelectionMode(1);
            JScrollPane listScroller = new JScrollPane(list);
            listScroller.setPreferredSize(new Dimension(200, 150));
            add(new JLabel("Filter:"));
            add(list.getFilterField(), "grow, gapbottom 5");
            add(new JLabel("File type:"));
            add(listScroller);
        }
    }

    static class TypeCellRenderer extends DefaultTableCellRenderer
    {

        public Component getTableCellRendererComponent(JTable table, Object obj, boolean isSelected, boolean hasFocus, int row, int column)
        {
            return new JComboBox(new Object[] {
                ((AbstractFileType)obj).getValue()
            });
        }

        private static final long serialVersionUID = 1L;

        TypeCellRenderer()
        {
        }
    }

    private static class OutputFileCellRenderer extends DefaultTableCellRenderer
    {

        public Component getTableCellRendererComponent(JTable table, Object obj, boolean isSelected, boolean hasFocus, int row, int column)
        {
            TargetFile tf = (TargetFile)obj;
            return super.getTableCellRendererComponent(table, tf.toStringPretty(), isSelected, hasFocus, row, column);
        }

        private static final long serialVersionUID = 1L;

        private OutputFileCellRenderer()
        {
        }

    }

    private class FileCellRenderer extends DefaultTableCellRenderer
    {

        public Component getTableCellRendererComponent(JTable table, Object obj, boolean isSelected, boolean hasFocus, int row, int column)
        {
            BomEntry entry = getModel().getEntry(convertRowIndexToModel(row));
            String path = entry.getSourcePathRelative();
            if(currentDir != null && currentDir.length() > 0 && path != null && path.startsWith(currentDir))
            {
                path = path.substring(currentDir.length());
                if(path.startsWith("!"))
                    path = path.substring(1);
                if(path.startsWith("/"))
                    path = path.substring(1);
            }
            String src = (new StringBuilder()).append("<html><font color=gray>").append(path).append("</font>").append(entry.getName()).append("</html>").toString();
            Component cell = super.getTableCellRendererComponent(table, src, isSelected, hasFocus, row, column);
            if(entry.hasIssues(Level.SEVERE))
                setIcon(IssuesTable.itemErrorIcon);
            else
            if(entry.hasIssues(Level.WARNING))
                setIcon(IssuesTable.itemWarningIcon);
            else
                setIcon(null);
            setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
            return cell;
        }

        private static final long serialVersionUID = 1L;
        final FilesTable this$0;

        private FileCellRenderer()
        {
            this$0 = FilesTable.this;
            super();
        }

    }

    private static class IncludedCellRenderer extends DefaultTableCellRenderer
    {

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            cb.setSelected(((Boolean)value).booleanValue());
            cb.setEnabled(table.isCellEditable(row, column));
            return cb;
        }

        private static final long serialVersionUID = 1L;
        private static final JCheckBox cb;

        static 
        {
            cb = new JCheckBox();
            cb.setHorizontalAlignment(0);
        }

        private IncludedCellRenderer()
        {
        }

    }

    private static final class FilterType extends Enum
    {

        public static FilterType[] values()
        {
            return (FilterType[])$VALUES.clone();
        }

        public static FilterType valueOf(String name)
        {
            return (FilterType)Enum.valueOf(oracle/hub/tf/dropgenerator/gui/FilesTable$FilterType, name);
        }

        public static final FilterType FOLDER;
        public static final FilterType NAME;
        public static final FilterType PROBLEMATIC;
        private static final FilterType $VALUES[];

        static 
        {
            FOLDER = new FilterType("FOLDER", 0);
            NAME = new FilterType("NAME", 1);
            PROBLEMATIC = new FilterType("PROBLEMATIC", 2);
            $VALUES = (new FilterType[] {
                FOLDER, NAME, PROBLEMATIC
            });
        }

        private FilterType(String s, int i)
        {
            super(s, i);
        }
    }


    public FilesTable()
    {
        super(new FilesTableModel());
        setAutoCreateColumnsFromModel(false);
        setSelectionMode(2);
        setColumnSelectionAllowed(false);
        setSelectionForeground(Color.white);
        setSelectionBackground(Color.blue);
        getTableHeader().setReorderingAllowed(false);
        getModel().addTableModelListener(this);
        setGridColor(Color.LIGHT_GRAY);
        setRowHeight(23);
        setupPopupMenu();
        FileCellRenderer fileCellRenderer = new FileCellRenderer();
        colSourceFile.setCellRenderer(fileCellRenderer);
        colIncluded.setCellRenderer(new IncludedCellRenderer());
        sorter = new TableRowSorter(getModel());
        setRowSorter(sorter);
        setFileTypesView();
    }

    public void setFileTypesView()
    {
        if(isFileTypesView())
        {
            return;
        } else
        {
            removeColumns();
            FilesTableModel.Column.INCLUDED.visible = true;
            addColumn(colIncluded);
            FilesTableModel.Column.FILETYPE.visible = true;
            addColumn(colType);
            FilesTableModel.Column.SOURCEFILE.visible = true;
            addColumn(colSourceFile);
            includeMenuItem.setVisible(true);
            excludeMenuItem.setVisible(true);
            detectFileTypeMenuItem.setVisible(true);
            recheckErrorsMenuItem.setVisible(true);
            setFileTypeMenuItem.setVisible(true);
            configureLanguageTokensMenuItem.setVisible(false);
            return;
        }
    }

    private boolean isFileTypesView()
    {
        return FilesTableModel.Column.FILETYPE.visible;
    }

    public void setTokensView()
    {
        if(isTokensView())
        {
            return;
        } else
        {
            removeColumns();
            FilesTableModel.Column.SOURCEFILE.visible = true;
            addColumn(colSourceFile);
            FilesTableModel.Column.OUTPUTFILE.visible = true;
            addColumn(colOutputFile);
            FilesTableModel.Column.OUTPUTSAMPLE.visible = true;
            addColumn(colOutputSample);
            includeMenuItem.setVisible(false);
            excludeMenuItem.setVisible(false);
            detectFileTypeMenuItem.setVisible(false);
            recheckErrorsMenuItem.setVisible(false);
            setFileTypeMenuItem.setVisible(false);
            configureLanguageTokensMenuItem.setVisible(true);
            return;
        }
    }

    private boolean isTokensView()
    {
        return FilesTableModel.Column.OUTPUTFILE.visible;
    }

    public void sortBy(FilesTableModel.Column col)
    {
        java.util.List sortKeys = new ArrayList();
        sortKeys.add(new javax.swing.RowSorter.SortKey(col.ordinal(), SortOrder.ASCENDING));
        sorter.setSortKeys(sortKeys);
    }

    private void removeColumns()
    {
        FilesTableModel.Column arr$[] = FilesTableModel.Column.values();
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            FilesTableModel.Column col = arr$[i$];
            removeColumn(getColumn(col));
            col.visible = false;
        }

    }

    public void clear()
    {
        getModel().fireTableDataChanged();
        filters.clear();
        sorter.setRowFilter(null);
        sorter.setSortKeys(null);
        pickFileTypePanel = null;
        setFileTypesView();
    }

    private TableColumn getColumn(FilesTableModel.Column column)
    {
        int index = getColumnIndex(column);
        if(index < 0)
            return null;
        else
            return getColumnModel().getColumn(index);
    }

    private int getColumnIndex(FilesTableModel.Column column)
    {
        int index = -1;
        try
        {
            index = getColumnModel().getColumnIndex(column.toString());
        }
        catch(IllegalArgumentException e) { }
        return index;
    }

    private void setupPopupMenu()
    {
        includeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                updateIncluded(true);
            }

            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                super();
            }
        }
);
        excludeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                updateIncluded(false);
            }

            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                super();
            }
        }
);
        setFileTypeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                setFileTypeToMenuAction();
            }

            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                super();
            }
        }
);
        detectFileTypeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                updateFileType();
            }

            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                super();
            }
        }
);
        recheckErrorsMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                recheckErrors();
            }

            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                super();
            }
        }
);
        configureLanguageTokensMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                DropGeneratorWindow.configureLanguageTokenMenuItem.doClick();
            }

            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                super();
            }
        }
);
        entryDetailsMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                DetailsDialog.showEntry(FilesTable.this);
            }

            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                super();
            }
        }
);
    }

    protected void processMouseEvent(MouseEvent e)
    {
        if(e.getButton() == 3)
            showPopup(this, e);
        else
        if(e.getButton() == 1)
        {
            int col = columnAtPoint(e.getPoint());
            if(col == getColumnIndex(FilesTableModel.Column.SOURCEFILE))
            {
                int row = rowAtPoint(e.getPoint());
                if(isIcon(row, col, e))
                {
                    if(DropGeneratorWindow.tabbedPane.getSelectedIndex() != DropGeneratorWindow.Tab.ISSUES.ordinal())
                        DropGeneratorWindow.tabbedPane.setSelectedIndex(DropGeneratorWindow.Tab.ISSUES.ordinal());
                    DropGeneratorWindow.getIssuesTable().selectEntry(getModel().getEntry(convertRowIndexToModel(row)));
                }
            }
        }
        super.processMouseEvent(e);
    }

    protected void processMouseMotionEvent(MouseEvent e)
    {
        int col = columnAtPoint(e.getPoint());
        if(col == getColumnIndex(FilesTableModel.Column.SOURCEFILE))
        {
            int row = rowAtPoint(e.getPoint());
            if(isIcon(row, col, e))
            {
                setCursor(Cursor.getPredefinedCursor(12));
                setToolTipText("Click for details");
            } else
            {
                setCursor(Cursor.getDefaultCursor());
                setToolTipText(null);
            }
        } else
        {
            setCursor(Cursor.getDefaultCursor());
        }
        super.processMouseMotionEvent(e);
    }

    private boolean isIcon(int row, int col, MouseEvent e)
    {
        if(row < 0 || row > getRowCount())
            return false;
        int rowIndex = convertRowIndexToModel(row);
        if(rowIndex < 0)
            return false;
        BomEntry entry = getModel().getEntry(rowIndex);
        if(!entry.hasIssues())
            return false;
        FileCellRenderer component = (FileCellRenderer)getColumnModel().getColumn(col).getCellRenderer().getTableCellRendererComponent(this, getValueAt(row, col), false, true, row, col);
        MyImageIcon icon = (MyImageIcon)component.getIcon();
        if(icon == null)
        {
            return false;
        } else
        {
            Rectangle cellRectPos = new Rectangle(getCellRect(row, col, true));
            int yPos = e.getPoint().y - cellRectPos.y;
            Point cellRelative = new Point(e.getPoint().x - cellRectPos.x, yPos);
            return icon.isWithinBounds(cellRelative);
        }
    }

    public void showPopup(FilesTable c, MouseEvent e)
    {
        if(e.isPopupTrigger() && SwingUtilities.isRightMouseButton(e))
        {
            boolean changeSelection = true;
            int rowAtMouse = c.rowAtPoint(new Point(e.getPoint()));
            int arr$[] = getSelectedRows();
            int len$ = arr$.length;
            int i$ = 0;
            do
            {
                if(i$ >= len$)
                    break;
                int selectedRow = arr$[i$];
                if(rowAtMouse == selectedRow)
                {
                    changeSelection = false;
                    break;
                }
                i$++;
            } while(true);
            if(changeSelection)
                c.setRowSelectionInterval(rowAtMouse, rowAtMouse);
            checkSelection();
            popupMenu.show(c, e.getX(), e.getY());
            e.consume();
        }
    }

    public void updateIncluded(final boolean status)
    {
        Component frame = getParent();
        final int selectedRows[] = getSelectedRows();
        if(selectedRows.length == 0)
        {
            JOptionPane.showMessageDialog(frame, "You must select at least one row!");
            return;
        } else
        {
            (new SwingWorker() {

                protected Void doInBackground()
                    throws Exception
                {
                    int arr$[] = selectedRows;
                    int len$ = arr$.length;
                    for(int i$ = 0; i$ < len$; i$++)
                    {
                        int row = arr$[i$];
                        BomEntry b = getEntry(row);
                        b.setActive(status);
                    }

                    getModel().getBom().write();
                    return null;
                }

                protected void done()
                {
                    repaint();
                }

                protected volatile Object doInBackground()
                    throws Exception
                {
                    return doInBackground();
                }

                final int val$selectedRows[];
                final boolean val$status;
                final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                selectedRows = ai;
                status = flag;
                super();
            }
            }
).execute();
            return;
        }
    }

    void updateFileType(AbstractFileType type)
    {
        updateFileType(type, false);
    }

    public void updateFileType()
    {
        updateFileType(AbstractFileType.EMPTY_FILETYPE, true);
    }

    void updateFileType(final AbstractFileType type, final boolean detect)
    {
        Component frame = getParent();
        final int selectedRows[] = getSelectedRows();
        if(selectedRows.length == 0)
        {
            JOptionPane.showMessageDialog(frame, "You must select at least one row!");
            return;
        } else
        {
            (new SwingWorker() {

                protected Void doInBackground()
                    throws Exception
                {
                    int arr$[] = selectedRows;
                    int len$ = arr$.length;
                    for(int i$ = 0; i$ < len$; i$++)
                    {
                        int row = arr$[i$];
                        BomEntry b = getEntry(row);
                        if(detect)
                        {
                            DropGenerator.logger.log(Level.INFO, "Re-scanning {0}", b.getSourceRelative());
                            b.determineFileType();
                        } else
                        {
                            b.setFileType(type);
                        }
                    }

                    getModel().getBom().write();
                    return null;
                }

                protected void done()
                {
                    repaint();
                }

                protected volatile Object doInBackground()
                    throws Exception
                {
                    return doInBackground();
                }

                final int val$selectedRows[];
                final boolean val$detect;
                final AbstractFileType val$type;
                final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                selectedRows = ai;
                detect = flag;
                type = abstractfiletype;
                super();
            }
            }
).execute();
            return;
        }
    }

    public void setOutputFile(final String target)
    {
        Component frame = getParent();
        final int selectedRows[] = getSelectedRows();
        if(selectedRows.length == 0)
        {
            JOptionPane.showMessageDialog(frame, "You must select at least one row!");
            return;
        } else
        {
            (new SwingWorker() {

                protected Void doInBackground()
                    throws Exception
                {
                    int arr$[] = selectedRows;
                    int len$ = arr$.length;
                    for(int i$ = 0; i$ < len$; i$++)
                    {
                        int row = arr$[i$];
                        BomEntry b = getEntry(row);
                        b.setTarget(target);
                    }

                    getModel().getBom().write();
                    return null;
                }

                protected void done()
                {
                    repaint();
                }

                protected volatile Object doInBackground()
                    throws Exception
                {
                    return doInBackground();
                }

                final int val$selectedRows[];
                final String val$target;
                final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                selectedRows = ai;
                target = s;
                super();
            }
            }
).execute();
            return;
        }
    }

    public void recheckErrors()
    {
        Component frame = getParent();
        final int selectedRows[] = getSelectedRows();
        if(selectedRows.length == 0)
        {
            JOptionPane.showMessageDialog(frame, "You must select at least one row!");
            return;
        } else
        {
            (new SwingWorker() {

                protected Void doInBackground()
                    throws Exception
                {
                    int arr$[] = selectedRows;
                    int len$ = arr$.length;
                    for(int i$ = 0; i$ < len$; i$++)
                    {
                        int row = arr$[i$];
                        BomEntry b = getEntry(row);
                        DropGenerator.logger.log(Level.INFO, "Re-checking {0}", b.getSourceRelative());
                        b.validate();
                    }

                    getModel().getBom().write();
                    return null;
                }

                protected void done()
                {
                    repaint();
                }

                protected volatile Object doInBackground()
                    throws Exception
                {
                    return doInBackground();
                }

                final int val$selectedRows[];
                final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                selectedRows = ai;
                super();
            }
            }
).execute();
            return;
        }
    }

    void scrollToEntry(BomEntry b, BomEntryError e)
    {
        if(e.getErrorType().equals(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidToken) && isFileTypesView())
            DropGeneratorWindow.tokensButton.doClick();
        else
        if(!e.getErrorType().equals(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidToken) && isTokensView())
            DropGeneratorWindow.fileTypesButton.doClick();
        if(filters.remove(FilterType.NAME) != null || filters.remove(FilterType.PROBLEMATIC) != null)
            applyActiveFilters();
        int index = convertRowIndexToView(getModel().getBom().indexOf(b));
        Rectangle rect = getCellRect(index, 0, true);
        Rectangle visible = getVisibleRect();
        rect.y += ((rect.y >= visible.y ? 1 : -1) * visible.height) / 2;
        scrollRectToVisible(rect);
        getSelectionModel().setSelectionInterval(index, index);
    }

    public void setFileTypeToMenuAction()
    {
        if(getSelectedRows().length == 0)
        {
            JOptionPane.showMessageDialog(DropGeneratorWindow.getFrames()[0], "You must select at least one row!");
            return;
        }
        if(pickFileTypePanel == null)
            pickFileTypePanel = new PickFileTypePanel();
        int result = JOptionPane.showConfirmDialog(DropGeneratorWindow.getFrames()[0], pickFileTypePanel, "Set File Type", 2, -1);
        if(result == 2)
        {
            return;
        } else
        {
            updateFileType(pickFileTypePanel.getSelectedType());
            return;
        }
    }

    public BomEntry getEntry(int row)
    {
        return getModel().getEntry(convertRowIndexToModel(row));
    }

    public void setDirFilter(final String dir)
    {
        RowFilter rf = new RowFilter() {

            public boolean include(javax.swing.RowFilter.Entry entry)
            {
                BomEntry b = ((FilesTableModel)entry.getModel()).getEntry(((Integer)entry.getIdentifier()).intValue());
                return b.getSourcePathRelative().startsWith(dir);
            }

            final String val$dir;
            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                dir = s;
                super();
            }
        }
;
        filters.put(FilterType.FOLDER, rf);
        currentDir = dir;
        applyActiveFilters();
    }

    public void setNameFilter(final String name, final String type, final boolean contains)
    {
        if(name == null || name.trim().length() == 0)
        {
            filters.remove(FilterType.NAME);
        } else
        {
            RowFilter rf = new RowFilter() {

                public boolean include(javax.swing.RowFilter.Entry entry)
                {
                    BomEntry b = ((FilesTableModel)entry.getModel()).getEntry(((Integer)entry.getIdentifier()).intValue());
                    String match = b.getSourceRelative();
                    if(type.toLowerCase().equals("directory"))
                        match = b.getSourcePathRelative();
                    else
                    if(type.toLowerCase().equals("filename"))
                        match = b.getName();
                    boolean result = match.toLowerCase().contains(name.toLowerCase());
                    return result == contains;
                }

                final String val$type;
                final String val$name;
                final boolean val$contains;
                final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                type = s;
                name = s1;
                contains = flag;
                super();
            }
            }
;
            filters.put(FilterType.NAME, rf);
        }
        applyActiveFilters();
    }

    private void applyActiveFilters()
    {
        sorter.setRowFilter(RowFilter.andFilter(filters.values()));
    }

    public TableCellEditor getCellEditor(int row, int column)
    {
        if(column == getColumnIndex(FilesTableModel.Column.FILETYPE))
            return new DefaultCellEditor(getFileTypeComboBox(getModel().getEntry(convertRowIndexToModel(row))));
        if(column == getColumnIndex(FilesTableModel.Column.OUTPUTFILE))
        {
            JTextField textField = new JTextField();
            textField.setDocument(new OutputFileDocument());
            return new DefaultCellEditor(textField);
        } else
        {
            return super.getCellEditor(convertRowIndexToModel(row), column);
        }
    }

    public JComboBox getFileTypeComboBox(BomEntry b)
    {
        BlockComboBox cb = new BlockComboBox();
        TreeSet recommendedTypes = new TreeSet();
        recommendedTypes.add(AbstractFileType.EMPTY_FILETYPE);
        recommendedTypes.addAll(b.getPossibleFileTypes());
        cb.addElements(recommendedTypes);
        Set userTypes = FileTypes.getUserRecommendedTypes(Util.getExtension(b.getName()));
        if(userTypes.size() > 0)
            cb.addElements(userTypes);
        recommendedTypes.clear();
        recommendedTypes.add(AbstractFileType.OTHER_FILETYPE);
        cb.addElements(recommendedTypes);
        cb.addActionListener(new FileTypeComboBoxListener(this, b));
        return cb;
    }

    public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
    {
        Component cell = super.prepareRenderer(renderer, row, column);
        if(column == getColumnIndex(FilesTableModel.Column.FILETYPE))
            return cell;
        BomEntry b = getEntry(row);
        if(b.hasIssues(Level.SEVERE))
            cell.setBackground(isCellSelected(row, column) ? getSelectionBackground() : errorBackground);
        else
        if(b.hasIssues(Level.WARNING))
            cell.setBackground(isCellSelected(row, column) ? getSelectionBackground() : warningBackground);
        else
            cell.setBackground(isCellSelected(row, column) ? getSelectionBackground() : getBackground());
        cell.setForeground(isCellSelected(row, column) ? getSelectionForeground() : getForeground());
        return cell;
    }

    public void checkSelection()
    {
        boolean includeMenuEnabled = false;
        boolean excludeMenuEnabled = false;
        if(isTokensView())
            return;
        int arr$[] = getSelectedRows();
        int len$ = arr$.length;
        int i$ = 0;
        do
        {
            if(i$ >= len$)
                break;
            int selectedRow = arr$[i$];
            if(includeMenuEnabled && excludeMenuEnabled)
                break;
            boolean itemIncluded = ((Boolean)getValueAt(selectedRow, getColumnIndex(FilesTableModel.Column.INCLUDED))).booleanValue();
            boolean itemValid = isCellEditable(selectedRow, getColumnIndex(FilesTableModel.Column.INCLUDED));
            includeMenuEnabled |= !itemIncluded && itemValid;
            excludeMenuEnabled |= itemIncluded && itemValid;
            i$++;
        } while(true);
        includeMenuItem.setEnabled(includeMenuEnabled);
        excludeMenuItem.setEnabled(excludeMenuEnabled);
        DropGeneratorWindow.includedEnabled(includeMenuEnabled);
        DropGeneratorWindow.excludedEnabled(excludeMenuEnabled);
    }

    public FilesTableModel getModel()
    {
        return (FilesTableModel)super.getModel();
    }

    protected JTableHeader createDefaultTableHeader()
    {
        return new JTableHeader(columnModel) {

            public String getToolTipText(MouseEvent e)
            {
                int index = columnModel.getColumnIndexAtX(e.getPoint().x);
                int realIndex = columnModel.getColumn(index).getModelIndex();
                return FilesTableModel.Column.values()[realIndex].toolTip;
            }

            private static final long serialVersionUID = 1L;
            final FilesTable this$0;

            
            {
                this$0 = FilesTable.this;
                super(x0);
            }
        }
;
    }

    public volatile TableModel getModel()
    {
        return getModel();
    }

    private static final long serialVersionUID = 1L;
    private TableRowSorter sorter;
    public static final Color errorBackground = new Color(255, 210, 210);
    public static final Color warningBackground = new Color(255, 242, 198);
    private static final JPopupMenu popupMenu;
    private static final JMenuItem includeMenuItem;
    private static final JMenuItem excludeMenuItem;
    private static final JMenuItem detectFileTypeMenuItem;
    private static final JMenuItem recheckErrorsMenuItem;
    private static final JMenuItem setFileTypeMenuItem;
    private static final JMenuItem configureLanguageTokensMenuItem;
    private static final JMenuItem entryDetailsMenuItem;
    private PickFileTypePanel pickFileTypePanel;
    private final EnumMap filters = new EnumMap(oracle/hub/tf/dropgenerator/gui/FilesTable$FilterType);
    private String currentDir;
    private static final TableColumn colIncluded;
    private static final TableColumn colSourceFile;
    private static final TableColumn colType;
    private static final TableColumn colOutputFile;
    private static final TableColumn colOutputSample;

    static 
    {
        colIncluded = new TableColumn(FilesTableModel.Column.INCLUDED.ordinal());
        colIncluded.setResizable(false);
        colIncluded.setPreferredWidth(60);
        colIncluded.setMinWidth(60);
        colIncluded.setMaxWidth(60);
        colIncluded.setWidth(60);
        colType = new TableColumn(FilesTableModel.Column.FILETYPE.ordinal());
        colType.setResizable(false);
        colType.setPreferredWidth(170);
        colType.setMinWidth(170);
        colType.setMaxWidth(170);
        colType.setWidth(170);
        colType.setCellRenderer(new TypeCellRenderer());
        colSourceFile = new TableColumn(FilesTableModel.Column.SOURCEFILE.ordinal());
        colOutputFile = new TableColumn(FilesTableModel.Column.OUTPUTFILE.ordinal());
        colOutputFile.setCellRenderer(new OutputFileCellRenderer());
        colOutputSample = new TableColumn(FilesTableModel.Column.OUTPUTSAMPLE.ordinal());
        popupMenu = new JPopupMenu();
        includeMenuItem = new JMenuItem("Include");
        includeMenuItem.setAccelerator(KeyStroke.getKeyStroke(73, 2));
        excludeMenuItem = new JMenuItem("Exclude");
        excludeMenuItem.setAccelerator(KeyStroke.getKeyStroke(69, 2));
        setFileTypeMenuItem = new JMenuItem("Set File Type...");
        setFileTypeMenuItem.setAccelerator(KeyStroke.getKeyStroke(70, 2));
        detectFileTypeMenuItem = new JMenuItem("Detect File Type");
        recheckErrorsMenuItem = new JMenuItem("Re-check errors");
        configureLanguageTokensMenuItem = new JMenuItem("Configure Language Tokens...");
        entryDetailsMenuItem = new JMenuItem("Details");
        popupMenu.add(includeMenuItem);
        popupMenu.add(excludeMenuItem);
        popupMenu.add(setFileTypeMenuItem);
        popupMenu.add(detectFileTypeMenuItem);
        popupMenu.add(recheckErrorsMenuItem);
        popupMenu.add(configureLanguageTokensMenuItem);
        popupMenu.add(entryDetailsMenuItem);
    }

}
