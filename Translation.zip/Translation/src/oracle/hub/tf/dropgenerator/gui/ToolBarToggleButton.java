// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DropGeneratorWindow.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.Insets;
import javax.swing.*;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            LogTable

public class ToolBarToggleButton extends JToggleButton
{

    public ToolBarToggleButton(Icon icon)
    {
        super(icon);
        setMargin(margins);
        setVerticalTextPosition(3);
        setHorizontalTextPosition(0);
    }

    public ToolBarToggleButton(String icon, String text)
    {
        this(((Icon) (new ImageIcon((icon)))));
        setText(text);
    }

    private static final long serialVersionUID = 1L;
    private static final Insets margins = new Insets(3, 3, 3, 3);

}
