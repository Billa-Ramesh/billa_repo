// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IssuesTable.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.*;
import java.net.URL;
import javax.swing.ImageIcon;

class MyImageIcon extends ImageIcon
{

    public MyImageIcon(URL location)
    {
        super(location);
    }

    public synchronized void paintIcon(Component c, Graphics g, int x, int y)
    {
        paintx = x;
        painty = y;
        super.paintIcon(c, g, x, y);
    }

    public boolean isWithinBounds(Point p)
    {
        return p.x >= paintx && p.x <= paintx + getIconWidth() && p.y >= painty && p.y <= painty + getIconHeight();
    }

    private static final long serialVersionUID = 1L;
    private int paintx;
    private int painty;
}
