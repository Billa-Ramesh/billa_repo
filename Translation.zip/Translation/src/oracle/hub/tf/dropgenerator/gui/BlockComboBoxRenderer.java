// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockComboBox.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.HashSet;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            BlockComboBoxRendererAbstract

class BlockComboBoxRenderer extends BlockComboBoxRendererAbstract
{

    public BlockComboBoxRenderer(ListCellRenderer delegate)
    {
        super(delegate);
        separatorPositions = new HashSet();
    }

    public void addSeparator(int index)
    {
        separatorPositions.add(Integer.valueOf(index - 1));
    }

    protected boolean addSeparatorAfter(JList list, Object value, int index)
    {
        return separatorPositions.contains(new Integer(index));
    }

    private HashSet separatorPositions;
}
