// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FilesTable.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import oracle.hub.tf.dropgenerator.core.*;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            FilesTable, FilesTableModel

class FileTypeComboBoxListener
    implements ActionListener
{

    FileTypeComboBoxListener(FilesTable tbl, BomEntry entry)
    {
        this.tbl = tbl;
        b = entry;
    }

    public void actionPerformed(ActionEvent evt)
    {
        if(!(evt.getSource() instanceof JComboBox))
            return;
        JComboBox cb = (JComboBox)evt.getSource();
        if(!(cb.getSelectedItem() instanceof AbstractFileType))
            return;
        AbstractFileType newItem = (AbstractFileType)cb.getSelectedItem();
        if(newItem.equals(b.getFileType()))
            return;
        if(newItem.getKey().equals("other"))
        {
            ArrayList possibilities = new ArrayList();
            possibilities.addAll(FileTypes.getTypesAll(tbl.getModel().getBom().getDropType()));
            AbstractFileType selectedType = (AbstractFileType)JOptionPane.showInputDialog(cb, "Pick the file type that should be set for the selection", "Set File Type Dialog", -1, null, possibilities.toArray(), "");
            if(selectedType == null)
                newItem = b.getFileType();
            else
                newItem = selectedType;
        }
        tbl.updateFileType(newItem);
    }

    FilesTable tbl;
    BomEntry b;
}
