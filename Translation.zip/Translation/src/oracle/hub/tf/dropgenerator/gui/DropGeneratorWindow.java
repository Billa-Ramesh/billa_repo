// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DropGeneratorWindow.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileSystemView;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.tree.*;
import oracle.hub.tf.dropgenerator.core.*;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            LogTable, FilesTable, IssuesTable, ToolBarButton, 
//            ToolBarToggleButton, IssuesRowModel, FilesTableModel, OpenDialog, 
//            SaveDialog, DialogAbout, LanguageTokensDialog, VersionChecker, 
//            DetailsDialog

public class DropGeneratorWindow extends JFrame
{
    private static class TreeDirFilterCellRenderer extends DefaultTreeCellRenderer
    {

        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus)
        {
            DefaultMutableTreeNode tn = (DefaultMutableTreeNode)value;
            Icon icon = null;
            Object userObject = tn.getUserObject();
            String text;
            if(userObject.getClass().equals(java/net/URI))
            {
                URI uri = (URI)tn.getUserObject();
                String relative = DropGenerator.relativize(uri);
                if(!uri.getScheme().equals("file"))
                    uri = URI.create(uri.getRawSchemeSpecificPart());
                String pathComponents[];
                if(relative.isEmpty())
                    pathComponents = uri.getPath().split("/");
                else
                    pathComponents = relative.split("/");
                if(pathComponents.length == 0)
                    text = relative;
                else
                    text = pathComponents[pathComponents.length - 1];
                File file = new File(uri);
                if(file != null)
                {
                    icon = (Icon)iconCache.get(file.getAbsolutePath());
                    if(icon == null)
                    {
                        icon = FileSystemView.getFileSystemView().getSystemIcon(file);
                        if(icon == null)
                            icon = FileSystemView.getFileSystemView().getSystemIcon(DropGenerator.getImportDir());
                        iconCache.put(file.getAbsolutePath(), icon);
                    }
                }
            } else
            {
                text = userObject.toString();
            }
            JLabel result = (JLabel)super.getTreeCellRendererComponent(tree, text, sel, expanded, leaf, row, hasFocus);
            if(icon != null)
                result.setIcon(icon);
            return result;
        }

        private static final long serialVersionUID = 1L;
        private Map iconCache;

        private TreeDirFilterCellRenderer()
        {
            iconCache = new HashMap();
        }

    }

    public static final class Tab extends Enum
    {

        public static Tab[] values()
        {
            return (Tab[])$VALUES.clone();
        }

        public static Tab valueOf(String name)
        {
            return (Tab)Enum.valueOf(oracle/hub/tf/dropgenerator/gui/DropGeneratorWindow$Tab, name);
        }

        public String toString()
        {
            return displayName;
        }

        public static final Tab LOG;
        public static final Tab ISSUES;
        private final String displayName;
        private static final Tab $VALUES[];

        static 
        {
            LOG = new Tab("LOG", 0, "Message log");
            ISSUES = new Tab("ISSUES", 1, "Issues");
            $VALUES = (new Tab[] {
                LOG, ISSUES
            });
        }

        private Tab(String s, int i, String display)
        {
            super(s, i);
            displayName = display;
        }
    }


    public static IssuesTable getIssuesTable()
    {
        return issuesTable;
    }

    public static void main(String args[])
    {
        SwingUtilities.invokeLater(new Runnable() {

            public void run()
            {
                DropGenerator dg = new DropGenerator();
                DropGeneratorWindow window = new DropGeneratorWindow("Drop Generator", dg);
                window.setVisible(true);
                VersionChecker vc = new VersionChecker();
                vc.startupCheck();
            }

        }
);
    }

    public DropGeneratorWindow(String title, DropGenerator dg)
        throws HeadlessException
    {
        super(title);
        dropGen = dg;
        setDefaultCloseOperation(3);
        setMenuItemListeners();
        setJMenuBar(menuBar);
        logTable = new LogTable();
        filesTable = new FilesTable();
        treeDirFilter = new JTree(new DefaultMutableTreeNode("No project loaded"));
        treeDirFilter.setExpandsSelectedPaths(true);
        treeDirFilter.setScrollsOnExpand(true);
        issuesTable = new IssuesTable(filesTable, treeDirFilter);
        JComponent contentPane = (JComponent)getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(getTopPane(), "North");
        contentPane.add(getMainPane());
        pack();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gs[] = ge.getScreenDevices();
        GraphicsDevice gd = gs[0];
        GraphicsConfiguration gc[] = gd.getConfigurations();
        Rectangle gcBounds = gc[0].getBounds();
        int width = (3 * gcBounds.width) / 4;
        int height = (3 * gcBounds.height) / 4;
        setSize(width, height);
        Canvas c = new Canvas(gc[0]);
        setLocationRelativeTo(c);
        updateStatus(false);
        DropGenerator.logger.log(Level.INFO, "To start, please choose a directory by clicking the \"{0}\" button", scanButton.getText());
        setVisible(true);
        splitPane.setDividerLocation(0.65000000000000002D);
        for(int i = 0; i < IssuesRowModel.columnWidths.length; i++)
        {
            TableColumn column = issuesTable.getColumnModel().getColumn(i);
            if(IssuesRowModel.columnWidths[i] == 0.0D)
                continue;
            if(IssuesRowModel.columnWidths[i] <= 1.0D)
                column.setPreferredWidth((int)((double)issuesTable.getSize().width * IssuesRowModel.columnWidths[i]));
            else
                column.setPreferredWidth((int)IssuesRowModel.columnWidths[i]);
        }

    }

    public final void updateStatus(boolean enabled)
    {
        closeMenuItem.setEnabled(enabled);
        generateMenuItem.setEnabled(enabled);
        selectAllMenuItem.setEnabled(enabled);
        selectNoneMenuItem.setEnabled(enabled);
        filterType.setEnabled(enabled);
        filterInclude.setEnabled(enabled);
        txtFilter.setText("");
        txtFilter.setEnabled(enabled);
        setFileTypeMenuItem.setEnabled(enabled);
        configureLanguageTokenMenuItem.setEnabled(enabled);
        detectFileTypeMenuItem.setEnabled(enabled);
        recheckErrorsMenuItem.setEnabled(enabled);
        rescanMenuItem.setEnabled(enabled);
        detailsMenuItem.setEnabled(enabled);
        fileTypesButton.setEnabled(enabled);
        tokensButton.setEnabled(enabled);
        generateButton.setEnabled(enabled);
        refreshButton.setEnabled(enabled);
        includeMenuItem.setEnabled(false);
        excludeMenuItem.setEnabled(false);
        if(!enabled)
        {
            DropGenerator.clearDropInfo();
            FileTypes.clearUserExtensionTypes();
            if(dropGen.getBom() != null)
            {
                Bom bom = dropGen.getBom();
                bom.clear();
                bom = null;
            }
            DefaultTreeModel tm = (DefaultTreeModel)treeDirFilter.getModel();
            DefaultMutableTreeNode n = (DefaultMutableTreeNode)tm.getRoot();
            n.removeAllChildren();
            n.setUserObject("No project loaded");
            tm.nodeStructureChanged(n);
            filesTable.clear();
            issuesTable.clear();
            logTable.clear();
            setTitle("Drop Generator");
        } else
        {
            saveDialog = null;
            filesTable.getModel().fireTableDataChanged();
            if(DropGenerator.getImportDir().exists() && DropGenerator.getImportDir().isDirectory())
            {
                setTitle((new StringBuilder()).append("Drop Generator - ").append(DropGenerator.getImportDir().getAbsolutePath()).toString());
                fileTypesButton.setSelected(true);
            }
        }
    }

    private void scanSourceDir(File sourceDir, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dt)
    {
        updateStatus(false);
        progressMonitor = new ProgressMonitor(this, "Scanning selected directory...", "Counting files", 0, 100);
        progressMonitor.setProgress(0);
        progressMonitor.setMillisToDecideToPopup(0);
        progressMonitor.setMillisToPopup(0);
        dropGen.scanSourceDirectory(sourceDir, dt, new PropertyChangeListener() {

            public void propertyChange(PropertyChangeEvent evt)
            {
                if(progressMonitor.isCanceled() && !dropGen.getActiveWorker().isCancelled())
                {
                    dropGen.getActiveWorker().cancel(true);
                    updateStatus(false);
                    return;
                }
                if("progress".equals(evt.getPropertyName()))
                {
                    int progress = ((Integer)evt.getNewValue()).intValue();
                    progressMonitor.setProgress(progress);
                } else
                if("state".equals(evt.getPropertyName()))
                {
                    if(dropGen.getActiveWorker().isDone() && !dropGen.getActiveWorker().isCancelled())
                    {
                        DropGenerator.logger.info("Please refer to the Issues tab to see warning/error details");
                        DefaultMutableTreeNode root = null;
                        try
                        {
                            root = (DefaultMutableTreeNode)dropGen.getActiveWorker().get();
                        }
                        catch(InterruptedException ex)
                        {
                            Logger.getLogger(oracle/hub/tf/dropgenerator/gui/DropGeneratorWindow.getName()).log(Level.SEVERE, null, ex);
                        }
                        catch(ExecutionException ex)
                        {
                            Logger.getLogger(oracle/hub/tf/dropgenerator/gui/DropGeneratorWindow.getName()).log(Level.SEVERE, null, ex);
                        }
                        DefaultTreeModel tm = (DefaultTreeModel)treeDirFilter.getModel();
                        DefaultMutableTreeNode n = (DefaultMutableTreeNode)tm.getRoot();
                        tm.setRoot(root);
                        tm.nodeStructureChanged(n);
                        filesTable.getModel().setBom(dropGen.getBom());
                        filesTable.sortBy(FilesTableModel.Column.FILETYPE);
                        updateStatus(true);
                    }
                } else
                if("note".equals(evt.getPropertyName()))
                    progressMonitor.setNote(evt.getNewValue().toString());
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
    }

    private void setMenuItemListeners()
    {
        editMenu.addMouseListener(new MouseListener() {

            public void mouseClicked(MouseEvent mouseevent)
            {
            }

            public void mouseEntered(MouseEvent e)
            {
                filesTable.checkSelection();
            }

            public void mouseExited(MouseEvent mouseevent)
            {
            }

            public void mouseReleased(MouseEvent mouseevent)
            {
            }

            public void mousePressed(MouseEvent mouseevent)
            {
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        ActionListener scanActionListener = new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                if(openDialog == null)
                    openDialog = new OpenDialog(DropGeneratorWindow.this, "Choose directory", openDialog != null ? openDialog.getSelectedDir() : DropGenerator.getImportDir());
                openDialog.setVisible(true);
                if(openDialog.getAction() == 2 || !openDialog.isValidDir())
                {
                    return;
                } else
                {
                    scanSourceDir(openDialog.getSelectedDir(), openDialog.getDropType());
                    return;
                }
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
;
        scanMenuItem.addActionListener(scanActionListener);
        closeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                updateStatus(false);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        ActionListener generateActionListener = new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                saveDialog = new SaveDialog(DropGeneratorWindow.this, saveDialog != null ? saveDialog.getSelectedDir() : DropGenerator.getImportDir(), hasForms(), dropGen.getBom().getDropType());
                saveDialog.setProductName(dropGen.getBom().getMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productname));
                saveDialog.setProductVersion(dropGen.getBom().getMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productversion));
                saveDialog.setProductModule(dropGen.getBom().getMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productmodule));
                saveDialog.setProductDrop(dropGen.getBom().getDropNumber());
                saveDialog.setProductGroup(dropGen.getBom().getMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productgroup));
                saveDialog.setFormsVersion(dropGen.getBom().getFormsVersion());
                saveDialog.setVisible(true);
                if(saveDialog.getAction() == 2 || !saveDialog.isValidDir())
                    return;
                File saveDir = saveDialog.getSelectedDir();
                if(!dropGen.getBom().getMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productname).equals(saveDialog.getProduct()))
                {
                    dropGen.getBom().setMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productname, saveDialog.getProduct());
                    filesTable.getModel().fireTableRowsUpdated(0, filesTable.getModel().getRowCount() - 1);
                }
                dropGen.getBom().setMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productgroup, saveDialog.getGroup());
                dropGen.getBom().setMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productversion, saveDialog.getVersion());
                dropGen.getBom().setMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productmodule, saveDialog.getModule());
                dropGen.getBom().setMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.productdrop, Integer.valueOf(saveDialog.getDrop()));
                dropGen.getBom().setMetaData(oracle.hub.tf.dropgenerator.core.Bom.MetaData.formsversion, saveDialog.getFormsVersion());
                progressMonitor = new ProgressMonitor(DropGeneratorWindow.this, "Generating translation kit", "Revalidating files...", 0, 100);
                progressMonitor.setMillisToDecideToPopup(0);
                progressMonitor.setMillisToPopup(0);
                progressMonitor.setProgress(0);
                dropGen.createDropZip(saveDir, new PropertyChangeListener() {

                    public void propertyChange(PropertyChangeEvent evt)
                    {
                        if(progressMonitor.isCanceled())
                            dropGen.getActiveWorker().cancel(false);
                        if("progress".equals(evt.getPropertyName()))
                        {
                            int progress = ((Integer)evt.getNewValue()).intValue();
                            progressMonitor.setProgress(progress);
                        } else
                        if("note".equals(evt.getPropertyName()))
                            progressMonitor.setNote(evt.getNewValue().toString());
                    }

                    final _cls6 this$1;

                    
                    {
                        this$1 = _cls6.this;
                        super();
                    }
                }
);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
;
        generateMenuItem.addActionListener(generateActionListener);
        selectNoneMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event)
            {
                SwingUtilities.invokeLater(new Runnable() {

                    public void run()
                    {
                        filesTable.clearSelection();
                    }

                    final _cls7 this$1;

                    
                    {
                        this$1 = _cls7.this;
                        super();
                    }
                }
);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        selectAllMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event)
            {
                SwingUtilities.invokeLater(new Runnable() {

                    public void run()
                    {
                        filesTable.selectAll();
                    }

                    final _cls8 this$1;

                    
                    {
                        this$1 = _cls8.this;
                        super();
                    }
                }
);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        includeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event)
            {
                filesTable.updateIncluded(true);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        excludeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event)
            {
                filesTable.updateIncluded(false);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        setFileTypeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event)
            {
                filesTable.setFileTypeToMenuAction();
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        configureLanguageTokenMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event)
            {
                if(languageTokenDialog == null)
                    languageTokenDialog = new LanguageTokensDialog(DropGeneratorWindow.this, filesTable);
                languageTokenDialog.setVisible(true);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        detectFileTypeMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event)
            {
                filesTable.updateFileType();
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        recheckErrorsMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                filesTable.recheckErrors();
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        ActionListener rescanActionListener = new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                scanSourceDir(DropGenerator.getImportDir(), dropGen.getBom().getDropType());
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
;
        rescanMenuItem.addActionListener(rescanActionListener);
        detailsMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                if(filesTable.getSelectedRows().length == 0)
                {
                    JOptionPane.showMessageDialog(DropGeneratorWindow.this, "You must select at least one row!");
                    return;
                } else
                {
                    DetailsDialog.showEntry(filesTable);
                    return;
                }
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        supportMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    Desktop.getDesktop().browse(new URI("http://wptg.oraclecorp.com/pls/htmldb/f?p=101:68::::68:P68_SELECTED_CATEGORY:ssutil"));
                }
                catch(IOException e1)
                {
                    DropGenerator.logger.severe("Default browser could not be found!");
                }
                catch(URISyntaxException e1)
                {
                    DropGenerator.logger.log(Level.SEVERE, "The specified URL is not valid: {0}", e1.getMessage());
                }
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        langTokensMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    Desktop.getDesktop().browse(new URI("https://wptg.oracle.com/repository/internal/kb/18325/DG-AddingLanguageTokens.html"));
                }
                catch(IOException e1)
                {
                    DropGenerator.logger.severe("Default browser could not be found!");
                }
                catch(URISyntaxException e1)
                {
                    DropGenerator.logger.log(Level.SEVERE, "The specified URL is not valid: {0}", e1.getMessage());
                }
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        checkUpdatesMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                VersionChecker vc = new VersionChecker();
                vc.checkLatest();
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        aboutMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                if(aboutDialog == null)
                    aboutDialog = new DialogAbout(DropGeneratorWindow.this);
                aboutDialog.setVisible(true);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        ActionListener filter = new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                JComboBox cb = (JComboBox)e.getSource();
                if(DropGeneratorWindow.txtFilter.getText().trim().length() > 0)
                {
                    boolean include = ((String)DropGeneratorWindow.filterInclude.getSelectedItem()).equals("contains");
                    String type = (String)DropGeneratorWindow.filterType.getSelectedItem();
                    filesTable.setNameFilter(DropGeneratorWindow.txtFilter.getText(), type, include);
                }
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
;
        filterInclude.addActionListener(filter);
        filterType.addActionListener(filter);
        scanButton.addActionListener(scanActionListener);
        fileTypesButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                filesTable.setFileTypesView();
                languageTokenDialog.setVisible(false);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        tokensButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                filesTable.setTokensView();
                DropGeneratorWindow.configureLanguageTokenMenuItem.doClick();
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        generateButton.addActionListener(generateActionListener);
        refreshButton.addActionListener(rescanActionListener);
    }

    private JPanel getTopPane()
    {
        JPanel filtersPanel = new JPanel();
        filtersPanel.setLayout(new BoxLayout(filtersPanel, 0));
        filtersPanel.setBorder(new EmptyBorder(0, 6, 0, 6));
        filtersPanel.add(Box.createHorizontalGlue());
        filtersPanel.add(filterType);
        filtersPanel.add(Box.createHorizontalStrut(4));
        filtersPanel.add(filterInclude);
        filtersPanel.add(Box.createHorizontalStrut(4));
        filtersPanel.add(txtFilter);
        txtFilter.setMaximumSize(txtFilter.getPreferredSize());
        filterType.setMaximumSize(new Dimension(60, 20));
        filterInclude.setMaximumSize(new Dimension(60, 20));
        txtFilter.addKeyListener(new KeyAdapter() {

            public void keyReleased(KeyEvent event)
            {
                filesTable.setNameFilter(DropGeneratorWindow.txtFilter.getText(), DropGeneratorWindow.filterType.getSelectedItem().toString(), ((String)DropGeneratorWindow.filterInclude.getSelectedItem()).equals("contains"));
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        JPanel container = new JPanel();
        container.setLayout(new BorderLayout());
        container.add(toolBar, "West");
        container.add(filtersPanel, "Center");
        return container;
    }

    private JPanel getMainPane()
    {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        treeDirFilter.getSelectionModel().setSelectionMode(1);
        treeDirFilter.setCellRenderer(new TreeDirFilterCellRenderer());
        treeDirFilter.setEditable(false);
        treeDirFilter.setBorder(BorderFactory.createEmptyBorder(3, 3, 0, 0));
        treeDirFilter.addTreeSelectionListener(new TreeSelectionListener() {

            public void valueChanged(TreeSelectionEvent event)
            {
                Object selectedNode = treeDirFilter.getLastSelectedPathComponent();
                if(selectedNode == null)
                    return;
                String filter = null;
                if(selectedNode instanceof DefaultMutableTreeNode)
                {
                    Object userObject = ((DefaultMutableTreeNode)selectedNode).getUserObject();
                    if(userObject == null)
                        return;
                    filter = DropGenerator.relativize((URI)userObject);
                }
                filesTable.setDirFilter(filter);
            }

            final DropGeneratorWindow this$0;

            
            {
                this$0 = DropGeneratorWindow.this;
                super();
            }
        }
);
        JScrollPane dropFilterView = new JScrollPane(treeDirFilter);
        dropFilterView.setPreferredSize(new Dimension(200, 0));
        JSplitPane dirTreeAndFilesTable = new JSplitPane(1);
        dirTreeAndFilesTable.setRightComponent(new JScrollPane(filesTable));
        dirTreeAndFilesTable.setLeftComponent(dropFilterView);
        Tab arr$[] = Tab.values();
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            Tab title = arr$[i$];
            tabbedPane.addTab(title.toString(), null);
        }

        tabbedPane.setComponentAt(Tab.LOG.ordinal(), new JScrollPane(logTable));
        tabbedPane.setComponentAt(Tab.ISSUES.ordinal(), new JScrollPane(issuesTable));
        splitPane.setLeftComponent(dirTreeAndFilesTable);
        splitPane.setRightComponent(tabbedPane);
        panel.add(splitPane);
        return panel;
    }

    private boolean hasForms()
    {
        for(Iterator i$ = dropGen.getBom().iterator(); i$.hasNext();)
        {
            BomEntry entry = (BomEntry)i$.next();
            if(entry.getFileType().getKey().equals("fmb"))
                return true;
        }

        return false;
    }

    public static void includedEnabled(boolean enabled)
    {
        includeMenuItem.setEnabled(enabled);
    }

    public static void excludedEnabled(boolean enabled)
    {
        excludeMenuItem.setEnabled(enabled);
    }

    public FilesTable getFilesTable()
    {
        return filesTable;
    }

    public JTree getTreeDirFilter()
    {
        return treeDirFilter;
    }

    public static final String version;
    private static final long serialVersionUID = 1L;
    private static final JToolBar toolBar;
    private static final ToolBarButton scanButton;
    private static final ButtonGroup toggleButtonGroup;
    static final ToolBarToggleButton fileTypesButton;
    static final ToolBarToggleButton tokensButton;
    private static final ToolBarButton generateButton;
    private static final ToolBarButton refreshButton;
    private static final JMenuBar menuBar;
    private static final JMenu editMenu;
    private static final JMenuItem scanMenuItem;
    private static final JMenuItem closeMenuItem;
    private static final JMenuItem generateMenuItem;
    private static final JMenuItem quitMenuItem;
    private static final JMenuItem selectAllMenuItem;
    private static final JMenuItem selectNoneMenuItem;
    private static final JMenuItem includeMenuItem;
    private static final JMenuItem excludeMenuItem;
    private static final JMenuItem detectFileTypeMenuItem;
    private static final JMenuItem setFileTypeMenuItem;
    public static final JMenuItem configureLanguageTokenMenuItem;
    private static final JMenuItem recheckErrorsMenuItem;
    private static final JMenuItem rescanMenuItem;
    private static final JMenuItem detailsMenuItem;
    private static final JMenuItem supportMenuItem;
    private static final JMenuItem langTokensMenuItem;
    private static final JMenuItem checkUpdatesMenuItem;
    private static final JMenuItem aboutMenuItem;
    private static final JComboBox filterType = new JComboBox(new String[] {
        "Filepath", "Filename", "Directory"
    });
    private static final JComboBox filterInclude = new JComboBox(new String[] {
        "contains", "does not contain"
    });
    private static final JTextField txtFilter = new JTextField(20);
    private FilesTable filesTable;
    private JTree treeDirFilter;
    private LogTable logTable;
    private static IssuesTable issuesTable;
    private OpenDialog openDialog;
    private SaveDialog saveDialog;
    private ProgressMonitor progressMonitor;
    private DialogAbout aboutDialog;
    private LanguageTokensDialog languageTokenDialog;
    private static final JSplitPane splitPane = new JSplitPane(0);
    public static final JTabbedPane tabbedPane = new JTabbedPane();
    private DropGenerator dropGen;

    static 
    {
        InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("dropgenerator-gui.properties");
        Properties prop = new Properties();
        try
        {
            prop.load(in);
        }
        catch(IOException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/gui/DropGeneratorWindow.getName()).log(Level.SEVERE, null, ex);
        }
        version = prop.getProperty("application.version");
        if(version == null)
            System.exit(0);
        try
        {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception e)
        {
            System.err.println((new StringBuilder()).append("Could not initialize default system LAF: ").append(e.getMessage()).toString());
        }
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic('F');
        editMenu = new JMenu("Edit");
        editMenu.setMnemonic('E');
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic('H');
        scanMenuItem = new JMenuItem("Scan drop files...");
        scanMenuItem.setAccelerator(KeyStroke.getKeyStroke(79, 2));
        fileMenu.add(scanMenuItem);
        closeMenuItem = new JMenuItem("Close active drop");
        closeMenuItem.setAccelerator(KeyStroke.getKeyStroke(88, 2));
        fileMenu.add(closeMenuItem);
        rescanMenuItem = new JMenuItem("Rescan");
        rescanMenuItem.setAccelerator(KeyStroke.getKeyStroke(116, 0));
        fileMenu.add(rescanMenuItem);
        generateMenuItem = new JMenuItem("Generate drop...");
        generateMenuItem.setAccelerator(KeyStroke.getKeyStroke(83, 2));
        fileMenu.addSeparator();
        fileMenu.add(generateMenuItem);
        quitMenuItem = new JMenuItem("Quit");
        quitMenuItem.setAccelerator(KeyStroke.getKeyStroke(81, 2));
        quitMenuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }

        }
);
        fileMenu.addSeparator();
        fileMenu.add(quitMenuItem);
        selectAllMenuItem = new JMenuItem("Select All");
        selectAllMenuItem.setAccelerator(KeyStroke.getKeyStroke(65, 2));
        editMenu.add(selectAllMenuItem);
        selectNoneMenuItem = new JMenuItem("Select None");
        editMenu.add(selectNoneMenuItem);
        includeMenuItem = new JMenuItem("Include");
        includeMenuItem.setAccelerator(KeyStroke.getKeyStroke(73, 2));
        editMenu.addSeparator();
        editMenu.add(includeMenuItem);
        excludeMenuItem = new JMenuItem("Exclude");
        excludeMenuItem.setAccelerator(KeyStroke.getKeyStroke(69, 2));
        editMenu.add(excludeMenuItem);
        detectFileTypeMenuItem = new JMenuItem("Detect File Type");
        editMenu.addSeparator();
        editMenu.add(detectFileTypeMenuItem);
        setFileTypeMenuItem = new JMenuItem("Set File Type...");
        setFileTypeMenuItem.setAccelerator(KeyStroke.getKeyStroke(70, 2));
        editMenu.add(setFileTypeMenuItem);
        configureLanguageTokenMenuItem = new JMenuItem("Configure Language Tokens...");
        editMenu.add(configureLanguageTokenMenuItem);
        recheckErrorsMenuItem = new JMenuItem("Re-check errors");
        editMenu.add(recheckErrorsMenuItem);
        detailsMenuItem = new JMenuItem("Details");
        editMenu.add(detailsMenuItem);
        supportMenuItem = new JMenuItem("On-line support");
        helpMenu.add(supportMenuItem);
        langTokensMenuItem = new JMenuItem("Adding Language Tokens");
        helpMenu.add(langTokensMenuItem);
        checkUpdatesMenuItem = new JMenuItem("Check for Updates...");
        helpMenu.add(checkUpdatesMenuItem);
        aboutMenuItem = new JMenuItem("About...");
        helpMenu.add(aboutMenuItem);
        menuBar = new JMenuBar();
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(helpMenu);
        scanButton = new ToolBarButton("toolbar-scan.png", "Scan files");
        toggleButtonGroup = new ButtonGroup();
        fileTypesButton = new ToolBarToggleButton("toolbar-filetypes.png", "File types");
        fileTypesButton.setToolTipText("File type selection view");
        tokensButton = new ToolBarToggleButton("toolbar-tokens.png", "Language tokens");
        tokensButton.setToolTipText("Language token configuration view");
        toggleButtonGroup.add(tokensButton);
        toggleButtonGroup.add(fileTypesButton);
        generateButton = new ToolBarButton("toolbar-generate.png", "Generate drop");
        refreshButton = new ToolBarButton("toolbar-refresh.png", "Refresh");
        toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.add(scanButton);
        toolBar.add(refreshButton);
        toolBar.addSeparator();
        toolBar.add(fileTypesButton);
        toolBar.add(tokensButton);
        toolBar.addSeparator();
        toolBar.add(generateButton);
    }


















}
