// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LogTable.java

package oracle.hub.tf.dropgenerator.gui;

import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.*;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            LogTableModel, LogTableHandler

public class LogTable extends JTable
{
    private static class JComponentCellRenderer
        implements TableCellRenderer
    {

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            return (JComponent)value;
        }

        private JComponentCellRenderer()
        {
        }

    }


    public LogTable()
    {
        super(new LogTableModel());
        model = (LogTableModel)getModel();
     
  //   setDefaultRenderer(JComponentCellRenderer.class,model);
        setRowHeight(20);
        setGridColor(new Color(0xebe8da));
        setTableHeader(null);
        DropGenerator.logger.addHandler(new LogTableHandler(this));
        DropGenerator.logger.setLevel(Level.INFO);
    }

    public void addRow(Level type, String message, boolean last)
    {
        JLabel label = new JLabel(message);
        label.setFont(defaultFont);
        label.setIcon(infoIcon);
        if(type == Level.SEVERE)
            label.setIcon(errorIcon);
        else
        if(type == Level.WARNING)
            label.setIcon(warningIcon);
        if(last)
            label.setIcon(successIcon);
        label.setHorizontalAlignment(2);
        label.setIconTextGap(5);
        final JLabel l = label;
        SwingUtilities.invokeLater(new Runnable() {

            public void run()
            {
                model.addRow(l);
                scrollRectToVisible(getCellRect(getRowCount() - 1, 0, true));
            }

            
        }
);
    }

    public void clear()
    {
        model.clear();
    }

    public TableCellRenderer getCellRenderer(int row, int column)
    {
        TableColumn tableColumn = getColumnModel().getColumn(column);
        TableCellRenderer renderer = tableColumn.getCellRenderer();
        /*if(renderer == null)
        {
            Class c = getColumnClass(column);
            if(c.equals(java/lang/Object))
            {
                Object o = getValueAt(row, column);
                if(o != null)
                    c = getValueAt(row, column).getClass();
            }
            renderer = getDefaultRenderer(c);
        }*/
        return renderer;
    }

    private static final long serialVersionUID = 1L;
    private LogTableModel model;
    public static final Icon successIcon = new ImageIcon("log-check.gif");
    public static final Icon errorIcon = new ImageIcon("log-error.gif");
    public static final Icon infoIcon = new ImageIcon("log-info.gif");
    public static final Icon warningIcon = new ImageIcon("log-warning.gif");
    private static final Font defaultFont = new Font("Monospaced", 0, 12);


}
