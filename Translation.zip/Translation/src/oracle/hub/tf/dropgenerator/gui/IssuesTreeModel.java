// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IssuesTable.java

package oracle.hub.tf.dropgenerator.gui;

import java.util.*;
import java.util.logging.Level;
import javax.swing.SwingUtilities;
import javax.swing.tree.*;
import oracle.hub.tf.dropgenerator.core.BomEntry;
import oracle.hub.tf.dropgenerator.core.BomEntryError;

class IssuesTreeModel extends DefaultTreeModel
{

    public IssuesTreeModel(DefaultMutableTreeNode root)
    {
        super(root);
        warnings = new DefaultMutableTreeNode(Level.WARNING);
        errors = new DefaultMutableTreeNode(Level.SEVERE);
        root.add(errors);
        root.add(warnings);
        nodeStructureChanged(root);
    }

    public void issueAdded(String topic, BomEntryError issue)
    {
        addIssue(issue);
    }

    public void issueRemoved(String topic, BomEntryError issue)
    {
        removeIssue(issue);
    }

    public Set getInsertedNodes()
    {
        return Collections.unmodifiableSet(insertedNodes);
    }

    public void addIssue(BomEntryError err)
    {
        if(insertedNodes.contains(err))
            return;
        insertedNodes.add(err);
        final DefaultMutableTreeNode parent = err.getLevel() != Level.WARNING ? errors : warnings;
        DefaultMutableTreeNode newEntry = new DefaultMutableTreeNode(err);
        Enumeration children = parent.children();
        int index = 0;
        do
        {
            if(!children.hasMoreElements())
                break;
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)children.nextElement();
            BomEntryError error = (BomEntryError)node.getUserObject();
            if(error.getEntry().getName().compareToIgnoreCase(err.getEntry().getName()) > 0)
                break;
            index++;
        } while(true);
        parent.insert(newEntry, index);
        final int indexF = index;
        SwingUtilities.invokeLater(new Runnable() {

            public void run()
            {
                try
                {
                    nodesWereInserted(parent, new int[] {
                        indexF
                    });
                }
                catch(ArrayIndexOutOfBoundsException e) { }
            }

            final DefaultMutableTreeNode val$parent;
            final int val$indexF;
            final IssuesTreeModel this$0;

            
            {
                this$0 = IssuesTreeModel.this;
                parent = defaultmutabletreenode;
                indexF = i;
                super();
            }
        }
);
    }

    public void removeIssue(BomEntryError err)
    {
        if(!insertedNodes.contains(err))
            return;
        insertedNodes.remove(err);
        final DefaultMutableTreeNode parent = err.getLevel() != Level.WARNING ? errors : warnings;
        Enumeration enumeration = parent.children();
        int i = 0;
        do
        {
            if(!enumeration.hasMoreElements())
                break;
            DefaultMutableTreeNode child = (DefaultMutableTreeNode)enumeration.nextElement();
            BomEntryError childError = (BomEntryError)child.getUserObject();
            if(childError.equals(err))
            {
                parent.remove(i);
                final int j = i;
                final DefaultMutableTreeNode childFinal = child;
                SwingUtilities.invokeLater(new Runnable() {

                    public void run()
                    {
                        nodesWereRemoved(parent, new int[] {
                            j
                        }, new Object[] {
                            childFinal
                        });
                    }

                    final DefaultMutableTreeNode val$parent;
                    final int val$j;
                    final DefaultMutableTreeNode val$childFinal;
                    final IssuesTreeModel this$0;

            
            {
                this$0 = IssuesTreeModel.this;
                parent = defaultmutabletreenode;
                j = i;
                childFinal = defaultmutabletreenode1;
                super();
            }
                }
);
                break;
            }
            i++;
        } while(true);
    }

    public void clear()
    {
        insertedNodes.clear();
        warnings.removeAllChildren();
        errors.removeAllChildren();
        nodeStructureChanged(root);
    }

    public Object getChild(Object parent, int index)
    {
        return super.getChild(parent, index);
    }

    public int getIndexOfChild(Object parent, Object child)
    {
        return super.getIndexOfChild(parent, child);
    }

    public TreeNode[] getPathTo(BomEntry entry)
    {
        DefaultMutableTreeNode p = entry.hasIssues(Level.SEVERE) ? errors : warnings;
        for(Enumeration e = p.children(); e.hasMoreElements();)
        {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)e.nextElement();
            BomEntryError error = (BomEntryError)node.getUserObject();
            if(error.getEntry().equals(entry))
                return node.getPath();
        }

        return null;
    }

    public int getChildCount(Object parent)
    {
        return super.getChildCount(parent);
    }

    public boolean isLeaf(Object node)
    {
        return super.isLeaf(node);
    }

    private static final long serialVersionUID = 1L;
    private final DefaultMutableTreeNode warnings;
    private final DefaultMutableTreeNode errors;
    private final HashSet insertedNodes = new HashSet();
}
