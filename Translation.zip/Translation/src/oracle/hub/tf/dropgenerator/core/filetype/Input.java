// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CachingEntityResolver.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.*;
import org.w3c.dom.ls.LSInput;

class Input
    implements LSInput
{

    public String getPublicId()
    {
        return publicId;
    }

    public void setPublicId(String publicId)
    {
        this.publicId = publicId;
    }

    public String getBaseURI()
    {
        return null;
    }

    public InputStream getByteStream()
    {
        return null;
    }

    public boolean getCertifiedText()
    {
        return false;
    }

    public Reader getCharacterStream()
    {
        return null;
    }

    public String getEncoding()
    {
        return null;
    }

    public String getStringData()
    {
        BufferedInputStream bufferedinputstream = inputStream;
        JVM INSTR monitorenter ;
        String contents;
        byte input[] = new byte[inputStream.available()];
        inputStream.read(input);
        contents = new String(input);
        return contents;
        IOException e;
        e;
        null;
        bufferedinputstream;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setBaseURI(String s)
    {
    }

    public void setByteStream(InputStream inputstream)
    {
    }

    public void setCertifiedText(boolean flag)
    {
    }

    public void setCharacterStream(Reader reader)
    {
    }

    public void setEncoding(String s)
    {
    }

    public void setStringData(String s)
    {
    }

    public String getSystemId()
    {
        return systemId;
    }

    public void setSystemId(String systemId)
    {
        this.systemId = systemId;
    }

    public BufferedInputStream getInputStream()
    {
        return inputStream;
    }

    public Input(String publicId, String sysId, InputStream input)
    {
        this.publicId = publicId;
        systemId = sysId;
        inputStream = new BufferedInputStream(input);
    }

    private String publicId;
    private String systemId;
    private final BufferedInputStream inputStream;
}
