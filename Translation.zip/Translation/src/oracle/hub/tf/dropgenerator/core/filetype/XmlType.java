// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   XmlType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.*;
import javax.xml.xpath.XPathExpressionException;
import oracle.hub.tf.dropgenerator.core.BomEntryError;
import oracle.hub.tf.dropgenerator.core.DropGenerator;
import org.xml.sax.SAXException;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            AbstractXmlFileType, XPathValidator, ValidationException, CachingEntityResolver

public class XmlType extends AbstractXmlFileType
{

    public XmlType(String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dropType)
    {
        super(typeCode, name, dropType);
        validating = true;
    }

    public void setValidating(boolean validating)
    {
        this.validating = validating;
    }

    public void setXpath(String xpathString)
        throws XPathExpressionException
    {
        if(xpathString != null && !xpathString.isEmpty())
            xpath = new XPathValidator(xpathString);
        else
            xpath = null;
    }

    public void loadSchema(InputStream is)
    {
        if(is == null)
            return;
        Schema schema = schemaFactory.newSchema(new StreamSource(is));
        schemaValidator = schema.newValidator();
        SAXException ex;
        if(is != null)
            try
            {
                is.close();
            }
            // Misplaced declaration of an exception variable
            catch(SAXException ex)
            {
                Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/XmlType.getName()).log(Level.SEVERE, null, ex);
            }
        break MISSING_BLOCK_LABEL_156;
        ex;
        DropGenerator.logger.log(Level.SEVERE, "Could not compile schema: {0}.xsd: {1}", new Object[] {
            getKey(), ex.getMessage()
        });
        if(is != null)
            try
            {
                is.close();
            }
            // Misplaced declaration of an exception variable
            catch(SAXException ex)
            {
                Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/XmlType.getName()).log(Level.SEVERE, null, ex);
            }
        break MISSING_BLOCK_LABEL_156;
        Exception exception;
        exception;
        if(is != null)
            try
            {
                is.close();
            }
            catch(IOException ex)
            {
                Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/XmlType.getName()).log(Level.SEVERE, null, ex);
            }
        throw exception;
    }

    public boolean detect(byte data[])
    {
        if(xpath != null)
            return checkPath(data, xpath.getXpathCompiled());
        if(schemaValidator != null)
            try
            {
                validateSchema(new ByteArrayInputStream(data), schemaValidator);
                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        else
            return false;
    }

    public void validate(byte data[])
        throws ValidationException
    {
        super.validate(data);
        if(validating)
            if(schemaValidator != null)
                validateSchema(new ByteArrayInputStream(data), schemaValidator);
            else
            if(xpath != null && !checkPath(data, xpath.getXpathCompiled()))
                throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidXML, (new StringBuilder()).append(getKey()).append(" must (at minimum) must conform to the following xpath expression: [").append(xpath.getXpath()).append("]. Please consult WPTG for more information.").toString(), null);
    }

    private boolean validating;
    private XPathValidator xpath;
    private static final SchemaFactory schemaFactory;
    private Validator schemaValidator;

    static 
    {
        schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        schemaFactory.setResourceResolver(CachingEntityResolver.getInstance());
    }
}
