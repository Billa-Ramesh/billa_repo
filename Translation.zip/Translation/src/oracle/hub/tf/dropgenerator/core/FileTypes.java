// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FileTypes.java

package oracle.hub.tf.dropgenerator.core;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.*;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            DropGenerator, PropertyLoader, Util

public class FileTypes
{

    public FileTypes()
    {
    }

    static void loadConfig()
        throws Exception
    {
        Properties config = PropertyLoader.loadProperties((new StringBuilder()).append(oracle/hub/tf/dropgenerator/core/FileTypes.getPackage().getName()).append(".config").toString());
        Iterator i$ = config.keySet().iterator();
        do
        {
            if(!i$.hasNext())
                break;
            Object keyCode = i$.next();
            String key = keyCode.toString();
            String keyComponents[] = key.split("\\.");
            if(keyComponents.length == 3)
            {
                DropGenerator.DropType dropType = DropGenerator.DropType.valueOf(keyComponents[1]);
                String fileType = keyComponents[2];
                String typeName = config.getProperty(key);
                String typeFilter = (new StringBuilder()).append(key).append(".filter").toString();
                String filterName = config.containsKey(typeFilter) ? config.getProperty(typeFilter) : "GenericType";
                AbstractFileType fileTypeInstance;
                Class fileTypeClass;
                try
                {
                    fileTypeClass = Class.forName((new StringBuilder()).append("oracle.hub.tf.dropgenerator.core.filetype.").append(filterName).toString());
                    fileTypeInstance = AbstractFileType.getFileType(fileTypeClass, fileType, typeName, dropType);
                }
                catch(ClassNotFoundException ex)
                {
                    DropGenerator.logger.log(Level.SEVERE, "Could not create filter by name: {0}", ex.getMessage());
                    throw ex;
                }
                ((HashMap)fileTypes.get(dropType)).put(fileType, fileTypeInstance);
                String extensionsKey = (new StringBuilder()).append(key).append(".ext").toString();
                if(config.containsKey(extensionsKey))
                {
                    String extensions = config.getProperty(extensionsKey);
                    addExtensionsForType(dropType, extensions, fileTypeInstance);
                }
                String defaultKey = (new StringBuilder()).append(key).append(".default").toString();
                if(config.containsKey(defaultKey))
                {
                    String defaultValues = config.getProperty(defaultKey);
                    String arr$[] = defaultValues.split(",");
                    int len$ = arr$.length;
                    for(int i$ = 0; i$ < len$; i$++)
                    {
                        String extension = arr$[i$];
                        extension = extension.trim().toLowerCase();
                        ((HashMap)defaultExtensions.get(dropType)).put(extension, fileTypeInstance);
                    }

                }
                String validatingKey = (new StringBuilder()).append(key).append(".validating").toString();
                if(config.containsKey(validatingKey))
                {
                    Boolean validating = Boolean.valueOf(Boolean.parseBoolean(config.getProperty(validatingKey)));
                    try
                    {
                        Method setValidating = fileTypeClass.getMethod("setValidating", new Class[] {
                            Boolean.TYPE
                        });
                        setValidating.invoke(fileTypeInstance, new Object[] {
                            validating
                        });
                    }
                    catch(Exception ex)
                    {
                        DropGenerator.logger.log(Level.SEVERE, "In order to set validating property the class {0} must contain setValidating(boolean) method: {1}", new Object[] {
                            fileTypeClass.getName(), ex.getMessage()
                        });
                        throw ex;
                    }
                }
                String xpathKey = (new StringBuilder()).append(key).append(".xpath").toString();
                if(config.containsKey(xpathKey))
                {
                    String xpath = config.getProperty(xpathKey).trim();
                    try
                    {
                        Method setXpath = fileTypeClass.getMethod("setXpath", new Class[] {
                            java/lang/String
                        });
                        setXpath.invoke(fileTypeInstance, new Object[] {
                            xpath
                        });
                    }
                    catch(Exception ex)
                    {
                        DropGenerator.logger.log(Level.SEVERE, "In order to set validating property the class {0} must contain setXpath(String) method: {1}", new Object[] {
                            fileTypeClass.getName(), ex.getMessage()
                        });
                        throw ex;
                    }
                }
                String schemaKey = (new StringBuilder()).append(key).append(".schema").toString();
                if(config.containsKey(schemaKey))
                    try
                    {
                        Method setSchema = fileTypeClass.getMethod("loadSchema", new Class[] {
                            java/io/InputStream
                        });
                        InputStream schemaStream = oracle/hub/tf/dropgenerator/core/DropGenerator.getResourceAsStream((new StringBuilder()).append("xsd/").append(fileTypeInstance.getKey()).append(".xsd").toString());
                        if(schemaStream == null || schemaStream.available() == 0)
                            throw new Exception((new StringBuilder()).append("Could not locate schema xsd/").append(fileTypeInstance.getKey()).append(".xsd").toString());
                        setSchema.invoke(fileTypeInstance, new Object[] {
                            schemaStream
                        });
                    }
                    catch(Exception ex)
                    {
                        DropGenerator.logger.log(Level.SEVERE, "Could not load schema for {0}: {1}", new Object[] {
                            fileTypeInstance.getKey(), ex.getMessage()
                        });
                        throw ex;
                    }
                String patternKey = (new StringBuilder()).append(key).append(".pattern").toString();
                if(config.containsKey(patternKey))
                {
                    String pattern = config.getProperty(patternKey).trim();
                    ((HashMap)extensionPatterns.get(dropType)).put(fileTypeInstance, Pattern.compile(pattern, 66));
                }
                String regexPattern = (new StringBuilder()).append(key).append(".regex").toString();
                int i = 1;
                while(config.containsKey(regexPattern)) 
                {
                    String regex = config.getProperty(regexPattern);
                    try
                    {
                        Method setRegex = fileTypeClass.getMethod("addRegex", new Class[] {
                            java/lang/String
                        });
                        setRegex.invoke(fileTypeInstance, new Object[] {
                            regex
                        });
                    }
                    catch(Exception ex)
                    {
                        DropGenerator.logger.log(Level.SEVERE, "In order to define regular expression detection, the class {0} must contain setRegex(String) method: {1}", new Object[] {
                            fileTypeClass.getName(), ex.getMessage()
                        });
                        throw ex;
                    }
                    i++;
                    regexPattern = (new StringBuilder()).append(regexPattern.substring(0, regexPattern.length() - (i != 2 ? 1 : 0))).append(i).toString();
                }
            }
        } while(true);
    }

    private static void addExtensionsForType(DropGenerator.DropType dropType, String extensions, AbstractFileType fileType)
    {
        if(extensions == null || extensions.trim().isEmpty())
            return;
        String arr$[] = extensions.split(",");
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            String extension = arr$[i$];
            extension = extension.trim().toLowerCase();
            SortedSet typesForExt;
            if(!((HashMap)extensionTypes.get(dropType)).containsKey(extension))
                typesForExt = new TreeSet();
            else
                typesForExt = (SortedSet)((HashMap)extensionTypes.get(dropType)).get(extension);
            typesForExt.add(fileType);
            ((HashMap)extensionTypes.get(dropType)).put(extension, typesForExt);
        }

    }

    public static AbstractFileType getFileType(DropGenerator.DropType dt, String code)
    {
        AbstractFileType type = (AbstractFileType)((HashMap)fileTypes.get(DropGenerator.DropType.COMMON)).get(code);
        if(type != null)
            return type;
        type = (AbstractFileType)((HashMap)fileTypes.get(dt)).get(code);
        if(type != null)
            return type;
        else
            return AbstractFileType.EMPTY_FILETYPE;
    }

    public static void addUserExtensionType(DropGenerator.DropType dt, String extension, AbstractFileType type)
    {
        if(type == null || extension == null || !type.isValid() || extension.isEmpty())
            return;
        extension = extension.toLowerCase();
        SortedSet types;
        if(userExtensionTypes.containsKey(extension))
        {
            types = (SortedSet)userExtensionTypes.get(extension);
            if(types.contains(type))
                return;
        } else
        {
            types = new TreeSet();
        }
        types.add(type);
        userExtensionTypes.put(extension, types);
    }

    public static Set getUserRecommendedTypes(String ext)
    {
        ext = ext.toLowerCase();
        if(!userExtensionTypes.containsKey(ext))
            return Collections.emptySet();
        else
            return Collections.unmodifiableSet((Set)userExtensionTypes.get(ext));
    }

    public static void clearUserExtensionTypes()
    {
        userExtensionTypes.clear();
    }

    static Set getTypesForFile(DropGenerator.DropType dt, String filename)
    {
        TreeSet available = new TreeSet();
        Iterator i$ = ((HashMap)extensionPatterns.get(dt)).entrySet().iterator();
        do
        {
            if(!i$.hasNext())
                break;
            java.util.Map.Entry entry = (java.util.Map.Entry)i$.next();
            try
            {
                Matcher regexMatcher = ((Pattern)entry.getValue()).matcher(filename);
                if(regexMatcher.find())
                {
                    available.add(entry.getKey());
                    return available;
                }
            }
            catch(PatternSyntaxException ex) { }
        } while(true);
        available.addAll(getTypesForExt(dt, Util.getExtension(filename)));
        if(available.isEmpty())
            return Collections.emptySet();
        else
            return Collections.unmodifiableSet(available);
    }

    private static Set getTypesForExt(DropGenerator.DropType dt, String ext)
    {
        ext = ext.toLowerCase();
        TreeSet available = new TreeSet();
        SortedSet common = (SortedSet)((HashMap)extensionTypes.get(DropGenerator.DropType.COMMON)).get(ext);
        if(common != null)
            available.addAll(common);
        SortedSet specific = (SortedSet)((HashMap)extensionTypes.get(dt)).get(ext);
        if(specific != null)
            available.addAll(specific);
        if(available.isEmpty())
            return Collections.emptySet();
        else
            return Collections.unmodifiableSet(available);
    }

    public static TreeSet getTypesAll(DropGenerator.DropType dt)
    {
        TreeSet returnTypes = new TreeSet(((HashMap)fileTypes.get(dt)).values());
        returnTypes.addAll(((HashMap)fileTypes.get(DropGenerator.DropType.COMMON)).values());
        return returnTypes;
    }

    private static final EnumMap fileTypes;
    private static final EnumMap extensionTypes;
    protected static final EnumMap defaultExtensions;
    private static final HashMap userExtensionTypes = new HashMap();
    private static final EnumMap extensionPatterns;

    static 
    {
        fileTypes = new EnumMap(oracle/hub/tf/dropgenerator/core/DropGenerator$DropType);
        extensionPatterns = new EnumMap(oracle/hub/tf/dropgenerator/core/DropGenerator$DropType);
        extensionTypes = new EnumMap(oracle/hub/tf/dropgenerator/core/DropGenerator$DropType);
        defaultExtensions = new EnumMap(oracle/hub/tf/dropgenerator/core/DropGenerator$DropType);
        DropGenerator.DropType arr$[] = DropGenerator.DropType.values();
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            DropGenerator.DropType dropType = arr$[i$];
            fileTypes.put(dropType, new HashMap());
            extensionPatterns.put(dropType, new HashMap());
            extensionTypes.put(dropType, new HashMap());
            defaultExtensions.put(dropType, new HashMap());
        }

        try
        {
            loadConfig();
        }
        catch(Exception ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Config load failed", ex.getMessage());
        }
    }
}
