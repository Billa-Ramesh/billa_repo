// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   RuleParser.java

package oracle.hub.tf.dropgenerator.core;

import java.io.*;
import java.net.URI;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.*;
import javax.xml.bind.*;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;
import oracle.hub.tf.dropgenerator.core.rules.Rule;
import oracle.hub.tf.dropgenerator.core.rules.Rules;
import oracle.hub.tf.dropgenerator.core.rules.Token;
import org.xml.sax.SAXException;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            DropGenerator, TokenConfigValidationEventHandler, BomEntry, Bom, 
//            TargetFile, FileTypes, Util

public class RuleParser
{

    public RuleParser()
    {
    }

    public static Rules loadRules(InputStream tokenRulesFile)
        throws JAXBException
    {
        SchemaFactory sf = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        InputStream tokenSchemaInputStream = oracle/hub/tf/dropgenerator/core/DropGenerator.getResourceAsStream("/xsd/rules.xsd");
        Schema tokenSchema = null;
        try
        {
            tokenSchema = sf.newSchema(new StreamSource(tokenSchemaInputStream));
        }
        catch(SAXException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Invalid language token schema (/xsd/rules.xsd)!");
        }
        DropGenerator.logger.log(Level.INFO, "Applying language tokens");
        JAXBContext jaxbContext = JAXBContext.newInstance("oracle.hub.tf.dropgenerator.core.rules");
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        unmarshaller.setSchema(tokenSchema);
        unmarshaller.setEventHandler(new TokenConfigValidationEventHandler());
        Rules rules = (Rules)unmarshaller.unmarshal(tokenRulesFile);
        try
        {
            tokenRulesFile.close();
        }
        catch(IOException ex) { }
        ArrayList invalid = new ArrayList();
        String currentRegex = null;
        Iterator i$ = rules.getRule().iterator();
        do
        {
            if(!i$.hasNext())
                break;
            Rule rule = (Rule)i$.next();
            try
            {
                currentRegex = rule.getSource();
                Pattern compiled = Pattern.compile(currentRegex, 2);
                patternCache.put(currentRegex, compiled);
                if(rule.getDirectory() != null)
                {
                    currentRegex = rule.getDirectory();
                    compiled = Pattern.compile(currentRegex, 2);
                    patternCache.put(currentRegex, compiled);
                }
            }
            catch(PatternSyntaxException ex)
            {
                DropGenerator.logger.log(Level.WARNING, "Invalid pattern detected in config file [{0}]: {1}. Rule will not be used.", new Object[] {
                    currentRegex, ex.getMessage()
                });
                invalid.add(rule);
            }
        } while(true);
        rules.getRule().removeAll(invalid);
        return rules;
    }

    public static void applyRules(Bom bom, InputStream tokenRulesFile)
        throws JAXBException
    {
        applyRules(bom, loadRules(tokenRulesFile));
    }

    protected static void applyRules(Bom bom, File tokenRulesFile)
        throws JAXBException, FileNotFoundException
    {
        applyRules(bom, loadRules(new FileInputStream(tokenRulesFile)));
    }

    public static void applyRules(Bom bom, Rules tokenRules)
    {
        DropGenerator.logger.log(Level.INFO, "Applying rules from XML");
        HashSet matchedEntries = new HashSet();
        Iterator i$ = tokenRules.getRule().iterator();
label0:
        do
        {
            if(i$.hasNext())
            {
                Rule rule = (Rule)i$.next();
                DropGenerator.logger.log(Level.FINE, "Running rule {0}", new Object[] {
                    rule.getSource()
                });
                if(rule.getType().equals("file"))
                {
                    Iterator i$ = bom.iterator();
                    do
                    {
                        BomEntry b;
                        Matcher regexMatcher;
                        do
                        {
                            do
                            {
                                do
                                {
                                    if(!i$.hasNext())
                                        continue label0;
                                    b = (BomEntry)i$.next();
                                } while(tokenRules.isExclusive() && matchedEntries.contains(b));
                                regexMatcher = ruleFires(rule, b.getUri());
                            } while(regexMatcher == null);
                            if(applyFileType(rule, bom, b))
                                matchedEntries.add(b);
                        } while(rule.getToken() == null || rule.getToken().isEmpty() || !verifyGroupTokens(regexMatcher, rule.getToken()));
                        String newFileName = replaceGroupsWithTokens(regexMatcher, rule.getToken());
                        b.setTarget((new StringBuilder()).append(b.getSourcePathRelative()).append("/").append(newFileName).toString());
                        matchedEntries.add(b);
                    } while(true);
                }
                Matcher targetMatcher = null;
                if(rule.getTarget() != null)
                    targetMatcher = detectCapturingGroups.matcher(rule.getTarget());
                Iterator i$ = bom.iterator();
                do
                {
                    BomEntry b;
                    Matcher sourceMatcher;
                    do
                    {
                        do
                        {
                            if(!i$.hasNext())
                                continue label0;
                            b = (BomEntry)i$.next();
                        } while(tokenRules.isExclusive() && matchedEntries.contains(b));
                        sourceMatcher = ruleFires(rule, b.getUri());
                    } while(sourceMatcher == null);
                    if(targetMatcher != null && sourceMatcher.groupCount() > 0)
                    {
                        DropGenerator.logger.log(Level.WARNING, "Skipping rule {0}: When target is defined, the source pattern must NOT contain capturing groups as target's capturing groups will be used instead.", sourceMatcher.pattern());
                        continue label0;
                    }
                    if(!verifyGroupTokens(sourceMatcher, rule.getToken()) || !verifyGroupTokens(targetMatcher, rule.getToken()))
                    {
                        DropGenerator.logger.log(Level.WARNING, "Skipping rule {0}: Unmatched capturing groups found. Each group must have a corresponding token.", sourceMatcher.pattern());
                        continue label0;
                    }
                    String newDirName;
                    if(targetMatcher != null && rule.getToken() == null)
                        newDirName = rule.getTarget();
                    else
                    if(targetMatcher != null)
                        newDirName = replaceMatchesWithTokens(targetMatcher, rule.getToken());
                    else
                        newDirName = replaceGroupsWithTokens(sourceMatcher, rule.getToken());
                    String currentFileName = b.getTarget().toString();
                    int slashIndex = currentFileName.lastIndexOf('/');
                    if(slashIndex >= 0)
                        currentFileName = currentFileName.substring(slashIndex + 1);
                    b.setTarget((new StringBuilder()).append(newDirName).append("/").append(currentFileName).toString());
                    matchedEntries.add(b);
                } while(true);
            }
            return;
        } while(true);
    }

    private static boolean applyFileType(Rule rule, Bom bom, BomEntry b)
    {
        if(rule.getFiletype() == null || rule.getFiletype().trim().isEmpty())
            return false;
        AbstractFileType ft = FileTypes.getFileType(bom.getDropType(), rule.getFiletype());
        if(ft.equals(AbstractFileType.EMPTY_FILETYPE))
        {
            DropGenerator.logger.log(Level.WARNING, "The file type {0} specified in the rules file does not exist and will not be applied to entry {1}", new Object[] {
                rule.getFiletype(), b.getSourceRelative()
            });
            return false;
        } else
        {
            b.setActive(true);
            b.setFileType(ft);
            return true;
        }
    }

    private static boolean verifyGroupTokens(Matcher regexMatcher, List tokens)
    {
        if(regexMatcher == null)
            return true;
        for(int i = 1; i <= regexMatcher.groupCount(); i++)
            if(findTokenForGroup(tokens, i) == null)
            {
                DropGenerator.logger.log(Level.WARNING, "Skipping rule {0}. Could not match capture group {1} to a valid replacement token.", new Object[] {
                    regexMatcher.pattern().toString(), Integer.valueOf(i)
                });
                return false;
            }

        regexMatcher.reset().find();
        for(int i = 1; regexMatcher.find(); i++)
            if(findTokenForGroup(tokens, i) == null)
            {
                DropGenerator.logger.log(Level.WARNING, "Skipping rule {0}. Could not match matching group {1} to a valid replacement token.", new Object[] {
                    regexMatcher.pattern().toString(), Integer.valueOf(i)
                });
                return false;
            }

        return true;
    }

    private static String replaceGroupsWithTokens(Matcher regexMatcher, List tokens)
    {
        regexMatcher.reset().find();
        StringBuilder sb = new StringBuilder(regexMatcher.group());
        int offsetModifier = 0;
        for(int i = 1; i <= regexMatcher.groupCount(); i++)
        {
            String match = regexMatcher.group(i);
            String languageToken = findTokenForGroup(tokens, i);
            if(match.isEmpty())
                sb.insert(regexMatcher.start(i) + offsetModifier, languageToken);
            else
                sb.replace(regexMatcher.start(i) + offsetModifier, regexMatcher.end(i) + offsetModifier, languageToken);
            offsetModifier += languageToken.length() - match.length();
        }

        return sb.toString();
    }

    private static String replaceMatchesWithTokens(Matcher regexMatcher, List tokens)
    {
        StringBuffer resultString = new StringBuffer();
        regexMatcher.reset();
        for(int i = 1; regexMatcher.find(); i++)
            try
            {
                regexMatcher.appendReplacement(resultString, findTokenForGroup(tokens, i));
            }
            catch(IllegalStateException ex) { }
            catch(IllegalArgumentException ex) { }
            catch(IndexOutOfBoundsException ex) { }

        regexMatcher.appendTail(resultString);
        return resultString.toString();
    }

    private static String findTokenForGroup(List tokens, int group)
    {
        for(Iterator i$ = tokens.iterator(); i$.hasNext();)
        {
            Token t = (Token)i$.next();
            if(t.getGroup() == group)
                return t.getReplacement();
        }

        return null;
    }

    public static Matcher ruleFires(Rule rule, URI uri)
    {
        String sourcePathRelative = Util.getUriPathNoFilename(DropGenerator.relativize(uri));
        Pattern sourcePattern = cacheGet(rule.getSource());
        Matcher sourceMatcher;
        if(rule.getType().equals("file"))
        {
            if(rule.getDirectory() != null)
            {
                String directoryFilter = rule.getDirectory();
                try
                {
                    Pattern directoryFilterPattern = cacheGet(directoryFilter);
                    if(directoryFilterPattern == null)
                    {
                        directoryFilterPattern = Pattern.compile(directoryFilter, 2);
                        patternCache.put(directoryFilter, directoryFilterPattern);
                    }
                    Matcher directoryMatcher = directoryFilterPattern.matcher(sourcePathRelative);
                    if(!directoryMatcher.matches())
                        return null;
                }
                catch(PatternSyntaxException ex)
                {
                    DropGenerator.logger.log(Level.WARNING, "Directory filter {0} is invalid: {1}. Skipping...", new Object[] {
                        directoryFilter, ex.getMessage()
                    });
                }
            }
            sourceMatcher = sourcePattern.matcher(Util.getFilenameFromUri(uri));
            if(!sourceMatcher.matches())
                return null;
        } else
        {
            sourceMatcher = sourcePattern.matcher(sourcePathRelative);
            if(!sourceMatcher.matches())
                return null;
        }
        return sourceMatcher;
    }

    private static Pattern cacheGet(String pattern)
        throws PatternSyntaxException
    {
        if(pattern == null)
        {
            return null;
        } else
        {
            Pattern compiled = Pattern.compile(pattern, 2);
            patternCache.put(pattern, compiled);
            return compiled;
        }
    }

    static final Pattern detectCapturingGroups = Pattern.compile("\\(.*?\\)(?<!\\\\\\))");
    private static HashMap patternCache = new HashMap();

}
