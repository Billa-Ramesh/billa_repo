// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ZipDrop.java

package oracle.hub.tf.dropgenerator.core;

import java.io.*;
import java.net.*;
import java.util.HashSet;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.swing.SwingWorker;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            BomEntry, DropGenerator, Bom

class ZipDrop extends SwingWorker
{

    public ZipDrop(File zip, Bom b)
    {
        filesToZip = new HashSet();
        bom = b;
        String zipFileName = zip.getName().replaceAll(" ", "").toLowerCase();
        zipFile = new File(zip.getParentFile(), zipFileName);
    }

    protected Void doInBackground()
    {
        int totalFiles;
        File tempZipBom;
        DropGenerator.FormsVersion formsVersion;
        DropGenerator.logger.log(Level.INFO, "Kit generation process started");
        Iterator i$ = bom.iterator();
        do
        {
            if(!i$.hasNext())
                break;
            BomEntry b = (BomEntry)i$.next();
            if(isCancelled())
                return null;
            if(b.getFileType().getKey().equals("formreference") || b.isActive() && b.isValid())
                filesToZip.add(b);
        } while(true);
        if(filesToZip.isEmpty())
        {
            DropGenerator.logger.warning("No valid files found! Kit not generated.");
            cancel(false);
            return null;
        }
        totalFiles = filesToZip.size();
        try
        {
            zipOut = new ZipOutputStream(new FileOutputStream(zipFile));
        }
        catch(FileNotFoundException e1)
        {
            DropGenerator.logger.severe("Could not create translation kit at specified location! Aborting...");
            cancel(false);
            return null;
        }
        String productName = bom.getMetaData(Bom.MetaData.productname);
        StringBuilder bomName = new StringBuilder();
        bomName.append(productName).append("/").append(productName);
        if(!bom.getMetaData(Bom.MetaData.productmodule).isEmpty())
            bomName.append("-").append(bom.getMetaData(Bom.MetaData.productmodule));
        bomName.append(".bom");
        tempZipBom = bom.write(true);
        try
        {
            addFileToKit(zipOut, tempZipBom.toURI().toURL(), bomName.toString());
        }
        catch(MalformedURLException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not convert file {0} to a valid URL: {1}", new Object[] {
                tempZipBom.getAbsolutePath(), ex.getMessage()
            });
            cancel(false);
            return null;
        }
        tempZipBom.delete();
        formsVersion = bom.getFormsVersion();
        if(formsVersion == null)
            break MISSING_BLOCK_LABEL_448;
        File tempFormsVersion;
        tempFormsVersion = File.createTempFile("formsversion", null);
        try
        {
            addFileToKit(zipOut, tempFormsVersion.toURI().toURL(), (new StringBuilder()).append("ReferenceFiles/formsversion.").append(formsVersion.name).toString());
        }
        catch(MalformedURLException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not convert file {0} to a valid URL: {1}", new Object[] {
                tempZipBom.getAbsolutePath(), ex.getMessage()
            });
            cancel(false);
            return null;
        }
        try
        {
            tempFormsVersion.delete();
        }
        catch(IOException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not create/add formsVersion file to archive!");
        }
        int progressCounter = 0;
        Iterator i$ = filesToZip.iterator();
        do
        {
            if(!i$.hasNext())
                break;
            BomEntry b = (BomEntry)i$.next();
            if(isCancelled())
                return null;
            setProgress((int)(((double)(++progressCounter) * 100D) / (double)totalFiles));
            firePropertyChange("note", "", (new StringBuilder()).append("Archiving file ").append(progressCounter + 1).append(" of ").append(totalFiles).toString());
            if(b.getFileType().getKey().equals("formreference") || b.getFileType().getKey().equals("fmb"))
            {
                addFileToKit(zipOut, b.getUrl(), (new StringBuilder()).append("ReferenceFiles/").append(b.getName()).toString());
                if(b.getFileType().getKey().equals("formreference"))
                    continue;
            }
            addFileToKit(zipOut, b.getUrl(), b.getBomSourceString(true));
        } while(true);
        try
        {
            zipOut.close();
        }
        catch(IOException e)
        {
            DropGenerator.logger.severe("Could not finish writing translation kit! Operation aborted.");
            cancel(false);
            return null;
        }
        return null;
    }

    protected void done()
    {
        setProgress(100);
        if(isCancelled())
        {
            if(zipFile.exists())
                zipFile.delete();
            DropGenerator.logger.warning("Drop generation process cancelled");
        } else
        {
            DropGenerator.logger.log(Level.INFO, "Translation kit successfully created in {0}", zipFile.getAbsolutePath());
        }
    }

    private void addFileToKit(ZipOutputStream out, URL url, String zipPath)
    {
        if(isCancelled())
            return;
        byte buffer[] = new byte[16384];
        InputStream in;
        try
        {
            in = url.openStream();
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.WARNING, "Could not open {0} for reading!", url.toString());
            return;
        }
        ZipEntry entry = new ZipEntry(zipPath);
        try
        {
            out.putNextEntry(entry);
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.WARNING, "Could not add file {0} to the archive. Duplicate form reference?", url.toString());
            return;
        }
        try
        {
            int len;
            for(; (len = in.read(buffer)) > 0 && !isCancelled(); out.write(buffer, 0, len));
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.WARNING, "Could not write file {0} into the archive!", url.toString());
            return;
        }
        try
        {
            out.closeEntry();
            in.close();
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.WARNING, "Could not close streams for file {0}!", url.toString());
        }
    }

    protected volatile Object doInBackground()
        throws Exception
    {
        return doInBackground();
    }

    private HashSet filesToZip;
    private ZipOutputStream zipOut;
    private Bom bom;
    private File zipFile;
}
