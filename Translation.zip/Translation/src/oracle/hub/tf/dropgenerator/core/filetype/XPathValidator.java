// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   XPathValidator.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.xpath.*;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

class XPathValidator
{

    public XPathValidator(String xpath)
        throws XPathExpressionException
    {
        this.xpath = xpath;
        XPathExpression initXpath = null;
        try
        {
            initXpath = xpathCompiler.compile(xpath);
        }
        catch(XPathExpressionException e)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not compile xpath expression: {0}", xpath);
            throw e;
        }
        xpathCompiled = initXpath;
    }

    public String getXpath()
    {
        return xpath;
    }

    public XPathExpression getXpathCompiled()
    {
        return xpathCompiled;
    }

    public boolean equals(Object obj)
    {
        if(obj == null)
            return false;
        if(getClass() != obj.getClass())
            return false;
        XPathValidator other = (XPathValidator)obj;
        return xpath != null ? xpath.equals(other.xpath) : other.xpath == null;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = 83 * hash + (xpath == null ? 0 : xpath.hashCode());
        return hash;
    }

    public String toString()
    {
        return xpath;
    }

    private final String xpath;
    private final XPathExpression xpathCompiled;
    private static final XPath xpathCompiler = XPathFactory.newInstance().newXPath();

}
