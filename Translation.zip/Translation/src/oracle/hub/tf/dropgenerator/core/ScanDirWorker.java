// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ScanDirWorker.java

package oracle.hub.tf.dropgenerator.core;

import java.io.*;
import java.net.URI;
import java.net.URLEncoder;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingWorker;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.xml.bind.JAXBException;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;
import oracle.hub.tf.dropgenerator.core.rules.Rule;
import oracle.hub.tf.dropgenerator.core.rules.Rules;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            BomEntry, DropGenerator, Bom, Util, 
//            FileTypes, RuleParser, BomEntryError

class ScanDirWorker extends SwingWorker
{

    public ScanDirWorker(Bom b, File id, Rules tokenRules)
    {
        root = null;
        importDir = id;
        bom = b;
        root = new DefaultMutableTreeNode(importDir.toURI());
        this.tokenRules = tokenRules;
    }

    protected DefaultMutableTreeNode doInBackground()
    {
        setProgress(1);
        firePropertyChange("note", "", "Counting files... 0");
        innerListFiles(root);
        int i = 1;
        for(Iterator i$ = files.iterator(); i$.hasNext();)
        {
            URI u = (URI)i$.next();
            firePropertyChange("note", "", (new StringBuilder()).append("Loading file ").append(DropGenerator.relativize(u)).append(" [").append(i).append(" / ").append(files.size()).append("]").toString());
            if(isCancelled())
                return null;
            Set typesForFile = FileTypes.getTypesForFile(bom.getDropType(), Util.getFilenameFromUri(u));
            if(tokenRules == null || tokenRules != null && (!tokenRules.isFilter() || tokenRules.isFilter() && (isIncluded(u) || typesForFile.contains(FileTypes.getFileType(bom.getDropType(), "formreference")))))
            {
                BomEntry b = new BomEntry(bom, u);
                bom.add(b);
            }
            setProgress((int)Math.ceil((99D * (double)i) / (double)files.size()));
            i++;
        }

        if(bom.getFile().exists())
        {
            firePropertyChange("note", "", "Loading configuration");
            bom.loadConfig();
        }
        if(isCancelled())
            return null;
        postProcess();
        int warnings = 0;
        int errors = 0;
        for(Iterator i$ = bom.iterator(); i$.hasNext();)
        {
            BomEntry b = (BomEntry)i$.next();
            Iterator i$;
            for(i$ = b.getIssues(Level.SEVERE).values().iterator(); i$.hasNext();)
            {
                List list = (List)i$.next();
                errors += list.size();
            }

            i$ = b.getIssues(Level.WARNING).values().iterator();
            while(i$.hasNext()) 
            {
                List list = (List)i$.next();
                warnings += list.size();
            }
        }

        if(errors > 0)
            DropGenerator.logger.log(Level.WARNING, "{0} file errors", Integer.valueOf(errors));
        if(warnings > 0)
            DropGenerator.logger.log(Level.WARNING, "{0} file warnings", Integer.valueOf(warnings));
        DropGenerator.logger.log(Level.INFO, "Directory scan complete!", Boolean.TRUE);
        return root;
    }

    private void postProcess()
    {
        if(bom.getDropType() == DropGenerator.DropType.UA)
        {
            Iterator i$ = bom.iterator();
            do
            {
                if(!i$.hasNext())
                    break;
                final BomEntry b = (BomEntry)i$.next();
                if(b.hasFileType() && b.getFileType().getKey().equals("solbook"))
                {
                    DropGenerator.logger.log(Level.INFO, "SolBook content detected. Applying default SolBook drop rules.");
                    InputStream solbookRules = oracle/hub/tf/dropgenerator/core/rules/Rules.getResourceAsStream("solbook.xml");
                    Rules rules = null;
                    try
                    {
                        rules = RuleParser.loadRules(solbookRules);
                    }
                    catch(JAXBException ex)
                    {
                        DropGenerator.logger.log(Level.SEVERE, "Problem loading solbook rules file!");
                    }
                    RuleParser.applyRules(bom, rules);
                    break;
                }
                if(b.hasFileType() && b.getFileType().getKey().equals("UA") && b.getUri().getScheme().equals("file") && Util.isArchive(b.getUri()))
                {
                    File dir = (new File(b.getUri())).getParentFile();
                    FilenameFilter ff = new FilenameFilter() {

                        public boolean accept(File dir, String name)
                        {
                            return name.equals(Util.stripExtension(b.getName()));
                        }

                        final BomEntry val$b;
                        final ScanDirWorker this$0;

            
            {
                this$0 = ScanDirWorker.this;
                b = bomentry;
                super();
            }
                    }
;
                    File currentDirFiles[] = dir.listFiles(ff);
                    if(currentDirFiles != null && currentDirFiles.length != 0)
                        b.addError(BomEntryError.ErrorType.NotExtractable, (new StringBuilder()).append("The directory ").append(b.getSourcePathRelative()).append(" already contains a subdirectory named ").append(Util.stripExtension(b.getName())).append(". Therefore, this archive cannot be processed, and all the internal files will not be included in the generated drop.").toString());
                }
            } while(true);
        }
        if(tokenRules != null)
            RuleParser.applyRules(bom, tokenRules);
        checkNestedSolbook();
    }

    public void checkNestedSolbook()
    {
        AbstractFileType sbt = FileTypes.getFileType(DropGenerator.DropType.UA, "solbook");
        ArrayList bookFolders = new ArrayList();
        FilenameFilter ff = new FilenameFilter() {

            public boolean accept(File dir, String name)
            {
                return name.endsWith(".book") || name.endsWith(".xml");
            }

            final ScanDirWorker this$0;

            
            {
                this$0 = ScanDirWorker.this;
                super();
            }
        }
;
        Enumeration dirTree = root.breadthFirstEnumeration();
label0:
        do
        {
            if(dirTree.hasMoreElements())
            {
                DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode)dirTree.nextElement();
                URI currentDir = (URI)currentNode.getUserObject();
                if(!currentDir.getScheme().equals("file"))
                    continue;
                File currentDirFiles[] = (new File(currentDir)).listFiles(ff);
                if(currentDirFiles == null)
                    continue;
                File arr$[] = currentDirFiles;
                int len$ = arr$.length;
                int i$ = 0;
                do
                {
                    if(i$ >= len$)
                        continue label0;
                    File f = arr$[i$];
                    int entryIndex = bom.indexOf(f.toURI());
                    if(entryIndex >= 0 && bom.get(entryIndex).getFileType().equals(sbt))
                    {
                        bookFolders.add(currentNode);
                        Iterator i$ = bookFolders.iterator();
                        DefaultMutableTreeNode bf;
                        do
                        {
                            if(!i$.hasNext())
                                continue label0;
                            bf = (DefaultMutableTreeNode)i$.next();
                        } while(bf.equals(currentNode) || !currentNode.isNodeAncestor(bf));
                        BomEntry nestedSolbook = bom.get(entryIndex);
                        String relativeParent = DropGenerator.relativize((URI)bf.getUserObject());
                        relativeParent = relativeParent.isEmpty() ? "import directory" : relativeParent;
                        String relativeNested = nestedSolbook.getSourceRelative();
                        nestedSolbook.addError(BomEntryError.ErrorType.NestedSolbook, (new StringBuilder()).append("SolBook (.book) files can't be nested. Book ").append(relativeNested).append(" clashes with book in ").append(relativeParent).toString());
                        continue label0;
                    }
                    i$++;
                } while(true);
            }
            return;
        } while(true);
    }

    private boolean isIncluded(URI u)
    {
        boolean matches = false;
        for(Iterator i$ = tokenRules.getRule().iterator(); i$.hasNext();)
        {
            Rule rule = (Rule)i$.next();
            if(RuleParser.ruleFires(rule, u) != null)
            {
                matches = true;
                if(rule.isIgnore() != null && rule.isIgnore().booleanValue())
                    return false;
            }
        }

        if(!matches)
            DropGenerator.logger.log(Level.FINE, "Ignoring {0} because it doesn't match any rules or is explicitly ignored.", new Object[] {
                u.toString()
            });
        return matches;
    }

    protected void process(List list)
    {
    }

    protected void done()
    {
        if(isCancelled())
        {
            setProgress(100);
            return;
        } else
        {
            bom.write();
            setProgress(100);
            return;
        }
    }

    private void innerListFiles(DefaultMutableTreeNode parent)
    {
        if(isCancelled())
            return;
        File innerFiles[] = null;
        URI parentObject = (URI)parent.getUserObject();
        if(parentObject.getScheme().equals("file"))
        {
            File currentFile = new File(parentObject);
            if(currentFile.isFile())
                return;
            innerFiles = currentFile.listFiles();
        }
        if(innerFiles != null)
        {
            for(int i = 0; i < innerFiles.length; i++)
            {
                File currentFile = innerFiles[i];
                URI currentFileUri = currentFile.toURI();
                if(currentFile.isDirectory())
                {
                    DefaultMutableTreeNode currentNode = new DefaultMutableTreeNode(currentFileUri);
                    parent.add(currentNode);
                    innerListFiles(currentNode);
                    continue;
                }
                if(bom.getDropType().equals(DropGenerator.DropType.UA) && Util.isArchiveFile(currentFileUri))
                    try
                    {
                        DefaultMutableTreeNode jarTree = generateJarTree(currentFile);
                        parent.add(jarTree);
                    }
                    catch(IOException ex)
                    {
                        DropGenerator.logger.log(Level.WARNING, "Could not read contents of JAR file {0} : {1}", new Object[] {
                            parentObject.getPath(), ex.getMessage()
                        });
                    }
                if(Util.getExtension(currentFile).equals("bom") || Util.getExtension(currentFile).equals("wptg"))
                    continue;
                files.add(currentFileUri);
                if(files.size() % 50 == 0)
                    firePropertyChange("note", "", (new StringBuilder()).append("Counting files... ").append(files.size()).toString());
            }

        }
    }

    private DefaultMutableTreeNode generateJarTree(File file)
        throws IOException
    {
        JarFile jarFile = new JarFile(file);
        String jarUri = (new StringBuilder()).append("jar:").append(file.toURI()).append("!/").toString();
        Enumeration entries = jarFile.entries();
        DefaultMutableTreeNode jarTree = new DefaultMutableTreeNode(file.toURI());
        do
        {
            if(!entries.hasMoreElements())
                break;
            JarEntry element = (JarEntry)entries.nextElement();
            String split[] = element.getName().split("/");
            DefaultMutableTreeNode currentJarNode = (DefaultMutableTreeNode)jarTree.getRoot();
            for(int j = 0; j < split.length - (element.isDirectory() ? 0 : 1); j++)
            {
                String pathElement = split[j];
                if(pathElement.isEmpty())
                    break;
                StringBuilder sb = new StringBuilder();
                for(int k = 0; k < j; k++)
                    sb.append(split[k]).append("/");

                URI jarPathUri = URI.create((new StringBuilder()).append(jarUri).append((new StringBuilder()).append(sb.toString()).append(pathElement).toString().replace(" ", "%20")).append("/").toString());
                DefaultMutableTreeNode childNode = findChild(currentJarNode, jarPathUri);
                if(childNode == null)
                {
                    childNode = new DefaultMutableTreeNode(jarPathUri);
                    currentJarNode.add(childNode);
                }
                currentJarNode = childNode;
            }

            if(!element.isDirectory())
                files.add(URI.create((new StringBuilder()).append(jarUri).append(URLEncoder.encode(element.getName(), "UTF-8").replace("+", "%20").replace("%2F", "/")).toString()));
        } while(true);
        return jarTree;
    }

    private DefaultMutableTreeNode findChild(DefaultMutableTreeNode root, URI search)
    {
        for(Enumeration children = root.children(); children.hasMoreElements();)
        {
            DefaultMutableTreeNode child = (DefaultMutableTreeNode)children.nextElement();
            if(((URI)child.getUserObject()).equals(search))
                return child;
        }

        return null;
    }

    protected volatile Object doInBackground()
        throws Exception
    {
        return doInBackground();
    }

    private final ArrayList files = new ArrayList();
    private DefaultMutableTreeNode root;
    private final Bom bom;
    private final File importDir;
    private Rules tokenRules;
}
