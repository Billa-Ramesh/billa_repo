// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ValidationException.java

package oracle.hub.tf.dropgenerator.core.filetype;

import com.sun.org.apache.xerces.internal.impl.io.MalformedByteSequenceException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import oracle.hub.tf.dropgenerator.core.BomEntryError;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class ValidationException extends Exception
{

    public ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType errorType, String message, Throwable cause)
    {
        super(message, cause);
        this.errorType = errorType;
    }

    public ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType errorType, String message, Throwable cause, Collection otherExceptions)
    {
        super(message, cause);
        this.errorType = errorType;
        this.otherExceptions = otherExceptions;
    }

    public oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType getErrorType()
    {
        return errorType;
    }

    public Throwable getCause()
    {
        return super.getCause();
    }

    public String getMessage()
    {
        return super.getMessage();
    }

    public Collection getOtherExceptions()
    {
        return otherExceptions;
    }

    public static void handleException(Throwable ex)
        throws ValidationException
    {
        if(ex.getClass().equals(org/xml/sax/SAXParseException))
        {
            SAXParseException spe = (SAXParseException)ex;
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidXML, (new StringBuilder()).append("Line ").append(spe.getLineNumber()).append(", Column ").append(spe.getColumnNumber()).append(": ").append(ex.getMessage()).toString(), spe);
        }
        if(ex.getClass().equals(org/xml/sax/SAXException))
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidXML, ex.getMessage(), ex);
        if(ex.getClass().equals(java/io/FileNotFoundException) || ex.getClass().equals(java/io/IOException))
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.MissingSourceFile, ex.getMessage(), ex);
        if(ex.getClass().equals(com/sun/org/apache/xerces/internal/impl/io/MalformedByteSequenceException))
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.HighAscii, ex.getMessage(), ex);
        else
            return;
    }

    private oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType errorType;
    private Collection otherExceptions;
}
