// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TargetFile.java

package oracle.hub.tf.dropgenerator.core;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.*;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            DropGenerator, LanguageTokens

public class TargetFile
{

    TargetFile(String target, String example)
    {
        resultFile = "";
        resultFilePretty = "";
        resultReplaced = "";
        target = target.replaceAll("\\{", "'{'").replaceAll("\\}", "'}'");
        MessageFormat tokenizedFile;
        MessageFormat tokenizedFilePretty;
        MessageFormat tokenizedFileReplaced;
        try
        {
            tokenizedFile = new MessageFormat(tokenize(target, tokens));
            tokenizedFilePretty = new MessageFormat(tokenize(target, tokens).replaceAll("/", "<span>/</span>"));
            tokenizedFileReplaced = new MessageFormat(tokenize(example, tokens).replaceAll("/", "<span>/</span>"));
        }
        catch(IllegalArgumentException e)
        {
            String message = String.format("Could not process tokens for file %s: %s", new Object[] {
                target, e.getMessage()
            });
            DropGenerator.logger.log(Level.SEVERE, message);
            throw new IllegalArgumentException(message);
        }
        resultFile = tokenizedFile.format(((Object) (tokens.toArray())));
        String prettyTokens[] = new String[tokens.size()];
        String replacedTokens[] = new String[tokens.size()];
        for(int i = 0; i < prettyTokens.length; i++)
        {
            prettyTokens[i] = (new StringBuilder()).append("<b><font color=RED>").append((String)tokens.get(i)).append("</font></b>").toString();
            int tokenIndex = LanguageTokens.getColumnNames().indexOf(tokens.get(i));
            replacedTokens[i] = tokenIndex >= 0 ? (new StringBuilder()).append("<b><font color=RED>").append(replacements[tokenIndex]).append("</font></b>").toString() : "";
        }

        resultFilePretty = (new StringBuilder()).append("<HTML>").append(tokenizedFilePretty.format(prettyTokens)).append("</HTML>").toString();
        resultReplaced = (new StringBuilder()).append("<HTML>").append(tokenizedFileReplaced.format(replacedTokens)).append("</HTML>").toString();
    }

    private String tokenize(String s, ArrayList tokens)
    {
        if(s == null || s.trim().length() == 0)
            return "";
        String tokenized = s;
        tokens.clear();
        Matcher regexMatcher = tokenPattern.matcher(s);
        int i = 0;
        do
        {
            if(!regexMatcher.find())
                break;
            String token = regexMatcher.group();
            if(token.length() != 2 || token.charAt(1) != '%')
            {
                tokens.add(token);
                tokenized = tokenPattern.matcher(tokenized).replaceFirst((new StringBuilder()).append("{").append(i).append("}").toString());
                i++;
            }
        } while(true);
        return tokenized;
    }

    public ArrayList getTokens()
    {
        return new ArrayList(tokens);
    }

    public String toStringReplaced()
    {
        return resultReplaced;
    }

    public String toStringPretty()
    {
        return resultFilePretty;
    }

    public String toString()
    {
        return resultFile;
    }

    private static final String sampleLang = "German";
    private static final String replacements[];
    public static final Pattern tokenPattern;
    private final ArrayList tokens = new ArrayList();
    private String resultFile;
    private String resultFilePretty;
    private String resultReplaced;

    static 
    {
        String regex = "%(.|$)";
        Pattern p = null;
        try
        {
            p = Pattern.compile(regex);
        }
        catch(PatternSyntaxException ex)
        {
            DropGenerator.logger.severe("Regular expression for finding tokens not valid!");
        }
        tokenPattern = p;
        String selectedLang[] = null;
        for(int i = 0; i < LanguageTokens.getCsvData().size(); i++)
            if(((String[])LanguageTokens.getCsvData().get(i))[0].equals("German"))
                selectedLang = (String[])LanguageTokens.getCsvData().get(i);

        replacements = selectedLang;
    }
}
