// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AbstractXmlFileType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.CRC32;
import javax.xml.parsers.*;
import javax.xml.transform.sax.SAXSource;
import javax.xml.validation.Validator;
import javax.xml.xpath.*;
import oracle.hub.tf.dropgenerator.core.DropGenerator;
import org.w3c.dom.Document;
import org.xml.sax.*;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            AbstractFileType, ValidationException, CachingEntityResolver

public abstract class AbstractXmlFileType extends AbstractFileType
{

    public AbstractXmlFileType(String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dropType)
    {
        super(typeCode, name, dropType);
    }

    protected static boolean checkPath(byte data[], XPathExpression expression)
    {
        if(data == null || expression == null)
            return false;
        CRC32 crc = new CRC32();
        crc.update(data);
        Document doc;
        if(!domCache.containsKey(Long.valueOf(crc.getValue())))
        {
            try
            {
                doc = builder.parse(new ByteArrayInputStream(data));
            }
            catch(Exception ex)
            {
                return false;
            }
            domCache.put(Long.valueOf(crc.getValue()), doc);
        } else
        {
            doc = (Document)domCache.get(Long.valueOf(crc.getValue()));
        }
        boolean pathFound = false;
        try
        {
            pathFound = ((Boolean)expression.evaluate(doc, XPathConstants.BOOLEAN)).booleanValue();
        }
        catch(XPathExpressionException ex) { }
        return pathFound;
    }

    protected static void validateSchema(InputStream xmlIs, Validator validator)
        throws ValidationException
    {
        SAXSource ss;
        if(xmlIs == null || validator == null)
            return;
        InputSource is = new InputSource(xmlIs);
        is.setEncoding("UTF-8");
        ss = new SAXSource(is);
        validator.setResourceResolver(CachingEntityResolver.getInstance());
        validator.validate(ss);
        SAXException ex;
        try
        {
            xmlIs.close();
        }
        // Misplaced declaration of an exception variable
        catch(SAXException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/AbstractXmlFileType.getName()).log(Level.SEVERE, null, ex);
        }
        break MISSING_BLOCK_LABEL_181;
        ex;
        ValidationException.handleException(ex);
        try
        {
            xmlIs.close();
        }
        // Misplaced declaration of an exception variable
        catch(SAXException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/AbstractXmlFileType.getName()).log(Level.SEVERE, null, ex);
        }
        break MISSING_BLOCK_LABEL_181;
        ex;
        ValidationException.handleException(ex);
        try
        {
            xmlIs.close();
        }
        // Misplaced declaration of an exception variable
        catch(SAXException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/AbstractXmlFileType.getName()).log(Level.SEVERE, null, ex);
        }
        break MISSING_BLOCK_LABEL_181;
        Exception exception;
        exception;
        try
        {
            xmlIs.close();
        }
        catch(IOException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/AbstractXmlFileType.getName()).log(Level.SEVERE, null, ex);
        }
        throw exception;
    }

    public void validate(byte xmlFile[])
        throws ValidationException
    {
        SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
        XMLReader xmlReader = null;
        try
        {
            saxParserFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            SAXParser parser = saxParserFactory.newSAXParser();
            xmlReader = parser.getXMLReader();
        }
        catch(Exception e)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not initialize generic validator: {0}", e.getMessage());
        }
        xmlReader.setEntityResolver(CachingEntityResolver.getInstance());
        try
        {
            xmlReader.parse(new InputSource(new ByteArrayInputStream(xmlFile)));
        }
        catch(IOException ex)
        {
            ValidationException.handleException(ex);
        }
        catch(SAXException ex)
        {
            ValidationException.handleException(ex);
        }
    }

    private static final LinkedHashMap domCache = new LinkedHashMap(3) {

        public boolean removeEldestEntry(java.util.Map.Entry eldest)
        {
            return size() > 2;
        }

    }
;
    private static final DocumentBuilder builder;

    static 
    {
        int MAX_SIZE = 2;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder docBuilder = null;
        try
        {
            docBuilder = factory.newDocumentBuilder();
        }
        catch(ParserConfigurationException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not instantiate an XML document builder: {0}", ex.getMessage());
        }
        builder = docBuilder;
        builder.setEntityResolver(CachingEntityResolver.getInstance());
    }
}
