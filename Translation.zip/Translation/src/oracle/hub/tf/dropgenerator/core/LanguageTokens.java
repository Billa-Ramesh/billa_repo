// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LanguageTokens.java

package oracle.hub.tf.dropgenerator.core;

import au.com.bytecode.opencsv.CSVReader;
import java.io.*;
import java.util.*;

public class LanguageTokens
{
    public static class TokensForSite extends HashMap
    {

        public TokensForSite(File basePath, Map requestParameters)
            throws Exception
        {
            List rows = new ArrayList();
            put("languages", rows);
            put("columns", LanguageTokens.getColumnNames());
            String tokens[];
            for(Iterator i$ = LanguageTokens.getCsvData().iterator(); i$.hasNext(); rows.add(Arrays.asList(tokens)))
                tokens = (String[])i$.next();

            Collections.sort(rows, new Comparator() {

                public int compare(List o1, List o2)
                {
                    return ((String)o1.get(0)).compareToIgnoreCase((String)o2.get(0));
                }

                public volatile int compare(Object x0, Object x1)
                {
                    return compare((List)x0, (List)x1);
                }

                final TokensForSite this$0;

                
                {
                    this$0 = TokensForSite.this;
                    super();
                }
            }
);
        }
    }


    public LanguageTokens()
    {
    }

    public static List getColumnNames()
    {
        return Collections.unmodifiableList(columnNames);
    }

    public static List getCsvData()
    {
        return Collections.unmodifiableList(csvData);
    }

    private static final String configName = "fileLangCodes.csv";
    private static final List csvData;
    private static final List columnNames;

    static 
    {
        HashSet ignoredColNames;
        HashSet ignoredCols;
        int firstColumnIndex;
        InputStreamReader inputStreamReader;
        CSVReader reader;
        csvData = new ArrayList();
        columnNames = new ArrayList();
        ignoredColNames = new HashSet();
        ignoredCols = new HashSet();
        ignoredColNames.add("CultureIdentifier");
        ignoredCols.add(Integer.valueOf(0));
        firstColumnIndex = 0;
        inputStreamReader = new InputStreamReader(oracle/hub/tf/dropgenerator/core/LanguageTokens.getResourceAsStream("fileLangCodes.csv"));
        reader = new CSVReader(inputStreamReader);
        try
        {
            do
            {
                String line[];
                if((line = reader.readNext()) == null)
                    break;
                if(!line[0].startsWith("#") && line.length != 1)
                    if(line.length > 1 && line[1].equals("%j"))
                    {
                        int i = 0;
                        while(i < line.length) 
                        {
                            if(ignoredCols.contains(Integer.valueOf(i)) || ignoredColNames.contains(line[i]))
                                ignoredCols.add(Integer.valueOf(i));
                            else
                            if(line[i].equals("%e"))
                            {
                                firstColumnIndex = i;
                                columnNames.add(0, line[i]);
                            } else
                            {
                                columnNames.add(line[i]);
                            }
                            i++;
                        }
                    } else
                    {
                        ArrayList newRow = new ArrayList();
                        for(int col = 0; col < line.length; col++)
                        {
                            if(ignoredCols.contains(Integer.valueOf(col)))
                                continue;
                            if(col == firstColumnIndex)
                                newRow.add(0, line[col]);
                            else
                                newRow.add(line[col]);
                        }

                        csvData.add(((Object) (newRow.toArray(new String[newRow.size()]))));
                    }
            } while(true);
        }
        catch(IOException e)
        {
            try
            {
                inputStreamReader.close();
                reader.close();
            }
            // Misplaced declaration of an exception variable
            catch(IOException e) { }
            break MISSING_BLOCK_LABEL_388;
        }
        try
        {
            inputStreamReader.close();
            reader.close();
        }
        catch(IOException e) { }
        break MISSING_BLOCK_LABEL_388;
        Exception exception;
        exception;
        try
        {
            inputStreamReader.close();
            reader.close();
        }
        catch(IOException e) { }
        throw exception;
    }
}
