// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Bom.java

package oracle.hub.tf.dropgenerator.core;

import java.io.*;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            BomEntry, DropGenerator, Util, FileTypes, 
//            TargetFile

public class Bom  implements Iterable
{
    public static final class MetaData extends Enum
    {

        public static MetaData[] values()
        {
            return (MetaData[])$VALUES.clone();
        }

        public static MetaData valueOf(String name)
        {
            return (MetaData)Enum.valueOf(oracle/hub/tf/dropgenerator/core/Bom$MetaData, name);
        }

        public static final MetaData formsversion;
        public static final MetaData productname;
        public static final MetaData productgroup;
        public static final MetaData productversion;
        public static final MetaData productdrop;
        public static final MetaData productmodule;
        public static final MetaData droptype;
        public static final MetaData template;
        private static final MetaData $VALUES[];

        static 
        {
            formsversion = new MetaData("formsversion", 0);
            productname = new MetaData("productname", 1);
            productgroup = new MetaData("productgroup", 2);
            productversion = new MetaData("productversion", 3);
            productdrop = new MetaData("productdrop", 4);
            productmodule = new MetaData("productmodule", 5);
            droptype = new MetaData("droptype", 6);
            template = new MetaData("template", 7);
            $VALUES = (new MetaData[] {
                formsversion, productname, productgroup, productversion, productdrop, productmodule, droptype, template
            });
        }

        private MetaData(String s, int i)
        {
            super(s, i);
        }
    }


    public Bom(File f)
    {
        entries = new ArrayList();
        userEntries = new EnumMap(oracle/hub/tf/dropgenerator/core/Bom$MetaData);
        bom = f;
        if(f.exists() && f.length() > 0L)
            readMetaData();
    }

    public int add(BomEntry bomEntry)
    {
        int index = 0;
        if(bomEntry != null)
        {
            index = Collections.binarySearch(entries, bomEntry);
            if(index < 0)
            {
                entries.add(-index - 1, bomEntry);
                return -index - 1;
            }
        }
        return index;
    }

    public void loadConfig()
    {
        try
        {
            InputStreamReader in = new InputStreamReader(new FileInputStream(bom));
            BufferedReader br = new BufferedReader(in);
            DropGenerator.logger.log(Level.INFO, "Loading configuration from {0}", bom.getName());
            do
            {
                String strLine;
                if((strLine = br.readLine()) == null)
                    break;
                Object configLine[] = parseLine(strLine);
                if(configLine != null)
                {
                    Boolean bomActive = (Boolean)configLine[0];
                    String bomSource = (String)configLine[1];
                    String bomTarget = (String)configLine[2];
                    String bomLanguageScope = (String)configLine[3];
                    String bomFileType = (String)configLine[4];
                    DropGenerator.logger.log(Level.FINE, "{0} parsed from config file!", bomSource);
                    URI bomEntryUri = (new File((new StringBuilder()).append(DropGenerator.getImportDir()).append(File.separator).append(bomSource).toString())).toURI();
                    if(Util.isBomArchive(bomSource))
                        bomEntryUri = URI.create((new StringBuilder()).append("jar:").append(bomEntryUri.toString()).toString());
                    int index = indexOf(bomEntryUri);
                    if(index >= 0)
                    {
                        BomEntry b = (BomEntry)entries.get(index);
                        b.setLangScope(bomLanguageScope);
                        AbstractFileType fileType = FileTypes.getFileType(getDropType(), bomFileType);
                        if(fileType.isValid())
                            b.setFileType(fileType);
                        b.setActive(bomActive.booleanValue() || !fileType.isValid());
                        b.setTarget(bomTarget);
                    }
                }
            } while(true);
            in.close();
        }
        catch(FileNotFoundException ex)
        {
            DropGenerator.logger.log(Level.WARNING, "The BOM file doesn't exist at this path: {0}", bom);
        }
        catch(IOException ex)
        {
            DropGenerator.logger.severe(ex.getMessage());
        }
    }

    void loadEntries()
    {
        try
        {
            InputStreamReader in = new InputStreamReader(new FileInputStream(bom));
            BufferedReader br = new BufferedReader(in);
            DropGenerator.logger.log(Level.INFO, "Loading configuration from {0}", bom.getName());
            do
            {
                String strLine;
                if((strLine = br.readLine()) == null)
                    break;
                Object configLine[] = parseLine(strLine);
                if(configLine != null)
                {
                    Boolean bomActive = (Boolean)configLine[0];
                    String bomSource = (String)configLine[1];
                    String bomTarget = (String)configLine[2];
                    String bomLanguageScope = (String)configLine[3];
                    String bomFileType = (String)configLine[4];
                    DropGenerator.logger.log(Level.FINE, "{0} parsed from config file!", bomSource);
                    File entrySource = new File((new StringBuilder()).append(DropGenerator.getImportDir()).append(File.separator).append(bomSource).toString());
                    BomEntry entry = new BomEntry(this, entrySource, bomTarget, bomLanguageScope);
                    entry.setFileType(bomFileType);
                    entry.setActive(bomActive.booleanValue());
                    entries.add(entry);
                }
            } while(true);
            in.close();
        }
        catch(FileNotFoundException ex)
        {
            DropGenerator.logger.log(Level.WARNING, "The BOM file doesn't exist at this path: {0}", bom);
        }
        catch(IOException ex)
        {
            DropGenerator.logger.severe(ex.getMessage());
        }
    }

    public synchronized File write()
    {
        return write(false);
    }

    synchronized File write(boolean forZip)
    {
        File f = null;
        BufferedWriter bomWriter;
        try
        {
            f = forZip ? File.createTempFile("dropgen", ".bom") : bom;
            bomWriter = new BufferedWriter(new FileWriter(f));
        }
        catch(IOException e)
        {
            DropGenerator.logger.log(Level.WARNING, "Could not create BOM at given location [{0}]. Operation aborted", bom.getAbsolutePath());
            return f;
        }
        try
        {
            bomWriter.write(getHeader());
            bomWriter.newLine();
            for(Iterator i$ = entries.iterator(); i$.hasNext(); bomWriter.newLine())
            {
                BomEntry b = (BomEntry)i$.next();
                bomWriter.write(b.getBomString(forZip));
            }

            bomWriter.close();
        }
        catch(IOException e)
        {
            DropGenerator.logger.warning("Could not save changes!");
        }
        return f;
    }

    private void readMetaData()
    {
        BufferedReader br = null;
        try
        {
            InputStreamReader in = new InputStreamReader(new FileInputStream(bom));
            br = new BufferedReader(in);
            DropGenerator.logger.log(Level.INFO, "Loading meta-data from {0}", bom.getName());
            do
            {
                String strLine;
                if((strLine = br.readLine()) == null)
                    break;
                if(!strLine.startsWith("##!"))
                    continue;
                String entry = strLine.substring(3, strLine.length()).trim();
                String keyValue[] = entry.split("=");
                if(keyValue.length != 2)
                    continue;
                MetaData key;
                try
                {
                    key = MetaData.valueOf(keyValue[0]);
                }
                catch(IllegalArgumentException e)
                {
                    continue;
                }
                userEntries.put(key, keyValue[1]);
                DropGenerator.logger.log(Level.INFO, "{0}: {1}", new Object[] {
                    key, keyValue[1]
                });
            } while(true);
        }
        catch(FileNotFoundException e) { }
        catch(IOException e) { }
        try
        {
            if(br != null)
                br.close();
        }
        catch(IOException e) { }
    }

    private String getHeader()
    {
        String date = (new SimpleDateFormat("yyyy/MM/dd HH:mm:ss")).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append("###Created by Drop Generator ").append(Util.module).append(" on ").append(date).append("|v").append(DropGenerator.version);
        java.util.Map.Entry entry;
        for(Iterator i$ = userEntries.entrySet().iterator(); i$.hasNext(); sb.append("\n").append("##!").append(((MetaData)entry.getKey()).toString()).append("=").append((String)entry.getValue()))
            entry = (java.util.Map.Entry)i$.next();

        return sb.toString();
    }

    private Object[] parseLine(String line)
    {
        Boolean active = Boolean.valueOf(true);
        if(line.startsWith("##!") || line.startsWith("###"))
            return null;
        if(line.startsWith("#"))
        {
            active = Boolean.valueOf(false);
            line = line.substring(1);
        }
        String v[] = line.split(" ");
        ArrayList vl = new ArrayList();
        try
        {
            for(int i = 0; i < v.length; i++)
                if(v[i].trim().length() != 0)
                {
                    if(v[i].startsWith("\"") && v[i].endsWith("\""))
                        v[i] = v[i].substring(1, v[i].length() - 1);
                    if(v[i].startsWith("\"") && !v[i].endsWith("\""))
                    {
                        StringBuilder sb = new StringBuilder(v[i]);
                        do
                        {
                            sb.append(' ');
                            sb.append(v[++i]);
                        } while(!v[i].endsWith("\""));
                        vl.add(sb.substring(1, sb.length() - 1));
                    } else
                    {
                        vl.add(v[i]);
                    }
                }

        }
        catch(Exception e)
        {
            DropGenerator.logger.log(Level.WARNING, "Invalid quoted strings. The line [{0}] might have extra or missing quotes.", line);
        }
        if(vl.size() < 4 || vl.size() > 5)
        {
            DropGenerator.logger.log(Level.WARNING, "Entry ({0}) contains invalid number of fields!", line);
            return null;
        } else
        {
            String src = (String)vl.get(0);
            String target = (String)vl.get(1);
            String langSetName = (String)vl.get(2);
            String fileType = (String)vl.get(3);
            return (new Object[] {
                active, src, target, langSetName, fileType
            });
        }
    }

    public void renameTo(File file)
    {
        bom.renameTo(file);
        bom = file;
    }

    public File getFile()
    {
        return bom;
    }

    public void clear()
    {
        entries.clear();
        userEntries.clear();
    }

    public Iterator iterator()
    {
        return entries.iterator();
    }

    public int size()
    {
        return entries.size();
    }

    public BomEntry get(int index)
    {
        return (BomEntry)entries.get(index);
    }

    public int indexOf(URI uri)
    {
        if(bom == null)
            return -1;
        else
            return Collections.binarySearch(entries, uri);
    }

    public int indexOf(BomEntry b)
    {
        if(bom == null)
            return -1;
        else
            return Collections.binarySearch(entries, b);
    }

    public DropGenerator.DropType getDropType()
    {
        String dt = getMetaData(MetaData.droptype);
        if(dt.trim().length() == 0)
            return DropGenerator.DropType.UI;
        try
        {
            return DropGenerator.DropType.valueOf(dt);
        }
        catch(IllegalArgumentException e)
        {
            return DropGenerator.DropType.UI;
        }
    }

    public int getDropNumber()
    {
        Integer productDrop = Integer.valueOf(-1);
        try
        {
            productDrop = Integer.valueOf(Integer.parseInt(getMetaData(MetaData.productdrop)));
        }
        catch(NumberFormatException e) { }
        return productDrop.intValue();
    }

    public DropGenerator.FormsVersion getFormsVersion()
    {
        String entry = getMetaData(MetaData.formsversion);
        if(entry.length() == 0)
            return null;
        try
        {
            return DropGenerator.FormsVersion.valueOf(getMetaData(MetaData.formsversion));
        }
        catch(IllegalArgumentException e)
        {
            return null;
        }
    }

    public String getMetaData(MetaData key)
    {
        String value = (String)userEntries.get(key);
        if(key.equals(MetaData.productname))
        {
            if(value == null)
                value = bom.getAbsoluteFile().getParentFile().getName();
            value = value.toLowerCase();
            Matcher regexMatcher = Util.vobDisallowed.matcher(value);
            return regexMatcher.replaceAll("");
        } else
        {
            return value != null ? value.trim() : "";
        }
    }

    public void setMetaData(MetaData key, Object value)
    {
        if(key == null || value == null)
            return;
        String val = value.toString();
        if(!val.trim().isEmpty())
        {
            userEntries.put(key, val);
            if(key.equals(MetaData.productname))
            {
                BomEntry b;
                for(Iterator i$ = iterator(); i$.hasNext(); b.setTarget(b.getTarget().toString()))
                    b = (BomEntry)i$.next();

            }
        }
    }

    private static final long serialVersionUID = 0x766309ad0aa8c255L;
    public static final char entrySeparator = 32;
    private ArrayList entries;
    private File bom;
    private Map userEntries;
}
