// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CachingEntityResolver.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.validation.SchemaFactory;
import oracle.hub.tf.dropgenerator.core.DropGenerator;
import oracle.hub.tf.dropgenerator.core.Util;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.*;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            Input

public class CachingEntityResolver
    implements EntityResolver, LSResourceResolver
{
    private static class Entity
    {

        String name;
        byte content[];

        private Entity()
        {
        }

    }

    private static final class StreamType extends Enum
    {

        public static StreamType[] values()
        {
            return (StreamType[])$VALUES.clone();
        }

        public static StreamType valueOf(String name)
        {
            return (StreamType)Enum.valueOf(oracle/hub/tf/dropgenerator/core/filetype/CachingEntityResolver$StreamType, name);
        }

        public static final StreamType entity;
        public static final StreamType resource;
        private static final StreamType $VALUES[];

        static 
        {
            entity = new StreamType("entity", 0);
            resource = new StreamType("resource", 1);
            $VALUES = (new StreamType[] {
                entity, resource
            });
        }

        private StreamType(String s, int i)
        {
            super(s, i);
        }
    }


    protected CachingEntityResolver()
    {
        buffer = new byte[0x7d000];
        EntityResolver der = null;
        try
        {
            der = SAXParserFactory.newInstance().newSAXParser().getXMLReader().getEntityResolver();
        }
        catch(Exception ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not initialize default entity resolver: {0}", ex.getMessage());
        }
        entityResolver = der;
    }

    public static CachingEntityResolver getInstance()
    {
        return instance;
    }

    public LSInput resolveResource(String type, String namespaceURI, String publicId, String systemId, String baseURI)
    {
        InputStream stream = null;
        try
        {
            stream = getEntity(StreamType.resource, publicId, systemId, type, namespaceURI, baseURI);
        }
        catch(IOException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/CachingEntityResolver.getName()).log(Level.SEVERE, null, ex);
        }
        catch(SAXException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/CachingEntityResolver.getName()).log(Level.SEVERE, null, ex);
        }
        if(stream != null)
            return new Input(publicId, systemId, stream);
        else
            return null;
    }

    public InputSource resolveEntity(String publicId, String systemId)
        throws IOException, SAXException
    {
        InputStream stream = getEntity(StreamType.entity, publicId, systemId, null, null, null);
        if(stream != null)
        {
            InputSource source = new InputSource(stream);
            source.setPublicId(publicId);
            source.setSystemId(systemId);
            return source;
        } else
        {
            return null;
        }
    }

    private InputStream getEntity(StreamType streamType, String publicId, String systemId, String type, String namespaceURI, String baseURI)
        throws IOException, SAXException
    {
        Entity entity = null;
        if(localResources.containsKey(systemId))
        {
            entity = new Entity();
            entity.name = systemId;
            entity.content = Util.toByteArray(oracle/hub/tf/dropgenerator/core/DropGenerator.getResourceAsStream((String)localResources.get(systemId)));
        }
        String key = publicId == null ? systemId : publicId;
        if(entities.containsKey(key))
            entity = (Entity)entities.get(key);
        if(entity == null)
        {
            DropGenerator.logger.log(Level.INFO, "Downloading schema/DTD: : {0}, {1}", new Object[] {
                publicId, systemId
            });
            if(!System.getProperties().containsKey("http.proxyHost"))
                try
                {
                    Proxy proxy = Util.findProxy(new URI(systemId));
                    if(!proxy.equals(Proxy.NO_PROXY))
                    {
                        Properties sysProps = System.getProperties();
                        InetSocketAddress addr = (InetSocketAddress)proxy.address();
                        if(addr != null)
                        {
                            sysProps.put("http.proxyHost", addr.getHostName());
                            sysProps.put("http.proxyPort", Integer.valueOf(addr.getPort()));
                        }
                    }
                }
                catch(URISyntaxException ex)
                {
                    System.out.println(ex.getMessage());
                }
            InputStream source;
            try
            {
                URL systemIdUrl = new URL(systemId);
                systemIdUrl.toURI();
                URLConnection openConnection = systemIdUrl.openConnection();
                openConnection.setConnectTimeout(10000);
                openConnection.setReadTimeout(10000);
                source = openConnection.getInputStream();
            }
            catch(SocketTimeoutException e)
            {
                DropGenerator.logger.log(Level.WARNING, "Socket timeout while resolving {0}", systemId);
                return cacheEntity(publicId, systemId, new ByteArrayInputStream("".getBytes()));
            }
            catch(URISyntaxException e)
            {
                DropGenerator.logger.log(Level.WARNING, "URI invalid {0}", systemId);
                return cacheEntity(publicId, systemId, new ByteArrayInputStream("".getBytes()));
            }
            catch(MalformedURLException e)
            {
                DropGenerator.logger.log(Level.WARNING, "Malformed URL {0}", systemId);
                return cacheEntity(publicId, systemId, new ByteArrayInputStream("".getBytes()));
            }
            catch(NoRouteToHostException e)
            {
                DropGenerator.logger.log(Level.WARNING, "No route to host while resolving {0}", systemId);
                return cacheEntity(publicId, systemId, new ByteArrayInputStream("".getBytes()));
            }
            catch(FileNotFoundException e)
            {
                DropGenerator.logger.log(Level.WARNING, "Resource does not exist: {0}", systemId);
                return cacheEntity(publicId, systemId, new ByteArrayInputStream("".getBytes()));
            }
            if(source == null)
                if(streamType == StreamType.entity)
                    source = entityResolver.resolveEntity(publicId, systemId).getByteStream();
                else
                if(streamType == StreamType.resource)
                {
                    LSInput input = resourceResolver.resolveResource(type, namespaceURI, publicId, systemId, baseURI);
                    source = input.getByteStream();
                }
            if(source != null)
                return cacheEntity(publicId, systemId, source);
            else
                return cacheEntity(publicId, systemId, new ByteArrayInputStream("".getBytes()));
        } else
        {
            return new ByteArrayInputStream(entity.content);
        }
    }

    private InputStream cacheEntity(String publicId, String systemId, InputStream stream)
        throws IOException
    {
        stream = new BufferedInputStream(stream);
        int count;
        int i;
        for(count = 0; count < buffer.length && (i = stream.read(buffer, count, buffer.length - count)) >= 0; count += i);
        byte content[] = new byte[count];
        System.arraycopy(buffer, 0, content, 0, count);
        if(count != buffer.length)
        {
            Entity entity = new Entity();
            entity.name = publicId == null ? systemId : publicId;
            entity.content = content;
            entities.put(entity.name, entity);
            return new ByteArrayInputStream(content);
        } else
        {
            return new SequenceInputStream(new ByteArrayInputStream(content), stream);
        }
    }

    private static final CachingEntityResolver instance = new CachingEntityResolver();
    public final int MAX_CACHE_ENTRY_SIZE = 0x7d000;
    private final EntityResolver entityResolver;
    private final LSResourceResolver resourceResolver = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema").getResourceResolver();
    private final Map entities = Collections.synchronizedMap(new HashMap());
    private byte buffer[];
    private static final HashMap localResources = new HashMap() {

            
            {
                put("http://www.w3.org/2001/xml.xsd", "xsd/specs/xml.xsd");
                put("http://www.oasis-open.org/docbook/xml/4.4/docbookx.dtd", "xsd/specs/docbookx.dtd");
            }
    }
;

}
