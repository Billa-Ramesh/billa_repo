// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DropGenerator.java

package oracle.hub.tf.dropgenerator.core;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.*;
import java.net.URI;
import java.util.Properties;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingWorker;
import javax.xml.bind.JAXBException;
import oracle.hub.tf.dropgenerator.core.rules.Rules;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            Bom, ScanDirWorker, ZipDrop, RuleParser

public class DropGenerator
{
    public static final class DropType extends Enum
    {

        public static DropType[] values()
        {
            return (DropType[])$VALUES.clone();
        }

        public static DropType valueOf(String name)
        {
            return (DropType)Enum.valueOf(oracle/hub/tf/dropgenerator/core/DropGenerator$DropType, name);
        }

        public static DropType valueFor(String name)
        {
            if(name == null)
                return null;
            DropType arr$[] = values();
            int len$ = arr$.length;
            for(int i$ = 0; i$ < len$; i$++)
            {
                DropType value = arr$[i$];
                if(value.name.equals(name))
                    return value;
            }

            return null;
        }

        public static final DropType UI;
        public static final DropType UA;
        public static final DropType COMMON;
        public final String name;
        private static final DropType $VALUES[];

        static 
        {
            UI = new DropType("UI", 0, "User interface");
            UA = new DropType("UA", 1, "On-line help");
            COMMON = new DropType("COMMON", 2, "Common");
            $VALUES = (new DropType[] {
                UI, UA, COMMON
            });
        }

        private DropType(String s, int i, String n)
        {
            super(s, i);
            name = n;
        }
    }

    public static final class FormsVersion extends Enum
    {

        public static FormsVersion[] values()
        {
            return (FormsVersion[])$VALUES.clone();
        }

        public static FormsVersion valueOf(String name)
        {
            return (FormsVersion)Enum.valueOf(oracle/hub/tf/dropgenerator/core/DropGenerator$FormsVersion, name);
        }

        public static FormsVersion valueFor(String name)
        {
            if(name == null)
                return null;
            FormsVersion arr$[] = values();
            int len$ = arr$.length;
            for(int i$ = 0; i$ < len$; i$++)
            {
                FormsVersion value = arr$[i$];
                if(value.name.equals(name))
                    return value;
            }

            return null;
        }

        public static final FormsVersion R11;
        public static final FormsVersion R12;
        public final String name;
        private static final FormsVersion $VALUES[];

        static 
        {
            R11 = new FormsVersion("R11", 0, "6i");
            R12 = new FormsVersion("R12", 1, "10g");
            $VALUES = (new FormsVersion[] {
                R11, R12
            });
        }

        private FormsVersion(String s, int i, String n)
        {
            super(s, i);
            name = n;
        }
    }


    public DropGenerator()
    {
        tokenRules = null;
    }

    public void scanSourceDirectory(File id, DropType dt)
    {
        try
        {
            scanSourceDirectory(id, dt, new PropertyChangeListener() {

                public void propertyChange(PropertyChangeEvent evt)
                {
                    DropGenerator.logger.log(Level.FINE, "{0}: {1}", new Object[] {
                        evt.getPropertyName(), evt.getNewValue().toString()
                    });
                }

                final DropGenerator this$0;

            
            {
                this$0 = DropGenerator.this;
                super();
            }
            }
);
            activeWorker.get();
        }
        catch(InterruptedException ex)
        {
            logger.log(Level.SEVERE, "Scan directory failed due to InterruptedException: {0}", ex.getMessage());
        }
        catch(ExecutionException ex)
        {
            logger.log(Level.SEVERE, "Scan directory failed due to ExecutionException: {0}", ex.getMessage());
        }
    }

    public void scanSourceDirectory(File id, DropType dt, PropertyChangeListener listener)
    {
        if(!id.exists() || !id.isDirectory())
        {
            logger.severe("Chosen source directory is not valid!");
            return;
        }
        importDir = id;
        File defaultBom = getDefaultBom(importDir, dt);
        if(!defaultBom.exists())
        {
            File arr$[] = importDir.listFiles();
            int len$ = arr$.length;
            int i$ = 0;
            do
            {
                if(i$ >= len$)
                    break;
                File f = arr$[i$];
                if(f.isFile() && f.getName().endsWith(".bom") && !f.getName().equals((new StringBuilder()).append(DropType.UI).append(".bom").toString()) && !f.getName().equals((new StringBuilder()).append(DropType.UA).append(".bom").toString()))
                {
                    f.renameTo(defaultBom);
                    break;
                }
                i$++;
            } while(true);
        }
        bom = new Bom(defaultBom);
        bom.setMetaData(Bom.MetaData.droptype, dt);
        activeWorker = new ScanDirWorker(bom, importDir, tokenRules);
        activeWorker.addPropertyChangeListener(listener);
        logger.log(Level.INFO, "Scanning source directory: {0}", importDir);
        activeWorker.execute();
    }

    public File createDropZip(File saveDir)
    {
        File f = createDropZip(saveDir, null);
        try
        {
            activeWorker.get();
        }
        catch(InterruptedException ex)
        {
            logger.log(Level.SEVERE, "Creating zip failed due to InterruptedException: {0}", ex.getMessage());
        }
        catch(ExecutionException ex)
        {
            logger.log(Level.SEVERE, "Creating zip failed due to ExecutionException: {0}", ex.getMessage());
        }
        catch(CancellationException ex) { }
        return f;
    }

    public File createDropZip(File saveDir, PropertyChangeListener listener)
    {
        bom.write();
        StringBuilder filename = new StringBuilder();
        filename.append(bom.getMetaData(Bom.MetaData.productname));
        if(bom.getMetaData(Bom.MetaData.productversion).length() > 0 && bom.getDropNumber() > 0)
        {
            filename.insert(0, (new StringBuilder()).append(bom.getMetaData(Bom.MetaData.productgroup).length() <= 0 ? bom.getMetaData(Bom.MetaData.productname) : bom.getMetaData(Bom.MetaData.productgroup)).append("-").toString());
            filename.append("-").append(bom.getMetaData(Bom.MetaData.productversion));
            filename.append("-drop").append(bom.getDropNumber());
            if(!bom.getMetaData(Bom.MetaData.productmodule).trim().isEmpty())
                filename.append("-").append(bom.getMetaData(Bom.MetaData.productmodule));
            filename.append("-").append(bom.getDropType().toString().toLowerCase());
        }
        File zipFile = new File(saveDir.getAbsolutePath(), (new StringBuilder()).append(filename.toString()).append(".zip").toString());
        activeWorker = new ZipDrop(zipFile, bom);
        activeWorker.addPropertyChangeListener(listener);
        activeWorker.execute();
        return zipFile;
    }

    public void loadFromBom(File bomFile, File importDir)
    {
        importDir = importDir != null ? importDir : bomFile.getParentFile();
        bom = new Bom(bomFile);
        bom.loadEntries();
    }

    public static String relativize(URI sourceUri)
    {
        if(!sourceUri.getScheme().equals("file"))
        {
            String path = sourceUri.getRawSchemeSpecificPart();
            sourceUri = URI.create(path);
        }
        String relative = importDir.toURI().relativize(sourceUri).getPath();
        if(relative.endsWith("/"))
            relative = relative.substring(0, relative.length() - 1);
        return relative;
    }

    public void setRulesFile(File rulesFile)
        throws JAXBException, FileNotFoundException
    {
        tokenRules = RuleParser.loadRules(new FileInputStream(rulesFile));
        logger.log(Level.FINE, "Language token and filtering rules loaded successfully");
    }

    public static void clearDropInfo()
    {
        importDir = new File("");
    }

    public SwingWorker getActiveWorker()
    {
        return activeWorker;
    }

    public static File getImportDir()
    {
        return importDir;
    }

    public Bom getBom()
    {
        return bom;
    }

    public static File getDefaultBom(File importDir, DropType dt)
    {
        return new File(importDir, (new StringBuilder()).append(dt).append(".bom").toString());
    }

    private static final long serialVersionUID = 1L;
    public static final String version;
    public static final Logger logger;
    static File importDir = new File("");
    private Bom bom;
    private SwingWorker activeWorker;
    private Rules tokenRules;

    static 
    {
        logger = Logger.getLogger("dropgenerator.core");
        InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("dropgenerator-core.properties");
        Properties prop = new Properties();
        try
        {
            prop.load(in);
        }
        catch(IOException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/DropGenerator.getName()).log(Level.SEVERE, null, ex);
        }
        version = prop.getProperty("application.version");
        if(version == null)
            logger.severe("Could not obtain application version.");
    }
}
