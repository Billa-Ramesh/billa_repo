// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Util.java

package oracle.hub.tf.dropgenerator.core;

import java.io.*;
import java.net.*;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.*;

public class Util
{

    public Util()
    {
    }

    public static Proxy findProxy(URI uri)
    {
        System.setProperty("java.net.useSystemProxies", "true");
        try
        {
            ProxySelector selector = ProxySelector.getDefault();
            List proxyList = selector.select(uri);
            if(proxyList.size() > 1)
                return (Proxy)proxyList.get(0);
        }
        catch(IllegalArgumentException e) { }
        return Proxy.NO_PROXY;
    }

    public static String getExtension(File f)
    {
        return getExtension(f.getName());
    }

    public static String getExtension(URI u)
    {
        return getExtension(u.getPath());
    }

    public static String getExtension(String s)
    {
        String ext = "";
        int i = s.lastIndexOf('.');
        if(i >= 0)
            ext = s.substring(i + 1);
        return ext.toLowerCase();
    }

    public static String stripExtension(File f)
    {
        return stripExtension(f.getName());
    }

    public static String stripExtension(String str)
    {
        if(str == null)
            return null;
        int pos = str.lastIndexOf(".");
        if(pos == -1)
            return str;
        else
            return str.substring(0, pos);
    }

    public static String[] getPathComponents(File path)
    {
        ArrayList components = new ArrayList();
        components.add(path.getName());
        while((path = path.getParentFile()) != null) 
            components.add(path.getName());
        return (String[])components.toArray(new String[components.size()]);
    }

    public static String join(Object array[], char separator)
    {
        if(array == null)
            return null;
        int arraySize = array.length;
        int bufSize = arraySize != 0 ? ((array[0] != null ? array[0].toString().length() : 16) + 1) * arraySize : 0;
        StringBuilder buf = new StringBuilder(bufSize);
        for(int i = 0; i < arraySize; i++)
        {
            if(array[i] == null)
                continue;
            if(i > 0)
                buf.append(separator);
            buf.append(array[i]);
        }

        return buf.toString();
    }

    public static String join(HashSet objs, char delimiter)
    {
        String entries[] = (String[])objs.toArray(new String[objs.size()]);
        return join(((Object []) (entries)), delimiter);
    }

    public static String join(List objs, char delimiter)
    {
        String entries[] = (String[])objs.toArray(new String[objs.size()]);
        return join(((Object []) (entries)), delimiter);
    }

    public static void copyFile(File in, File out)
        throws IOException
    {
        FileChannel inChannel;
        FileChannel outChannel;
        inChannel = (new FileInputStream(in)).getChannel();
        outChannel = (new FileOutputStream(out)).getChannel();
        inChannel.transferTo(0L, inChannel.size(), outChannel);
        if(inChannel != null)
            inChannel.close();
        if(outChannel != null)
            outChannel.close();
        break MISSING_BLOCK_LABEL_75;
        Exception exception;
        exception;
        if(inChannel != null)
            inChannel.close();
        if(outChannel != null)
            outChannel.close();
        throw exception;
    }

    public static String wildcardToRegex(String wildcard)
    {
        StringBuilder s = new StringBuilder(wildcard.length());
        s.append('^');
        int i = 0;
        for(int is = wildcard.length(); i < is; i++)
        {
            char c = wildcard.charAt(i);
            switch(c)
            {
            case 42: // '*'
                s.append(".*");
                break;

            case 63: // '?'
                s.append(".");
                break;

            case 36: // '$'
            case 40: // '('
            case 41: // ')'
            case 46: // '.'
            case 91: // '['
            case 92: // '\\'
            case 93: // ']'
            case 94: // '^'
            case 123: // '{'
            case 124: // '|'
            case 125: // '}'
                s.append("\\");
                s.append(c);
                break;

            default:
                s.append(c);
                break;
            }
        }

        s.append('$');
        return s.toString();
    }

    public static String readFile(File f)
        throws IOException
    {
        FileInputStream stream = new FileInputStream(f);
        String s;
        FileChannel fc = stream.getChannel();
        java.nio.MappedByteBuffer bb = fc.map(java.nio.channels.FileChannel.MapMode.READ_ONLY, 0L, fc.size());
        s = Charset.defaultCharset().decode(bb).toString();
        stream.close();
        return s;
        Exception exception;
        exception;
        stream.close();
        throw exception;
    }

    public static String streamToString(InputStream is)
        throws IOException
    {
        if(is != null)
            return new String(toByteArray(is), "UTF-8");
        else
            return null;
    }

    public static byte[] toByteArray(InputStream is)
        throws IOException
    {
        if(is == null)
            return null;
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        BufferedInputStream bis = new BufferedInputStream(is);
        byte data[] = new byte[32768];
        int nRead;
        while((nRead = bis.read(data, 0, data.length)) != -1) 
            buffer.write(data, 0, nRead);
        buffer.flush();
        try
        {
            if(bis != null)
                bis.close();
            if(is != null)
                is.close();
        }
        catch(IOException e) { }
        return buffer.toByteArray();
    }

    public static File extractRecursively(File zipFile, File destination)
        throws ZipException, IOException
    {
        int BUFFER = 2048;
        ZipFile zip = new ZipFile(zipFile);
        if(destination == null)
            destination = new File(zipFile.getParentFile(), stripExtension(zipFile.getName()));
        if(destination.exists() && destination.isDirectory())
            deleteRecursively(destination);
        if(!destination.mkdir())
            throw new IOException((new StringBuilder()).append("Could not create folder for extracting JAR file: ").append(destination.getPath()).toString());
        Enumeration zipFileEntries = zip.entries();
        do
        {
            if(!zipFileEntries.hasMoreElements())
                break;
            ZipEntry entry = (ZipEntry)zipFileEntries.nextElement();
            String currentEntry = entry.getName();
            File destFile = new File(destination, currentEntry);
            File destinationParent = destFile.getParentFile();
            destinationParent.mkdirs();
            if(!entry.isDirectory())
            {
                BufferedInputStream is = new BufferedInputStream(zip.getInputStream(entry));
                byte data[] = new byte[BUFFER];
                FileOutputStream fos = new FileOutputStream(destFile);
                BufferedOutputStream dest = new BufferedOutputStream(fos, BUFFER);
                int currentByte;
                while((currentByte = is.read(data, 0, BUFFER)) != -1) 
                    dest.write(data, 0, currentByte);
                dest.flush();
                dest.close();
                is.close();
            }
        } while(true);
        return destination;
    }

    public static void deleteRecursively(File f)
    {
        if(f.isDirectory())
        {
            File arr$[] = f.listFiles();
            int len$ = arr$.length;
            for(int i$ = 0; i$ < len$; i$++)
            {
                File c = arr$[i$];
                deleteRecursively(c);
            }

        }
        f.delete();
    }

    public static JarURLConnection getJarConnection(URL url)
        throws IOException
    {
        return (JarURLConnection)url.openConnection();
    }

    public static String getUriPathNoFilename(String uri)
    {
        if(uri == null)
            return "";
        if(uri.equals("") || uri.equals("/") || uri.endsWith("/"))
            return uri;
        int lastSlashPos = uri.lastIndexOf('/');
        if(lastSlashPos >= 0)
        {
            if(uri.charAt(lastSlashPos - 1) == '!')
                lastSlashPos++;
            return uri.substring(0, lastSlashPos);
        } else
        {
            return "";
        }
    }

    public static String getFilenameFromUri(URI uri)
    {
        if(uri == null)
            return "";
        if(!uri.getScheme().equals("file"))
            uri = URI.create(uri.getRawSchemeSpecificPart());
        String uriString = uri.getPath();
        if(uriString == null)
            return "";
        if(uriString.endsWith("!/"))
            uriString = uriString.substring(0, uriString.length() - 2);
        else
        if(uriString.endsWith("/"))
            return "";
        int lastSlash = uriString.lastIndexOf('/') + 1;
        if(lastSlash > 0 && uriString.length() > lastSlash)
            return uriString.substring(lastSlash);
        else
            return "";
    }

    public static String uriEncode(String input)
    {
        StringBuilder resultStr = new StringBuilder();
        char arr$[] = input.toCharArray();
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            char ch = arr$[i$];
            if(isUnsafe(ch))
            {
                resultStr.append('%');
                resultStr.append(toHex(ch / 16));
                resultStr.append(toHex(ch % 16));
            } else
            {
                resultStr.append(ch);
            }
        }

        return resultStr.toString();
    }

    private static char toHex(int ch)
    {
        return (char)(ch >= 10 ? (65 + ch) - 10 : 48 + ch);
    }

    private static boolean isUnsafe(char ch)
    {
        if(ch > '\200' || ch < 0)
            return true;
        else
            return " %$&+,/:;=?@<>#%".indexOf(ch) >= 0;
    }

    public static URI getUnderlyingJar(URI uri)
    {
        if(!isArchive(uri))
            return null;
        String underlying = uri.toString();
        if(uri.getScheme().equals("jar"))
            underlying = uri.getRawSchemeSpecificPart();
        int separator = 0;
        String arr$[] = archiveExtensions;
        int len$ = arr$.length;
        int i$ = 0;
        do
        {
            if(i$ >= len$)
                break;
            String ext = arr$[i$];
            separator = underlying.indexOf((new StringBuilder()).append(ext).append("!/").toString());
            if(separator > 0)
                break;
            i$++;
        } while(true);
        if(separator <= 0)
            return null;
        if((separator += 4) >= underlying.length())
            return null;
        else
            return URI.create(underlying.substring(0, separator));
    }

    public static String archivePathToFolderPath(String jarPath)
    {
        String arr$[] = archiveExtensions;
        int len$ = arr$.length;
        int i$ = 0;
        do
        {
            if(i$ >= len$)
                break;
            String ext = arr$[i$];
            String replaced = jarPath.replaceFirst((new StringBuilder()).append("\\").append(ext).append("!/").toString(), "/");
            if(!replaced.equals(jarPath))
            {
                jarPath = replaced;
                break;
            }
            i$++;
        } while(true);
        return jarPath;
    }

    public static boolean isBomArchive(String sourcePath)
    {
        String arr$[] = archiveExtensions;
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            String ext = arr$[i$];
            if(sourcePath.contains((new StringBuilder()).append(ext).append("!/").toString()))
                return true;
        }

        return false;
    }

    public static boolean isArchive(URI uri)
    {
        if(uri.getScheme().equals("jar"))
            return true;
        else
            return isArchiveFile(uri);
    }

    public static boolean isArchiveFile(URI uri)
    {
        ZipFile zf;
        boolean valid = false;
        String fileName = getFilenameFromUri(uri);
        String arr$[] = archiveExtensions;
        int len$ = arr$.length;
        int i$ = 0;
        do
        {
            if(i$ >= len$)
                break;
            String ext = arr$[i$];
            if(fileName.endsWith(ext))
            {
                valid = true;
                break;
            }
            i$++;
        } while(true);
        if(!valid)
            return false;
        zf = null;
        boolean flag;
        zf = new ZipFile(new File(uri));
        flag = true;
        if(zf != null)
            try
            {
                zf.close();
            }
            catch(IOException ex) { }
        return flag;
        Exception ex;
        ex;
        boolean flag1 = false;
        if(zf != null)
            try
            {
                zf.close();
            }
            catch(IOException ex) { }
        return flag1;
        Exception exception;
        exception;
        if(zf != null)
            try
            {
                zf.close();
            }
            catch(IOException ex) { }
        throw exception;
    }

    public static final Pattern vobDisallowed = Pattern.compile("[^\\p{Digit}\\p{Lower}_\\.]");
    public static final Pattern outputFileDisallowed = Pattern.compile("[*|\"<>?:\\\\]");
    public static final String removeMessage = "Error removed";
    public static final String module;
    private static final String archiveExtensions[] = {
        ".jar", ".zip"
    };

    static 
    {
        HashMap modules = new HashMap() {

            
            {
                put("oracle.hub.tf.dropgenerator.cli.DropGeneratorCLI", "CLI");
                put("oracle.hub.tf.dropgenerator.gui.DropGeneratorWindow", "GUI");
            }
        }
;
        String detectedModule = "API";
        Iterator i$ = modules.keySet().iterator();
        do
        {
            if(!i$.hasNext())
                break;
            String mymod = (String)i$.next();
            try
            {
                Class.forName(mymod, true, oracle/hub/tf/dropgenerator/core/Util.getClassLoader());
                detectedModule = (String)modules.get(mymod);
                break;
            }
            catch(ClassNotFoundException ex) { }
        } while(true);
        module = detectedModule;
    }
}
