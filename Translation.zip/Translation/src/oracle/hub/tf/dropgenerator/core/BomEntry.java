// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BomEntry.java

package oracle.hub.tf.dropgenerator.core;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import oracle.hub.tf.dropgenerator.core.filetype.AbstractFileType;
import oracle.hub.tf.dropgenerator.core.filetype.ValidationException;
import org.bushe.swing.event.EventBus;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            TargetFile, BomEntryError, Bom, DropGenerator, 
//            Util, LanguageTokens, FileTypes

public class BomEntry
    implements Comparable
{

    public BomEntry(Bom parent, File source)
    {
        this(parent, source, null, "all");
    }

    public BomEntry(Bom parent, URI u)
    {
        this(parent, u, null, "all");
    }

    public BomEntry(Bom parent, URI sourceUri, String targetDir, String langScope)
    {
        recommendedFileTypes = new TreeSet();
        fileType = AbstractFileType.EMPTY_FILETYPE;
        active = Boolean.valueOf(true);
        issues = new HashMap();
        issues.put(Level.WARNING, new EnumMap(oracle/hub/tf/dropgenerator/core/BomEntryError$ErrorType));
        issues.put(Level.SEVERE, new EnumMap(oracle/hub/tf/dropgenerator/core/BomEntryError$ErrorType));
        this.sourceUri = sourceUri;
        try
        {
            sourceUrl = sourceUri.toURL();
        }
        catch(MalformedURLException ex)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Provided URI ").append(sourceUri).append(" cannot be converted to a valid URL").toString(), ex);
        }
        this.parent = parent;
        setTarget(targetDir);
        this.langScope = langScope;
        if(parent.getMetaData(Bom.MetaData.droptype).isEmpty())
        {
            throw new IllegalArgumentException("Parent BOM file MUST have a drop type defined!");
        } else
        {
            scan();
            return;
        }
    }

    public BomEntry(Bom parent, File sourceFile, String targetDir, String langScope)
    {
        this(parent, sourceFile.toURI(), targetDir, langScope);
    }

    public Object clone()
        throws CloneNotSupportedException
    {
        return new BomEntry(parent, sourceUri, getTarget(), getLangScope(), getFileType());
    }

    private BomEntry(Bom parent, URI sourceUri, TargetFile target, String langScope, AbstractFileType ft)
    {
        recommendedFileTypes = new TreeSet();
        fileType = AbstractFileType.EMPTY_FILETYPE;
        active = Boolean.valueOf(true);
        issues = new HashMap();
        issues.put(Level.WARNING, new EnumMap(oracle/hub/tf/dropgenerator/core/BomEntryError$ErrorType));
        issues.put(Level.SEVERE, new EnumMap(oracle/hub/tf/dropgenerator/core/BomEntryError$ErrorType));
        this.sourceUri = sourceUri;
        this.target = target;
        this.langScope = langScope;
        this.parent = parent;
        fileType = ft;
    }

    public final void scan()
    {
        setPossibleFileTypes();
        determineFileType();
        validate();
    }

    public void validate()
    {
        removeError(BomEntryError.ErrorType.MissingSourceFile);
        if(!exists())
            addError(BomEntryError.ErrorType.MissingSourceFile, "Missing file! (does not exist on the filesystem)");
        removeError(BomEntryError.ErrorType.NoTranslatableContent);
        if(getFileSize() <= 0L)
            addError(BomEntryError.ErrorType.NoTranslatableContent, "Zero byte filesize (nothing to translate)");
        removeError(BomEntryError.ErrorType.InvalidXLIFF);
        removeError(BomEntryError.ErrorType.InvalidXML);
        removeError(BomEntryError.ErrorType.HighAscii);
        removeError(BomEntryError.ErrorType.InvalidProperties);
        removeError(BomEntryError.ErrorType.AmbiguousType);
        if(!hasFileType())
        {
            addError(BomEntryError.ErrorType.AmbiguousType, "Please select the correct type for this file.");
            return;
        }
        try
        {
            DropGenerator.logger.log(Level.FINE, "Validating {0}", getSourceRelative());
            byte data[] = getData();
            getFileType().validate(data);
        }
        catch(ValidationException ex)
        {
            addError(ex.getErrorType(), ex.getMessage());
            if(ex.getOtherExceptions() != null)
            {
                ValidationException e;
                for(Iterator i$ = ex.getOtherExceptions().iterator(); i$.hasNext(); addError(e.getErrorType(), e.getMessage()))
                    e = (ValidationException)i$.next();

            }
        }
        catch(IOException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not determine file type of {0} due to an I/O exception: {1}", new Object[] {
                sourceUri, ex.getMessage()
            });
        }
        validateTokens();
    }

    private boolean exists()
    {
        if(sourceUri.getScheme().equals("file"))
            return (new File(sourceUri)).exists();
        if(sourceUri.getScheme().equals("jar"))
        {
            try
            {
                JarURLConnection connection = Util.getJarConnection(sourceUrl);
                connection.getJarEntry();
                return true;
            }
            catch(FileNotFoundException e)
            {
                return false;
            }
            catch(IOException ex)
            {
                DropGenerator.logger.log(Level.WARNING, "Unable to check if file exists within JAR {0}: {1}", new Object[] {
                    sourceUri, ex.getMessage()
                });
            }
            return false;
        } else
        {
            return false;
        }
    }

    private long getFileSize()
    {
        try
        {
            URLConnection openConnection = sourceUrl.openConnection();
            return (long)openConnection.getContentLength();
        }
        catch(IOException ex)
        {
            DropGenerator.logger.log(Level.WARNING, "Unable to check file size for {0}: {1}", new Object[] {
                sourceUri, ex.getMessage()
            });
        }
        return 0L;
    }

    private void validateTokens()
    {
        removeError(BomEntryError.ErrorType.InvalidToken);
        Iterator i$ = target.getTokens().iterator();
        do
        {
            if(!i$.hasNext())
                break;
            String token = (String)i$.next();
            if(!LanguageTokens.getColumnNames().contains(token))
            {
                String msg = (new StringBuilder()).append("Token ").append(token).append(" is not supported! The % sign can be escaped by doubling it (i.e. %%)").toString();
                if(token.length() == 1)
                    msg = "Tokens can't appear at the end of a line and MUST be followed by a supported letter or another % sign";
                addError(BomEntryError.ErrorType.InvalidToken, msg);
            }
        } while(true);
    }

    public void determineFileType()
    {
        if(recommendedFileTypes.size() == 1)
        {
            setFileType((AbstractFileType)recommendedFileTypes.first());
            return;
        }
        byte data[];
        try
        {
            data = getData();
        }
        catch(IOException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not determine file type of {0} due to an I/O exception: {1}", new Object[] {
                sourceUri, ex.getMessage()
            });
            return;
        }
        for(Iterator i$ = recommendedFileTypes.iterator(); i$.hasNext();)
        {
            AbstractFileType type = (AbstractFileType)i$.next();
            if(type.detect(data))
            {
                setFileType(type);
                return;
            }
        }

        if(!hasFileType() && getPossibleFileTypes().isEmpty())
        {
            Set oppositeType = FileTypes.getTypesForFile(parent.getDropType() != DropGenerator.DropType.UI ? DropGenerator.DropType.UI : DropGenerator.DropType.UA, getName());
            if(oppositeType.size() > 0)
                setFileType("DNT");
        }
    }

    public String getSourcePathRelative()
    {
        String relative = getSourceRelative();
        relative = Util.getUriPathNoFilename(relative);
        if(!relative.endsWith("/"))
            relative = (new StringBuilder()).append(relative).append("/").toString();
        return relative;
    }

    public String getSourceRelative()
    {
        return DropGenerator.relativize(sourceUri);
    }

    public TargetFile getTarget()
    {
        return target;
    }

    public final void setTarget(String t)
    {
        if(t == null || t.trim().isEmpty())
            t = getName();
        t = t.trim();
        t = Util.outputFileDisallowed.matcher(t).replaceAll("");
        if(Util.isArchive(sourceUri))
            t = Util.archivePathToFolderPath(t);
        String product = "";
        if(parent != null)
            product = (new StringBuilder()).append(parent.getMetaData(Bom.MetaData.productname)).append("/").toString();
        String exampleString;
        if(t.contains("/"))
            exampleString = (new StringBuilder()).append(product).append(t).toString();
        else
            exampleString = (new StringBuilder()).append(product).append(Util.archivePathToFolderPath(getSourcePathRelative())).append(t).toString();
        target = new TargetFile(t, exampleString);
        validateTokens();
    }

    public String getLangScope()
    {
        return langScope;
    }

    public void setLangScope(String langScope)
    {
        if(langScope == null)
            langScope = "";
        this.langScope = langScope;
    }

    public SortedSet getPossibleFileTypes()
    {
        return recommendedFileTypes;
    }

    private void setPossibleFileTypes()
    {
        Set fileTypes = FileTypes.getTypesForFile(parent.getDropType(), getName());
        if(fileTypes == null || fileTypes.isEmpty())
            return;
        recommendedFileTypes = new TreeSet(fileTypes);
        if(fileTypes.size() == 1)
        {
            setFileType((AbstractFileType)fileTypes.iterator().next());
        } else
        {
            AbstractFileType defaultType = (AbstractFileType)((HashMap)FileTypes.defaultExtensions.get(parent.getDropType())).get(getExtension());
            if(defaultType != null)
                setFileType(defaultType);
        }
    }

    public AbstractFileType getFileType()
    {
        return hasFileType() ? fileType : AbstractFileType.EMPTY_FILETYPE;
    }

    public boolean hasFileType()
    {
        return fileType.isValid() && !fileType.equals(AbstractFileType.EMPTY_FILETYPE);
    }

    public void setFileType(AbstractFileType ft)
    {
        if(ft.equals(fileType))
            return;
        DropGenerator.logger.log(Level.FINE, "Setting filetype of {0} to {1}", new Object[] {
            this, ft
        });
        fileType = ft;
        if(ft.getKey().equals("DNT"))
            setActive(false);
        if(!recommendedFileTypes.contains(ft))
            FileTypes.addUserExtensionType(parent.getDropType(), getExtension(), fileType);
        validate();
    }

    public void setFileType(String fileTypeCode)
    {
        setFileType(FileTypes.getFileType(parent.getDropType(), fileTypeCode));
    }

    public EnumMap getIssues(Level level)
    {
        return (EnumMap)issues.get(level);
    }

    public void addError(BomEntryError.ErrorType type, String msg)
    {
        BomEntryError issue = new BomEntryError(type, msg, this);
        EnumMap currentIssues = (EnumMap)issues.get(type.severity);
        List typeIssues = (List)currentIssues.get(type);
        if(typeIssues == null)
        {
            typeIssues = new ArrayList();
            currentIssues.put(type, typeIssues);
        }
        typeIssues.add(issue);
        EventBus.publish("erroradded", issue);
        DropGenerator.logger.log(type.severity, msg, issue);
    }

    public boolean hasIssues(Level level)
    {
        return !((EnumMap)issues.get(level)).keySet().isEmpty();
    }

    public boolean hasIssues()
    {
        return hasIssues(Level.WARNING) || hasIssues(Level.SEVERE);
    }

    private void removeError(BomEntryError.ErrorType type)
    {
        List list = (List)((EnumMap)issues.get(type.severity)).get(type);
        if(list == null)
            return;
        BomEntryError entryError;
        for(Iterator i$ = list.iterator(); i$.hasNext(); EventBus.publish("errorremoved", entryError))
            entryError = (BomEntryError)i$.next();

        ((EnumMap)issues.get(type.severity)).remove(type);
    }

    public boolean isActive()
    {
        boolean parentArchiveActive = true;
        if(parent.getDropType() == DropGenerator.DropType.UA && getUri().getScheme().equals("jar"))
        {
            URI underlyingJar = Util.getUnderlyingJar(sourceUri);
            if(underlyingJar != null)
            {
                int index = parent.indexOf(underlyingJar);
                if(index >= 0)
                {
                    BomEntry parentJar = parent.get(index);
                    parentArchiveActive = parentJar.isValid();
                }
            }
        }
        return active.booleanValue() && isValid() && parentArchiveActive;
    }

    public boolean isValid()
    {
        return !hasIssues(Level.SEVERE) && fileType.isValid() && !fileType.getKey().equals("formreference");
    }

    public void setActive(boolean a)
    {
        active = Boolean.valueOf(a);
        if(parent.getDropType() == DropGenerator.DropType.UA && Util.isArchive(sourceUri))
            if(sourceUri.getScheme().equals("jar") && a)
                try
                {
                    URI underlyingJar = Util.getUnderlyingJar(sourceUri);
                    if(underlyingJar != null)
                    {
                        int bomIndex = parent.indexOf(underlyingJar);
                        if(bomIndex >= 0 && !parent.get(bomIndex).isActive())
                            parent.get(bomIndex).setActive(true);
                    }
                }
                catch(Exception ex) { }
            else
            if(sourceUri.getScheme().equals("file") && !a)
            {
                String jarPath = (new StringBuilder()).append(getSourceRelative()).append("!/").toString();
                Iterator i$ = parent.iterator();
                do
                {
                    if(!i$.hasNext())
                        break;
                    BomEntry b = (BomEntry)i$.next();
                    if(b.getSourceRelative().startsWith(jarPath) && b.isActive() != a)
                        b.setActive(a);
                } while(true);
            }
    }

    public String getBomString()
    {
        return getBomString(false);
    }

    public String getBomString(boolean forZip)
    {
        String source = (new StringBuilder()).append('"').append(getBomSourceString(forZip)).append('"').toString();
        String type = hasFileType() ? getFileType().getKey() : "Manual";
        String outputFile = getTarget().toString();
        if(forZip && outputFile.contains("/"))
            outputFile = (new StringBuilder()).append(parent.getMetaData(Bom.MetaData.productname)).append('/').append(outputFile).toString();
        outputFile = (new StringBuilder()).append('"').append(outputFile).append('"').toString();
        String namespace = forZip ? getNamespace() : null;
        return (new StringBuilder()).append(isActive() ? "" : "#").append(Util.join(new Object[] {
            source, outputFile, getLangScope(), type, namespace
        }, ' ')).toString();
    }

    public String getBomSourceString(boolean forZip)
    {
        String source = getSourceRelative();
        if(forZip)
        {
            source = (new StringBuilder()).append(parent.getMetaData(Bom.MetaData.productname)).append('/').append(source).toString();
            if(Util.isArchive(sourceUri))
                source = Util.archivePathToFolderPath(source);
        }
        return source;
    }

    private String getNamespace()
    {
        if(!parent.getMetaData(Bom.MetaData.productgroup).equalsIgnoreCase("peopleapps"))
            return null;
        String split[] = getSourcePathRelative().split("/");
        if(split.length == 0 || split.length == 1 && split[0].isEmpty())
            return null;
        else
            return (new StringBuilder()).append("namespace=").append(parent.getMetaData(Bom.MetaData.productname)).append(":").append(split[0]).toString();
    }

    public int compareTo(Object o)
    {
        if(this == o)
            return 0;
        if(o instanceof URI)
            return sourceUri.compareTo((URI)o);
        if(o instanceof URL)
            sourceUrl.toString().compareTo(o.toString());
        else
        if(o.getClass().equals(getClass()))
            return getUri().compareTo(((BomEntry)o).getUri());
        return -1;
    }

    public boolean equals(Object obj)
    {
        if(obj == null)
            return false;
        if(getClass() != obj.getClass())
            return false;
        BomEntry other = (BomEntry)obj;
        return sourceUri == other.sourceUri || sourceUri != null && sourceUri.equals(other.sourceUri);
    }

    public int hashCode()
    {
        int hash = 7;
        hash = 11 * hash + (sourceUri == null ? 0 : sourceUri.hashCode());
        return hash;
    }

    public String getName()
    {
        return Util.getFilenameFromUri(sourceUri);
    }

    public URI getUri()
    {
        return sourceUri;
    }

    public URL getUrl()
    {
        return sourceUrl;
    }

    public String getExtension()
    {
        return Util.getExtension(sourceUri.toString());
    }

    public byte[] getData()
        throws IOException
    {
        return Util.toByteArray(sourceUrl.openStream());
    }

    private static final long serialVersionUID = 1L;
    public static final String ERROR_ADDED_TOPIC = "erroradded";
    public static final String ERROR_REMOVED_TOPIC = "errorremoved";
    private URI sourceUri;
    private URL sourceUrl;
    private TargetFile target;
    private String langScope;
    private SortedSet recommendedFileTypes;
    private AbstractFileType fileType;
    private final Map issues;
    private Boolean active;
    private final Bom parent;
}
