// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BomEntryError.java

package oracle.hub.tf.dropgenerator.core;

import java.util.logging.Level;
import java.util.logging.LogRecord;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            BomEntry

public class BomEntryError extends LogRecord
    implements Comparable
{
    public static final class ErrorType extends Enum
    {

        public static ErrorType[] values()
        {
            return (ErrorType[])$VALUES.clone();
        }

        public static ErrorType valueOf(String name)
        {
            return (ErrorType)Enum.valueOf(oracle/hub/tf/dropgenerator/core/BomEntryError$ErrorType, name);
        }

        public String toString()
        {
            return description;
        }

        public static final ErrorType MissingSourceFile;
        public static final ErrorType DuplicateFormReference;
        public static final ErrorType InvalidXLIFF;
        public static final ErrorType InvalidXML;
        public static final ErrorType InvalidToken;
        public static final ErrorType HighAscii;
        public static final ErrorType NestedSolbook;
        public static final ErrorType InvalidProperties;
        public static final ErrorType AmbiguousType;
        public static final ErrorType NoTranslatableContent;
        public static final ErrorType NotExtractable;
        final Level severity;
        private final String description;
        private static final ErrorType $VALUES[];

        static 
        {
            MissingSourceFile = new ErrorType("MissingSourceFile", 0, Level.SEVERE, "Missing source");
            DuplicateFormReference = new ErrorType("DuplicateFormReference", 1, Level.SEVERE, "Duplicate form reference");
            InvalidXLIFF = new ErrorType("InvalidXLIFF", 2, Level.SEVERE, "Invalid XLIFF");
            InvalidXML = new ErrorType("InvalidXML", 3, Level.SEVERE, "XML unrecognized");
            InvalidToken = new ErrorType("InvalidToken", 4, Level.SEVERE, "Invalid language token");
            HighAscii = new ErrorType("HighAscii", 5, Level.SEVERE, "High-ASCII error");
            NestedSolbook = new ErrorType("NestedSolbook", 6, Level.SEVERE, "Nested SolBooks");
            InvalidProperties = new ErrorType("InvalidProperties", 7, Level.WARNING, "Invalid java properties");
            AmbiguousType = new ErrorType("AmbiguousType", 8, Level.WARNING, "Ambiguous");
            NoTranslatableContent = new ErrorType("NoTranslatableContent", 9, Level.SEVERE, "No translatable content found");
            NotExtractable = new ErrorType("NotExtractable", 10, Level.SEVERE, "Archive will not be processed");
            $VALUES = (new ErrorType[] {
                MissingSourceFile, DuplicateFormReference, InvalidXLIFF, InvalidXML, InvalidToken, HighAscii, NestedSolbook, InvalidProperties, AmbiguousType, NoTranslatableContent, 
                NotExtractable
            });
        }

        private ErrorType(String s, int i, Level l, String d)
        {
            super(s, i);
            severity = l;
            description = d;
        }
    }


    BomEntryError(ErrorType errorType, String msg, BomEntry e)
    {
        super(errorType.severity, msg);
        this.errorType = errorType;
        entry = e;
    }

    public ErrorType getErrorType()
    {
        return errorType;
    }

    void setErrorType(ErrorType errorType)
    {
        this.errorType = errorType;
    }

    public BomEntry getEntry()
    {
        return entry;
    }

    public int compareTo(BomEntryError o)
    {
        if(o.equals(this))
            return 0;
        if(!getLevel().equals(o.getLevel()))
            return (new Integer(o.getLevel().intValue())).compareTo(Integer.valueOf(getLevel().intValue()));
        if(!entry.equals(o.getEntry()))
            return entry.compareTo(o.getEntry());
        if(!errorType.equals(o.getErrorType()))
            return errorType.compareTo(o.getErrorType());
        else
            return getMessage().compareTo(o.getMessage());
    }

    public int hashCode()
    {
        int hash = 7;
        hash *= errorType.toString().hashCode();
        hash *= getLevel().hashCode();
        hash *= entry.hashCode();
        hash *= getMessage().hashCode();
        return hash;
    }

    public boolean equals(Object obj)
    {
        if(this == obj)
            return true;
        if(!(obj instanceof BomEntryError))
        {
            return false;
        } else
        {
            BomEntryError other = (BomEntryError)obj;
            return errorType.equals(other.getErrorType()) && getLevel().equals(other.getLevel()) && entry.equals(other.getEntry()) && getMessage().equals(other.getMessage());
        }
    }

    public String toString()
    {
        return super.getMessage();
    }

    public volatile int compareTo(Object x0)
    {
        return compareTo((BomEntryError)x0);
    }

    private static final long serialVersionUID = 1L;
    private ErrorType errorType;
    private final BomEntry entry;
}
