// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   XliffType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            XliffValid

class XliffErrorHandler extends DefaultHandler
{

    XliffErrorHandler()
    {
        tagNumber = 0;
    }

    public void startElement(String uri, String name, String qName, Attributes atts)
        throws SAXException
    {
        if(tagNumber == 0 && !qName.equals("xliff"))
            throw new SAXException("The <xliff> tag must be document's root. Please consult XLIFF specification.");
        if(tagNumber == 1 && !qName.equals("file"))
            throw new SAXException("The <file> tag is mandatory, but could not be found. Please consult XLIFF specification.");
        if(tagNumber == 1 && qName.equals("file"))
        {
            for(int i = 0; i < atts.getLength(); i++)
                if(atts.getQName(i).equals("datatype"))
                    throw new SAXException(new XliffValid());

        } else
        if(tagNumber > 1)
            throw new SAXException("The <file> tag must contain the datatype attribute. Please consult XLIFF specification.");
        tagNumber++;
    }

    private int tagNumber;
}
