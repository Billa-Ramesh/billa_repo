// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LanguageTokens.java

package oracle.hub.tf.dropgenerator.core;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.*;

// Referenced classes of package oracle.hub.tf.dropgenerator.core:
//            DropGenerator

class TokenConfigValidationEventHandler
    implements ValidationEventHandler
{

    TokenConfigValidationEventHandler()
    {
    }

    public boolean handleEvent(ValidationEvent ve)
    {
        if(ve.getSeverity() == 2 || ve.getSeverity() == 1)
        {
            ValidationEventLocator locator = ve.getLocator();
            DropGenerator.logger.log(Level.WARNING, "Invalid token configuration document: {0}", locator.getURL());
            DropGenerator.logger.log(Level.WARNING, "Error at column {0}, line {1}: {2}", new Object[] {
                Integer.valueOf(locator.getColumnNumber()), Integer.valueOf(locator.getLineNumber()), ve.getMessage()
            });
            return false;
        } else
        {
            return true;
        }
    }
}
