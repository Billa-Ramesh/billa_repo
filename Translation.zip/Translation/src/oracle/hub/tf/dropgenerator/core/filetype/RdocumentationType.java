// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   RdocumentationType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import oracle.hub.tf.dropgenerator.core.BomEntryError;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            GenericType, ValidationException

public class RdocumentationType extends GenericType
{

    public RdocumentationType(String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dropType)
    {
        super(typeCode, name, dropType);
    }

    public void validate(byte data[])
        throws ValidationException
    {
        if(!detect(data))
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.NoTranslatableContent, "The R documentation type must contain one of the following translatable tags: \\title, \\description, \\arguments, \\details, \\value", null);
        else
            return;
    }
}
