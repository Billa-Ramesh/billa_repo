// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FileTypeInterface.java

package oracle.hub.tf.dropgenerator.core.filetype;

import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            ValidationException

interface FileTypeInterface
{

    public abstract oracle.hub.tf.dropgenerator.core.DropGenerator.DropType getDropType();

    public abstract void validate(byte abyte0[])
        throws ValidationException;

    public abstract boolean detect(byte abyte0[]);
}
