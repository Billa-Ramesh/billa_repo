// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PropertyLoader.java

package oracle.hub.tf.dropgenerator.core;

import java.io.InputStream;
import java.util.Properties;

abstract class PropertyLoader
{

    public static Properties loadProperties(String name, ClassLoader loader)
    {
        Properties result;
        InputStream in;
        if(name == null)
            throw new IllegalArgumentException("null input: name");
        if(name.startsWith("/"))
            name = name.substring(1);
        if(name.endsWith(".properties"))
            name = name.substring(0, name.length() - ".properties".length());
        result = null;
        in = null;
        if(loader == null)
            loader = Thread.currentThread().getContextClassLoader();
        name = name.replace('.', '/');
        if(!name.endsWith(".properties"))
            name = name.concat(".properties");
        in = loader.getResourceAsStream(name);
        if(in != null)
        {
            result = new Properties();
            result.load(in);
        }
        if(in != null)
            try
            {
                in.close();
            }
            catch(Throwable ignore) { }
        break MISSING_BLOCK_LABEL_171;
        Exception e;
        e;
        result = null;
        if(in != null)
            try
            {
                in.close();
            }
            catch(Throwable ignore) { }
        break MISSING_BLOCK_LABEL_171;
        Exception exception;
        exception;
        if(in != null)
            try
            {
                in.close();
            }
            catch(Throwable ignore) { }
        throw exception;
        if(result == null)
            throw new IllegalArgumentException((new StringBuilder()).append("could not load [").append(name).append("]").toString());
        else
            return result;
    }

    public static Properties loadProperties(String name)
    {
        return loadProperties(name, Thread.currentThread().getContextClassLoader());
    }

    private PropertyLoader()
    {
    }

    private static final boolean LOAD_AS_RESOURCE_BUNDLE = false;
    private static final String SUFFIX = ".properties";
}
