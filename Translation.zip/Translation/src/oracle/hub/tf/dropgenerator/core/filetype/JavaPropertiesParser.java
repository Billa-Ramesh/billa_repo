// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JavaPropertiesType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.*;
import java.text.ParseException;
import java.util.*;

class JavaPropertiesParser
{
    private class LineReader extends BufferedReader
    {

        public String readLine()
            throws IOException
        {
            String line = readLine2();
            if(line == null)
                return null;
            if(line.trim().length() == 0)
                return line;
            if(getCommentChars().indexOf(line.trim().charAt(0)) >= 0)
                return line;
            StringBuffer s = new StringBuffer(line);
            for(int lastChar = s.length() - 1; isStringContinued(s); lastChar = s.length() - 1)
            {
                s.deleteCharAt(lastChar);
                String next = readLine2();
                if(next != null)
                {
                    next = next.replaceFirst("^[ \t]+", "");
                    s.append(next);
                }
            }

            return s.toString();
        }

        private boolean isStringContinued(StringBuffer s)
        {
            int charPos = s.length() - 1;
            int numBackslashes = 0;
            for(; charPos >= 0 && s.charAt(charPos) == '\\'; charPos--)
                numBackslashes++;

            return numBackslashes % 2 != 0;
        }

        private String readLine2()
            throws IOException
        {
            currentLine++;
            return super.readLine();
        }

        public int getCurrentLine()
        {
            return currentLine;
        }

        private int currentLine;
        final JavaPropertiesParser this$0;

        public LineReader(Reader r)
        {
            this$0 = JavaPropertiesParser.this;
            super(r);
            currentLine = 0;
        }
    }


    JavaPropertiesParser()
    {
        issues = new HashMap();
    }

    public List parse(String properties)
        throws IOException, ParseException
    {
        parseInternal(new StringReader(properties));
        return new ArrayList(issues.values());
    }

    protected void parseInternal(Reader in)
        throws ParseException, IOException
    {
        Map names;
        String commentChars;
        String delimiters;
        LineReader r2;
        boolean inMultiLineComment;
        StringBuilder comment;
        names = new HashMap();
        commentChars = getCommentChars();
        delimiters = getDelimiters();
        r2 = new LineReader(in);
        inMultiLineComment = false;
        comment = new StringBuilder(256);
_L3:
        String line;
        int keyStart;
        int keyLen;
        int valueStart;
        String key;
label0:
        {
            if((line = r2.readLine()) == null)
                break; /* Loop/switch isn't completed */
            String line2 = line.trim();
            if(line2.length() == 0)
                continue; /* Loop/switch isn't completed */
            boolean cStyleCommentLine = false;
            if(line2.indexOf("/*") == 0)
            {
                cStyleCommentLine = true;
                inMultiLineComment = true;
            } else
            if(line2.indexOf("*/") != -1 && line2.indexOf("*/") == line2.length() - 2 && inMultiLineComment)
            {
                cStyleCommentLine = true;
                inMultiLineComment = false;
            } else
            if(line2.indexOf('*') == 0 && (inMultiLineComment || line2.length() == 1 || DELIMITERS.indexOf(line2.charAt(1)) != -1))
                cStyleCommentLine = true;
            else
            if(line2.length() >= 2 && (line2.charAt(0) == '/' && delimiters.indexOf(line2.charAt(1)) >= 0 || line2.indexOf("//") == 0))
                cStyleCommentLine = true;
            if(cStyleCommentLine)
                continue; /* Loop/switch isn't completed */
            if(commentChars.indexOf(line2.charAt(0)) >= 0)
            {
                comment.append(line2.substring(1).trim());
                continue; /* Loop/switch isn't completed */
            }
            boolean precedingBackslash = false;
            boolean hasSep = false;
            keyStart = 0;
            keyLen = 0;
            valueStart = 0;
            for(; Character.isWhitespace(line.charAt(keyStart)); keyStart++);
            for(; keyLen < line.length() - keyStart; keyLen++)
            {
                char c = line.charAt(keyStart + keyLen);
                if(delimiters.indexOf(c) >= 0 && !precedingBackslash)
                {
                    valueStart = keyStart + keyLen + 1;
                    hasSep = !Character.isWhitespace(c);
                    break;
                }
                if(c == '\\')
                    precedingBackslash = !precedingBackslash;
                else
                    precedingBackslash = false;
            }

            for(; valueStart < line.length(); valueStart++)
            {
                char c = line.charAt(valueStart);
                if(c == ' ' || c == '\t' || c == '\f')
                    continue;
                if(hasSep || c != '=' && c != ':')
                    break;
                hasSep = true;
            }

            synchronized(m_convertBuf)
            {
                key = loadConvert(line, keyStart, keyLen, m_convertBuf);
                key = convertKeyForKit(key, m_convertBuf);
                if(key.length() != 0)
                    break label0;
                issues.put(key, new ParseException("Blank/null key", r2.getCurrentLine()));
            }
            continue; /* Loop/switch isn't completed */
        }
        String value = "";
        if(valueStart > (keyStart + keyLen) - 1)
        {
            value = loadConvert(line, valueStart, line.length() - valueStart, m_convertBuf);
            value = value.replaceAll("\t", "\\\\t");
        }
        List lineNumbers = (List)names.get(key);
        if(lineNumbers != null)
        {
            StringBuilder msg = new StringBuilder();
            msg.append("Key \"");
            msg.append(key);
            msg.append("\" has already appeared at line(s) ");
            Iterator it = lineNumbers.iterator();
            do
            {
                if(!it.hasNext())
                    break;
                msg.append(it.next());
                if(msg.length() > 0)
                    msg.append(", ");
            } while(true);
            msg.delete(msg.length() - 2, msg.length());
            msg.append(". Non-unique keys are likely to increase translation costs due to over-translating.");
            lineNumbers.add(new Integer(r2.getCurrentLine()));
            issues.put(key, new ParseException(msg.toString(), r2.getCurrentLine()));
        } else
        {
            lineNumbers = new LinkedList();
            lineNumbers.add(new Integer(r2.getCurrentLine()));
            names.put(key, lineNumbers);
        }
        ac;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
        comment.setLength(0);
        if(true) goto _L3; else goto _L2
_L2:
    }

    protected String getCommentChars()
    {
        return COMMENT_CHARS;
    }

    protected String getDelimiters()
    {
        return DELIMITERS;
    }

    protected String convertKeyForKit(String in, char convtBuf[])
    {
        char out[] = convtBuf;
        int outLen = 0;
        int off = 0;
        for(int end = in.length(); off < end;)
        {
            char aChar = in.charAt(off++);
            if(aChar == '\\')
            {
                aChar = in.charAt(off++);
                if(aChar == 'r' || aChar == 't' || aChar == 'n')
                    out[outLen++] = ' ';
                else
                    out[outLen++] = aChar;
            } else
            {
                out[outLen++] = aChar;
            }
        }

        return new String(out, 0, outLen);
    }

    protected String loadConvert(String in, int off, int len, char convtBuf[])
        throws ParseException
    {
        if(convtBuf.length < len)
        {
            int newLen = len * 2;
            if(newLen < 0)
                newLen = 0x7fffffff;
            convtBuf = new char[newLen];
        }
        char out[] = convtBuf;
        int outLen = 0;
        int start = off;
        for(int end = off + len; off < end;)
        {
            char aChar = in.charAt(off++);
            if(aChar == '\\')
            {
                aChar = in.charAt(off++);
                if(aChar == 'u')
                {
                    if(in.length() - off < 4)
                        throw new ParseException("\\u not followed by 4 hex digits at offset ", start);
                    int value = 0;
                    for(int i = 0; i < 4; i++)
                    {
                        aChar = in.charAt(off++);
                        switch(aChar)
                        {
                        case 48: // '0'
                        case 49: // '1'
                        case 50: // '2'
                        case 51: // '3'
                        case 52: // '4'
                        case 53: // '5'
                        case 54: // '6'
                        case 55: // '7'
                        case 56: // '8'
                        case 57: // '9'
                            value = ((value << 4) + aChar) - 48;
                            break;

                        case 97: // 'a'
                        case 98: // 'b'
                        case 99: // 'c'
                        case 100: // 'd'
                        case 101: // 'e'
                        case 102: // 'f'
                            value = ((value << 4) + 10 + aChar) - 97;
                            break;

                        case 65: // 'A'
                        case 66: // 'B'
                        case 67: // 'C'
                        case 68: // 'D'
                        case 69: // 'E'
                        case 70: // 'F'
                            value = ((value << 4) + 10 + aChar) - 65;
                            break;

                        case 58: // ':'
                        case 59: // ';'
                        case 60: // '<'
                        case 61: // '='
                        case 62: // '>'
                        case 63: // '?'
                        case 64: // '@'
                        case 71: // 'G'
                        case 72: // 'H'
                        case 73: // 'I'
                        case 74: // 'J'
                        case 75: // 'K'
                        case 76: // 'L'
                        case 77: // 'M'
                        case 78: // 'N'
                        case 79: // 'O'
                        case 80: // 'P'
                        case 81: // 'Q'
                        case 82: // 'R'
                        case 83: // 'S'
                        case 84: // 'T'
                        case 85: // 'U'
                        case 86: // 'V'
                        case 87: // 'W'
                        case 88: // 'X'
                        case 89: // 'Y'
                        case 90: // 'Z'
                        case 91: // '['
                        case 92: // '\\'
                        case 93: // ']'
                        case 94: // '^'
                        case 95: // '_'
                        case 96: // '`'
                        default:
                            throw new ParseException((new StringBuilder()).append("Malformed unicode encoding: \"\\u").append(in.substring(off - i - 1, (off - i) + 3)).append("\".").toString(), start);
                        }
                    }

                    if((char)value <= '\177')
                    {
                        out[outLen++] = '\\';
                        out[outLen++] = 'u';
                        int i = 4;
                        while(i > 0) 
                        {
                            out[outLen++] = in.charAt(off - i);
                            i--;
                        }
                    } else
                    if(!isCharValid((char)value))
                    {
                        out[outLen++] = '\\';
                        out[outLen++] = 'u';
                        int i = 4;
                        while(i > 0) 
                        {
                            out[outLen++] = in.charAt(off - i);
                            i--;
                        }
                    } else
                    {
                        out[outLen++] = (char)value;
                    }
                } else
                if(off == start + 2 && " =:".indexOf(aChar) != -1)
                {
                    out[outLen++] = aChar;
                } else
                {
                    out[outLen++] = '\\';
                    out[outLen++] = aChar;
                }
            } else
            {
                out[outLen++] = aChar;
            }
        }

        return new String(out, 0, outLen);
    }

    protected boolean isCharValid(char ch)
    {
        CharsetEncoder win1252 = Charset.forName("windows-1252").newEncoder().onUnmappableCharacter(CodingErrorAction.REPORT);
        CoderResult cr = win1252.encode(CharBuffer.wrap(new char[] {
            ch
        }), ByteBuffer.allocate(4), true);
        return !cr.isUnmappable();
    }

    private static String COMMENT_CHARS = "!#";
    private static String DELIMITERS = "=: \t\f";
    final char m_convertBuf[] = new char[1024];
    Map issues;

}
