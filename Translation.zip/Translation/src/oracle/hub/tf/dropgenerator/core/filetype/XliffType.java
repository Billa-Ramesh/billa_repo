// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   XliffType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.*;
import java.util.logging.Logger;
import oracle.hub.tf.dropgenerator.core.BomEntryError;
import oracle.hub.tf.dropgenerator.core.DropGenerator;
import org.xml.sax.*;
import org.xml.sax.helpers.XMLReaderFactory;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            AbstractXmlFileType, ValidationException, XliffErrorHandler, XliffValid

public class XliffType extends AbstractXmlFileType
{

    public XliffType(String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dropType)
    {
        super(typeCode, name, dropType);
    }

    public boolean detect(byte data[])
    {
        try
        {
            validate(data);
        }
        catch(ValidationException ex)
        {
            return false;
        }
        return true;
    }

    public void validate(byte data[])
        throws ValidationException
    {
        super.validate(data);
        validator.setContentHandler(new XliffErrorHandler());
        try
        {
            validator.parse(new InputSource(new ByteArrayInputStream(data)));
        }
        catch(FileNotFoundException e)
        {
            ValidationException.handleException(e);
        }
        catch(IOException e)
        {
            ValidationException.handleException(e);
        }
        catch(SAXException e)
        {
            if(!(e.getException() instanceof XliffValid))
                throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidXLIFF, e.getMessage(), e);
        }
    }

    private static final XMLReader validator;

    static 
    {
        XMLReader xr = null;
        try
        {
            xr = XMLReaderFactory.createXMLReader();
        }
        catch(SAXException e)
        {
            DropGenerator.logger.severe("Could not initialize XML Reader");
        }
        xr.setEntityResolver(new EntityResolver() {

            public InputSource resolveEntity(String publicId, String systemId)
                throws SAXException, IOException
            {
                return new InputSource(new StringReader(""));
            }

        }
);
        validator = xr;
    }
}
