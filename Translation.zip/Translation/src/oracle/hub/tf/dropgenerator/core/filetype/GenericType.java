// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   GenericType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            AbstractFileType, ValidationException

public class GenericType extends AbstractFileType
{

    public GenericType(String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dt)
    {
        super(typeCode, name, dt);
        patterns = new ArrayList();
    }

    public void validate(byte abyte0[])
        throws ValidationException
    {
    }

    public boolean detect(byte data[])
    {
        String fileContents;
        try
        {
            fileContents = new String(data, "UTF-8");
        }
        catch(UnsupportedEncodingException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "UTF-8 charset not supported on this platform. Aborting detection...");
            return false;
        }
        if(fileContents == null || fileContents.isEmpty())
            return false;
        for(Iterator i$ = patterns.iterator(); i$.hasNext();)
        {
            Pattern p = (Pattern)i$.next();
            Matcher regexMatcher = p.matcher(fileContents);
            if(regexMatcher.find())
                return true;
        }

        return false;
    }

    public void addRegex(String regex)
    {
        patterns.add(Pattern.compile(regex));
    }

    private ArrayList patterns;
}
