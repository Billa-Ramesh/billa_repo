// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   XliffType.java

package oracle.hub.tf.dropgenerator.core.filetype;


class XliffValid extends Exception
{

    XliffValid()
    {
    }

    private static final long serialVersionUID = 1L;
}
