// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OpenOfficeType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import oracle.hub.tf.dropgenerator.core.BomEntryError;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            AbstractFileType, ValidationException

public final class OpenOfficeType extends AbstractFileType
{

    public OpenOfficeType(String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dt)
    {
        super(typeCode, name, dt);
    }

    public void validate(byte data[])
        throws ValidationException
    {
        ByteArrayInputStream bis;
        ZipInputStream zip;
        ZipEntry content;
        bis = new ByteArrayInputStream(data);
        zip = new ZipInputStream(bis);
        content = null;
        IOException ex;
        while((content = zip.getNextEntry()) != null) 
            if(content.getName().equals("content.xml"))
            {
                if(bis != null)
                    try
                    {
                        bis.close();
                    }
                    // Misplaced declaration of an exception variable
                    catch(IOException ex)
                    {
                        Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/OpenOfficeType.getName()).log(Level.SEVERE, null, ex);
                    }
                return;
            }
        if(bis != null)
            try
            {
                bis.close();
            }
            // Misplaced declaration of an exception variable
            catch(IOException ex)
            {
                Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/OpenOfficeType.getName()).log(Level.SEVERE, null, ex);
            }
        break MISSING_BLOCK_LABEL_203;
        ex;
        DropGenerator.logger.log(Level.INFO, "Error while reading OpenOffice file: {0}", new Object[] {
            ex.getMessage()
        });
        if(bis != null)
            try
            {
                bis.close();
            }
            catch(IOException ex)
            {
                Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/OpenOfficeType.getName()).log(Level.SEVERE, null, ex);
            }
        return;
        Exception exception;
        exception;
        if(bis != null)
            try
            {
                bis.close();
            }
            catch(IOException ex)
            {
                Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/OpenOfficeType.getName()).log(Level.SEVERE, null, ex);
            }
        throw exception;
        if(content == null)
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.NoTranslatableContent, "No translatable content found (could not find content.xml in archive root).", null);
        else
            return;
    }

    public boolean detect(byte data[])
    {
        return false;
    }
}
