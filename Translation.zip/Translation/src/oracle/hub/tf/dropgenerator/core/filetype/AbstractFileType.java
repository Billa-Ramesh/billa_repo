// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AbstractFileType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            GenericType, FileTypeInterface

public abstract class AbstractFileType
    implements FileTypeInterface, java.util.Map.Entry, Comparable
{

    public AbstractFileType(String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dropType)
    {
        this.typeCode = typeCode;
        this.name = name;
        this.dropType = dropType;
    }

    public static AbstractFileType getFileType(Class c, String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dropType)
    {
        Constructor constructor;
        try
        {
            constructor = c.getConstructor(new Class[] {
                java/lang/String, java/lang/String, oracle/hub/tf/dropgenerator/core/DropGenerator$DropType
            });
        }
        catch(NoSuchMethodException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Could not find constructor for {0}: {1}", new String[] {
                c.getName(), ex.getMessage()
            });
            return null;
        }
        catch(SecurityException ex)
        {
            DropGenerator.logger.log(Level.SEVERE, "Security exception: {0}", ex.getMessage());
            return null;
        }
        AbstractFileType fileType = null;
        try
        {
            fileType = (AbstractFileType)constructor.newInstance(new Object[] {
                typeCode, name, dropType
            });
        }
        catch(InstantiationException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/AbstractFileType.getName()).log(Level.SEVERE, null, ex);
        }
        catch(IllegalAccessException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/AbstractFileType.getName()).log(Level.SEVERE, null, ex);
        }
        catch(IllegalArgumentException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/AbstractFileType.getName()).log(Level.SEVERE, null, ex);
        }
        catch(InvocationTargetException ex)
        {
            Logger.getLogger(oracle/hub/tf/dropgenerator/core/filetype/AbstractFileType.getName()).log(Level.SEVERE, null, ex);
        }
        return fileType;
    }

    public boolean isValid()
    {
        return !getKey().trim().isEmpty() && !getValue().trim().isEmpty();
    }

    public String getKey()
    {
        return typeCode;
    }

    public String getValue()
    {
        return name;
    }

    public oracle.hub.tf.dropgenerator.core.DropGenerator.DropType getDropType()
    {
        return dropType;
    }

    public final String setValue(String value)
    {
        throw new UnsupportedOperationException((new StringBuilder()).append(getClass().getName()).append(" is immutable").toString());
    }

    public int compareTo(AbstractFileType o)
    {
        if(o.equals(this))
            return 0;
        else
            return getValue().compareTo(o.getValue());
    }

    public String toString()
    {
        return getValue();
    }

    public boolean equals(Object obj)
    {
        if(obj == null)
            return false;
        if(obj == this)
            return true;
        if(!(obj instanceof AbstractFileType))
        {
            return false;
        } else
        {
            AbstractFileType other = (AbstractFileType)obj;
            return getKey().equals(other.getKey()) && getDropType().equals(other.getDropType());
        }
    }

    public int hashCode()
    {
        int hash = 3;
        hash *= getKey().hashCode();
        hash *= getDropType().hashCode();
        return hash;
    }

    public volatile Object setValue(Object x0)
    {
        return setValue((String)x0);
    }

    public volatile Object getValue()
    {
        return getValue();
    }

    public volatile Object getKey()
    {
        return getKey();
    }

    public volatile int compareTo(Object x0)
    {
        return compareTo((AbstractFileType)x0);
    }

    private final String typeCode;
    private final String name;
    private final oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dropType;
    public static final AbstractFileType EMPTY_FILETYPE;
    public static final AbstractFileType OTHER_FILETYPE;

    static 
    {
        EMPTY_FILETYPE = new GenericType("", "", oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.COMMON);
        OTHER_FILETYPE = new GenericType("other", "Other ...", oracle.hub.tf.dropgenerator.core.DropGenerator.DropType.COMMON);
    }
}
