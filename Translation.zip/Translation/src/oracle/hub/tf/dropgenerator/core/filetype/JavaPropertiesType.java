// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JavaPropertiesType.java

package oracle.hub.tf.dropgenerator.core.filetype;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import oracle.hub.tf.dropgenerator.core.BomEntryError;
import oracle.hub.tf.dropgenerator.core.DropGenerator;

// Referenced classes of package oracle.hub.tf.dropgenerator.core.filetype:
//            AbstractFileType, JavaPropertiesParser, ValidationException

public class JavaPropertiesType extends AbstractFileType
{

    public JavaPropertiesType(String typeCode, String name, oracle.hub.tf.dropgenerator.core.DropGenerator.DropType dropType)
    {
        super(typeCode, name, dropType);
    }

    public void validate(byte data[])
        throws ValidationException
    {
        JavaPropertiesParser parser = new JavaPropertiesParser();
        List exceptions = null;
        try
        {
            exceptions = parser.parse(new String(data, "UTF-8"));
        }
        catch(IOException ex)
        {
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.MissingSourceFile, ex.getMessage(), ex);
        }
        catch(ParseException ex)
        {
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidProperties, ex.getMessage(), ex);
        }
        if(exceptions != null && !exceptions.isEmpty())
        {
            ArrayList otherIssues = null;
            if(exceptions.size() > 1)
            {
                otherIssues = new ArrayList(exceptions.size() - 1);
                for(int i = 1; i < exceptions.size(); i++)
                {
                    ParseException e = (ParseException)exceptions.get(i);
                    otherIssues.add(new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidProperties, (new StringBuilder()).append("Line ").append(e.getErrorOffset()).append(": ").append(e.getMessage()).toString(), e));
                }

            }
            ParseException e = (ParseException)exceptions.get(0);
            throw new ValidationException(oracle.hub.tf.dropgenerator.core.BomEntryError.ErrorType.InvalidProperties, (new StringBuilder()).append("Line ").append(e.getErrorOffset()).append(": ").append(e.getMessage()).toString(), e, otherIssues);
        } else
        {
            return;
        }
    }

    public boolean detect(byte data[])
    {
        return false;
    }
}
