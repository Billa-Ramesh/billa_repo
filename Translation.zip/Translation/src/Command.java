import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Command {

	public static void main(String args[]){
		 System.out.print("Please enter  1 for Import & 2 for Export: ");
	      //  open up standard input
	      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	      String option = null;
	      //  read the username from the command-line; need to use try/catch with the
	      //  readLine() method
	      try {
	    	  option = br.readLine();
	    	  System.out.println("enter the second value :yes/no ? ");
	    	  String  options = br.readLine();
	    	  System.out.println(options+option);
	    	  
	      }catch (IOException ioe) {
		         System.out.println("IO error trying to read your name!");
		         System.exit(1);
		      }
	}
}
