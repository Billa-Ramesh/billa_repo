import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;


public class CreateRadioButton extends JPanel{
	 
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 917627546250212907L;
	private JComboBox filterType;
	private JLabel l1,l2,l3;
	ActionListener filePath = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	fc = new JFileChooser();
    		fc.setCurrentDirectory(new java.io.File("."));
    		fc.setDialogTitle("sdfdf");
    		fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    		//
    		// disable the "All files" option.
    		//
    		fc.setAcceptAllFileFilterUsed(false);
    		//    
    		if (fc.showOpenDialog(selectFilePath) == JFileChooser.APPROVE_OPTION) {

    			File path = fc.getSelectedFile();
    			try {
    				filepath = path.getCanonicalPath();
    			} catch (IOException e1) {
    				
    				e1.printStackTrace();
    			}
    			System.out.println("getCurrentDirectory(): "
    					+ fc.getCurrentDirectory() + filepath);
    			jtextArea.setText(filepath);
    			System.out.println("getSelectedFile() : " + fc.getSelectedFile());
    		} else {
    			System.out.println("No Selection ");
    		}
        }

          
    };
	ActionListener action = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            JRadioButton button = (JRadioButton) e.getSource();
            System.out.println("You select button: " + button.getText());
        }
    };
    ActionListener buttonActionListener = new ActionListener() {
        public void actionPerformed(ActionEvent actionEvent) {
        	
        	 String ad = group.getSelection().getActionCommand();
        	 
        System.out.println("selected----------> "+ad+" next "+filterType.getSelectedItem());
        
        checkLog l=new checkLog(jtextArea);
        l.loop();
        
        }
      };
      
	private ButtonGroup group;
	private JRadioButton button1,button2,button3,button4,button5;
	
	private JFileChooser fc;
	private String filepath;
	private JButton selectFilePath;
	private JTextArea jtextArea;
	private Box masterAndFinalBox;
	private JButton submit;
	
	private JLabel createXLIFFLable;
	private Box createXLIFFBox;
	private JButton createXLIFFSubmit;
	private Box createXLIFFBox1;
	private JButton createXLIFFbutton;
	
	public CreateRadioButton(JComboBox filterType, JTextArea jtextArea){
	this.filterType=filterType;
	this.jtextArea=jtextArea;
	//setPreferredSize(new Dimension(300, 0));
	//setBorder(BorderFactory.createLineBorder (Color.blue, 2));
	

	}
	public CreateRadioButton() {
		JLabel j=new JLabel("Ramesh");
		add(j);
		setVisible(true);
		// TODO Auto-generated constructor stub
	}
	public void masterAndFinal(){
		this.removeAll();
		button1 = new JRadioButton("Insert into Master table :");
		button1.setActionCommand("INSERT_MASTER_FINAL");
	
	    button2 = new JRadioButton("Update with PM changes :");
	    button2.setActionCommand("UPDATE_PM_CHANGES");
	 
	    button3 = new JRadioButton("Insert Duplicates :");
	    button3.setActionCommand("INSERT_DUPLICATE");

	    button4 = new JRadioButton("Delete Duplicates :");
	    button4.setActionCommand("DELETE-DUPLICATE");
	    
	    button5 = new JRadioButton("Insert unique values into Final table :");
	    button4.setActionCommand("INSERT_FINAL");
	    masterAndFinalBox = Box.createVerticalBox();
	 
	    submit = new JButton("Submit");
		group = new ButtonGroup();
		group.add(button1);
		
		group.add(button2);
		group.add(button3);
		group.add(button4);
		group.add(button5);
		masterAndFinalBox.add(button1);
		masterAndFinalBox.add(button2);
		masterAndFinalBox.add(button3);
		masterAndFinalBox.add(button4);
		masterAndFinalBox.add(button5);
		masterAndFinalBox.add(submit);
		
		add(masterAndFinalBox, BorderLayout.CENTER);
		submit.addActionListener(buttonActionListener);
		revalidate();
		repaint();
		setVisible(true);
	}
	 void addCompForBorder(Border border,
                          String description,
                          Container container) {
        JPanel comp = new JPanel(new GridLayout(1, 1), false);
        createXLIFFLable=new JLabel("Select Path For Storing the XLIFF FIles:");
		createXLIFFbutton=new JButton("Browse");
	    createXLIFFBox = Box.createHorizontalBox();
	    createXLIFFBox1 = Box.createVerticalBox();
		createXLIFFSubmit = new JButton("Submit");
		createXLIFFBox.add(createXLIFFLable);
	    createXLIFFBox.add(createXLIFFbutton);
	    createXLIFFBox1.add(createXLIFFBox);
		createXLIFFBox1.add(createXLIFFSubmit);
		
		comp.add(createXLIFFBox1, BorderLayout.CENTER);
		createXLIFFSubmit.addActionListener(buttonActionListener);
     //   JLabel label = new JLabel(description, JLabel.CENTER);
     //   comp.add(label);
        comp.setBorder(border);

        container.add(Box.createRigidArea(new Dimension(0, 10)));
        container.add(comp);
    }
	public void createXLIFF(){
		this.removeAll();
		
		createXLIFFLable=new JLabel("Select Path For Storing the XLIFF FIles:");
		createXLIFFbutton=new JButton("Browse");
	    createXLIFFBox = Box.createHorizontalBox();
	    createXLIFFBox1 = Box.createVerticalBox();
		createXLIFFSubmit = new JButton("Submit");
		createXLIFFBox.add(createXLIFFLable);
	    createXLIFFBox.add(createXLIFFbutton);
	    createXLIFFBox1.add(createXLIFFBox);
		createXLIFFBox1.add(createXLIFFSubmit);
		
		
		add(createXLIFFBox1, BorderLayout.CENTER);
		createXLIFFSubmit.addActionListener(buttonActionListener);
		createXLIFFbutton.addActionListener(filePath);
	    revalidate();
	    repaint();
		setVisible(true);
	}
	public void xliff2DB(){
		this.removeAll();
		Border paneEdge = BorderFactory.createEmptyBorder(0,10,10,10);
		JPanel titledBorders = new JPanel();
        titledBorders.setBorder(paneEdge);
        titledBorders.setLayout(new BoxLayout(titledBorders,
                                              BoxLayout.Y_AXIS));
        TitledBorder titled;

        titled = BorderFactory.createTitledBorder("Creating The XLIFF Files");
        addCompForBorder(titled,
                         "default titled border"
                         + " (default just., default pos.)",
                         titledBorders);
        add(titledBorders);
        revalidate();
	    repaint();
		setVisible(true);
	}
	public void insertAll(){
		this.removeAll();
		//Border paneEdge = BorderFactory.createEmptyBorder(0,10,10,10);
		JPanel titledBorders = new JPanel();
       // titledBorders.setBorder(paneEdge);
        titledBorders.setLayout(new BoxLayout(titledBorders,
                                              BoxLayout.Y_AXIS));
        TitledBorder titled;

        titled = BorderFactory.createTitledBorder("Insert All Tables data Into the \n corresponding table");
           
	//	JPanel comp = new JPanel(new GridLayout(1, 1), false);
        createXLIFFLable=new JLabel("Select Path For Storing the XLIFF FIles:");
		createXLIFFbutton=new JButton("Browse");
	    createXLIFFBox = Box.createHorizontalBox();
	    createXLIFFBox1 = Box.createHorizontalBox();
		createXLIFFSubmit = new JButton("Submit");
		createXLIFFBox.add(createXLIFFLable);
	    createXLIFFBox.add(createXLIFFbutton);
	    createXLIFFBox1.add(createXLIFFBox);
		createXLIFFBox1.add(createXLIFFSubmit);
		
	//	comp.add(createXLIFFBox1, BorderLayout.CENTER);
		
     //   JLabel label = new JLabel(description, JLabel.CENTER);
     //   comp.add(label);
//        comp.setBorder(titled);
		titledBorders.setBorder(titled);
        titledBorders.add(Box.createRigidArea(new Dimension(0, 100)));
        
     titledBorders.add(createXLIFFBox1);
      add(titledBorders);
		createXLIFFSubmit.addActionListener(buttonActionListener);
	    revalidate();
	    repaint();
		setVisible(true);
	}
	public void cavDrop(){
this.removeAll();
		
		createXLIFFLable=new JLabel("Select Path For Storing the XLIFF FIles:");
		createXLIFFbutton=new JButton("Browse");
	    createXLIFFBox = Box.createHorizontalBox();
	    createXLIFFBox1 = Box.createVerticalBox();
		createXLIFFSubmit = new JButton("Submit");
		createXLIFFBox.add(createXLIFFLable);
	    createXLIFFBox.add(createXLIFFbutton);
	    createXLIFFBox1.add(createXLIFFBox);
		createXLIFFBox1.add(createXLIFFSubmit);
		
	
		add(createXLIFFBox1, BorderLayout.CENTER);
		createXLIFFSubmit.addActionListener(buttonActionListener);
	    revalidate();
	    repaint();
		setVisible(true);
	}
	public void clear() {
	
		
	
		// TODO Auto-generated method stub
		
	}
	public void updateAll() {
this.removeAll();
		
		createXLIFFLable=new JLabel("Select Path For Storing the XLIFF FIles:");
		createXLIFFbutton=new JButton("Browse");
	    createXLIFFBox = Box.createHorizontalBox();
	    createXLIFFBox1 = Box.createVerticalBox();
		createXLIFFSubmit = new JButton("Submit");
		createXLIFFBox.add(createXLIFFLable);
	    createXLIFFBox.add(createXLIFFbutton);
	    createXLIFFBox1.add(createXLIFFBox);
		createXLIFFBox1.add(createXLIFFSubmit);
		
	
		add(createXLIFFBox1, BorderLayout.CENTER);
		createXLIFFSubmit.addActionListener(buttonActionListener);
	    revalidate();
	    repaint();
		setVisible(true);
		
	}
	
	/*public static void main(String[] args)
	  {
		CreateRadioButton d=new CreateRadioButton();
		d.init();
	  }*/
	}
	

