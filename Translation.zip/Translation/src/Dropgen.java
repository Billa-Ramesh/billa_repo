import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;

import javax.swing.GroupLayout;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.ProgressMonitor;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import javax.swing.border.EmptyBorder;

import javax.swing.tree.DefaultMutableTreeNode;

import oracle.hub.tf.dropgenerator.core.DropGenerator;
import oracle.hub.tf.dropgenerator.gui.DialogAbout;

import oracle.hub.tf.dropgenerator.gui.DropGeneratorWindow;
import oracle.hub.tf.dropgenerator.gui.FilesTable;
import oracle.hub.tf.dropgenerator.gui.IssuesTable;
import oracle.hub.tf.dropgenerator.gui.LanguageTokensDialog;
import oracle.hub.tf.dropgenerator.gui.LogTable;

import oracle.hub.tf.dropgenerator.gui.ToolBarButton;
import oracle.hub.tf.dropgenerator.gui.ToolBarToggleButton;
import oracle.hub.tf.dropgenerator.gui.DropGeneratorWindow.Tab;

public class Dropgen extends JFrame {
	private static ToolBarButton createXliff;
	private static ToolBarButton xliff2DB;
	private static ToolBarButton insertAll;
	private static ToolBarButton updateAll;

	/**
	 * 
	 */
	static{
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static final long serialVersionUID = 1L;
	private static final JToolBar toolBar;
	private static final ToolBarButton masterAndFinal;
	
	
	private static final JMenuBar menuBar;
	private static final JMenu editMenu;

	private static final JMenuItem quitMenuItem;

	private static final JMenuItem detailsMenuItem;

	private static final JMenuItem aboutMenuItem;
	private static final JComboBox filterType = new JComboBox(new String[] {
			"en_US","ar_EG", "zh_CN","zh_TW", "fr_FR", "de_DE",
			"it_IT", "ja_JP", "ko_KR", "pt_BR", "ru_RU", "es_WW", "th_TH",
			"vi_VN", "id_ID" });
		//	"Filepath", "Filename", "Directory" });
	private static final JComboBox filterInclude = new JComboBox(new String[] {
			"contains", "does not contain" });
	private static final JTextField txtFilter = new JTextField(20);
	private static final ToolBarButton csvdrop;
	private FilesTable filesTable;
	private JTree treeDirFilter;
	private DialogAbout aboutDialog;
	private static final JSplitPane splitPane = new JSplitPane(0);
	public static final JTabbedPane tabbedPane = new JTabbedPane();
	   private LogTable logTable;
	private  CreateRadioButton createRadioButton;
	private ImageComponent imageComponent;
	public  JTextArea jtextArea=new JTextArea();;

	static {
		 
		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic('F');
		editMenu = new JMenu("Edit");
		editMenu.setMnemonic('E');
		JMenu helpMenu = new JMenu("Help");
		helpMenu.setMnemonic('H');

		fileMenu.addSeparator();

		quitMenuItem = new JMenuItem("Quit");
		quitMenuItem.setAccelerator(KeyStroke.getKeyStroke(81, 2));
		quitMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}

		});
		fileMenu.addSeparator();
		fileMenu.add(quitMenuItem);

		editMenu.addSeparator();

		editMenu.addSeparator();

		detailsMenuItem = new JMenuItem("Details");
		editMenu.add(detailsMenuItem);

		aboutMenuItem = new JMenuItem("About...");
		helpMenu.add(aboutMenuItem);
		menuBar = new JMenuBar();
		menuBar.add(fileMenu);
		menuBar.add(editMenu);
		menuBar.add(helpMenu);

		masterAndFinal = new ToolBarButton("graphs_export.gif", "Master & Final");
		
		createXliff = new ToolBarButton("toolbar-filetypes.png","Create XLIFF");
		createXliff.setToolTipText("Create XLIFF Files");
		
		xliff2DB = new ToolBarButton("toolbar-tokens.png","XLIFF2DB");
		xliff2DB.setToolTipText("XLIFF files to uniq  language table");
		
		insertAll = new ToolBarButton("toolbar-generate.png","Insert All");
		updateAll = new ToolBarButton("toolbar-refresh.png", "Update All");
		
		csvdrop = new ToolBarButton("toolbar-refresh.png", "CSV drop");
		toolBar = new JToolBar();
		toolBar.setFloatable(false);
		toolBar.add(masterAndFinal);
				
		toolBar.add(createXliff);
		toolBar.addSeparator();
		toolBar.add(xliff2DB);
		toolBar.addSeparator();
		toolBar.add(insertAll);
		toolBar.add(updateAll);
		toolBar.add(csvdrop);
	}

	public Dropgen(String title) {
		super(title);

		setDefaultCloseOperation(3);
		setMenuItemListeners();
		setJMenuBar(menuBar);
		createRadioButton = new CreateRadioButton(filterType,jtextArea);
	//	 Image image = Toolkit.getDefaultToolkit(  ).getImage("toolbar-refresh.png");

	//	imageComponent=new ImageComponent(image);
		treeDirFilter = new JTree(new DefaultMutableTreeNode(
				"No project loaded"));
		treeDirFilter.setExpandsSelectedPaths(true);
		treeDirFilter.setScrollsOnExpand(true);
		// issuesTable = new IssuesTable(filesTable, treeDirFilter);
		
		JComponent contentPane = (JComponent) getContentPane();
		  contentPane.setLayout(new BorderLayout());
		//  contentPane.setLayout(new GridLayout(2,1));
	       contentPane.add(getTopPane(),"North");
	     // contentPane.add(getSubTopPane());
	        contentPane.add(getMainPane());
		pack();

		GraphicsEnvironment ge = GraphicsEnvironment
				.getLocalGraphicsEnvironment();
		GraphicsDevice gs[] = ge.getScreenDevices();
		GraphicsDevice gd = gs[0];
		GraphicsConfiguration gc[] = gd.getConfigurations();
		Rectangle gcBounds = gc[0].getBounds();
		int width = (3 * gcBounds.width) / 4;
		int height = (3 * gcBounds.height) / 4;
		setSize(width, height);
		Canvas c = new Canvas(gc[0]);
		setLocationRelativeTo(c);
		setVisible(true);
		splitPane.setDividerLocation(0.65000000000000002D);
		// TODO Auto-generated constructor stub
	}
	
	private void setMenuItemListeners()
    {
	 aboutMenuItem.addActionListener(new ActionListener() {

         public void actionPerformed(ActionEvent e)
         {
             if(aboutDialog == null)
                 aboutDialog = new DialogAbout(Dropgen.this);
             aboutDialog.setVisible(true);
         }

              
         
     }
);
	 
	 masterAndFinal.addActionListener(new ActionListener() {

		 
         public void actionPerformed(ActionEvent e)
         {
        	 
        	 
        	 filterType.setEnabled(false);
        	 System.out.println(e.getActionCommand());
        	// createRadioButton.clear();
        	 
        	createRadioButton.masterAndFinal();
        	
        	//imageComponent.setVisible(false);
             //languageTokenDialog.setVisible(false);
         }

        
     }
);
	 createXliff.addActionListener(new ActionListener() {

         public void actionPerformed(ActionEvent e)
         {
        	
        	 filterType.setEnabled(false);
        	 System.out.println(e.getActionCommand());
        	 
        //	 createRadioButton.clear();
        	createRadioButton.createXLIFF();
        	
        	//imageComponent.setVisible(false);
             //languageTokenDialog.setVisible(false);
         }

        
     }
);
	 xliff2DB.addActionListener(new ActionListener() {

         public void actionPerformed(ActionEvent e)
         {
        	 
        	 filterType.setEnabled(true);
        	 System.out.println(e.getActionCommand());
        	        	 
        	createRadioButton.xliff2DB();
        	
        	//imageComponent.setVisible(false);
             //languageTokenDialog.setVisible(false);
         }

        
     }
);
	 insertAll.addActionListener(new ActionListener() {

         public void actionPerformed(ActionEvent e)
         {
        	 
        	 filterType.setEnabled(true);
        	 System.out.println(e.getActionCommand());
        	 
        	 
        	createRadioButton.insertAll();
        	
        	//imageComponent.setVisible(false);
             //languageTokenDialog.setVisible(false);
         }

        
     }
);
	 updateAll.addActionListener(new ActionListener() {

         public void actionPerformed(ActionEvent e)
         {
        	 
        	 filterType.setEnabled(true);
        	 System.out.println(e.getActionCommand());
        	 
        	 
        	createRadioButton.updateAll();
        	
        	//imageComponent.setVisible(false);
             //languageTokenDialog.setVisible(false);
         }

        
     }
);
	 csvdrop.addActionListener(new ActionListener() {

         public void actionPerformed(ActionEvent e)
         {
        	 
        	 filterType.setEnabled(true);
        	 System.out.println(e.getActionCommand());
        	 
        	 
        	createRadioButton.cavDrop();
        	
        	//imageComponent.setVisible(false);
             //languageTokenDialog.setVisible(false);
         }

        
     }
);
	 
     
    }
	
	 public final void updateStatus(boolean enabled)
	    {
	    
	    }
	private JPanel getMainPane() {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		treeDirFilter.getSelectionModel().setSelectionMode(1);

		treeDirFilter.setEditable(false);
		treeDirFilter.setBorder(BorderFactory.createEmptyBorder(3, 3, 0, 0));

		JScrollPane dropFilterView = new JScrollPane(treeDirFilter);
		dropFilterView.setPreferredSize(new Dimension(200, 0));
		JSplitPane dirTreeAndFilesTable = new JSplitPane(1);
		dirTreeAndFilesTable.setRightComponent(new JScrollPane(createRadioButton));
		dirTreeAndFilesTable.setLeftComponent(dropFilterView);
      
		// tabbedPane.setComponentAt(1, new JScrollPane());
		// tabbedPane.setComponentAt( 2,new JScrollPane());
		splitPane.setLeftComponent(dirTreeAndFilesTable);
		splitPane.setRightComponent(tabbedPane);
		
		JScrollPane botom = new JScrollPane(jtextArea);
		splitPane.setBottomComponent(botom);
		panel.add(splitPane);
	
		return panel;
	}

	private JPanel getTopPane() {
		JComponent contentPane1 = (JComponent) getContentPane();
		 javax.swing.
		JPanel container = new JPanel();
		container.setLayout(new GridLayout(2,1));
		
		container.add(toolBar);
		container.add(getCreateTop());
		//container.add(getSubTopPane());
		 //     contentPane1.setComponent(createRadioButton, 2);
		//      container.add(jr);
		//container.setPreferredSize(new  Dimension(50, 100) );
		//container.add(filtersPanel, "Center");
		return container;
	}
	private JPanel getCreateTop() {
		JPanel container = new JPanel();
		container.setLayout(new BorderLayout());
		
		container.add(toolBar);
		return container;
		//return new CreateRadioButton();
	}

	private JPanel getSubTopPane() {
		JPanel filtersPanel = new JPanel();
		filtersPanel.setLayout(new BoxLayout(filtersPanel,0));
	//	filtersPanel.setBorder(new EmptyBorder(0, 6, 0, 6));
		filtersPanel.add(Box.createHorizontalGlue());
		filtersPanel.add(filterType);
		filtersPanel.add(Box.createHorizontalStrut(4));
		filtersPanel.add(filterInclude);
		filtersPanel.add(Box.createHorizontalStrut(4));
		filtersPanel.add(txtFilter);
		txtFilter.setMaximumSize(txtFilter.getPreferredSize());
		filterType.setMaximumSize(new Dimension(50, 20));
		filterInclude.setMaximumSize(new Dimension(50, 20));
		JPanel container = new JPanel();
		container.add(filtersPanel);
		return container;
	}
	public static void main(String args[]) {
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				Dropgen window = new Dropgen("Traslation Tool");
				window.setVisible(true);

			}

		});
	}

}
