package com.app.trans.gui;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.app.trans.core.DB2allUpdate;
import com.app.trans.core.RunProcedurs;
import com.app.trans.core.checkLog;
import com.app.trans.core.CSVTables;
import com.app.trans.core.CSVAll2Database;
import com.app.trans.core.DB2Xliff;
import com.app.trans.core.Xliff2DB;
import com.app.trans.util.xmlupdate;

public class DynamiComponets extends JPanel {
	
	
	public DynamiComponets(JComboBox filterType, JTextArea jtextArea) {
		this.filterType = filterType;
		this.jtextArea = jtextArea;
		
		// setPreferredSize(new Dimension(300, 0));
		// setBorder(BorderFactory.createLineBorder (Color.blue, 2));

	}
	ActionListener filePath = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			fc = new JFileChooser();
			fc.setCurrentDirectory(new java.io.File("."));
			fc.setDialogTitle("sdfdf");
			fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			//
			// disable the "All files" option.
			//
			fc.setAcceptAllFileFilterUsed(false);
			//    
			if (fc.showOpenDialog(selectFilePath) == JFileChooser.APPROVE_OPTION) {

				File path = fc.getSelectedFile();
				try {
					filepath = path.getCanonicalPath();
				} catch (IOException e1) {

					e1.printStackTrace();
				}
				System.out.println("getCurrentDirectory(): "
						+ fc.getCurrentDirectory() + filepath);
				jtextArea.setText(filepath);
				System.out.println("getSelectedFile() : "
						+ fc.getSelectedFile());
			} else {
				System.out.println("No Selection ");
			}
		}

	};
	ActionListener action = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JButton button = (JButton) e.getSource();
			System.out.println("You select button: " + button.getText());
		}
	};

	ActionListener masterAndFinal = new ActionListener() {
		private String command;

		public void actionPerformed(ActionEvent actionEvent) {
			
			//if(command==null||command =="")
				
			
			try{
			command = group.getSelection().getActionCommand();
			}catch(Exception e){
				JOptionPane.showMessageDialog(null, "Please select one Option \n", e.getMessage(), JOptionPane.ERROR_MESSAGE);
			System.err.print("dfd");
			}

			System.out.println("selected----------> " + command + " next "
					+ filterType.getSelectedItem());
			CSVAll2Database csvAllDatabase = new CSVAll2Database();
			
			if(command.equals("INSERT_MASTER")){
				JPanel p1 = null;
				csvAllDatabase.insert2Table(p1);
			}else
			if(command.equals("UPDATE_PM_CHANGES")){
				JPanel p1 = null;
				csvAllDatabase.updateMessages(p1);
			}else
			if(command.equals("INSERT_DUPLICATE")){
				JPanel p1 = null;
				csvAllDatabase.insertDupliacates(p1);
			}else
			if(command.equals("DELETE_DUPLICATE")){
				JPanel p1 = null;
				csvAllDatabase.deleteDuplicates(p1);
			}else
			if(command.equals("INSERT_FINAL")){
				JPanel p1 = null;
				csvAllDatabase.insert2Final(p1);
			}else
				if(command.equals("APP_NAME")){
					JPanel p1 = null;
					text.getText();
					if(text== null)

						JOptionPane.showMessageDialog(null, this,
								"Please Enter App name", JOptionPane.WARNING_MESSAGE);
					csvAllDatabase.createTables(p1,text.getText());
			}
			
			
			//checkLog l = new checkLog(jtextArea);
			//l.loop();

		}
	};
	ActionListener createXLIFF = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String PattAppender = "/";
			/*DB2Xliff db2xliff = new DB2Xliff();
			db2xliff.method(filepath + PattAppender,jtextArea);*/
			 com.app.trans.util.xmlupdate x=new xmlupdate();
			 x.method();
			//jtextArea.append("\n createXLIFF");
			JButton button = (JButton) e.getSource();
			System.out.println("You select button: " + button.getText());
		}
	};
	ActionListener xliff2DB = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			if (filepath != null) {
				String encode = "en";
				String PattAppender = "/";
				Xliff2DB xliff2DB= new Xliff2DB();
						
				xliff2DB.insert2DB(filepath + PattAppender, encode,(String) filterType.getSelectedItem());
			
				
			}
			
		}
	};
	ActionListener insertAll = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			RunProcedurs run=new RunProcedurs();
			try {
				run.insertLocaleType1((String) filterType.getSelectedItem());
			} catch (SQLException e1) {
			
				e1.printStackTrace();
			}
			
		}
	};
	ActionListener cavDrop = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			CSVTables csvTables=new CSVTables();
			System.out.println("Genearting CSV tables");
			csvTables.writetable((String) filterType.getSelectedItem());
			
			jtextArea.append("\n createXLIFF");
			JButton button = (JButton) e.getSource();
			System.out.println("You select button: " + button.getText());
		}
	};
	ActionListener updateAll = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			DB2allUpdate updateall=new DB2allUpdate();
			updateall.update2Table((String) filterType.getSelectedItem());
			
			

		}
	};
	
	public void masterAndFinal() {
		this.removeAll();
		System.out.println("in master");
		JLabel appName= new JLabel("App Name");
		text=new JTextField();
		text.setPreferredSize(new Dimension(120,20));
		JRadioButton appNameButton=new JRadioButton("Create Tables");
		appNameButton.setActionCommand("APP_NAME");
		
		JRadioButton button1 = new JRadioButton("Insert into Master  :");
		button1.setActionCommand("INSERT_MASTER");

		JRadioButton button2 = new JRadioButton("Update with PM changes :");
		button2.setActionCommand("UPDATE_PM_CHANGES");

		JRadioButton button3 = new JRadioButton("Insert Duplicates :");
		button3.setActionCommand("INSERT_DUPLICATE");

		JRadioButton button4 = new JRadioButton("Delete Duplicates :");
		button4.setActionCommand("DELETE_DUPLICATE");

		JRadioButton button5 = new JRadioButton("Insert into Final:");
		button5.setActionCommand("INSERT_FINAL");
		Box masterAndFinalBox = Box.createHorizontalBox();

		JButton submit = new JButton("Submit");
		group = new ButtonGroup();
		group.add(button1);

		group.add(button2);
		group.add(button3);
		group.add(button4);
		group.add(button5);
		group.add(appNameButton);
		masterAndFinalBox.add(button1);
		masterAndFinalBox.add(button2);
		masterAndFinalBox.add(button3);
		masterAndFinalBox.add(button4);
		masterAndFinalBox.add(button5);
		masterAndFinalBox.add(submit);
       add(appName);
       add(text);
       add(appNameButton);
		add(masterAndFinalBox, BorderLayout.CENTER);
		submit.addActionListener(masterAndFinal);
		revalidate();
		repaint();
		setVisible(true);
	}

	
	public void createXLIFF() {
		this.removeAll();

		JLabel createXLIFFLable = new JLabel(
				"Select Path For Storing the XLIFF FIles:  ");
		JButton createXLIFFbutton = new JButton("Browse");
		Box createXLIFFBox = Box.createHorizontalBox();
		// createXLIFFBox1 = Box.createVerticalBox();
		JButton createXLIFFSubmit = new JButton("Create XLIFF");
		createXLIFFBox.add(createXLIFFLable);
		createXLIFFBox.setSize(60, 20);
		createXLIFFBox.add(createXLIFFbutton);
		createXLIFFBox.add(createXLIFFSubmit);

		add(createXLIFFBox, BorderLayout.CENTER);
		createXLIFFSubmit.addActionListener(createXLIFF);
		createXLIFFbutton.addActionListener(filePath);
		revalidate();
		repaint();
		setVisible(true);
	}
	public void xliff2DB() {
		this.removeAll();

	
		JLabel xliff2DBLable = new JLabel(
				"Select The Path XLIFF FIles:  ");
		JButton xliff2DBbutton = new JButton("Browse");
		JButton xliff2DSubmit = new JButton("Import XLIFF TO DB");
		add(xliff2DBLable);
		add(xliff2DBbutton);
		add(xliff2DSubmit);
		xliff2DSubmit.addActionListener(xliff2DB);
		xliff2DBbutton.addActionListener(filePath);
		revalidate();
		repaint();
		setVisible(true);
	}

	public void insertAll() {
		this.removeAll();
		JLabel insertAllLable = new JLabel("Insert all the tables data : ");

		JButton insertAllSubmit = new JButton("Insert All");
		add(insertAllLable);
		add(insertAllSubmit);
		insertAllSubmit.addActionListener(insertAll);

		revalidate();
		repaint();
		setVisible(true);
	}

	public void cavDrop() {
		this.removeAll();
		JLabel csvLable = new JLabel("Create the CSV Files");

		JButton csvSubmit = new JButton("CSV");
		add(csvLable);
		add(csvSubmit);
		csvSubmit.addActionListener(cavDrop);

		revalidate();
		repaint();
		setVisible(true);
	}

	public void clear() {

		// TODO Auto-generated method stub

	}

	public void updateAll() {
		this.removeAll();
		JLabel updateLable = new JLabel("Update all the tables data : ");

		JButton updateSubmit = new JButton("Update");
		add(updateLable);
		add(updateSubmit);
		updateSubmit.addActionListener(updateAll);

		revalidate();
		repaint();
		setVisible(true);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 917627546250212907L;
	private JComboBox filterType;

	private ButtonGroup group;
		private JFileChooser fc;
	private String filepath;
	private JButton selectFilePath;
	private JTextArea jtextArea;
	private JTextField text;

 checkLog chek=new checkLog(jtextArea);
}
