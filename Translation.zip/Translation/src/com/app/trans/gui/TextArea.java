package com.app.trans.gui;

import javax.swing.JTextArea;

public class TextArea extends JTextArea {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public TextArea(String text){
		
		append(text);
	}
	public TextArea(){
		
		
	}
	public void setText(){
			
	}
}
