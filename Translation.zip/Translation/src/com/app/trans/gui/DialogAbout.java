
package com.app.trans.gui;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            DropGeneratorWindow

public class DialogAbout extends JDialog
{

    public DialogAbout(Frame parent)
    {
        super(parent, true);
        contentPane = (JComponent)getContentPane();
        closeButton = new JButton("Close");
        contentPane.setLayout(new BorderLayout());
        JPanel imagePanel = new JPanel();
        JLabel imageLabel = new JLabel("about");
        imagePanel.add(imageLabel);
        imageLabel.setBorder(new BevelBorder(1));
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, 0));
        JLabel versionLabel = new JLabel((new StringBuilder()).append("Version ").append("some").toString(), 0);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(versionLabel);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(Box.createHorizontalStrut(4));
        buttonPanel.add(closeButton);
        buttonPanel.setBorder(new EmptyBorder(0, 8, 0, 8));
        contentPane.add(imagePanel);
        contentPane.add(buttonPanel, "South");
        pack();
        setResizable(false);
        centre();
        closeButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
            }

         

            
            
        }
);
    }

    private void centre()
    {
        Toolkit toolkit = getToolkit();
        Dimension screenDimension = toolkit.getScreenSize();
        Dimension dimension = getSize();
        setLocation((screenDimension.width - dimension.width) / 2, (screenDimension.height - dimension.height) / 3);
    }

    private static final long serialVersionUID = 1L;
    private JComponent contentPane;
    private JButton closeButton;
}
