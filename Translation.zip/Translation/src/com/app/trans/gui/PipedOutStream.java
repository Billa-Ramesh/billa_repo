package com.app.trans.gui;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PipedOutputStream;

public class PipedOutStream  extends OutputStream {

	@Override
	public void write(int arg0) throws IOException {
		// TODO Auto-generated method stub
		
	}
	 public void flush(){
		 
	 }
	 public void close() {
	   
	}
	
}
