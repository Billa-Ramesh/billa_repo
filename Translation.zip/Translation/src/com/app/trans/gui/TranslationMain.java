package com.app.trans.gui;


import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import com.app.trans.gui.ToolBarButton;
public class TranslationMain extends JFrame {
	/**
	 * 
	 */
	static {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
	}

	private static final long serialVersionUID = 1L;
	private static final JToolBar toolBar;
	private static final ToolBarButton masterAndFinal;
	private static ToolBarButton createXliff;
	private static ToolBarButton xliff2DB;
	private static ToolBarButton insertAll;
	private static ToolBarButton updateAll;
	private static final JMenuBar menuBar;
	private static final JMenu editMenu;

	private static final JMenuItem quitMenuItem;

	private static final JMenuItem detailsMenuItem;

	private static final JMenuItem aboutMenuItem;
	private static final JComboBox filterType = new JComboBox(new String[] {
			"en_US", "ar_EG", "zh_CN", "zh_TW", "fr_FR", "de_DE", "it_IT",
			"ja_JP", "ko_KR", "pt_BR", "ru_RU", "es_WW", "th_TH", "vi_VN",
			"id_ID" });
	private static final ToolBarButton csvdrop;
	
	private DialogAbout aboutDialog;
	private TextArea textArea;
	private static final JSplitPane splitPane = new JSplitPane(0);
	public static final JTabbedPane tabbedPane = new JTabbedPane();
	private DynamiComponets createRadioButton;
	public JTextArea jtextArea = new JTextArea();
	private final PipedInputStream pin=new PipedInputStream(); 
	 private JTextArea textAreas = new JTextArea(15, 30);
	   private TextAreaOutputStream taOutputStream;
	static {

		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic('F');
		editMenu = new JMenu("Edit");
		editMenu.setMnemonic('E');
		JMenu helpMenu = new JMenu("Help");
		helpMenu.setMnemonic('H');

		fileMenu.addSeparator();

		quitMenuItem = new JMenuItem("Quit");
		quitMenuItem.setAccelerator(KeyStroke.getKeyStroke(81, 2));
		quitMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}

		});
		fileMenu.addSeparator();
		fileMenu.add(quitMenuItem);

		editMenu.addSeparator();

		editMenu.addSeparator();

		detailsMenuItem = new JMenuItem("Details");
		editMenu.add(detailsMenuItem);

		aboutMenuItem = new JMenuItem("About...");
		helpMenu.add(aboutMenuItem);
		menuBar = new JMenuBar();
		menuBar.add(fileMenu);
		menuBar.add(editMenu);
		menuBar.add(helpMenu);

		masterAndFinal = new ToolBarButton("graphs_export.gif",
				"Master & Final");

		createXliff = new ToolBarButton("toolbar-filetypes.png", "Create XLIFF");
		createXliff.setToolTipText("Create XLIFF Files");

		xliff2DB = new ToolBarButton("toolbar-tokens.png", "XLIFF2DB");
		xliff2DB.setToolTipText("XLIFF files to uniq  language table");

		insertAll = new ToolBarButton("toolbar-generate.png", "Insert All");
		updateAll = new ToolBarButton("toolbar-refresh.png", "Update All");

		csvdrop = new ToolBarButton("toolbar-refresh.png", "CSV drop");
		toolBar = new JToolBar();
		toolBar.setFloatable(false);
		toolBar.add(masterAndFinal);

		toolBar.add(createXliff);
		toolBar.addSeparator();
		toolBar.add(xliff2DB);
		toolBar.addSeparator();
		toolBar.add(insertAll);
		toolBar.add(updateAll);
		toolBar.add(csvdrop);
	}

	public TranslationMain(String title) throws IOException {
		super(title);

		setDefaultCloseOperation(3);
		setMenuItemListeners();
		setJMenuBar(menuBar);
		taOutputStream = new TextAreaOutputStream(textAreas, "Console");
		System.setOut(new PrintStream(taOutputStream));
		System.setErr(new PrintStream(taOutputStream));
		createRadioButton = new DynamiComponets(filterType, jtextArea);
		textArea=new TextArea();
		JComponent contentPane = (JComponent) getContentPane();
		contentPane.setLayout(new BorderLayout(2, 1));
		contentPane.add(getTopPane(), "North");
		contentPane.add(getMainPane());
		PipedOutputStream pout=new PipedOutputStream(this.pin);
		
		pack();
		GraphicsEnvironment ge = GraphicsEnvironment
				.getLocalGraphicsEnvironment();
		GraphicsDevice gs[] = ge.getScreenDevices();
		GraphicsDevice gd = gs[0];
		GraphicsConfiguration gc[] = gd.getConfigurations();
		Rectangle gcBounds = gc[0].getBounds();
		int width = (3 * gcBounds.width) / 4;
		int height = (3 * gcBounds.height) / 4;
		setSize(width, height);
		Canvas c = new Canvas(gc[0]);
		setLocationRelativeTo(c);
		setVisible(true);
		splitPane.setDividerLocation(0.65000000000000002D);
	}

	private void setMenuItemListeners()

	{
		// toolbarVisible(true);

		aboutMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				if (aboutDialog == null)
					aboutDialog = new DialogAbout(TranslationMain.this);
				aboutDialog.setVisible(true);
			}

		});

		masterAndFinal.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				System.out.println(e.getActionCommand());

				createRadioButton.masterAndFinal();

			}

		});
		createXliff.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				filterType.setEnabled(false);
				System.out.println(e.getActionCommand());

				createRadioButton.createXLIFF();

			}

		});
		xliff2DB.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				filterType.setEnabled(true);
				System.out.println(e.getActionCommand());

				createRadioButton.xliff2DB();

			}

		});
		insertAll.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				filterType.setEnabled(true);
				System.out.println(e.getActionCommand());

				createRadioButton.insertAll();

			}

		});
		updateAll.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				filterType.setEnabled(true);
				System.out.println(e.getActionCommand());

				createRadioButton.updateAll();

			}

		});
		csvdrop.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				filterType.setEnabled(true);
				System.out.println(e.getActionCommand());

				createRadioButton.cavDrop();

			}

		});

	}

	private void toolbarVisible(Boolean con) {
		masterAndFinal.setEnabled(con);
		createXliff.setEnabled(con);
		xliff2DB.setEnabled(con);
		insertAll.setEnabled(con);
		updateAll.setEnabled(con);
		csvdrop.setEnabled(con);
	}

	public final void updateStatus(boolean enabled) {

	}

	private JPanel getMainPane() {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		tabbedPane.add("LOG", new JScrollPane(textAreas));
		panel.add(tabbedPane);
		return panel;
	}

	private JPanel getTopPane() {

		JPanel filtersPanel = new JPanel();
		filtersPanel.setLayout(new BoxLayout(filtersPanel, 0));
		filtersPanel.setBorder(new EmptyBorder(0, 6, 0, 6));
		filtersPanel.add(Box.createHorizontalGlue());
		filtersPanel.add(filterType);
		filtersPanel.add(Box.createHorizontalStrut(4));
		filterType.setMaximumSize(new Dimension(60, 20));

		JPanel container = new JPanel();
		container.setLayout(new BorderLayout());
		container.add(toolBar, "West");
		container.add(filtersPanel, "Center");

		JPanel containerg = new JPanel();
		containerg.setLayout(new GridLayout(2, 1));
		containerg.add(container);
		containerg.add(getSubTopPane());

		return containerg;
	}

	private JPanel getSubTopPane() {

		JPanel container = new JPanel();
		container.setBorder(BorderFactory
				.createEtchedBorder(EtchedBorder.RAISED));
		container.add(createRadioButton);
		return container;
	}

	public static void main(String args[]) {
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				TranslationMain window = null;
				try {
					window = new TranslationMain("Traslation Tool");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				window.setVisible(true);

			}

		});
	}

}
