package com.app.trans.gui;

import java.awt.Insets;
import javax.swing.*;

// Referenced classes of package oracle.hub.tf.dropgenerator.gui:
//            LogTable

public class ToolBarButton extends JButton
{

    public ToolBarButton(Icon icon)
    {
        super(icon);
        setMargin(margins);
        setVerticalTextPosition(3);
        setHorizontalTextPosition(0);
    }

    public ToolBarButton(String icon, String text)
    {
        this(((Icon) (new ImageIcon((icon)))));
        setText(text);
    }

    public ToolBarButton(String icon) {
    	 this(((Icon) (new ImageIcon((icon)))));
         //setText(text);
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = 1L;
    private static final Insets margins = new Insets(3, 3, 3, 3);

}
