package com.app.trans.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	private static Connection con=null;
	public  static Connection getConnection()
	{
		
		
		try{
			
			
			Class.forName("oracle.jdbc.OracleDriver");
			//Old IP
		//con = DriverManager.getConnection("jdbc:oracle:thin:@10.184.108.111:1521:EPMSUP","UTFPSUEDO","UTFPSUEDO");			
		con = DriverManager.getConnection("jdbc:oracle:thin:@10.184.134.1:1521:EPMSUP","DEVTRANSUSER","DEVTRANSUSER");
			//con = DriverManager.getConnection("jdbc:oracle:thin:@10.184.134.1:1521:EPMSUP","DEVTRANSUSER","DEVTRANSUSER");
		}catch (Exception ex)
		{ 
			System.out.println("Error getting connection");
		}
		
		return con;
	
		
	}
     
}
