package com.app.trans.util;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.w3c.dom.*;

import javax.swing.JTextArea;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class xmlupdate {
	static Connection con = com.app.trans.util.DBConnection.getConnection();
	PreparedStatement del_sql = null;

	public  void method() {
		try {
			DocumentBuilderFactory odbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder odb = odbf.newDocumentBuilder();
			Document odoc = odb.parse("MR - sharedcaptions.xml");
			odoc.getDocumentElement().normalize();

			System.out.println("Root element of the doc is "
					+ odoc.getDocumentElement().getNodeName());
			NodeList LOP = odoc.getElementsByTagName("WebMessageTable");
			int totalPersons = LOP.getLength();
			// System.out.println("Total no of tables : " + totalPersons);
			for (int s = 0; s < LOP.getLength(); s++) {

				Node FPN = LOP.item(s);

				if (FPN.getNodeType() == Node.ELEMENT_NODE) {
					Element firstPElement = (Element) FPN;
					NamedNodeMap x = firstPElement.getAttributes();
			               
	                  Node description = x.getNamedItem("description");
	                  
	                  
	                 Node l= x.getNamedItem("path");
	                 String pathvalue = l.getTextContent();
	             // System.out.println( pathvalue);
	                  		  
             		
					
					NodeList childNodes = firstPElement
							.getElementsByTagName("WebMessage");
					int childNodesLength = childNodes.getLength();

					for (int c = 0; c < childNodesLength; c++) {

						// System.out.println("on row");
						Node childNode = childNodes.item(c);

						if (childNode.getNodeType() == Node.ELEMENT_NODE) {

						

							Element webMessageElement = (Element) childNodes
									.item(c);
					//		System.out.println(webMessageElement.getAttribute("name"));
					String	keytext=webMessageElement.getAttribute("name");
					
							NodeList childNodess = webMessageElement
									.getChildNodes();
							for (int ch = 0; ch < childNodess.getLength(); ch++) {

								Node childNodesss = childNodess.item(ch);
								if (childNodesss.getNodeType() == Node.ELEMENT_NODE) {

									Element childNodesssElement = (Element) childNodess
											.item(ch);
									childNodesssElement.getNodeName();
									String source = childNodesssElement
											.getNodeName();
									
									String text = childNodesssElement
									.getTextContent();
									firstPElement.getParentNode().getParentNode();
									
									System.out.println("source node"+webMessageElement.getParentNode().getNodeName());
									if(description!=null ){
										 
										insertXmlData(keytext,description.getTextContent(),text);
									}else{
										insertXmlData(keytext,text);
									}
									
									
								//	insertXmlData(keytext,description,text);
						//		System.out.println("source node"+source);
									
								//	System.out.println(target);
                                   //System.out.println("tehe"+   methodGet(keytext));
                                   
                                   

                                
									// System.out.println(":"+value+":"
									// +childNodesssElement.getNodeName()+":"+childNodesssElement.getTextContent());

								}

							}

						}

					}

				}
				

			}
			System.out.println("Success Fully Completed");
		} catch (SAXParseException err) {
			System.out.println(err.getMessage());
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		System.out.println("Success Fully Completed");
	}

	private synchronized static void insertXmlData(String keytext, String text) {

		System.out.println("source node"+keytext);
		
		
		
		PreparedStatement ps;
	
		
		try {
			ps = con.prepareStatement("insert into test_ram values(?,?,?)");
			ps.setString(1,keytext);
			ps.setString(2,"");
			ps.setString(3,text);
			  ps.executeUpdate();
			
					
					 
					ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	
		
	}

	private synchronized static void insertXmlData(String keytext, String description,
			String text) {
		
		
		System.out.println("source node"+keytext);
		
		PreparedStatement ps;
		ResultSet rs;
		
		try {
			ps = con.prepareStatement("insert into test_ram values(?,?,?)");
			ps.setString(1,keytext);
			ps.setString(2,description);
			ps.setString(3,text);
			ps.executeUpdate();
			
					ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}

	public void method(JTextArea jtextArea) {
		// TODO Auto-generated method stub
		
	}

	/*private synchronized  static String methodGet(String textvalue) {
		PreparedStatement ps;
		ResultSet rs;
		String text = null;
		try {
			ps = con.prepareStatement("Select text from or_sharedcaptions_ol_T where mls_cd='heb'  AND name like ?");
			ps.setString(1,textvalue);
			 rs = ps.executeQuery();
			int count=1;
					while (rs.next()) {
				//System.out.println("Within while");
				text = rs.getString(1);
		//	System.out.println(key);
			} 
					 rs.close();
					ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return text;
		
	}

	private synchronized  static String methodGetDesc(String path) {
		
		PreparedStatement ps;
		ResultSet rs;
		String desc = null;
		try {
			ps = con.prepareStatement("Select description from or_sharedcaptions_ol_T where mls_cd='heb'  AND path like ?");
			ps.setString(1,path);
			 rs = ps.executeQuery();
			int count=1;
					while (rs.next()) {
				//System.out.println("Within while");
				desc = rs.getString(1);
		//	System.out.println(key);
			} 
					 rs.close();
					ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return desc;
		
		// TODO Auto-generated method stub
		
	}*/
}
