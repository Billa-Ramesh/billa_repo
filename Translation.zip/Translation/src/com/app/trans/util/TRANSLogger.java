package com.app.trans.util;
import org.apache.log4j.*;
public class TRANSLogger {

	public static final TRANSLogger oTRANSLogger = getInstance();
	private static boolean blnIsEventLoggerInitialized = false;

	
	private TRANSLogger() {

	}
	private static TRANSLogger getInstance() {
		if (oTRANSLogger == null) {
			return new TRANSLogger();
		} else
			return oTRANSLogger;
	}
	
	public static void initializeTRANSLogger() throws Exception {
				
		blnIsEventLoggerInitialized = false;
		PropertyConfigurator.configure("log4j.properties");
		blnIsEventLoggerInitialized = true;
		
	}
	private static void log(
			Object strcallingObject,
			String strmethodName,
			String strlogStatement,
			Throwable thrown,
			Priority strpriority) {

			String className = "";
			String shortClassName = null;
			Logger oLogger = null;
			
			if (strcallingObject == null)
				strcallingObject = new Object();

			if (!blnIsEventLoggerInitialized) {
				try {
					initializeTRANSLogger();
				} catch (Exception lfie) {
					lfie.printStackTrace();
				}
			}
			
			if (strcallingObject instanceof String) {

				oLogger = Logger.getLogger((String) strcallingObject);
				className = (String) strcallingObject;
			} else {

				oLogger = Logger.getLogger(strcallingObject.getClass().getName());
				className = strcallingObject.getClass().getName();
			}

			if (oLogger.isEnabledFor(strpriority)) {
				int nIndex = className.lastIndexOf('.');
				shortClassName = className.substring(nIndex + 1);
				StringBuffer loggedMessage = new StringBuffer(shortClassName);
				if (strmethodName != null) {
					loggedMessage.append("--").append(
						strmethodName);
				}

				loggedMessage.append("--").append(strlogStatement);
				if (thrown == null) {

					oLogger.log(strpriority, loggedMessage.toString());
				} else {

					oLogger.log(strpriority, loggedMessage.toString(), thrown);
				}

			}

		}

	public static void logInfo(
			Object strcallingObject,
			String strmethodName,
			String strmessage) {
		TRANSLogger.log(
				strcallingObject,
				strmethodName,
				strmessage,
				null,
				Priority.INFO);
		}
	public static void logDebug(
			Object strcallingObject,
			String strdebugMessage) {

		TRANSLogger.log(
				strcallingObject,
				null,
				strdebugMessage,
				null,
				Priority.DEBUG);

		}
	public static void logError(
			Object strcallingObject,
			Throwable strthrown,
			String strdebugMessage) {

		TRANSLogger.log(
				strcallingObject,
				null,
				strdebugMessage,
				strthrown,
				Priority.ERROR);
		}
	
	public static void logFatal(
			Object strcallingObject,
			Throwable strthrown,
			String strmethodName,
			String strlogStatement) {
		TRANSLogger.log(
				strcallingObject,
				strmethodName,
				strlogStatement,
				strthrown,
				Priority.FATAL);
		}
}
