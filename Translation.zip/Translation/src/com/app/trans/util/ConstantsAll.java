package com.app.trans.util;


public final class ConstantsAll {
	  public static final String master_table = "MASTER_TABLE";
	  public static final String uniq_table = "UNIQ_TABLE";
	  public static final String meta_data = "META_DATA_TABLE";
	  public static final String dupe_table="DUPLICATE_TABLE";
	  public static final String property_filename="Property_value.properties";
	  
	  
	}
