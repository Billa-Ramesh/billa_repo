package com.app.trans.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import com.app.trans.util.ConstantsAll;
public class TransloadPropertyFile {
	
public	static Properties getLoadFile(){
		Properties properties=null;
	
	File propertyFile = new File(ConstantsAll.property_filename);
	  if(propertyFile.exists()){
		   properties = new Properties();
		  FileInputStream inStream = null;
		  try {
			  inStream = new FileInputStream(propertyFile);
			  properties.load(inStream);
				
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	   catch (IOException e1) {
			
			e1.printStackTrace();
		}
	  }
	return properties;
	
}
}
