package com.app.trans.core;

import java.sql.SQLException;

public class RunProcedurs {
	public void insertLocaleType1(String mlsC1) throws SQLException{
		
		System.out.println(" inserLocale type 1 " +mlsC1 );
	}
}
