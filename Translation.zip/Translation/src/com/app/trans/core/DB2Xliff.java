package com.app.trans.core;



import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextArea;

import com.app.trans.gui.TextArea;
import com.app.trans.gui.TextAreaOutputStream;
import com.app.trans.util.CSVWriter;
import com.app.trans.util.TRANSLogger;


public class DB2Xliff {

	File f = new File("trans_strings_6.csv");
	private JTextArea textArea;
	private TextAreaOutputStream taOutputStream = new TextAreaOutputStream(
			textArea, "Test");
	static Connection con = null;

	private static FileOutputStream output;

	private static String xliffFile;

	private static String sourceLanguage = "en-US";
 private static JTextArea stringBuilder;
	public DB2Xliff() {
		
	}

	private void writeString(String string)
			throws UnsupportedEncodingException, IOException {
		output.write(string.getBytes("UTF-8"));
	}

	private String cleanString(String s) {

		try {

			for (int control = s.indexOf("&"); control != -1; control = s
					.indexOf("&", control)) {
				s = s.substring(0, control) + "&amp;"
						+ s.substring(control + 1);
				if (control < s.length())
					control++;
			}

			for (int control = s.indexOf("<"); control != -1; control = s
					.indexOf("<", control)) {
				s = s.substring(0, control) + "&lt;" + s.substring(control + 1);
				if (control < s.length())
					control++;
			}

			for (int control = s.indexOf(">"); control != -1; control = s
					.indexOf(">", control)) {
				s = s.substring(0, control) + "&gt;" + s.substring(control + 1);
				if (control < s.length())
					control++;
			}

		} catch (Exception ec) {
			TRANSLogger.logError(this, ec, ec.getMessage()
					+ "Error while Cleaning Message :" + s);
		}
		return s;
	}

	public void method(String filepath, JTextArea jtextArea) {
		stringBuilder=jtextArea;
		PreparedStatement preparedStmt = null, preparedStmt1 = null;
		ResultSet rs = null, rs1 = null;

		try {
			con = com.app.trans.util.DBConnection.getConnection();
			String sql = "Select table_name,TRANSLATABLE_FIELD1,TRANSLATABLE_FIELD2 from Info_6_1";

			preparedStmt = con.prepareStatement(sql);

			rs = preparedStmt.executeQuery();
			TRANSLogger.logInfo(this, " method()", " Queary :" + sql);
			while (rs.next()) {

				String tableNameXliff = rs.getString(1);

				String translatableField1 = rs.getString(2);
				String translatableField2 = rs.getString(3);

				try {
					String sql1 = "select table_name from final_6_1_2 where table_name=?";
					preparedStmt1 = con.prepareStatement(sql1);
					preparedStmt1.setString(1, tableNameXliff);
					rs1 = preparedStmt1.executeQuery();

					if (rs1.next()) {

						output = new FileOutputStream(filepath + tableNameXliff
								+ ".xlf");

						writeString("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
						writeString("<xliff version=\"1.0\">\n");
						writeString("<file source-language=\"" + sourceLanguage
								+ "\" original=\"" + tableNameXliff
								+ "\" datatype=\"x-ofsaa\">\n");

						writeString("<body>\n");

						if (tableNameXliff == "MESSAGES_EN_US") {
							methodMESS(tableNameXliff, translatableField1,
									translatableField2,jtextArea);

						} else {
							method2(tableNameXliff, translatableField1,
									translatableField2,jtextArea);

						}
						writeString("</body>\n");
						writeString("</file>\n");
						writeString("</xliff>");
					}

					// System.out.println(table_column.toString());
				} catch (Exception e) {
					System.out.println("in selct table " + e.getMessage());
					e.printStackTrace();
				} finally {
					rs1.close();
					preparedStmt1.close();
				}
			}

		} catch (Exception e) {

			// logger.info("Exception: "+e.getMessage());
			System.err.println("Exception: " + e.getMessage());

			// System.exit(-1);
			e.printStackTrace();

		} finally {
			try {

				rs.close();

				preparedStmt.close();
				con.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		System.out.println("SuccssesFully complete");

	}

	private void method2(String tableNameXliff, String translatableField1,
			String translatableField2, JTextArea jtextArea) {
		
		int countStrings = 0;
		java.sql.Statement preparedStmtxlff = null;
		ResultSet rs_xlf = null;
		try {
			con = com.app.trans.util.DBConnection.getConnection();
			// String xlf_sql =
			// "select message_key,message_text from FSI_Translation_Messages_final where table_name="
			// + "'" + tableNameXliff + "'";

			String xlf_sql = "select message_key,message_text,comments from final_6_1_2 where table_name="
					+ "'" + tableNameXliff + "'";
    
			
			
			System.out.println(xlf_sql);
		
			// TRANSLogger.logInfo(this," method2()",
			// "File Name :"+tableNameXliff+" Queary : \n"+xlf_sql); //commented
			// on 14/03
			preparedStmtxlff = con.createStatement();

			rs_xlf = preparedStmtxlff.executeQuery(xlf_sql);
			while (rs_xlf.next()) {
				countStrings++;
				// System.out.println("in hile"); //commented on 14/03
				String keyXliff = rs_xlf.getString(1);
				String valueXliff = rs_xlf.getString(2);
				String comments = rs_xlf.getString(3);
				StringBuffer table_column = new StringBuffer();
				StringBuffer table_column1 = new StringBuffer();
				table_column.append(tableNameXliff).append("~").append(
						translatableField1);
				table_column1.append(tableNameXliff).append("~").append(
						translatableField2);
				if (keyXliff.startsWith(table_column1.toString()))
					wrtiteSegment(keyXliff, valueXliff, tableNameXliff,
							translatableField2, comments);
				else if (keyXliff.startsWith(table_column.toString())) {
					wrtiteSegment(keyXliff, valueXliff, tableNameXliff,
							translatableField1, comments);

				}

			}
			/**
			 * commented on 14 /03 PrintWriter pw = new PrintWriter( new
			 * FileWriter(f,true)); CSVWriter csv = new CSVWriter(pw, false,
			 * ',', System.getProperty("line.separator") );
			 * 
			 * 
			 * 
			 * csv.write(tableNameXliff); csv.write(""+countStrings);
			 * csv.writeln(); csv.close();
			 **/
			TRANSLogger.logInfo("", "", "File Name :" + tableNameXliff
					+ " Count of Key/Value pairs : " + countStrings);
			System.out.println(countStrings);
		} catch (Exception e1) {

			TRANSLogger.logError(this, e1, e1.getMessage());

			System.out.println("in method2" + e1.getMessage());
		} finally {
			try {
				rs_xlf.close();
				preparedStmtxlff.close();

			} catch (SQLException e) {

				e.printStackTrace();
			}

		}
	}

	private void methodMESS(String tableNameXliff, String translatableField1,
			String translatableField2, JTextArea jtextArea) {
		int countStrings = 0;
		java.sql.Statement preparedStmtxlff = null;
		ResultSet rs_xlf = null;
		try {
			con = com.app.trans.util.DBConnection.getConnection();
			// String xlf_sql =
			// "select message_key,message_text from FSI_Translation_Messages_final where table_name="
			// + "'" + tableNameXliff + "'";
			String xlf_sql = "select message_key,message_text,comments from final_6_1_2 where table_name="
					+ "'" + tableNameXliff + "'";
			System.out.println(xlf_sql);

			// TRANSLogger.logInfo(this," method2()",
			// "File Name :"+tableNameXliff+" Queary : \n"+xlf_sql); //commented
			// on 14/03
			preparedStmtxlff = con.createStatement();

			rs_xlf = preparedStmtxlff.executeQuery(xlf_sql);
			while (rs_xlf.next()) {
				countStrings++;
				System.out.println("in hile");
				String keyXliff = rs_xlf.getString(1);
				String valueXliff = rs_xlf.getString(2);
				String comments = rs_xlf.getString(3);
				StringBuffer table_column = new StringBuffer();
				StringBuffer table_column1 = new StringBuffer();
				table_column.append(tableNameXliff).append("~").append(
						translatableField1);
				table_column1.append(tableNameXliff).append("~").append(
						translatableField2);
				if (keyXliff.startsWith(table_column1.toString()))
					wrtiteSegment(keyXliff, valueXliff, tableNameXliff,
							translatableField2, comments);
				if (keyXliff.startsWith(table_column.toString())) {
					wrtiteSegment(keyXliff, valueXliff, tableNameXliff,
							translatableField1, comments);

				}
				// System.out.println(rs_xlf.getString(1));

			}
			PrintWriter pw = new PrintWriter(new FileWriter(f, true));
			CSVWriter csv = new CSVWriter(pw, false, ',', System
					.getProperty("line.separator"));

			csv.write(tableNameXliff);
			csv.write("" + countStrings);
			csv.writeln();
			csv.close();
			TRANSLogger.logInfo("", "", "File Name :" + tableNameXliff
					+ " Count of Key/Value pairs : " + countStrings);
		} catch (Exception e1) {

			TRANSLogger.logError(this, e1, e1.getMessage());
			System.out.println("in method2" + e1.getMessage());
		} finally {
			try {
				rs_xlf.close();
				preparedStmtxlff.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	private int getMaxwidth(String tableNameXliff, String columnNameXliff) {
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		int maxWidth1 = 0;
		try {
			con = com.app.trans.util.DBConnection.getConnection();
			String sql = "select DATA_LENGTH from fsi_trans_tables where TABLE_NAME=? and COLUMN_NAME=?";
			preparedStmt = con.prepareStatement(sql);
			preparedStmt.setString(1, tableNameXliff);
			preparedStmt.setString(2, columnNameXliff);

			rs = preparedStmt.executeQuery();

			if (rs.next()) {

				maxWidth1 = rs.getInt(1);

				// TRANSLogger.logInfo(this," getMaxwidth()",
				// "File Name :"+tableNameXliff+" max width :"+maxWidth1);
				// //commented on 14/03

			} else {
				// logger.info("Error while creating the xliff file for "+tableName);
				// System.exit(-1);
			}

		} catch (Exception e) {
			// logger.info("Exception: "+e.getMessage());

			TRANSLogger.logError(this, e, e.getMessage());

			// System.err.println("Exception: " + e.getMessage()); //commented
			// on 14/03
			// System.exit(-1);
		} finally {

			try {

				preparedStmt.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}
		return maxWidth1;

	}

	private void wrtiteSegment(String keyXliff, String valueXliff,
			String tableNameXliff, String columnNameXliff, String comments)
			throws UnsupportedEncodingException, IOException {
		// int maxwidth = getMaxwidth(tableNameXliff, columnNameXliff);

		System.out.println("comments" + comments);

		if (valueXliff != null) {
			writeString("   <trans-unit id=\"" + keyXliff
					+ "\" size-unit=\"char\">\n" + "      <source>"
					+ cleanString(valueXliff) + "</source>\n");
			writeString("        <target/>\n");

			if (valueXliff.contains("#")) {

				if (comments != null) {

					writeString("         <note>" + comments
							+ ",\t'#' is Palceholder </note>\n");
					writeString("              <drop_num>6.1</drop_num>\n");
				}
				if (comments == null) {
					writeString("         <note>'#' is Palceholder </note>\n");
					writeString("              <drop_num>6.1</drop_num>\n");
				}

			} else

			if (valueXliff.contains("{0}") || valueXliff.contains("{1}")
					|| valueXliff.contains("{2}") || valueXliff.contains("{3}")
					|| valueXliff.contains("{4}") || valueXliff.contains("{5}")
					|| valueXliff.contains("{6}")) {
				if (comments != null) {
					writeString("        <note>" + comments
							+ ", \t{0},{1} ... are Placeholders</note>\n");
					writeString("              <drop_num>6.1</drop_num>\n");
				}

				if (comments == null) {
					writeString("        <note>{0},{1} ... are Placeholders</note>\n");
					writeString("              <drop_num>6.1</drop_num>\n");
				}
			} else if (comments != null) {
				writeString("           <note>" + comments + "</note>\n");
				writeString("                <drop_num>6.1</drop_num>\n");
			} else {
				writeString("           <drop_num>6.1</drop_num>\n");
			}

			writeString("   </trans-unit>\n");
		}

	}

}
