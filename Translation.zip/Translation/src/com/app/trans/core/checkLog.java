package com.app.trans.core;

import javax.swing.JTextArea;

public class checkLog {

	private JTextArea jtextArea;

	public checkLog(JTextArea jtextArea) {
		this.jtextArea = jtextArea;
	
	}

	public void loop() {

		for (int i = 0; i < 100000; i++) {
			jtextArea.append("value \n" + i);
			if (1 == 5) {
				int k;
				try {

					k = 0 / i;
					System.out.println(k);
				} catch (Exception e) {
					jtextArea.append("value \n" + e);
				}

			}
		}

	}
	
	
	
	
}
