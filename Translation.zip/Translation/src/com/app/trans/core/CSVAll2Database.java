package com.app.trans.core;



import javax.swing.JPanel;
import javax.swing.JTextArea;

import com.app.trans.gui.TextArea;
import com.app.trans.util.ConstantsAll;
import com.app.trans.util.TransloadPropertyFile;

public class CSVAll2Database {
	
	public void insert2Table(JPanel p1 ){
		System.out.println("\n  insert into  table");
	}
	public void insertDupliacates(JPanel p1,JTextArea jtextArea){
		System.out.println("\n  insertDupliacates");
	}
	public void deleteDuplicates(JPanel p1) {
		System.out.println("\n  deleteDuplicates");
	}
	public void insert2Final(JPanel p1){
		
		System.out.println("\n  insert2Final "+TransloadPropertyFile.getLoadFile().getProperty(ConstantsAll.master_table) );
	
	}
	public void updateMessages(JPanel p1) {
		System.out.println("\n   updateMessages");
	}
	public void insertDupliacates(JPanel p1) {
		System.out.println("\n  insert Duplicates");
		
	}
	public void createTables(JPanel p1, String string) {
		System.out.println(" createTables"+string);
		
	}
}
