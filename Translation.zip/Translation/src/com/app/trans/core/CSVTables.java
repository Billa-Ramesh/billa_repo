package com.app.trans.core;

import javax.swing.JTextArea;

public class CSVTables {
	

	public void writetable(String selectedItem) {
		
		System.out.println("\n  in CSV tABLES -->"+selectedItem);
		// TODO Auto-generated method stub
		
	}
}
