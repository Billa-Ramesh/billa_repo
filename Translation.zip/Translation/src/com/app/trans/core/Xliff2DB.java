package com.app.trans.core;

import javax.swing.JTextArea;

public class Xliff2DB {

	public void insert2DB(String string, String encode, String mlsXd) {
	System.out.println("\n  insert into  table" +mlsXd +string );
		
		
		
	}

	

}
