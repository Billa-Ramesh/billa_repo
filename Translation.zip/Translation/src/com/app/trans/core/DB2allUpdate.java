package com.app.trans.core;

import javax.swing.JTextArea;

public class DB2allUpdate {
	public void update2Table(String mls) {
		System.out.println("\n  update2Table" +mls);
	}
	
}
