package reder;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.table.*;
import java.sql.*;
import java.util.*;
import java.util.Vector.*;
import java.text.*;
import java.util.Date;
 
 
public class DatabaseT extends AbstractTableModel{

	 
	 
    Connection con = null;
    Statement stm = null;
    ResultSet rs = null;
    int columns = 0;
    Vector newRows;
    String tableColNames[];
    ResultSetMetaData md = null;
    String tableName;
    Vector allRows;
    Vector newRow;
    boolean rowNew = false;
    boolean rowInserted = false;
    Vector row;
    int type;
    String cType[];
    
 
    public DatabaseT(){
 
        try{
 
            con = getConnection();
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT *FROM person");
            newRows = new Vector();
            md = rs.getMetaData();
            tableName = md.getTableName(1);
            columns = md.getColumnCount();
            tableColNames = new String[columns];
            cType = new String[columns];
 
             for( int i = 0; i < columns; i++){
 
                tableColNames[i] = md.getColumnName(i + 1);
                type = md.getColumnType(i + 1);
                if(type == Types.INTEGER){
                    cType[i] = "java.lang.Integer";
 
                }
                if(type == Types.VARCHAR || type == Types.LONGVARCHAR
                        || type == Types.CHAR){
                    cType[i] = "java.lang.String";
 
                }
                if(type == Types.DATE){
                    cType[i] = "java.lang.Date";
 
                }
              
            }
 
            allRows = new Vector();
            while(rs.next()){
 
                newRow = new Vector();
                   for(int j = 1; j <= columns; j++){
                       switch(md.getColumnType(j)){
                           case Types.CHAR:
                           case Types.VARCHAR:
                           case Types.LONGVARCHAR:
                               String s = rs.getString(j);
                               if(rs.wasNull()){
                                   newRow.addElement(null);
                               }
                               else {
                                   newRow.addElement(s);
                               }
 
                       break;
 
                       case Types.INTEGER:
                           int n = rs.getInt(j);
                           if(rs.wasNull()){
                               newRow.addElement(null);
                           }
                           else {
                               newRow.addElement(n);
                           }
 
                        break;
 
                        case Types.FLOAT:
                        case Types.DOUBLE:
                            double d = rs.getDouble(j);
                            if(rs.wasNull()){
                                newRow.addElement(null);
                            }
                            else{
                                newRow.addElement(new Double(d));
                            }
 
                            break;
                       case Types.DATE:
                           java.sql.Date date = rs.getDate(j);
 
                           
                           if(rs.wasNull()){
                               newRow.addElement(null);
                           }
                           else {
 
                             SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                             String formatDate = formatter.format(date);
                              newRow.addElement(date);
                           }
 
                           break;
                    
                            //    newRow.addElement(rs.getObject(j));
 
                       }
 
                }
 
                allRows.addElement(newRow);
 
            }
 
 
        }catch(Exception e){
 
            System.out.println(e.getMessage());
        }finally{
            try{
                con.close();
                stm.close();
            }catch(SQLException e){
 
                e.printStackTrace();
            }
 
        }
 
    }
 
 
     public static Connection getConnection(){
 
         Connection conn = null;
 
        
         try{
        	 
        	 Class.forName("com.mysql.jdbc.Driver");
 			conn = DriverManager.getConnection("jdbc:mysql://localhost/test",
 					"root", "root");
 			Statement st = conn.createStatement();
 			
             if(conn != null){
                 System.out.println("A database connection has been created");
                 System.out.println("Connection: " + conn);
             }
         }catch(Exception e){
 
             System.out.println("Problem:" + e.toString());
         }
         return conn;
     }
 
    public Class getColumnClass(int col){
 
        try{
            switch(md.getColumnType(col + 1)){
                case Types.CHAR:
                case Types.VARCHAR:
                case Types.LONGVARCHAR:
                    return String.class;
 
                case Types.INTEGER:
 
                   return Integer.class;
 
                case Types.FLOAT:
                case Types.DOUBLE:
                    return Double.class;
 
                case Types.DATE:
                    return String.class;
 
                default:
                    return Object.class;
 
            }
 
        }catch(SQLException e){
 
            e.getMessage();
            return Object.class;
        }
            // return getValueAt(0, col).getClass();
       }
 
       public boolean isCellEditable(int row, int col){
 
           if(rowNew){
               return true;
           }
 
           else {
               return true;
           }
 
        }
 
        public String getColumnName(int col){
 
            return tableColNames[col];
        }
 
        public int getColumnCount(){
 
            return columns;
        }
 
 
        public int getRowCount()
        {
 
            return allRows.size();
        }
 
        public Object getValueAt(int arow, int col){
 
           row = (Vector)allRows.elementAt(arow);
 
           return row.elementAt(col);
        }
 
        public void setValueAt(Object aValue, int aRow, int aCol){
 
             Vector dataRow = (Vector)allRows.elementAt(aRow);
             dataRow.setElementAt(aValue, aCol);
             fireTableCellUpdated(aRow, aCol);
        }
 
 
        public void addRow(){
 
            int rowNumber = allRows.size();
 
            int numElements = newRow.size();
 
            Vector newRowVect = new Vector();
 
 
 
            for(int k = 0; k < numElements; k++){
 
                if(cType[k] == "java.lang.Integer"){
                    Integer blankInt = new Integer(0);
                    newRowVect.addElement(blankInt);
                }
                if(cType[k] == "java.lang.String"){
                    String blankString = new String();
                    newRowVect.addElement(blankString);
                }
                if(cType[k] == "java.lang.Date"){
                    //java.sql.Date date = null;
                    String date2 = null;
                    newRowVect.addElement(date2);
                }
 
 
            }
 
            allRows.addElement(newRowVect);
            rowNew = true;
            this.isCellEditable(allRows.size(), 0);
            fireTableRowsInserted(getRowCount()-1, getRowCount()-1);
 
        }
 
        public void deleteRow(){
 
        }
 
        public void updateDB(){
 
        }
 
 

}
