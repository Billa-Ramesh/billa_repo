package reder;


import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.CellEditorListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;


import com.app.trans.core.Center;


import com.app.trans.table.LoginConnection;
import com.app.trans.table.MyTableModel;
import com.app.trans.table.MyTableModelListener;
import com.app.trans.util.DBConnection;






public class FinalPanel extends JFrame implements ActionListener,KeyListener,TableModelListener,MouseListener
{
     private static JLabel           lblEmpHead,lblLine,lblkey,lblmtext,lblcomments,lblflag,lbltablename,lblluptext
     ,lblupcomment,lblID,lblStr,lblQu,lblNew;
     private static JTextField       txtkey,txtMtext,txtComments,txtflag,txttablename,txtuptext,txtupcomment
     ,txtID,txtStr,txtQu,txtNew;
     private static JButton          cmdSave,cmdFind,cmdUpdate,cmdClear,cmdDelete,search;
     private static JPanel           mainPanel,lblPanel,btnPanel,searchPanel,wptgPanel;
     private static Final    		 ph;
     private static DBConnection          Conn;
     private  LoginConnection  con = new LoginConnection().getInstance();
     private static Center			 center;
	private Connection simpleCon;
	
	private static JScrollPane myPane;
	private MyTableModel tm;
	private JTable myTable;
	private ResultSet rs;
	

   
     
     public FinalPanel() {
    	 
		 
    	 super("Update Panel");
        mainPanel=new JPanel();
        mainPanel.setLayout(null);
        //Label Panel

        lblPanel=new JPanel();
        lblPanel.setLayout(null);
       
        
        
       lblEmpHead     =new JLabel("Final Table Creation");
       lblEmpHead.setFont(new Font("TimesRoman",Font.BOLD,12));
       lblEmpHead.setBounds(210,5,300,12);
       lblLine =new JLabel("_____________________");
       lblLine.setBounds(210,8,300,20);
       lblLine.setForeground(Color.red);

       lblkey  =new JLabel("Message key :");
       lblkey.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblkey.setBounds(25,30,200,20);
       txtkey =new JTextField();
       txtkey.setFont(new Font("TimesRoman",Font.PLAIN,12));
       txtkey.setBounds(200,30,350,20);
       txtkey.addKeyListener(this);  

       lblmtext  =new JLabel("Message text :");
       lblmtext.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblmtext.setBounds(25,55,200,20);
       txtMtext =new JTextField();
       txtMtext.setFont(new Font("TimesRoman",Font.PLAIN,12));       
       txtMtext.setBounds(200,55,350,20);
       txtMtext.addKeyListener(this);  
       //txtMtext.setEditable(false);
       
       lblluptext  =new JLabel("Update text :");
       lblluptext.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblluptext.setBounds(25,80,200,20);
       txtuptext =new JTextField();
       txtuptext.setFont(new Font("TimesRoman",Font.PLAIN,12));       
       txtuptext.setBounds(200,80,350,20);
       txtuptext.addKeyListener(this);  
      // txtuptext.setEditable(false);
       
       lbltablename  =new JLabel("Table name : ");
       lbltablename.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lbltablename.setBounds(25,105,200,20);
       txttablename=new JTextField();
       txttablename.setFont(new Font("TimesRoman",Font.PLAIN,12));
       txttablename.setBounds(200,105,150,20);
       txttablename.addKeyListener(this);

       lblcomments  =new JLabel("Comments :");
       lblcomments.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblcomments.setBounds(25,130,200,20);
       txtComments=new JTextField();
       txtComments.setFont(new Font("TimesRoman",Font.PLAIN,12));
       txtComments.setBounds(200,130,350,20);
       txtComments.addKeyListener(this);
     //  txtComments.setEditable(false);
       
       
       lblupcomment  =new JLabel("Update comments :");
       lblupcomment.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblupcomment.setBounds(25,155,200,20);
       txtupcomment=new JTextField();
       txtupcomment.setFont(new Font("TimesRoman",Font.PLAIN,12));
       txtupcomment.setBounds(200,155,350,20);
       txtupcomment.addKeyListener(this); 
     //  txtupcomment.setEditable(false);
       
       lblflag  =new JLabel("Flag :");
       lblflag.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblflag.setBounds(25,180,200,20);
       txtflag=new JTextField();
       txtflag.setFont(new Font("TimesRoman",Font.PLAIN,12));
       txtflag.setBounds(200,180,50,20);
       txtflag.addKeyListener(this);
       
      

       lblPanel.add(lblEmpHead);
       lblPanel.add(lblLine);
       lblPanel.add(lblkey);
       lblPanel.add(txtkey) ;
       lblPanel.add(lblmtext);
       lblPanel.add(txtMtext) ;
       
       lblPanel.add(lblluptext);
       lblPanel.add(txtuptext) ;
       
       lblPanel.add(lblcomments);
       lblPanel.add(txtComments);
       lblPanel.add(lblupcomment);
       lblPanel.add(txtupcomment);
       
       lblPanel.add(lblflag);
       lblPanel.add(txtflag) ;
       lblPanel.add(lbltablename);
       lblPanel.add(txttablename) ;
       

       //Button Panel
       btnPanel  =new JPanel();
       btnPanel.setLayout(null);

       cmdSave=new JButton("Save");
       cmdSave.setMnemonic('S');
       cmdSave.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdSave.setBounds(5,10,80,20);
       cmdSave.addActionListener(this);

       cmdFind=new JButton("Find");
       cmdFind.setMnemonic('F');
       cmdFind.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdFind.setBounds(5,35,80,20);
       cmdFind.addActionListener(this);

       cmdUpdate=new JButton("Update");
       cmdUpdate.setMnemonic('u');
       cmdUpdate.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdUpdate.setBounds(5,60,80,20);
       cmdUpdate.addActionListener(this);

       cmdDelete=new JButton("Delete");
       cmdDelete.setMnemonic('D');
       cmdDelete.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdDelete.setBounds(5,85,80,20);
       cmdDelete.addActionListener(this);

       cmdClear=new JButton("Clear");
       cmdClear.setMnemonic('C');
       cmdClear.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdClear.setBounds(5,120,80,20);
       cmdClear.addActionListener(this);

       btnPanel.add(cmdUpdate);
       btnPanel.add(cmdClear);
       btnPanel.add(cmdSave);
       btnPanel.add(cmdFind);
       btnPanel.add(cmdDelete);

       
       
      
       mainPanel.add(lblPanel);
       lblPanel.setBounds(0,0,600,210);
       mainPanel.add(btnPanel);
       btnPanel.setBounds(650,0,100,210);
   
       wptgPanel=new JPanel();
       wptgPanel.setLayout(null);
       wptgPanel.setBounds(0,220,1000,530);
       
      
       searchPanel=new JPanel();
       searchPanel.setLayout(null);
       searchPanel.setBounds(25,5,600,100);
             
       lblID  =new JLabel("String Id :");
       lblID.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblID.setBounds(25,0,200,20);
       txtID =new JTextField();
       txtID.setFont(new Font("TimesRoman",Font.PLAIN,12));
       txtID.setBounds(120,0,200,20);
       txtID.addKeyListener(this);  
        search =new JButton("Search");
        search.setBounds(450,10,80,20);
        search.addActionListener(this);
       lblStr  =new JLabel("String :");
       lblStr.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblStr.setBounds(25,25,200,20);
       txtStr =new JTextField();
       txtStr.setFont(new Font("TimesRoman",Font.PLAIN,12));       
       txtStr.setBounds(120,25,200,20);
       txtStr.addKeyListener(this);  
       //txtMtext.setEditable(false);
       
       lblQu  =new JLabel("Catagory :");
       lblQu.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblQu.setBounds(25,50,200,20);
       txtQu =new JTextField();
       txtQu.setFont(new Font("TimesRoman",Font.PLAIN,12));       
       txtQu.setBounds(120,50,200,20);
       txtQu.addKeyListener(this);  
      
       
       lblNew  =new JLabel("New String : ");
       lblNew.setFont(new Font("TimesRoman",Font.PLAIN,12));
       lblNew.setBounds(25,75,200,20);
       txtNew=new JTextField();
       txtNew.setFont(new Font("TimesRoman",Font.PLAIN,12));
       txtNew.setBounds(120,75,150,20);
       txtNew.addKeyListener(this);
       
       searchPanel.add(lblID);
       searchPanel.add(txtID);
       searchPanel.add(lblStr);
       searchPanel.add(txtStr);
       searchPanel.add(lblQu);
       searchPanel.add(txtQu);
       searchPanel.add(lblNew);
       searchPanel.add(txtNew);
       wptgPanel.add(search);
       wptgPanel.add(searchPanel);
      // mainPanel.add(searchPanel);
       
     //  ResultSet rs=GetResultSet();
       tm = new MyTableModel();
       
     
       myTable = new JTable(tm);
       myPane = new JScrollPane(myTable,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
               JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
       myTable.setSelectionForeground(Color.white);
       myTable.setSelectionBackground(Color.red);
       myTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
       myTable.addKeyListener(this);
       myTable.addMouseListener(this);
       
     //  myTable.setCellSelectionEnabled(true);
       myTable.setRowSelectionAllowed(true);

       myTable.setCellSelectionEnabled(true);

   
     myTable.getDefaultEditor(String.class).addCellEditorListener(new MyCellEditorListener(myTable));
      
      // myTable.getDefaultRenderer(arg0);
  //     myTable.getModel().addTableModelListener(new MyTableModelListener(myTable));
	
      // myTable.setCellSelectionEnabled(true);
    //   myTable.setColumnSelectionAllowed(true);
   //    myTable.setRowSelectionAllowed(true);
       
 
       
       myPane.setBounds(20,110,970,230);
       wptgPanel.add(myPane);
       wptgPanel.setBorder(BorderFactory.createLineBorder(Color.black));
    //   myTable.setRowSelectionAllowed(false);
      
       myTable.getModel().addTableModelListener(this);
        getContentPane().add(wptgPanel);
       // wptgPanel.setBackground(Color.red);
       // searchPanel.setBackground(Color.blue);
       // mainPanel.setBackground(Color.red);
        getContentPane().add(mainPanel);
            
       cmdUpdate.setEnabled(false);
       cmdDelete.setEnabled(false);
       tm.setQuery("select * from ANALYSIS_REPORT");
     }

     private ResultSet GetResultSet() {
    	 try {
			simpleCon = DriverManager.getConnection("jdbc:oracle:thin:@10.184.203.0:1521:REVEXAII","oreclang","oreclang");
		
         Statement stat = simpleCon.createStatement();
         rs = stat.executeQuery("SELECT * FROM ANALYSIS_REPORT");
     } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	public void keyReleased(KeyEvent evt){
		//System.out.println("relesed");
	}	

     public void keyTyped(KeyEvent evt){
    	 
    	// System.out.println("typed");
     }	

     public void keyPressed(KeyEvent evt) {
    	 Object obj = evt.getSource();
    	 int key = evt.getKeyCode();
    	 if(key == KeyEvent.VK_ENTER){
    		 if(obj == txtkey) {
    			 txtMtext.requestFocus();
    			 BlankCheck(txtkey);
    		 }
    		 if(obj == txtMtext){
    			 txtuptext.requestFocus();
    			 BlankCheck(txtMtext);
    		 }
    		 if(obj == txtuptext){
    			 txttablename.requestFocus();
    			 BlankCheck(txtuptext);
    		 }
    		 if(obj == txttablename){
    			 txtComments.requestFocus();
    			 BlankCheck(txttablename);
    		 }
    		 if(obj == txtComments){
    			 txtupcomment.requestFocus();
    			 BlankCheck(txtComments);
    		 }
    		 if(obj == txtupcomment){
    			 txtflag.requestFocus();
    			 BlankCheck(txtupcomment);
    		 }
    		 if(obj == txtflag){
    			
    			 BlankCheck(txtflag);
    		 }
    		 
    		
    	 }
    	 if(key==KeyEvent.VK_UP){
        	 int  col=	 tm.getColumnCount();
        		int row= tm.getRowCount();
        		int curRow=	myTable.getSelectedRow();  
        		
        	if(!(curRow==0)){
        		//selectCell(myTable.getSelectedRow()-1,7);
        		myTable.setValueAt("fdf", 0, 2);
        			for (int j=0;j<col;j++){
        				String values=	(String) tm.getValueAt(myTable.getSelectedRow()-1, j);
    			        if(  tm.getColumnName(j).contains("id".toUpperCase())){
    			        txtkey.setText(values);
    			        }
    			        if(  tm.getColumnName(j).equals("string".toUpperCase())){
    			        	txtuptext.setText(values);
        			        }
    			        if(  tm.getColumnName(j).contains("file".toUpperCase())){
    			        	
    			        	txtupcomment.setText(values);
        			        }
    			       
        //		System.out.println(tm.getValueAt(myTable.getSelectedRow()-1, j));
        			}
        			
        		
        	}
        		// System.out.println("down key"+tm.getColumnCount()+ tm.getRowCount());
        		
        	 }
    	
    	 if(key==KeyEvent.VK_DOWN ){
    	    int  col= tm.getColumnCount();
    		int row= tm.getRowCount();
    	int curRow=	myTable.getSelectedRow();
    	
    	//System.out.println("curRow"+curRow+"\n"+row+"row");
    	
    	boolean s= curRow+1==row? true:false;
    //	System.out.println(s);
    	int vColIndex = 0;
    		if(!s)
    			for (int j=0;j<col;j++){
    	//	System.out.println(tm.getValueAt(myTable.getSelectedRow()+1, j));
    			String values=	(String) tm.getValueAt(myTable.getSelectedRow()+1, j);
    			        if(  tm.getColumnName(j).contains("id".toUpperCase())){
    			        txtkey.setText(values);
    			        }
    			        if(  tm.getColumnName(j).contains("new".toUpperCase())){
    			        	txtuptext.setText(values);
        			        }
    			        if(  tm.getColumnName(j).contains("dev".toUpperCase())){
    			        	myTable.getModel().setValueAt("billa", myTable.getSelectedRow(), j);
    			        	vColIndex=j;
    			        	
    			        	txtupcomment.setText(values);
        			        }
    			        System.out.println(values+"------------");
    			}
    		 
    	
    		// System.out.println("down key"+tm.getColumnCount()+ tm.getRowCount());
    		
    	 }
     }

     public void actionPerformed(ActionEvent e) {
    	 
         Conn = new DBConnection();
      // System.out.println("latest conn ----"+con.getConnection().toString());
         Final finaltable = new Final();
         
         Object obj = e.getSource();
          if(obj == cmdClear) {            
        	  Clear();                            
          }
          if(obj == cmdSave) {
        	  setFinal();
        	  FinalDAO.Save(Conn.getConnection(), ph);
              Clear();
          }
          if(obj == cmdFind) {
        	  
        	  System.out.println("in find");
        	  setFinal();
        	  finaltable = FinalDAO.GetFinal(Conn.getConnection(), ph);
        	  if (finaltable.getMassagekey() == null) {
        		  JOptionPane.showMessageDialog(null, "Your Final No is not available..");
        	  } else {
        		  
        		  txtkey.setText(finaltable.getMassagekey());
        		  txtMtext.setText(finaltable.getMessageText());
        		  txtuptext.setText(finaltable.getUpdateText());
        		  txttablename.setText(finaltable.getTablename());
        		  txtComments.setText(finaltable.getComments());
        		  txtupcomment.setText(finaltable.getComments());
            	  txtflag.setText(finaltable.getFlag());
        	  }
        	  cmdSave.setEnabled(false);
        	  cmdUpdate.setEnabled(true);
        	  cmdDelete.setEnabled(true);
        	  txtupcomment.setEditable(true);
        	  txtuptext.setEditable(true);
        	  txtMtext.setEditable(false);
        	  txtComments.setEditable(false);
          }
          if(obj == cmdDelete) {
        	  setFinal();
        	  
        	  FinalDAO.Delete(Conn.getConnection(), ph);
              Clear();
              cmdSave.setEnabled(true);
              cmdUpdate.setEnabled(false);
              cmdDelete.setEnabled(false);
         }
         if(obj == cmdUpdate) {
        	 setFinal();
        	 FinalDAO.Update(Conn.getConnection(), ph);
        	 Clear();
        	 cmdSave.setEnabled(true);
        	 cmdUpdate.setEnabled(false);
        	 cmdDelete.setEnabled(false);
         }
         if(obj==search){
        	
        		
        //	rs= WptgDao.searchData(Conn.getConnection(),txtID.getText(),txtStr.getText(),txtQu.getText(),txtNew.getText() );
        //	 while (rs.next()){
        //     	System.out.println(rs.getString(1));
        //      }
        	 String query="SELECT * FROM ANALYSIS_REPORT "  +
       		"WHERE STRING_ID like '%" + txtID.getText() + "%' and STRING LIKE '%"+txtStr.getText()+"%'"; 
        	//	MyTableModel m=	new MyTableModel();
        		tm.setQuery(query);
        		tm.fireTableDataChanged();
        		myTable.setModel(tm);
        	//	m.setQuery("select * from ANALYSIS_REPORT");
        	//tm = new MyTableModel(rs);
        	//myTable.setModel(new MyTableModel(rs));
      
        	
         }
      }

      public void  Clear() {
    	  txtkey.setText("");
    	  txtMtext.setText("");
    	  txtuptext.setText("");
    	  txtComments.setText("");
    	  txtupcomment.setText("");
    	  txtflag.setText("");
    	  txttablename.setText("");
      }

       public void BlankCheck(JTextField txt) {
    	   if (txt.getText().equals("")) {
    		   JOptionPane.showMessageDialog(null, "You Must Enter The Text  Box");
    		   txt.requestFocus();	
           }
        }

       //Set Final Information
       public void setFinal() { 
	       ph = new Final();
	       ph.setMassagekey(txtkey.getText().trim());
	       ph.setMessageText(txtMtext.getText().trim());
	       ph.setUpdateText(txtuptext.getText().trim());
	       ph.setTablename(txttablename.getText().trim());
	       ph.setComments(txtComments.getText().trim());
	       ph.setUpdateComment(txtupcomment.getText().trim());
	       ph.setFlag(txtflag.getText().trim());
	   
	  
       }

     //Main  Function
     public static void main(String[] args) {
    	 FinalPanel frmForm = new FinalPanel();
		 center = new Center(frmForm,800,600);
		
         frmForm.setVisible(true);
         frmForm.setResizable(false);
         frmForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     }
     public void selectCell(int row, int col) {
 		if (row != -1 && col != -1) {
 			myTable.setRowSelectionInterval(row, row);
 			myTable.setColumnSelectionInterval(col, col);
 		}
 	}

	@Override
	public void tableChanged(TableModelEvent source) {
		
	//	System.out.println("table changed ");

		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		
	//	System.out.println("clik");
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
	
	//	System.out.println("mousePressed");
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	
		
	}
}