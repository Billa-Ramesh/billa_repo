package reder;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.AbstractAction;
import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.Component;
import java.awt.Toolkit;
import java.text.NumberFormat;
import java.text.ParseException;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;
import java.util.*;
import java.lang.*;
import java.util.Date;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.DefaultCellEditor;
import java.awt.*;
import java.awt.event.*;
import javax.swing.text.*;
import javax.swing.border.*;
import javax.swing.JTextField;
 
public class TableEditor extends JFrame{
private JPanel panel;
public JTable table;
private JButton insert;
private JButton update;
private JButton delete;
private DatabaseT dbtable;
private JScrollPane pane;
private boolean DEBUG = true;
private JTextField textBox;
    public TableEditor(){
     
        setLayout(new BorderLayout());
        panel = new JPanel();
        dbtable = new DatabaseT();
        table = new JTable(dbtable);
       
        for(int t = 0; t < table.getColumnCount(); t++){
            TableModel mdl = table.getModel();
          
            if(mdl.getValueAt(0,t).getClass() == Integer.class){
            
                setUpIntegerEditor(table);
            }
            if( mdl.getValueAt(0,t).getClass() == java.lang.String.class){
 
                System.out.println(mdl.getValueAt(0,t).getClass());
                TableCellEditor fce = new CharEditor();
                table.setDefaultEditor(Object.class, fce);
 
               /* try{
                    MaskFormatter formatter = new MaskFormatter("###");
                    JFormattedTextField textField = new JFormattedTextField(formatter);
                    textField.setBorder(null);
                    TableCellEditor tce = new DefaultCellEditor(textField);
                   // table.setDefaultEditor(Object.class, tc);
                    table.getColumnModel().getColumn(0).setCellEditor(tce);
 
 
                }catch(Exception e){
 
                }*/
 
            }
 
     
        }
                
        insert = new JButton("Insert");
        update = new JButton("Update");
        delete = new JButton("Delete");
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        pane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
      
 
       // pane.getViewport().setBackground(Color.GRAY);
        panel.setBackground(Color.lightGray);
        add(pane);
        add(panel, BorderLayout.SOUTH);
 
       // panel.setLayout(new FlowLayout());
        panel.add(insert);
        panel.add(update);
        panel.add(delete);
 
        
        update.addActionListener(new ActionListener(){
 
            public void actionPerformed(ActionEvent e){
                dbtable.updateDB();
            }
 
        });
 
         insert.addActionListener(new ActionListener(){
 
            public void actionPerformed(ActionEvent e){
 
                 dbtable.addRow();
                 table.setEditingRow(dbtable.getRowCount());
                 table.setRowSelectionInterval(dbtable.getRowCount()-1,
                         dbtable.getRowCount()-1);
             }
         });
 
        setSize(400,200);
        setVisible(true);
 
        addWindowListener(new WindowAdapter(){
 
            public void windowClosing(WindowEvent e){
 
                System.exit(0);
            }
 
        });
 
        if (DEBUG) {
            table.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    printDebugData(table);
                }
            });
        }
 
    }
 private void setUpIntegerEditor(JTable table) {
        //Set up the editor for the integer cells.
     //   final WholeNumberField integerField = new WholeNumberField(0, 5);
  /*      integerField.setHorizontalAlignment(WholeNumberField.RIGHT);
 
        DefaultCellEditor integerEditor =
            new DefaultCellEditor(integerField) {
                //Override DefaultCellEditor's getCellEditorValue method
                //to return an Integer, not a String:
                public Object getCellEditorValue() {
                    return new Integer(integerField.getValue());
                }
            };
        table.setDefaultEditor(Integer.class, integerEditor);*/
    }
 
    private void printDebugData(JTable table) {
        int numRows = table.getRowCount();
        int numCols = table.getColumnCount();
        javax.swing.table.TableModel model = table.getModel();
 
        System.out.println("Value of data: ");
        for (int i=0; i < numRows; i++) {
            System.out.print("    row " + i + ":");
            for (int j=0; j < numCols; j++) {
                System.out.print("  " + model.getValueAt(i, j));
            }
            System.out.println();
        }
        System.out.println("--------------------------");
    }
 
    public static void main(String args[]){
 
        TableEditor editor = new TableEditor();
 
    }
 
 
 
class CharEditor extends DefaultCellEditor{
    
     CharEditor(){
 
         super(new JTextField());
     }
 
     public boolean stopCellEditing(){
 
    try{
        String editingValue = (String)getCellEditorValue();
        
        System.out.println("editingValue-----"+editingValue);
        DatabaseT t=new DatabaseT();
       Connection con = t.getConnection();
      int row=table.getSelectedRow();
     
    Enumeration<TableColumn> col = table.getColumnModel().getColumns();
    while(col.hasMoreElements()){
    	System.out.println(col.nextElement().getHeaderValue());
    	TableColumn value = col.nextElement();
    	//System.out.println(table.getColumn(value));
    }
   Object o = t.getValueAt(1, 2);
   System.out.println(o.toString()+"--"+row+1);
       try {
		PreparedStatement stat = con.prepareStatement("update person set name='"+editingValue+"' where id=1");
		stat.execute();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
        
        if(editingValue.length() > 5){
            JTextField textField = (JTextField)getComponent();
            textField.setBorder(new LineBorder(Color.red));
            textField.selectAll();
            textField.requestFocusInWindow();
 
            JOptionPane.showMessageDialog(null, "Please enter string with 5 letters.",
                    "Alert!", JOptionPane.ERROR_MESSAGE);
            return false;
        }
 
    }catch(ClassCastException exception){
 
        return false;
    }
 
    return super.stopCellEditing();
}
 
     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
             int row, int column){
 
         Component c = super.getTableCellEditorComponent(table, value, isSelected, row, column);
         ((JComponent)c).setBorder(new LineBorder(Color.black));
 
 
         return c;
 
     }
}
 
}
 
 

