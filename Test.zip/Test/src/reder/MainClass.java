package reder;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;

public class MainClass extends JFrame {
  
  public MainClass() {
    super("Table With DefaultCellEditor Example");
    setSize(500, 300);
    setDefaultCloseOperation(EXIT_ON_CLOSE);

    JTable table = new JTable(new AbstractTableModel() {
    	 private String[] columnNames = {"First Name",
                 "Last Name",
                 "Sport",
                 "# of Years",
                 "Vegetarian"};
private Object[][] data = {
{"Kathy", "Smith",
"Snowboarding", new Integer(5), new Boolean(false)},
{"John", "Doe",
"Rowing", new Integer(3), new Boolean(true)},
{"Sue", "Black",
"Knitting", new Integer(2), new Boolean(false)},
{"Jane", "White",
"Speed reading", new Integer(20), new Boolean(true)},
{"Joe", "Brown",
"Pool", new Integer(10), new Boolean(false)}
};
      public int getColumnCount() {
        return 3;
      }

      public int getRowCount() {
        return 10;
      }

      public Object getValueAt(int r, int c) {
    	  return data[r][c];
      }

      public Class getColumnClass(int c) {
        if (c == 2)
          return ColorName.class;
        return String.class;
      }

      public boolean isCellEditable(int r, int c) {
        return c == 2;
      }

      public void setValueAt(Object value, int r, int c) {
        data[r] = (String) value;
      }
    });

    table.setDefaultEditor(String.class, new DefaultCellEditor(new JTextField()));
    table.setDefaultRenderer(String.class, new DefaultTableCellRenderer());
    table.setRowHeight(20);
    getContentPane().add(new JScrollPane(table));
  }

  public static void main(String args[]) {
    MainClass ex = new MainClass();
    ex.setVisible(true);
  }

  public class ColorName {
    String cname;

    public ColorName(String name) {
      cname = name;
    }

    public String toString() {
      return cname;
    }
  }
}

           
         