package reder;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import com.app.trans.core.AnalysisReportUpdates;
import com.app.trans.util.ConstantsAll;




public class FinalDAO {
	
	public static final FinalDAO FinalDAO = new FinalDAO();
	
	public FinalDAO() {}
	
	public static void Save(Connection Conn, Final ph) {

		try {
	          Statement stmt=Conn.createStatement();
	 
	          String query = "INSERT INTO "+ConstantsAll.FINAL_TABLE+" VALUES ('"+ph.getMassagekey()+"','"+ph.getMessageText()+ "','" + ph.getTablename() + 
	          					"','" + ph.getComments() + "','" + ph.getFlag() + "')";
	          				System.out.println(query);	
	          int result=stmt.executeUpdate(query);
	          
	          if(result==1) {
	        	  JOptionPane.showMessageDialog(null, " \nSaving Successfully  \n");               
	          }
         } catch(SQLException sqlx) {
        	 JOptionPane.showMessageDialog(null, " \n SQLException \n " +sqlx.getMessage() + "\n");
         }
	}
	
	public static void Delete(Connection Conn, Final ph) {
       String phNo = ph.getMassagekey();
       try {
    	   
    	   
    	 int response=  JOptionPane.showConfirmDialog(null, "Do you want to continue?","Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
    	   if (response == JOptionPane.NO_OPTION) {
    		      System.out.println("No button clicked");
    		    } else if (response == JOptionPane.YES_OPTION) {
    		    	 ph = new Final();
    					Statement stmt=Conn.createStatement();
    					String query="DELETE FROM "+ConstantsAll.FINAL_TABLE+" WHERE MESSAGE_KEY = '" + phNo + "' ";
    					stmt.executeUpdate(query);
    					stmt.close();
    		    } else if (response == JOptionPane.CLOSED_OPTION) {
    		      System.out.println("JOptionPane closed");
    		    }
    	  
         } catch(SQLException sqlx) {
        	 JOptionPane.showMessageDialog(null, " \n *** SQLException ***  \n " +sqlx.getMessage() + "\n");
         }
    }
	
	public static void Update(Connection Conn, Final ph) {
	       String messageKey = ph.getMassagekey();
	       try {
	    	   int response = JOptionPane.showConfirmDialog(null, "Do you want to continue?", "Confirm",
	    		        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	    		    if (response == JOptionPane.NO_OPTION) {
	    		      System.out.println("No button clicked");
	    		    } else if (response == JOptionPane.YES_OPTION) {
	    		        Statement stmt=Conn.createStatement();
	    				String query="UPDATE "+ConstantsAll.FINAL_TABLE+" SET " +
	    								" MESSAGE_KEY ='" + ph.getMassagekey() + "', " +
	    								" MESSAGE_TEXT ='" + ph.getUpdateText() + "', " +
	    								" TABLE_NAME ='" + ph.getTablename() + "', " +
	    								" COMMENTS ='" + ph.getUpdateComment() + "', " +
	    								" FLAG ='" + ph.getFlag() + "'" +
	    								" WHERE MESSAGE_KEY = '" + messageKey + "'";
	    				System.out.println(query);
	    				stmt.executeUpdate(query);
	    				   				
	    				stmt.close();
	    				AnalysisReportUpdates upd=new AnalysisReportUpdates();
	    				
	    				upd.analysisUpdate(ph.getMessageText(),ph.getUpdateText(),ph.getUpdateComment());
	    		    } else if (response == JOptionPane.CLOSED_OPTION) {
	    		      System.out.println("JOptionPane closed");
	    		    }
	    	
	         } catch(SQLException sqlx) {
	        	 JOptionPane.showMessageDialog(null, " \n *** SQLException ***  \n " +sqlx.getMessage() + "\n");
	         }
    }

	public static Final GetFinal(Connection Conn, Final ph) {
		System.out.println("get Final");
		String messageKey = ph.getMassagekey();
		try {
              Statement stmt=Conn.createStatement();
             
              System.out.println("SELECT * FROM "+ConstantsAll.FINAL_TABLE+" WHERE MESSAGE_KEY='" + messageKey + "' ");
             
              String query="SELECT * FROM "+ConstantsAll.FINAL_TABLE+" WHERE MESSAGE_KEY='" + messageKey + "' ";
              
              ResultSet rs=stmt.executeQuery(query);
              while(rs.next()) {
            	  ph = new Final();
            	
	              ph.setMassagekey(rs.getString(1));
	              ph.setMessageText(rs.getString(2));
	              ph.setTablename(rs.getString(3));
	              ph.setComments(rs.getString(4));
	              ph.setFlag(rs.getString(5));
	             
              }    
		} catch(SQLException sqlx) {
			JOptionPane.showMessageDialog(null, " \n *** SQLException ***  \n " +sqlx.getMessage() + "\n");
		}
		return ph;
	}	
        

	/**
	 * @return the FinalDAO
	 */
	public static FinalDAO getFinalDAO() {
		return FinalDAO;
	}
}