package com.app.trans.update;

import java.awt.Color;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.EventObject;

import javax.swing.DefaultCellEditor;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import com.app.trans.table.MyTableModel;

import reder.DatabaseT;

public class CharEditor extends DefaultCellEditor {
    
    private JTable myTable;
    private MyTableModel tm;
	private Connection db;

	CharEditor(JTable myTable, MyTableModel tm){
        super(new JTextField());
this.myTable=myTable;
this.tm=tm;

    }

    public boolean stopCellEditing(){

   try{
       String editingValue = (String)getCellEditorValue();
       
       System.out.println("editingValue-----"+editingValue);
    
       try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   	 try {
		db = DriverManager.getConnection("jdbc:mysql://localhost/test","root", "root");
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
   	// db = DriverManager.getConnection("jdbc:oracle:thin:@10.184.203.0:1521:REVEXAII","oreclang","oreclang");
 
     int row=myTable.getSelectedRow();
    
   Enumeration<TableColumn> col = myTable.getColumnModel().getColumns();
   while(col.hasMoreElements()){
   	System.out.println(col.nextElement().getHeaderValue());
   	TableColumn value = col.nextElement();
   	//System.out.println(table.getColumn(value));
   }
  Object o =myTable.getValueAt(1, 2);
  System.out.println(o.toString()+"--"+row+1);
      try {
		PreparedStatement stat = db.prepareStatement("update person set email='"+editingValue+"' where id=1");
		boolean updated = stat.execute();
		if (updated){
		
		}
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
    myTable.setModel(new MyTableModel());
       if(editingValue.length() > 5){
           JTextField textField = (JTextField)getComponent();
           textField.setBorder(new LineBorder(Color.red));
           textField.selectAll();
           textField.requestFocusInWindow();

           JOptionPane.showMessageDialog(null, "Please enter string with 5 letters.",
                   "Alert!", JOptionPane.ERROR_MESSAGE);
           return false;
       }

   }catch(ClassCastException exception){

       return false;
   }

   return super.stopCellEditing();
}

    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
            int row, int column){

        Component c = super.getTableCellEditorComponent(table, value, isSelected, row, column);
        ((JComponent)c).setBorder(new LineBorder(Color.black));


        return c;

    }
}
