package com.app.trans.table;

import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.*;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.*;
import java.util.Vector;

public class MyTableModel extends AbstractTableModel {
/**
	 * 
	 */
	 Vector cache;
	 int colCount;

	  String[] headers;

	  Connection db;

	  Statement statement;

	  String currentURL;

	  public MyTableModel() {
		  this.cache = new Vector();
		  
		  
		  
	  }
	  public boolean isCellEditable(int row, int col){
		
		  boolean edit=false;
		  for(int j=0;j<=col;j++){
			  if( getColumnName(j).contains("Email") || getColumnName(col).contains("dev".toUpperCase()))
				  edit= true;
			 
		  }
		 
	   
	         return edit;
	      }
	  public String getColumnName(int i) {
	    return headers[i];
	  }

	  public int getColumnCount() {
	    return colCount;
	  }

	  public int getRowCount() {
	    return cache.size();
	  }

	  public Object getValueAt(int row, int col) {
	    return ((String[]) cache.elementAt(row))[col];
	  }
	  public void setValueAt(Object value, int row, int col) { 
		  
		  /*
		  String q="UPDATE  ANALYSIS_REPORT SET "  +
     		"dev_feedback='" + value.toString() + "' where  string_id='"+getValueAt(row, 6)+"'"; 
		  System.out.println(q);
		 	 try {
				db = DriverManager.getConnection("jdbc:oracle:thin:@10.184.203.0:1521:REVEXAII","oreclang","oreclang");
				System.out.println(db.toString()+"conecttion is avilable");
		         statement = db.createStatement();
		      // Execute the query and store the result set and its metadata
		         int co=statement.executeUpdate(q);
		      System.out.println("coount"+co);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    	fireTableCellUpdated(row, col);
		    	fireTableDataChanged();*/
      	//	MyTableModel m=	new MyTableModel();
      	//	tm.setQuery(query);
      	//	tm.fireTableDataChanged();
      	//	myTable.setModel(tm);*/
		  
		  
		 System.out.println(value.toString()+"--"+ getValueAt(row, 3));
		  fireTableCellUpdated(row, col); 
		  fireTableDataChanged();
		  fireTableRowsUpdated(row, col);
		  
	  }
	  public void setQuery(String q) {
		    cache = new Vector();
		    try {
		    	try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	 db = DriverManager.getConnection("jdbc:mysql://localhost/test",
		  					"root", "root");
		    	// db = DriverManager.getConnection("jdbc:oracle:thin:@10.184.203.0:1521:REVEXAII","oreclang","oreclang");
		    	System.out.println(db.toString()+"conecttion is avilable");
		         statement = db.createStatement();
		      // Execute the query and store the result set and its metadata
		      ResultSet rs = statement.executeQuery(q);
		      ResultSetMetaData meta = rs.getMetaData();
		      
		      colCount = meta.getColumnCount();

		      // Now we must rebuild the headers array with the new column names
		      headers = new String[colCount];
		      for (int h = 1; h <= colCount; h++) {
		        headers[h - 1] = meta.getColumnName(h);
		      }

		      // and file the cache with the records from our query. This would
		      // not be
		      // practical if we were expecting a few million records in response
		      // to our
		      // query, but we aren't, so we can do this.
		      while (rs.next()) {
		        String[] record = new String[colCount];
		        for (int i = 0; i < colCount; i++) {
		        	//System.out.println(rs.getString(i + 1));
		          record[i] = rs.getString(i + 1);
		        }
		        cache.addElement(record);
		      }
		    fireTableChanged(null); // notify everyone that we have a new table.
		      
		    } catch (Exception e) {
		      cache = new Vector(); // blank it out and keep going.
		      e.printStackTrace();
		    }
		  }
	
   }