/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : ReconUtil.java
Created By            : Rahul Manoharan 
Created On            : April 20th, 2012
Application Name      : General Ledger v3.5
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

 *********************************************************************************************************/

package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Priority;

import umm.bi.ClsUEntBIDataSet;
import umm.bi.ClsUEntHierarchy;

import com.iflex.fic.client.BusinessMetaData;
import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.iflex.fic.global.GlobalParameters;
import com.ofs.erm.gl.action.ActiveReconAction;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.global.JSONReader;
import com.ofs.erm.gl.model.ReconModel;

public class ReconUtil {

	/*
	 * 
	 * 
	 */

	public Map getCurrVal(String infoDom) {
		// TODO Auto-generated method stub
		Map currMap = new LinkedHashMap();

		List<LinkedHashMap> resList = new ArrayList<LinkedHashMap>();
		Cargo cargo1;
		DACRecordSet resultSet;
		String tableName = GlobalUtil.getParamValue("GL_CURRENCY", infoDom);

		GL35Logger.logThis("Querying - " + tableName
				+ " for Currency values ... ", Priority.DEBUG_INT);

		String currCodeCol = "SELECT V_PARAM_PREFIX FROM REVELEUS_PARAMETER_MASTER WHERE V_PARAM_CODE = 'GL_CURRENCY'";

		try {
			Cargo cargo11 = (Cargo) SMSServices.executeQuery(infoDom,
					currCodeCol, false);
			DACRecordSet resultSet1 = (DACRecordSet) cargo11.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				currCodeCol = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}
		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
		}

		String currDesc = "SELECT V_PARAM_SUFFIX FROM REVELEUS_PARAMETER_MASTER WHERE V_PARAM_CODE = 'GL_CURRENCY'";

		try {
			Cargo cargo11 = (Cargo) SMSServices.executeQuery(infoDom, currDesc,
					false);
			DACRecordSet resultSet1 = (DACRecordSet) cargo11.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				currDesc = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}
		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
		}

		String sqlQuery = "SELECT " + currCodeCol + "," + currDesc + " FROM "
				+ tableName + "";

		try {

			cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
			resultSet = (DACRecordSet) cargo1.getPayLoadObject();

			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				currMap.put(resultSet.fetchElement(1),
						resultSet.fetchElement(2));
				resultSet.moveNext();
			}

			/*
			 * for (Map.Entry<String, String> entry : lhm.entrySet()) {
			 * System.out.println(entry.getKey() + "/" + entry.getValue()); }
			 */

		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
		}

		return currMap;

	}

	public Map getTpList(String infoDom) {
		// TODO Auto-generated method stub
		Map tpList = new LinkedHashMap();
		Cargo cargo1;
		DACRecordSet resultSet;

		GL35Logger.logThis(
				"Querying SETUP_PRODUCT_PROCESSORS for TP values ...",
				Priority.DEBUG_INT);
		String sqlQuery = "SELECT V_TABLE_NAME,V_LOGIC_TABLE_NAME from SETUP_PRODUCT_PROCESSORS";

		try {

			cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
			resultSet = (DACRecordSet) cargo1.getPayLoadObject();

			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				tpList.put(resultSet.fetchElement(1), resultSet.fetchElement(2));
				resultSet.moveNext();
			}

			/*
			 * for (Map.Entry<String, String> entry : lhm.entrySet()) {
			 * System.out.println(entry.getKey() + "/" + entry.getValue()); }
			 */

		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
		}

		return tpList;
	}

	public String createRecon(ReconModel reconModel, String infoDom) {
		// TODO Auto-generated method stub

		GL35Logger.logThis("Entering createRecon...", Priority.DEBUG_INT);
		ArrayList<StringBuffer> alQueryList = new ArrayList<StringBuffer>();
		ArrayList<String> delQueryList = new ArrayList<String>();
		// Get PP Physical Table data
		Map ppMap = getPPMap(infoDom);

		StringBuffer sqlQuery1 = new StringBuffer();
		String pageMode = reconModel.getPageMode();

		String sMapType = reconModel.getIsActOrPass(); // Active/Passive Recon
		String sGlMapName = reconModel.getName();
		String sGLMapDesc = reconModel.getDesc();
		String sEntityCode = reconModel.getLegEntity();
		String sConsolType = reconModel.getSelConsolType();
		String sBalType = reconModel.getSelBalType();
		String sBookCode = reconModel.getGlBookType();
		String sGlType = reconModel.getSelGlType();
		String sAdjAllocReq = reconModel.getRadAdjReq();
		String sReconDef = reconModel.getRadReconDefTyp();
		String sGlThrshldCurr = reconModel.getSelTrsCrn();
		String sAdjAllocMthd = reconModel.getRadAdjAlloc();
		String sAdjEntryPost = reconModel.getRadAdjPostTo();
		String sCreatedUser = reconModel.getCreatedUser();

		/* To BE REMOVED */
		if (sCreatedUser == null)
			sCreatedUser = "GLUSER";
		/* To BE REMOVED */

		String sModUser = "";
		String sMapThrshldType = "";
		String sMapAdjFloor = "";
		String sMapPosThr = "";
		String sMapNegThr = "";
		String sCreatedDate = "";
		String sModDate = "";
		String sMapId = "";
		int iVersionNum = 0;

		if (!sReconDef.equals("G")) { // MAP LEVEL RECON
			// Input is of Type [<dummyRowValue>,,,,,,,,,.....<n rows>,Value]
			int length = reconModel.getSelTrsSpc().split(",").length;
			sMapThrshldType = removeElements(
					reconModel.getSelTrsSpc().split(","), length - 1)[0];
			sMapAdjFloor = removeElements(
					reconModel.getAdjEntryFloor().split(","), length - 1)[0];
			sMapPosThr = removeElements(reconModel.getPosCrctnThr().split(","),
					length - 1)[0];
			sMapNegThr = removeElements(reconModel.getNegCrctnThr().split(","),
					length - 1)[0];
		}

		if (pageMode.equals("CREATE")) {
			GL35Logger.logThis("Create Mode...", Priority.DEBUG_INT);
			/* Get Map Id */
			Cargo cargo1;
			DACRecordSet resultSet;
			String sqlQuery = "";

			sqlQuery = "SELECT SEQ_GLMAPMASTER_MAPID.NEXTVAL FROM DUAL";

			cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
			resultSet = (DACRecordSet) cargo1.getPayLoadObject();
			String colVal = "";

			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				sMapId = resultSet.fetchElement(1).trim();
				resultSet.moveNext();
			}

			iVersionNum = 1;

			// java.text.SimpleDateFormat sd = new
			// java.text.SimpleDateFormat("dd-MMM-yy");
			// sCreatedDate = sd.format(new Date());
			sCreatedDate = reconModel.getCreatedDate();

		}

		if (pageMode.equals("EDIT")) {

			GL35Logger.logThis("Edit Mode...", Priority.DEBUG_INT);
			sMapId = reconModel.getMapId().trim();
			iVersionNum = this.getVersionNum("FSI_GL_MAPPING_MASTER", sMapId,
					infoDom);
			sModUser = ""; // Hard Coded as this value does not come from UI

			// java.text.SimpleDateFormat sd = new
			// java.text.SimpleDateFormat("dd-MMM-yy");
			// sCreatedDate = sd.format(new Date());

			sCreatedDate = reconModel.getCreatedDate();

		}
		// GL_MAPPING_MASTER Data
		if (sMapType.equals("P")) {
			sBookCode = " ";
			reconModel.setHierarchyCode(" ");
		}
		try {

			if (sGlThrshldCurr == null) {
				sGlThrshldCurr = "";
			}
		} catch (NullPointerException e) {

		}

		if (sMapThrshldType.equals("-1")) {
			sMapThrshldType = "";
		}
		GL35Logger.logThis("Building query for FSI_GL_MAPPING_MASTER...",
				Priority.DEBUG_INT);
		sqlQuery1
				.append("INSERT INTO FSI_GL_MAPPING_MASTER (V_GL_MAP_ID,N_VERSION_NUMBER,V_GL_MAP_NAME,V_GL_MAPPING_DESC,V_RECON_TYPE,V_ENTITY_CODE,V_CONSOLIDATION_TYPE,V_BALANCE_TYPE,V_GL_BOOK,V_GL_TYPE,F_ADJUST_ALLOCATION_REQ,V_RECON_DEFINITION_LEVEL,V_THRESHOLD_CCY_CODE,F_ADJUST_ALLOCATION_METHOD,V_ADJUST_ENTRY_POSTED,V_MAP_THRESHOLD_TYPE,N_MAP_ADJUSTMENT_FLOOR,N_MAP_POSITIVE_THRESHOLD,N_MAP_NEGATIVE_THRESHOLD,V_CREATED_USER,D_VERSION_CREATED_DATE,F_IS_DELETED,V_GL_HCY_CODE) ");
		sqlQuery1.append("values (" + sMapId + "," + iVersionNum + ",'"
				+ sGlMapName + "','" + sGLMapDesc + "','" + sMapType + "','"
				+ sEntityCode + "','" + sConsolType + "','" + sBalType + "','"
				+ sBookCode + "','" + sGlType + "','" + sAdjAllocReq + "','"
				+ sReconDef + "','" + sGlThrshldCurr + "','" + sAdjAllocMthd
				+ "','" + sAdjEntryPost + "','" + sMapThrshldType + "','"
				+ sMapAdjFloor + "','" + sMapPosThr + "','" + sMapNegThr
				+ "','" + sCreatedUser + "',TO_DATE('" + sCreatedDate
				+ "','MM-DD-YY'),'N','" + reconModel.getHierarchyCode() + "')");

		alQueryList.add(sqlQuery1);

		// FSI_GL_MAPPING_GL_CODES Data

		/*
		 * If Passive Recon no need to insert GL Codes & Gl Filter Data.
		 */
		if (!sMapType.equals("P")) {

			GL35Logger.logThis("Building query for FSI_GL_MAPPING_GL_CODES...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery2 = new StringBuffer();

			String[] sArr = reconModel.getGlHierCode().split(",");

			if(sArr.length > 0) {
				for(int i = 0;i<sArr.length;i++) {
					sqlQuery2
							.append("INSERT INTO FSI_GL_MAPPING_GL_CODES (V_GL_MAP_ID,N_VERSION_NUMBER,V_GL_CODE,V_GL_BOOK) ");
					sqlQuery2.append("values (" + sMapId + "," + iVersionNum
							+ ",'" + sArr[i] + "','" + sBookCode + "'" + ")");
					alQueryList.add(sqlQuery2);
					sqlQuery2 = new StringBuffer();
				}
			}
 else {
				sqlQuery2
						.append("INSERT INTO FSI_GL_MAPPING_GL_CODES (V_GL_MAP_ID,N_VERSION_NUMBER,V_GL_CODE,V_GL_BOOK) ");
				sqlQuery2.append("values (" + sMapId + "," + iVersionNum + ",'"
						+ reconModel.getGlHierCode() + "','" + sBookCode + "'"
						+ ")");
				alQueryList.add(sqlQuery2);
			}
			// FSI_GL_BOOK_FILTERS
			/*
			 * 
			 * 
			 * TEST_6#^#[TEST_6].[MAP5189]~~
			 * 
			 * #@# ->1
			 * 
			 * GLH0006~@~-->3 [GLH0006].[MAP5188] ~~ -->2
			 * GLH0006~@~[GLH0006].[MAP5194]~~
			 * 
			 * #@#
			 */

			String sGlFiltHrCode = reconModel.getGlFilterHierCode();
			List<String> glFltr = new ArrayList<String>();
			try {
				String[] sArr1 = sGlFiltHrCode.split("#@#");
				for (int i = 0; i < sArr1.length; i++) {
					String[] sArr2 = sArr1[i].split("~~");
					for (int j = 0; j < sArr2.length; j++) {
						String[] sArr3 = sArr2[j].split("~@~");
						for (int k = 0; k < sArr3.length; k++) {
							glFltr.add(sArr3[k]);
						}
					}
				}
			} catch (ArrayIndexOutOfBoundsException ai) {
				GL35Logger.logThis(ai.getMessage(), Priority.ERROR_INT);
			}
			// iVersionNum = this.getVersionNum("FSI_GL_BOOK_FILTERS", infoDom);

			GL35Logger.logThis("Building query for FSI_GL_SOURCE_FILTERS...",
					Priority.DEBUG_INT);
			for (int i = 0; i < glFltr.toArray().length; i++) {
				if (!(glFltr.get(i).equals(""))) {
					StringBuffer sqlQuery2a = new StringBuffer();
					sqlQuery2a
							.append("INSERT INTO FSI_GL_SOURCE_FILTERS (V_GL_MAP_ID,N_VERSION_NUMBER,V_HCY_CODE,V_LEAF_CONDITION,V_HCY_NODE) ");

					sqlQuery2a.append("values ("
							+ sMapId
							+ ","
							+ iVersionNum
							+ ",'"
							+ glFltr.get(i)
							+ "','"
							+ GlobalUtil.getHierIdentifiers(infoDom,
									sCreatedUser, glFltr.get(i),
									glFltr.get(++i)) + "','" + glFltr.get(i)
							+ "')");
					alQueryList.add(sqlQuery2a);
				}
			}
		}
		// FSI_GL_MAP_PP Data
		StringBuffer sqlQuery3 = new StringBuffer();

		if (!(reconModel.getSelTpTab().equals(""))
				&& !(reconModel.getSelTpTab() == null)
				&& !(reconModel.getSelTpTab().equals("-1"))) {

			// Input is of Type [<dummyVal>,Value,Value...] Eg: [,2,3]
			String[] txnEntArr = removeElements(
					reconModel.getSelTpTab().split(","), 1);
			String[] balAmtArr = removeElements(reconModel.getSelAmtCol()
					.split(","), 0);

			String[] ppPosThrshld = new String[txnEntArr.length];
			String[] ppNegThrshld = new String[txnEntArr.length];
			String[] ppAdjFloorArr = new String[txnEntArr.length];
			String[] ppThrsTypArr = new String[txnEntArr.length];
			String[] glCodeColArr = new String[txnEntArr.length];

			// Table Values only for GL Level RECON. Input is of Type
			// [<dummyVal>,Value,Value...,<MapLevelVal>] Eg: [,,2]
			if (!(sReconDef.equals("M"))) {
				glCodeColArr = removeElements(reconModel.getSelGlColForTp()
						.split(","), 0);
				ppPosThrshld = removeElements(reconModel.getPosCrctnThr()
						.split(","), 1);
				ppNegThrshld = removeElements(reconModel.getNegCrctnThr()
						.split(","), 1);
				ppAdjFloorArr = removeElements(reconModel.getAdjEntryFloor()
						.split(","), 1);
				ppThrsTypArr = removeElements(
						reconModel.getSelTrsSpc().split(","), 1);
			} else if (!(sReconDef.equals("G"))) { // MAP LEVEL RECON - Values
													// from the form - Stored in
													// FSI_GL_MAPPING_MASTER
													// table
				for (int i = 0; i < ppPosThrshld.length; i++) {
					glCodeColArr[i] = "";
					ppPosThrshld[i] = "";
					ppNegThrshld[i] = "";
					ppAdjFloorArr[i] = "";
					ppThrsTypArr[i] = "";
				}
			}
			// iVersionNum = this.getVersionNum("FSI_GL_MAP_RECON_TARGETS",
			// infoDom);
			// Insert values for each row in the table

			GL35Logger.logThis(
					"Building query for FSI_GL_MAP_RECON_TARGETS...",
					Priority.DEBUG_INT);
			for (int i = 0; i < txnEntArr.length; i++) {
				sqlQuery3
						.append("INSERT INTO FSI_GL_MAP_RECON_TARGETS (V_GL_MAP_ID,N_VERSION_NUMBER,V_TABLE_NAME,V_LOGIC_TABLE_NAME,V_GL_CODE_COL_NAME,V_GL_CODE_LOGIC_COL_NAME,V_BALANCE_COL_NAME,V_BALANCE_LOGIC_COL_NAME,V_THRESHOLD_TYPE,N_ADJUSTMENT_FLOOR,N_POSITIVE_THRESHOLD,N_NEGATIVE_THRESHOLD) ");
				sqlQuery3.append(" values ("
						+ sMapId
						+ ","
						+ iVersionNum
						+ ",'"
						+ txnEntArr[i]
						+ "','"
						+ ppMap.get(txnEntArr[i])
						+ "','"
						+ glCodeColArr[i]
						+ "','"
						+ getLogicalName(txnEntArr[i], "V_GL_CODE_COLUMN_NAME",
								glCodeColArr[i], infoDom)
						+ "','"
						+ balAmtArr[i]
						+ "','"
						+ getLogicalName(txnEntArr[i].toString(),
								"V_BAL_AMOUNT_COLUMN_NAME", balAmtArr[i],
								infoDom) + "','");

				sqlQuery3.append(ppThrsTypArr[i] + "','" + ppAdjFloorArr[i]
						+ "','" + ppPosThrshld[i] + "','" + ppNegThrshld[i]
						+ "')");

				alQueryList.add(sqlQuery3);
				sqlQuery3 = new StringBuffer("");
			}
		}
 else {
			GL35Logger.logThis("EXITING ReconUtil.java. No PP's available...",
					Priority.ERROR_INT);
			throw new NullPointerException();

		}

		// FSI_TARGET_FILTERS
		/*
		 * 
		 * 
		 * TEST_6#^#[TEST_6].[MAP5189]~~
		 * 
		 * #@# ->1
		 * 
		 * GLH0006~@~-->3 [GLH0006].[MAP5188] ~~ -->2
		 * GLH0006~@~[GLH0006].[MAP5194]~~
		 * 
		 * #@#
		 */

		JSONReader reader = new JSONReader(); // Input comes as a JSON String
												// !!!
		String sCode = reconModel.getTpFilterHierCode();

		HashMap<String, String> result = (HashMap<String, String>) reader
				.read(sCode);
		String sTpFiltHrCode = "";
		for (Map.Entry<String, String> entry : result.entrySet()) {

			sTpFiltHrCode = entry.getValue().toString();

			List<String> tpFltr = new ArrayList<String>();
			try {
				String[] sArr11 = sTpFiltHrCode.split("#@#");
				for (int i = 0; i < sArr11.length; i++) {
					String[] sArr21 = sArr11[i].split("~~");
					for (int j = 0; j < sArr21.length; j++) {
						String[] sArr3 = sArr21[j].split("~@~");
						for (int k = 0; k < sArr3.length; k++) {
							tpFltr.add(sArr3[k]);
						}
					}
				}
			} catch (ArrayIndexOutOfBoundsException ai) {
				GL35Logger.logThis(ai.getMessage(), Priority.ERROR_INT);
			}

			// iVersionNum = this.getVersionNum("FSI_TARGET_FILTERS", infoDom);

			GL35Logger.logThis("Building query for FSI_TARGET_FILTERS...",
					Priority.DEBUG_INT);
			for (int i = 0; i < tpFltr.toArray().length; i++) {
				if (!(tpFltr.get(i).equals(""))) {
					StringBuffer sqlQuery3a = new StringBuffer();
					sqlQuery3a
							.append("INSERT INTO FSI_TARGET_FILTERS (V_GL_MAP_ID,N_VERSION_NUMBER,V_HCY_CODE,V_LEAF_CONDITION,V_HCY_NODE,V_TABLE_NAME,V_BALANCE_COL_NAME) ");

					sqlQuery3a.append("values ("
							+ sMapId
							+ ","
							+ iVersionNum
							+ ",'"
							+ tpFltr.get(i)
							+ "','"
							+ GlobalUtil.getHierIdentifiers(infoDom,
									sCreatedUser, tpFltr.get(i),
									tpFltr.get(++i)) + "','" + tpFltr.get(i)
							+ "','" + entry.getKey().split("!~!")[0] + "','"
							+ entry.getKey().split("!~!")[1] + "')");
					alQueryList.add(sqlQuery3a);
				}
			}
		}
		// FSI_GL_MAPPING_DIMENSIONS Data

		/*
		 * If Passive Recon no need to insert dimensions Data.
		 */

		if (!sMapType.equals("P")) {

			GL35Logger.logThis(
					"Building query for FSI_GL_MAPPING_DIMENSIONS...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery4 = new StringBuffer();

			GL35Logger.logThis("Fetching Mandatory Dimensions...",
					Priority.DEBUG_INT);
			StringBuffer sqlQry1 = new StringBuffer(
					"SELECT A.V_DIMENSION_HCY_CODE,A.V_DIMENSION_DESC ");
			sqlQry1.append(" FROM SETUP_GL_RECON_DIMENSIONS A");
			sqlQry1.append(" WHERE A.F_RECON_OR_MANDATORY='M'");

			DACRecordSet resultSet1;
			ArrayList<String> dimList = new ArrayList<String>();
			Cargo cargo1;

			cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQry1.toString(), false);
			resultSet1 = (DACRecordSet) cargo1.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				dimList.add(resultSet1.fetchElement(1));
				resultSet1.moveNext();
			}
			if (dimList.size() > 0) {
				for (String s : dimList) {
					sqlQuery4
							.append("INSERT INTO FSI_GL_MAPPING_DIMENSIONS (V_GL_MAP_ID,N_VERSION_NUMBER,V_DIMENSION_HCY_CODE) ");
					sqlQuery4.append("values (" + sMapId + "," + iVersionNum
							+ ",'" + s + "')");
					alQueryList.add(sqlQuery4);
					sqlQuery4 = new StringBuffer("");
				}
			}
			// Input is of Type [,Val1,Val2...] Eg: [,GLH001,GLH003...]
			String[] reconDimCodeArr = reconModel.getReconDimCode().split(",");
			// iVersionNum = this.getVersionNum("FSI_GL_MAPPING_DIMENSIONS",
			// infoDom);
			if ((reconDimCodeArr.length > 0)) {
				for (int i = 0; i < reconDimCodeArr.length; i++) {
					if (!reconDimCodeArr[i].equals("")
							|| reconDimCodeArr == null) {
						sqlQuery4
								.append("INSERT INTO FSI_GL_MAPPING_DIMENSIONS (V_GL_MAP_ID,N_VERSION_NUMBER,V_DIMENSION_HCY_CODE) ");
						sqlQuery4.append("values (" + sMapId + ","
								+ iVersionNum + ",'" + reconDimCodeArr[i]
								+ "')");
						alQueryList.add(sqlQuery4);
						sqlQuery4 = new StringBuffer("");
					}
				}
			} else {
				sqlQuery4
						.append("INSERT INTO FSI_GL_MAPPING_DIMENSIONS (V_GL_MAP_ID,N_VERSION_NUMBER,V_DIMENSION_HCY_CODE) ");
				sqlQuery4.append("values ("
						+ sMapId
						+ ","
						+ this.getVersionNum("FSI_GL_MAPPING_DIMENSIONS",
								sMapId, infoDom) + ",'"
						+ reconModel.getReconDimCode() + ")");
			}
		}
		// FSI_GL_MAPPING_ALLOC_DTLS Data
		if (!sAdjAllocReq.equals("N") && reconModel.getPpTableAlloc() != null) {
			StringBuffer sqlQuery5 = new StringBuffer();

			String[] txnAllocEntArr = reconModel.getPpTableAlloc().split(",");
			if (txnAllocEntArr.length == 0)
				txnAllocEntArr[0] = reconModel.getPpTableAlloc();

			String[] balAmtAllocArr = new String[txnAllocEntArr.length];
			if (!(null == reconModel.getBalAmtAlloc())) {
				balAmtAllocArr = reconModel.getBalAmtAlloc().split(",");
				if (balAmtAllocArr.length == 0)
					balAmtAllocArr[0] = reconModel.getBalAmtAlloc();
			} else {
				for (int i = 0; i < balAmtAllocArr.length; i++) {
					balAmtAllocArr[i] = "";
				}
			}
			String[] glColArr = removeElements(
					reconModel.getGlCol().split(","), 1);

			String[] targetAdjArr = new String[txnAllocEntArr.length];
			if (!((reconModel.getTargetOrAdjusted()) == null)) {
				targetAdjArr = reconModel.getTargetOrAdjusted().split(",");
				if (targetAdjArr.length == 0)
					targetAdjArr[0] = reconModel.getTargetOrAdjusted();
			} else {
				for (int i = 0; i < txnAllocEntArr.length; i++)
					targetAdjArr[i] = "";
			}
			// Handle null inputs
			String[] allocRatioArr = new String[txnAllocEntArr.length];
			if (!((reconModel.getAllocationRatio()) == null))
				allocRatioArr = removeElements(reconModel.getAllocationRatio()
						.split(","), 1);
			else
				for (int i = 0; i < txnAllocEntArr.length; i++)
					allocRatioArr[i] = "0";

			// Handle null inputs
			String[] glAmtColArr = new String[txnAllocEntArr.length];
			if (!((reconModel.getGlAmtCol()) == null))
				glAmtColArr = removeElements(reconModel.getGlAmtCol()
						.split(","), 0);
			else
				for (int i = 0; i < txnAllocEntArr.length; i++)
					glAmtColArr[i] = "";

			// iVersionNum = this.getVersionNum("FSI_GL_MAPPING_PP_ALLOC_DTLS",
			// infoDom);

			if ((txnAllocEntArr.length > 0)) {

				GL35Logger.logThis(
						"Building query for FSI_GL_MAPPING_PP_ALLOC_DTLS...",
						Priority.DEBUG_INT);
				for (int i = 0; i < txnAllocEntArr.length; i++) {
					String sColName = "";
					if (ppMap.get(targetAdjArr[i].trim()) != null) {
						sColName = ppMap.get(targetAdjArr[i].trim()).toString();
					}
					sqlQuery5
							.append("INSERT INTO FSI_GL_MAPPING_PP_ALLOC_DTLS (V_GL_MAP_ID,N_VERSION_NUMBER,V_TABLE_NAME,V_BALANCE_COL_NAME,V_TARGET_TABLE_NAME,V_TARGET_TABLE_LOGIC_NAME,V_GL_AMOUNT_COL_NAME,V_GL_AMOUNT_LOGIC_COL_NAME,V_GL_CODE_COL_NAME,N_ALLOCATION_RATIO) ");
					sqlQuery5.append("values ("
							+ sMapId
							+ ","
							+ iVersionNum
							+ ",'"
							+ txnAllocEntArr[i].trim()
							+ "','"
							+ balAmtAllocArr[i].trim()
							+ "','"
							+ targetAdjArr[i].trim()
							+ "','"
							+ sColName
							+ "','"
							+ glAmtColArr[i].trim()
							+ "','"
							+ getLogicalName(targetAdjArr[i].toString().trim(),
									"V_BAL_AMOUNT_COLUMN_NAME",
									glAmtColArr[i].trim(), infoDom) + "','");

					if (sReconDef.equals("MP")) { // Map Level => No GL Column
						sqlQuery5.append("");
					} else {
						sqlQuery5.append(glColArr[i].trim());
					}

					sqlQuery5.append("'," + allocRatioArr[i] + ")");

					alQueryList.add(sqlQuery5);
					sqlQuery5 = new StringBuffer("");
				}
			} else { // Ideally code should never reach here !!!!
				sqlQuery5.append("values ("
						+ sMapId
						+ ","
						+ this.getVersionNum("FSI_GL_MAPPING_PP_ALLOC_DTLS",
								sMapId, infoDom)
						+ ",'"
						+ ppMap.get(reconModel.getPpTableAlloc())
						+ "','"
						+ reconModel.getPpTableAlloc()
						+ "','"
						+ getLogicalName(ppMap.get(reconModel.getBalAmtAlloc())
								.toString(), "V_BAL_AMOUNT_COLUMN_NAME",
								reconModel.getBalAmtAlloc(), infoDom) + "','"
						+ reconModel.getBalAmtAlloc() + "',"
						+ reconModel.getAllocationRatio() + ",'"
						+ reconModel.getTargetOrAdjusted() + "','"
						+ reconModel.getGlCol() + "','"
						+ reconModel.getGlAmtCol() + "')");
			}

			// Default Values
			/*
			 * Input in format
			 * DefValType~@~PhysicalColName~@~ColValue~@~ColDataType~
			 * 
			 * @~ExpressionType ~!!~
			 * DefValType~@~PhysicalColName~@~ColValue~@~ColDataType
			 * ~@~ExpressionType
			 */

			String[] defVl = removeElements(reconModel.getDefaultValues()
					.split(","), 1);

			GL35Logger.logThis("Building query for FSI_PP_DEFAULT_VALUES...",
					Priority.DEBUG_INT);
			if (defVl.length > 0 && !defVl[0].equals("")) {
				for (int j = 0; j < defVl.length; j++) {
					String[] s1 = defVl[j].split("~!!~");
					for (int i = 0; i < s1.length; i++) {
						StringBuffer sqlQuery6 = new StringBuffer("");
						sqlQuery6
								.append("INSERT INTO FSI_PP_DEFAULT_VALUES (V_GL_MAP_ID,N_VERSION_NUMBER,V_TABLE_NAME,V_BALANCE_COL_NAME,V_DEFAULT_VALUE_TYPE,V_DEFAULT_COL_NAME,V_DEFAULT_COL_VALUE,V_DEFAULT_COL_DATA_TYPE,V_EXPRESSION_TYPE,V_TARGET_TABLE_NAME,V_GL_AMOUNT_COL_NAME) ");
						sqlQuery6.append("VALUES (" + sMapId + ","
								+ iVersionNum + ",'" + txnAllocEntArr[j].trim()
								+ "','" + balAmtAllocArr[j].trim() + "','"
								+ s1[i].split("~@~")[0] + "','"
								+ s1[i].split("~@~")[1] + "','");

						if (s1[i].split("~@~")[2].equals("^")
								|| s1[i].split("~@~")[2].equals("null"))
							sqlQuery6.append("");
						else
							sqlQuery6.append(s1[i].split("~@~")[2]);

						sqlQuery6.append("','" + s1[i].split("~@~")[3] + "','");

						if (s1[i].split("~@~")[4].equals("^")
								|| s1[i].split("~@~")[4].equals("null"))
							sqlQuery6.append("");
						else
							sqlQuery6.append(s1[i].split("~@~")[4]);

						sqlQuery6.append("','" + targetAdjArr[j].trim() + "','"
								+ glAmtColArr[j].trim());

						sqlQuery6.append("')");

						alQueryList.add(sqlQuery6);
					}
				}
			}
		} else {
			GL35Logger.logThis("Allocation Not Required..Proceeding to Save..",
					Priority.DEBUG_INT);
		}
		// return alQueryList;
		String[] arrQuery = new String[alQueryList.toArray().length];
		for (int i = 0; i < arrQuery.length; i++) {
			arrQuery[i] = alQueryList.get(i).toString();
		}

		Cargo cargo1;
		DACRecordSet resultSet;

		GL35Logger
				.logThis("Begin Query Run[Batch Mode]...", Priority.DEBUG_INT);
		// cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
		cargo1 = (Cargo) SMSServices.executeBatch(infoDom, arrQuery, true);

		if (!cargo1.getErrorFlag()) {
			if (sMapType.equals("P")) {
				String dimststus ="0";
				GL35Logger.logThis("Beginstart passive dimension insertion..", Priority.DEBUG_INT);
			String dimQry = "SELECT GET_PASSIVE_RECON_DIMENSIONS('"+ sMapId +"',"+iVersionNum+" )   FROM DUAL ";
			cargo1 = (Cargo) SMSServices.executeQuery(infoDom, dimQry, true);
				if (!cargo1.getErrorFlag()) {
					resultSet = (DACRecordSet)cargo1.getPayLoadObject();
				      while (!resultSet.EOF())
						{
				    	  dimststus = resultSet.fetchElement(1);
				    	  GL35Logger.logThis("Beginstart passive dimension dimststus.."+dimststus, Priority.DEBUG_INT);
				    	  resultSet.moveNext();
						}
				}
			      if( cargo1.getErrorFlag() || !dimststus.equalsIgnoreCase("1") )
					{
			    	  delQueryList.add("DELETE FROM FSI_GL_MAPPING_MASTER WHERE V_GL_MAP_ID = '"+sMapId+"' AND N_VERSION_NUMBER ="+iVersionNum);
			    	  delQueryList.add("DELETE FROM FSI_GL_MAP_RECON_TARGETS WHERE V_GL_MAP_ID = '"+sMapId+"' AND N_VERSION_NUMBER ="+iVersionNum);
			    	  delQueryList.add("DELETE FROM FSI_TARGET_FILTERS WHERE V_GL_MAP_ID = '"+sMapId+"' AND N_VERSION_NUMBER ="+iVersionNum);
			    	  delQueryList.add("DELETE FROM FSI_GL_MAPPING_PP_ALLOC_DTLS WHERE V_GL_MAP_ID = '"+sMapId+"' AND N_VERSION_NUMBER ="+iVersionNum);
			    	  delQueryList.add("DELETE FROM FSI_PP_DEFAULT_VALUES WHERE V_GL_MAP_ID = '"+sMapId+"' AND N_VERSION_NUMBER ="+iVersionNum);
			    	  cargo1 = (Cargo) SMSServices.executeBatch(infoDom, arrQuery, true);
						return "error";						
					}
			}
			GL35Logger.logThis(cargo1.getPayLoadObject().toString(),
					Priority.DEBUG_INT);
			try {
				String retVal = hierResave(infoDom);
				if (retVal != "Success") {
					GL35Logger.logThis("Hierarchy Resave Failure",
							Priority.ERROR_INT);
					return "error";
				}
			} catch (Exception e) {
				GL35Logger.logThis("Hierarchy Resave Failure",
						Priority.ERROR_INT);
				return "error";
			}
			return "success";
		} else {
			GL35Logger.logThis(cargo1.getPayLoadObject().toString(),
					Priority.ERROR_INT);
			return "error";
		}
	}

	@SuppressWarnings("unused")
	private String[] getBookName(String ppPhyTableName, String glPhyColName,
			String infoDom) {
		// TODO Auto-generated method stub

		GL35Logger.logThis("Entering getBookName...", Priority.DEBUG_INT);
		Cargo cargo1;
		DACRecordSet resultSet;
		String[] ppLHM = new String[2];

		String sqlQuery = "SELECT V_GL_BOOK_COL_NAME,V_GL_BOOK_LOGIC_COL_NAME FROM SETUP_PP_GL_BOOK WHERE V_TABLE_NAME = '"
				+ ppPhyTableName
				+ "' AND V_GL_CODE_COL_NAME = '"
				+ glPhyColName + "'";
		cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
		resultSet = (DACRecordSet) cargo1.getPayLoadObject();

		while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
			ppLHM[0] = resultSet.fetchElement(1);
			ppLHM[1] = resultSet.fetchElement(2);
			resultSet.moveNext();
		}
		return ppLHM;
	}

	public String[] removeElements(String[] inputArr, int n) {

		/*
		 * This element removes the first 'n' elements of the input Array and
		 * trims the resulting elements of the new Array.
		 */
		GL35Logger.logThis("Entering removeElements...", Priority.DEBUG_INT);
		String[] destArr = new String[inputArr.length - n];
		System.arraycopy(inputArr, n, destArr, 0, inputArr.length - n);
		for (int i = 0; i < destArr.length; i++) {
			destArr[i] = destArr[i].trim();
		}
		return destArr;
	}

	public int getVersionNum(String sTableName, String sMapId, String infoDom) {
		// TODO Auto-generated method stub

		GL35Logger.logThis("Entering getVersionNum...", Priority.DEBUG_INT);
		Cargo VersionCargo;
		DACRecordSet resultSet;

		/* TBD FILTER BASED ON MAP ID TO BE IMPLEMENTED !!!!! */

		String sqlQuery = "SELECT MAX(N_VERSION_NUMBER) FROM " + sTableName
				+ " WHERE V_GL_MAP_ID = '" + sMapId + "'";
		VersionCargo = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery,
				false);
		resultSet = (DACRecordSet) VersionCargo.getPayLoadObject();

		String max_version = "0";
		int auto_count = 1;
		while (!resultSet.EOF()) {
			max_version = resultSet.fetchElement(1);
			resultSet.moveNext();
		}
		if (max_version == null)
			max_version = "0";
		if (max_version.equals("0.1"))
			max_version = "0";
		int max_version1 = Integer.parseInt(max_version);
		return ++max_version1;
	}

	public static Map getPPMap(String infoDom) {

		GL35Logger.logThis("Entering getPPMap...", Priority.DEBUG_INT);
		Cargo cargo1;
		DACRecordSet resultSet;
		Map ppLHM = new LinkedHashMap();

		String sqlQuery = "SELECT V_TABLE_NAME,V_LOGIC_TABLE_NAME FROM SETUP_PRODUCT_PROCESSORS";
		cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
		resultSet = (DACRecordSet) cargo1.getPayLoadObject();

		while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
			ppLHM.put(resultSet.fetchElement(1), resultSet.fetchElement(2));
			resultSet.moveNext();
		}
		ppLHM.put("", "");
		return ppLHM;
	}

	public String getLogicalName(String ppPhyTableName, String phyColName,
			String phyColVal, String infoDom) {

		GL35Logger.logThis("Entering getLogicalName...", Priority.DEBUG_INT);
		Cargo cargo1;
		DACRecordSet resultSet;
		String sqlQuery = "";
		if (phyColVal == null || phyColVal.equals(""))
			return "";

		if (phyColName.equals("V_GL_CODE_COLUMN_NAME")) {
			sqlQuery = "SELECT V_GL_CODE_LOGIC_COL_NAME FROM SETUP_PP_GL_CODE WHERE V_TABLE_NAME = '"
					+ ppPhyTableName
					+ "' AND V_GL_CODE_COL_NAME = '"
					+ phyColVal + "'";
		} else if (phyColName.equals("V_BAL_AMOUNT_COLUMN_NAME")) {
			sqlQuery = "SELECT V_BALANCE_LOGIC_COL_NAME FROM SETUP_PP_BALANCE_COLUMNS WHERE V_TABLE_NAME = '"
					+ ppPhyTableName
					+ "' AND V_BALANCE_COL_NAME = '"
					+ phyColVal + "'";
		}

		cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
		resultSet = (DACRecordSet) cargo1.getPayLoadObject();
		String colVal = "";

		while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
			colVal = resultSet.fetchElement(1);
			resultSet.moveNext();
		}
		return colVal;
	}

	public Map getGlCol(String ppTableName, String infoDom) {
		// TODO Auto-generated method stub

		Cargo cargo1;
		DACRecordSet resultSet;
		String sqlQuery = "";
		Map ppLHM = new LinkedHashMap();

		GL35Logger
				.logThis("Querying for GL Column Name...", Priority.DEBUG_INT);
		sqlQuery = "SELECT V_GL_CODE_COL_NAME,V_GL_CODE_LOGIC_COL_NAME FROM SETUP_PP_GL_CODE WHERE V_TABLE_NAME = '"
				+ ppTableName + "'";

		cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
		resultSet = (DACRecordSet) cargo1.getPayLoadObject();
		String colVal = "";

		while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
			ppLHM.put(resultSet.fetchElement(1), resultSet.fetchElement(2));
			resultSet.moveNext();
		}

		return ppLHM;
	}

	public Map getAmtCol(String ppTableName, String infoDom) {
		// TODO Auto-generated method stub
		Cargo cargo1;
		DACRecordSet resultSet;
		String sqlQuery = "";
		Map ppLHM = new LinkedHashMap();

		GL35Logger.logThis("Querying for Amount Column Name...",
				Priority.DEBUG_INT);
		sqlQuery = "SELECT V_BALANCE_COL_NAME,V_BALANCE_LOGIC_COL_NAME FROM SETUP_PP_BALANCE_COLUMNS WHERE V_TABLE_NAME = '"
				+ ppTableName + "'";

		cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
		resultSet = (DACRecordSet) cargo1.getPayLoadObject();

		while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
			ppLHM.put(resultSet.fetchElement(1), resultSet.fetchElement(2));
			resultSet.moveNext();
		}

		return ppLHM;

	}

	public String hierResave(String infoDom) {
		/* Hier Resave */
		GL35Logger.logThis("Entering hierResave...", Priority.DEBUG_INT);
		String hierCode = GlobalUtil.getParamValue("RECON_MAP_HIERCODE",
				infoDom);
		String langCode = ActiveReconAction.getSession().get("lclPostFix")
				.toString();
		Cargo crForHierarcy = BusinessMetaData.getMetaDataObjectFromServer(
				infoDom, hierCode, GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,
				GlobalParameters.AUTHORIZED_VERSION, new Locale(langCode));

		GL35Logger.logThis("XQX GlobalParameters.AUTHORIZED_VERSION="
				+ GlobalParameters.AUTHORIZED_VERSION);

		ClsUEntHierarchy argHierObj = (ClsUEntHierarchy) crForHierarcy
				.getPayLoadObject();
		argHierObj.setAutoAuthorization(true);
		GL35Logger.logThis("argHierObj--->" + argHierObj.getCode());

		String retVal = BusinessMetaData.maintainMetaDataObject(infoDom,
				GlobalParameters.OPERATION_UPDATE,
				GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,
				GlobalParameters.AUTHORIZED_VERSION, argHierObj, new Locale(
						langCode));

		GL35Logger.logThis("resave........-->" + retVal);
		String rtn = "";
		if (retVal == null) {
			rtn = "Error";
		} else {
			rtn = "Success";
		}
		return rtn;
	}

	/*
	 * This method takes the selected PP fetches the common hierarchies mapped
	 * to the tables , and compares with the selected Dimension Hierarchies to
	 * check if it is a valid selection or not.
	 */
	public List<String> getValidHier(String tblSet, String glDataSet,
			String[] dimArr, String sInfodom, Locale slocale) {

		GL35Logger.logThis("Entering getValidHier...", Priority.DEBUG_INT);

		ClsUEntBIDataSet objDataset = new ClsUEntBIDataSet();
		Cargo cr;
		List<String> commTab = new ArrayList<String>();
		List<String> dimHierList = new ArrayList<String>();
		List<String> invHierArr = new ArrayList<String>();

		dimHierList = getCommonHier(tblSet, glDataSet, sInfodom);

		// Validation Code.

		dimArr = removeElements(dimArr, 1);
		for (String s : dimArr) {
			if (!dimHierList.contains(s)) {
				if (!invHierArr.contains(s))
					invHierArr.add(s);
			}
		}

		return invHierArr;
	}

	public List<String> getCommonHier(String tblSet, String glDataSet,
			String sInfodom) {

		GL35Logger.logThis("Entering getCommonHier...", Priority.DEBUG_INT);

		List<String> dimHierList = new ArrayList<String>();
		StringBuffer sqlQuery = new StringBuffer();
		Cargo cargo1;
		DACRecordSet resultSet;

		String[] tblSetArr = tblSet.split(",");

		sqlQuery.append("SELECT DISTINCT SRDCM.V_DIMENSION_HCY_CODE FROM SETUP_RECON_DIM_COL_MAP SRDCM"
				+ " INNER JOIN SETUP_GL_RECON_DIMENSIONS SGRD "
				+ " ON SGRD.V_DIMENSION_HCY_CODE = SRDCM.V_DIMENSION_HCY_CODE "
				+ " INNER JOIN SETUP_GL_SOURCE SGB "
				+ " ON SGB.V_TABLE_NAME = SRDCM.V_PP_GL_TABLE_NAME "
				+ " WHERE SRDCM.V_PP_OR_GL = 'GL' "
				+ " AND SGRD.F_RECON_OR_MANDATORY = 'R' "
				+ " AND SGB.V_DATASET_CODE = '" + glDataSet + "' ");

		for (String tblName : tblSetArr) {
			if ((null != tblName) && !(tblName.equals(""))) {
				sqlQuery.append(" INTERSECT ");
				sqlQuery.append("SELECT  DISTINCT SRDCM.V_DIMENSION_HCY_CODE FROM SETUP_RECON_DIM_COL_MAP SRDCM "
						+ " INNER JOIN SETUP_GL_RECON_DIMENSIONS SGRD "
						+ " ON SGRD.V_DIMENSION_HCY_CODE = SRDCM.V_DIMENSION_HCY_CODE "
						+ " WHERE SRDCM.V_PP_GL_TABLE_NAME = '"
						+ tblName
						+ "' "
						+ " AND SRDCM.V_PP_OR_GL = 'PP' "
						+ " AND SGRD.F_RECON_OR_MANDATORY = 'R'");
			} else {
				sqlQuery = new StringBuffer("");
			}
		}
		if (!sqlQuery.toString().equals("")) {
			cargo1 = (Cargo) SMSServices.executeQuery(sInfodom,
					sqlQuery.toString(), false);
			resultSet = (DACRecordSet) cargo1.getPayLoadObject();

			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				dimHierList.add(resultSet.fetchElement(1).toString());
				resultSet.moveNext();
			}
		}
		return dimHierList;
	}

	public String getFormData(ReconModel reconModel, String infoDom,
			ActiveReconAction actRecon) {
		// TODO Auto-generated method stub
		GL35Logger.logThis("Entering getFormData...", Priority.DEBUG_INT);
		Cargo cargo1;
		DACRecordSet resultSet;
		try {
			// Get GL_MAPPING_MASTER values
			String sMapId = reconModel.getMapId().trim();
			int iVerNum = 1;
			if (reconModel.getVersionNum() != null) {
				iVerNum = Integer.parseInt(reconModel.getVersionNum());
			}

			GL35Logger.logThis("Get FSI_GL_MAPPING_MASTER Data...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery1 = new StringBuffer(
					"SELECT V_GL_MAP_ID,N_VERSION_NUMBER,V_GL_MAP_NAME,V_GL_MAPPING_DESC,V_RECON_TYPE,V_ENTITY_CODE,V_CONSOLIDATION_TYPE,V_BALANCE_TYPE,V_GL_BOOK,V_GL_TYPE,F_ADJUST_ALLOCATION_REQ,V_RECON_DEFINITION_LEVEL,V_THRESHOLD_CCY_CODE,F_ADJUST_ALLOCATION_METHOD,V_ADJUST_ENTRY_POSTED,V_MAP_THRESHOLD_TYPE,N_MAP_ADJUSTMENT_FLOOR,N_MAP_POSITIVE_THRESHOLD,N_MAP_NEGATIVE_THRESHOLD,V_CREATED_USER,D_VERSION_CREATED_DATE,V_GL_HCY_CODE ");
			sqlQuery1.append(" FROM FSI_GL_MAPPING_MASTER ");
			sqlQuery1.append(" WHERE V_GL_MAP_ID = '" + sMapId
					+ "' AND N_VERSION_NUMBER = " + iVerNum
					+ " AND F_IS_DELETED != 'Y'");

			cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1.toString(), false);
			resultSet = (DACRecordSet) cargo1.getPayLoadObject();

			// This should fetch one row only
			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				// Set Data
				reconModel.setMapId(resultSet.fetchElement(1));
				reconModel.setVersionNum(resultSet.fetchElement(2));
				reconModel.setName(resultSet.fetchElement(3));
				reconModel.setDesc(resultSet.fetchElement(4));
				reconModel.setIsActOrPass(resultSet.fetchElement(5));
				reconModel.setLegEntity(resultSet.fetchElement(6));
				reconModel.setSelConsolType(resultSet.fetchElement(7));
				reconModel.setSelBalType(resultSet.fetchElement(8));
				reconModel.setGlBookType(resultSet.fetchElement(9));
				reconModel.setSelGlType(resultSet.fetchElement(10));
				reconModel.setRadAdjReq(resultSet.fetchElement(11));
				reconModel.setRadReconDefTyp(resultSet.fetchElement(12));
				reconModel.setSelTrsCrn(resultSet.fetchElement(13));
				reconModel.setRadAdjAlloc(resultSet.fetchElement(14));
				reconModel.setRadAdjPostTo(resultSet.fetchElement(15));
				reconModel.setSelTrsSpc(resultSet.fetchElement(16));
				reconModel.setAdjEntryFloor(resultSet.fetchElement(17));
				reconModel.setPosCrctnThr(resultSet.fetchElement(18));
				reconModel.setNegCrctnThr(resultSet.fetchElement(19));
				reconModel.setCreatedUser(resultSet.fetchElement(20));
				reconModel.setCreatedDate(resultSet.fetchElement(21));
				reconModel.setHierarchyCode(resultSet.fetchElement(22));
				resultSet.moveNext();
			}
			reconModel.setLegalEntityDesc(GlobalUtil.getHierDescription(
					infoDom, reconModel.getCreatedUser(),
					GlobalUtil.getLegalHierCode(infoDom),
					reconModel.getLegEntity()));
			if (!reconModel.getIsActOrPass().equals("P")
					&& reconModel.getGlBookType() != "") {
				reconModel.setGlBookTypeDesc(GlobalUtil.getHierDescription(
						infoDom, reconModel.getCreatedUser(),
						GlobalUtil.getParamValue("GLBOOK_TYPE_HIERCODE",
								infoDom), reconModel.getGlBookType()));
			}
			// FSI_GL_MAPPING_GL_CODES Data
			/*
			 * If Passive Recon no need to Fetch GL Codes & Gl Filter Data.
			 */
			if (!reconModel.getIsActOrPass().equals("P")) {

				GL35Logger.logThis("Get FSI_GL_MAPPING_GL_CODES Data...",
						Priority.DEBUG_INT);
				StringBuffer sqlQuery2 = new StringBuffer(
						"SELECT V_GL_MAP_ID,N_VERSION_NUMBER,V_GL_CODE,V_GL_BOOK ");
				sqlQuery2.append(" FROM FSI_GL_MAPPING_GL_CODES ");
				sqlQuery2.append(" WHERE V_GL_MAP_ID = '" + sMapId
						+ "' AND N_VERSION_NUMBER = " + iVerNum);

				DACRecordSet resultSet1;
				cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
						sqlQuery2.toString(), false);
				resultSet1 = (DACRecordSet) cargo1.getPayLoadObject();
				String sGlCode = "";
				String sGlCodeDesc = "";
				String retVal = "";
				while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {

					sGlCode += resultSet1.fetchElement(3);
					String sTempGlDesc = GlobalUtil.getHierDescription(infoDom,
							reconModel.getCreatedUser(),
							reconModel.getHierarchyCode(),
							resultSet1.fetchElement(3));
					sGlCodeDesc += sTempGlDesc;

					retVal += resultSet1.fetchElement(3) + "~" + sTempGlDesc
							+ "{*}";
					sGlCode += ",";
					sGlCodeDesc += ",";
					resultSet1.moveNext();
				}
				sGlCode = sGlCode.substring(0, sGlCode.lastIndexOf(","));
				sGlCodeDesc = sGlCodeDesc.substring(0,
						sGlCodeDesc.lastIndexOf(","));

				reconModel.setGlHierCode(sGlCode);
				reconModel.setGlHierDesc(sGlCodeDesc);
				
				actRecon.setDummyStr1(retVal);
			}
			// FSI_GL_MAP_RECON_TARGETS Data

			GL35Logger.logThis("Get FSI_GL_MAP_RECON_TARGETS Data...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery3 = new StringBuffer(
					"SELECT V_TABLE_NAME,V_LOGIC_TABLE_NAME,V_GL_CODE_COL_NAME,V_GL_CODE_LOGIC_COL_NAME,V_BALANCE_COL_NAME,V_BALANCE_LOGIC_COL_NAME,V_THRESHOLD_TYPE,N_ADJUSTMENT_FLOOR,N_POSITIVE_THRESHOLD,N_NEGATIVE_THRESHOLD");
			sqlQuery3.append(" FROM FSI_GL_MAP_RECON_TARGETS ");
			sqlQuery3.append("WHERE V_GL_MAP_ID = '" + sMapId
					+ "' AND N_VERSION_NUMBER = " + iVerNum);

			DACRecordSet resultSet2;
			ArrayList alTpTab = new ArrayList();
			cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery3.toString(), false);
			resultSet2 = (DACRecordSet) cargo1.getPayLoadObject();
			while (!resultSet2.EOF() && resultSet2.getRowCount() > 0) {
				ReconModel recMod = new ReconModel();
				recMod.setSelTpTab(resultSet2.fetchElement(1));
				recMod.setSelGlColForTp(resultSet2.fetchElement(3));
				recMod.setGlBookType(resultSet2.fetchElement(11));
				recMod.setSelAmtCol(resultSet2.fetchElement(5));
				recMod.setSelTrsSpc(resultSet2.fetchElement(7));
				recMod.setAdjEntryFloor(resultSet2.fetchElement(8));
				recMod.setPosCrctnThr(resultSet2.fetchElement(9));
				recMod.setNegCrctnThr(resultSet2.fetchElement(10));
				alTpTab.add(recMod);
				resultSet2.moveNext();
			}
			actRecon.setTpTabList(alTpTab);

			// FSI_GL_MAPPING_PP_ALLOC_DTLS
			String sAdjAllocReq = reconModel.getRadAdjReq();

			if (!sAdjAllocReq.equals("N")) {
				GL35Logger.logThis("Get FSI_GL_MAPPING_PP_ALLOC_DTLS Data...",
						Priority.DEBUG_INT);
				StringBuffer sqlQuery5 = new StringBuffer(
						"SELECT V_TABLE_NAME,V_BALANCE_COL_NAME,V_TARGET_TABLE_NAME,V_TARGET_TABLE_LOGIC_NAME,V_GL_AMOUNT_COL_NAME,V_GL_AMOUNT_LOGIC_COL_NAME,V_GL_CODE_COL_NAME,N_ALLOCATION_RATIO");
				sqlQuery5.append(" FROM FSI_GL_MAPPING_PP_ALLOC_DTLS ");
				sqlQuery5.append(" WHERE V_GL_MAP_ID = '" + sMapId
						+ "' AND N_VERSION_NUMBER = " + iVerNum);

				DACRecordSet resultSet4;
				ArrayList<ReconModel> alAllocTab = new ArrayList<ReconModel>();
				cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
						sqlQuery5.toString(), false);
				resultSet4 = (DACRecordSet) cargo1.getPayLoadObject();
				while (!resultSet4.EOF() && resultSet4.getRowCount() > 0) {
					ReconModel recMod = new ReconModel();
					recMod.setPpTableAlloc(resultSet4.fetchElement(1));
					recMod.setBalAmtAlloc(resultSet4.fetchElement(2));
					recMod.setTargetOrAdjusted(resultSet4.fetchElement(3));
					recMod.setGlAmtCol(resultSet4.fetchElement(5));
					recMod.setSelGlColForAllocTp(resultSet4.fetchElement(7));
					recMod.setAllocationRatio(resultSet4.fetchElement(8));
					alAllocTab.add(recMod);
					resultSet4.moveNext();
				}
				actRecon.setAllocTabList(alAllocTab);

				// DEFAULT VALUES
				GL35Logger.logThis("Get FSI_PP_DEFAULT_VALUES Data...",
						Priority.DEBUG_INT);
				ArrayList alDfltValues = new ArrayList();

				for (int i = 0; i < alAllocTab.size(); i++) {

					ReconModel recMod = new ReconModel();
					String sTableName = alAllocTab.get(i).getPpTableAlloc();
					String sBalColName = alAllocTab.get(i).getBalAmtAlloc();
					String sTargetName = alAllocTab.get(i)
							.getTargetOrAdjusted();
					String sGlColName = alAllocTab.get(i).getGlAmtCol();

					StringBuffer sqlQuery5a = new StringBuffer(
							"SELECT V_DEFAULT_VALUE_TYPE,V_DEFAULT_COL_NAME,V_DEFAULT_COL_VALUE,V_DEFAULT_COL_DATA_TYPE,V_EXPRESSION_TYPE");
					sqlQuery5a.append(" FROM FSI_PP_DEFAULT_VALUES ");
					sqlQuery5a.append(" WHERE V_GL_MAP_ID = '" + sMapId
							+ "' AND N_VERSION_NUMBER = " + iVerNum);
					sqlQuery5a.append(" AND V_TABLE_NAME = '" + sTableName
							+ "' AND V_BALANCE_COL_NAME = '" + sBalColName);
					sqlQuery5a.append("' AND V_TARGET_TABLE_NAME = '"
							+ sTargetName + "' AND V_GL_AMOUNT_COL_NAME = '"
							+ sGlColName + "'");

					DACRecordSet resultSet4a;
					String defVal = "";
					String display = "";

					cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
							sqlQuery5a.toString(), false);
					resultSet4a = (DACRecordSet) cargo1.getPayLoadObject();
					int count = 0;
					while (!resultSet4a.EOF() && resultSet4a.getRowCount() > 0) {

						++count;
						// DefValType~@~PhysicalColName~@~ColValue~@~ColDataType~@~ExpressionType
						defVal += resultSet4a.fetchElement(1) + "~@~"
								+ resultSet4a.fetchElement(2) + "~@~"
								+ resultSet4a.fetchElement(3) + "~@~"
								+ resultSet4a.fetchElement(4) + "~@~"
								+ resultSet4a.fetchElement(5) + "~@~";
						defVal += "~!!~";

						/* Get Logical Col Name */
						String logColName = GlobalUtil.getLogicalColName(
								resultSet4a.fetchElement(2), sTargetName,
								infoDom);

						if (resultSet4a.fetchElement(3) != null)
							display += logColName + " = "
									+ resultSet4a.fetchElement(3);
						else
							display += logColName + " = "
									+ resultSet4a.fetchElement(5);
						if (!(count == resultSet4a.getRowCount()))
							display += ",";

						resultSet4a.moveNext();
					}
					recMod.setDefaultValues(defVal);
					recMod.setComments(display);
					alDfltValues.add(recMod);
				}
				actRecon.setDefValList(alDfltValues);
			}
			// FILTER DATA
			// FSI_TARGET_FILTERS Data

			GL35Logger
					.logThis("Get FSI_TARGET_FILTERS Data...", Priority.DEBUG_INT);
			StringBuffer sqlQuery6 = new StringBuffer(
					"SELECT V_TABLE_NAME,V_HCY_CODE,V_HCY_NODE,V_BALANCE_COL_NAME ");
			sqlQuery6.append(" FROM FSI_TARGET_FILTERS ");
			sqlQuery6.append(" WHERE V_GL_MAP_ID = '" + sMapId
					+ "' AND N_VERSION_NUMBER = " + iVerNum);

			DACRecordSet resultSet5;
			ArrayList<LinkedHashMap<String, List<String>>> tpFilter = new ArrayList<LinkedHashMap<String, List<String>>>();
			LinkedHashMap<String, List<String>> map = new LinkedHashMap<String, List<String>>();

			cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery6.toString(), false);
			resultSet5 = (DACRecordSet) cargo1.getPayLoadObject();
			while (!resultSet5.EOF() && resultSet5.getRowCount() > 0) {
				ReconModel recMod = new ReconModel();
				recMod.setTxnEntityName(resultSet5.fetchElement(1) + "!~!"
						+ resultSet5.fetchElement(4));
				recMod.setTpFilterHierCode(resultSet5.fetchElement(2)
						+ "~"
						+ GlobalUtil.getHierDescription(infoDom,
								reconModel.getCreatedUser(),
								resultSet5.fetchElement(2), ""));
				recMod.setTpFilterHierNode(resultSet5.fetchElement(2)
						+ "~@~"
						+ resultSet5.fetchElement(3)
						+ "~"
						+ GlobalUtil.getHierDescription(infoDom,
								reconModel.getCreatedUser(),
								resultSet5.fetchElement(2),
								resultSet5.fetchElement(3)));

				if (!map.containsKey(recMod.getTxnEntityName())) {
					List<String> list = new ArrayList<String>();
					map.put(recMod.getTxnEntityName(), list);
				}

				List<String> list = (List<String>) map.get(recMod
						.getTxnEntityName());
				list.add(recMod.getTpFilterHierCode() + "^~^"
						+ recMod.getTpFilterHierNode());

				resultSet5.moveNext();
			}
			tpFilter.add(map);
			actRecon.setTpFilterList(tpFilter);

			// FSI_GL_BOOK_FILTERS Data
			/*
			 * If Passive Recon no need to Fetch Dimensions Data.
			 */

			if (!reconModel.getIsActOrPass().equals("P")) {

				GL35Logger.logThis("Get FSI_GL_SOURCE_FILTERS Data...",
						Priority.DEBUG_INT);
				StringBuffer sqlQuery7 = new StringBuffer(
						"SELECT V_HCY_CODE,V_HCY_NODE ");
				sqlQuery7.append(" FROM FSI_GL_SOURCE_FILTERS ");
				sqlQuery7.append(" WHERE V_GL_MAP_ID = '" + sMapId
						+ "' AND N_VERSION_NUMBER = " + iVerNum);

				DACRecordSet resultSet6;
				ArrayList glFilter = new ArrayList();

				cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
						sqlQuery7.toString(), false);
				resultSet6 = (DACRecordSet) cargo1.getPayLoadObject();
				while (!resultSet6.EOF() && resultSet6.getRowCount() > 0) {
					ReconModel recMod = new ReconModel();
					recMod.setGlFilterHierCode(resultSet6.fetchElement(1)
							+ "~"
							+ GlobalUtil.getHierDescription(infoDom,
									reconModel.getCreatedUser(),
									resultSet6.fetchElement(1), ""));
					recMod.setGlFilterHierNode(resultSet6.fetchElement(1)
							+ "~@~"
							+ resultSet6.fetchElement(2)
							+ "~"
							+ GlobalUtil.getHierDescription(infoDom,
									reconModel.getCreatedUser(),
									resultSet6.fetchElement(1),
									resultSet6.fetchElement(2)));
					glFilter.add(recMod);
					resultSet6.moveNext();
				}
				actRecon.setGlFilterList(glFilter);
			}
			// DIMENSIONS Data
			/*
			 * If Passive Recon no need to Fetch Dimensions Data.
			 */

			if (!reconModel.getIsActOrPass().equals("P")) {

				GL35Logger.logThis("Get FSI_GL_MAPPING_DIMENSIONS Data...",
						Priority.DEBUG_INT);
				StringBuffer sqlQuery8 = new StringBuffer(
						"SELECT A.V_DIMENSION_HCY_CODE,B.V_DIMENSION_DESC ");
				sqlQuery8
						.append(" FROM FSI_GL_MAPPING_DIMENSIONS A,SETUP_GL_RECON_DIMENSIONS B");
				sqlQuery8.append(" WHERE A.V_GL_MAP_ID = '" + sMapId
						+ "' AND A.N_VERSION_NUMBER = " + iVerNum);
				sqlQuery8
						.append(" AND A.V_DIMENSION_HCY_CODE = B.V_DIMENSION_HCY_CODE AND B.F_RECON_OR_MANDATORY='R'");

				DACRecordSet resultSet7;
				ArrayList dimList = new ArrayList();

				cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
						sqlQuery8.toString(), false);
				resultSet7 = (DACRecordSet) cargo1.getPayLoadObject();
				while (!resultSet7.EOF() && resultSet7.getRowCount() > 0) {
					ReconModel recMod = new ReconModel();
					recMod.setReconDimCode(resultSet7.fetchElement(1));
					recMod.setReconDim(resultSet7.fetchElement(2));
					dimList.add(recMod);
					resultSet7.moveNext();
				}
				actRecon.setDimTabList(dimList);
			}
		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
			return "error";
		}
		return "success";
	}

	public String deleteMapping(ReconModel reconModel, String infoDom) {

		GL35Logger.logThis("Entering deleteMapping....", Priority.DEBUG_INT);
		Cargo cargo1;
		DACRecordSet resultSet;

		// Get GL_MAPPING_MASTER values
		String sMapId = reconModel.getMapId().trim();
		int iVerNum = 1;
		if (reconModel.getVersionNum() != null) {
			iVerNum = Integer.parseInt(reconModel.getVersionNum());
		}
		try {
			String paramValue = sMapId + "-" + iVerNum;
			StringBuffer sqlQuery1 = new StringBuffer(
					"SELECT COUNT(*) FROM RUN_EXE_PARAMETERS WHERE  V_PARAM_ID LIKE 'RECONNAME_HIER' AND V_PARAM_VALUE_CODE = '"+paramValue +"'");

			cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1.toString(), false);
			
			DACRecordSet resultSet1;
			resultSet1 = (DACRecordSet) cargo1.getPayLoadObject();
			String count = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				count = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			if (Integer.parseInt(count) > 0) {
				GL35Logger.logThis(
						"Map is part of a Run execution - Cannot delete",
						Priority.ERROR_INT);
				return "CannotDel";
			}
		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
			return "error";
		}

		try {
			StringBuffer sqlQuery1 = new StringBuffer(
					"UPDATE FSI_GL_MAPPING_MASTER SET F_IS_DELETED = 'Y' ");
			sqlQuery1.append(" WHERE V_GL_MAP_ID = '" + sMapId
					+ "' AND N_VERSION_NUMBER = " + iVerNum);

			cargo1 = (Cargo) SMSServices.executeUpdate(infoDom,
					sqlQuery1.toString());

			if (cargo1.getErrorFlag() || cargo1 == null)
				return "error";
		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
			return "error";
		}

		try {
			String retVal = hierResave(infoDom);
			if (retVal != "Success") {
				GL35Logger.logThis("Hierarchy Resave Failure",
						Priority.ERROR_INT);
				return "error";
			}
		} catch (Exception e) {
			GL35Logger.logThis("Hierarchy Resave Failure", Priority.ERROR_INT);
			return "error";
		}
		return "success";

	}

	public String processAjax(String infoDom, int mode,
			ActiveReconAction activeReconAction, HttpServletRequest request) {

		DACRecordSet resultSet1;
		ArrayList dimList = new ArrayList();
		Cargo cargo;
		String retVal = "";

		switch (mode) {
		case 1: // Gl Book Type
		{
			GL35Logger.logThis("Case 1- Gl Book Type...", Priority.DEBUG_INT);
			GL35Logger.logThis("Get the GL Hierarchy Code...",
					Priority.DEBUG_INT);

			String tblName = "";
			String sGlHierCode = "";

			StringBuffer sqlQry = new StringBuffer(
					"SELECT V_TABLE_NAME FROM SETUP_GL_BOOKS WHERE ");
			sqlQry.append(" V_GL_BOOK = '"
					+ request.getParameter("bookHierCode") + "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQry.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				tblName = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			StringBuffer sqlQuery1 = new StringBuffer(
					"SELECT V_DATASET_CODE,V_GL_HCY_CODE FROM SETUP_GL_SOURCE WHERE ");
			sqlQuery1.append(" V_TABLE_NAME = '" + tblName + "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				retVal = resultSet1.fetchElement(1) + "~@~"
						+ resultSet1.fetchElement(2);
				sGlHierCode = resultSet1.fetchElement(2);
				resultSet1.moveNext();
			}
			retVal += "!~!"; // Separator for GlCodes List

			GL35Logger.logThis("Get the GL Codes...", Priority.DEBUG_INT);

			GL35Logger.logThis("Calling PKG_MATADATA_INFO.GETLEAFCODE()...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery1a = new StringBuffer(
					"SELECT PKG_MATADATA_INFO.GETLEAFCODE('"
							+ request.getParameter("bookHierCode")
							+ "') FROM DUAL");
			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1a.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			String sGlBookCode = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sGlBookCode = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}
			String sGlCodeColName = GlobalUtil.getHierAttributeCode(infoDom,
					request.getParameter("userId"), sGlHierCode);

			GL35Logger.logThis("Getting ColNames from SETUP_GL_BOOKS...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery1b = new StringBuffer(
					"SELECT V_GL_HCY_DIM_TABLE_NAME,V_GL_HCY_GL_BOOK_COL_NAME,V_GL_HCY_GL_TYPE_COL_NAME,V_GL_HCY_INTRA_GROUP_COL_NAME FROM SETUP_GL_SOURCE WHERE ");
			sqlQuery1b.append("  V_TABLE_NAME = '" + tblName + "'");
			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1b.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();

			String sDimTableName = "";
			String sBookColName = "";
			String sGlTypeColName = "";
			String sIntraGrpColName = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sDimTableName = resultSet1.fetchElement(1);
				sBookColName = resultSet1.fetchElement(2);
				sGlTypeColName = resultSet1.fetchElement(3);
				sIntraGrpColName = resultSet1.fetchElement(4);
				resultSet1.moveNext();
			}

			GL35Logger.logThis("Finally...Getting List of GLCodes...",
					Priority.DEBUG_INT);

			String glTypeCode = request.getParameter("glTypeCode");
			if (glTypeCode.equals("ALL")) {
				glTypeCode = "%%";
			}
			StringBuffer sqlQuery1c = new StringBuffer("SELECT "
					+ sGlCodeColName + " FROM " + sDimTableName + " WHERE ");
			sqlQuery1c.append(sBookColName + " = '" + sGlBookCode + "' AND ");
			sqlQuery1c.append(sGlTypeColName + " LIKE '" + glTypeCode
					+ "' AND "
					+ sIntraGrpColName + "= 'N'");
			GL35Logger.logThis("Query is .. " + sqlQuery1c);

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1c.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {

				retVal += resultSet1.fetchElement(1);
				retVal += "~@~";
				resultSet1.moveNext();
			}

			break;
		}
		case 2: // Tp Row Select
		{
			GL35Logger.logThis("Case 2- Tp Row Select...", Priority.DEBUG_INT);

			StringBuffer sqlQuery2 = new StringBuffer(
					"SELECT V_DATASET_CODE FROM SETUP_PRODUCT_PROCESSORS WHERE ");
			sqlQuery2.append(" V_TABLE_NAME = '"
					+ request.getParameter("tableName") + "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery2.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				retVal = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}
			break;
		}
		case 3: // Duplicate Check
		{
			GL35Logger
					.logThis("Case 3- Duplicate Check...", Priority.DEBUG_INT);

			String fldValue = request.getParameter("fldValue").split("~~")[0];
			String fldName = request.getParameter("fldValue").split("~~")[1];
			StringBuffer sqlQuery3 = new StringBuffer("");
			String fldName1 = "";
			if (fldName.equals("Name")) {
				fldName1 = "V_GL_MAP_NAME";
			} else if (fldName.equals("Description")) {
				fldName1 = "V_GL_MAPPING_DESC";
			}
			sqlQuery3
					.append("SELECT COUNT(*) FROM FSI_GL_MAPPING_MASTER WHERE ");
			sqlQuery3.append(fldName1 + "  = '" + fldValue + "'");
			// sqlQuery3.append(" AND V_RECON_TYPE = '"+request.getParameter("scrType").toString()
			// + "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery3.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {

				if (Integer.parseInt(resultSet1.fetchElement(1)) > 0) {
					retVal = "true~~" + fldName;
				} else
					retVal = "false~~" + fldName;
				resultSet1.moveNext();
			}

			break;
		}
		case 4: // Dimension Validations
		{
			GL35Logger.logThis("Case 4- Validate Dimensions...",
					Priority.DEBUG_INT);
			// parameter = "tblSet=" + param +"&glDataSet=" + glDataSet
			// +"&dimArr="+$("reconDimCode").value + "&infoDom=" + infoDom +
			// "&mode=4";
			String tblSet = request.getParameter("tblSet");
			String glDataSet = request.getParameter("glDataSet");
			String sInfodom = request.getParameter("infoDom");
			String[] dimArr = request.getParameter("dimArr").split(",");

			List<String> invHier = getValidHier(tblSet, glDataSet, dimArr,
					sInfodom,
					new Locale(ActiveReconAction.getSession().get("lclPostFix")
							.toString()));
			for (String s : invHier) {
				if (!s.equals("") && s != null) {
					StringBuffer sqlQuery4 = new StringBuffer();
					sqlQuery4
							.append("SELECT V_DIMENSION_DESC FROM SETUP_GL_RECON_DIMENSIONS WHERE V_DIMENSION_HCY_CODE = '"
									+ s + "'");

					cargo = (Cargo) SMSServices.executeQuery(infoDom,
							sqlQuery4.toString(), false);
					resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
					while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {

						retVal += resultSet1.fetchElement(1);
						retVal += ",";

						resultSet1.moveNext();
					}
				}
			}
			break;
		}
		case 5:// Dimension population on Click of Dim tab
		{
			GL35Logger.logThis("Case 5- Dimension Population...",
					Priority.DEBUG_INT);
			// parameter = "tblSet=" + param +"&glDataSet=" + glDataSet +
			// "&userId=" + userId + "&infoDom=" + infoDom + "&mode=4";
			String tbl = request.getParameter("tblSet");
			String glDSet = request.getParameter("glDataSet");
			String infodom = request.getParameter("infoDom");
			String sUserId = request.getParameter("userId");

			retVal = populateDimTab(tbl, glDSet, infodom, sUserId);
			break;
		}

		case 6: // Balance Type population based on GL Book Type
		{
			GL35Logger.logThis("Case 6 - Balance Type Population ... ",
					Priority.DEBUG_INT);

			String glBook = request.getParameter("glBookCode");
			String sInfoDom = request.getParameter("infoDom");
			Map<String, String> balColMap = new HashMap();

			DACRecordSet resultSet;
			String sqlQuery = "";
			String tblName = "";

			StringBuffer sqlQry = new StringBuffer(
					"SELECT V_TABLE_NAME FROM SETUP_GL_BOOKS WHERE ");
			sqlQry.append(" V_GL_BOOK = '" + request.getParameter("glBookCode")
					+ "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQry.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				tblName = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			GL35Logger.logThis("Querying for Bal Column Name...",
					Priority.DEBUG_INT);
			sqlQuery = "SELECT  SGBTM.V_BALANCE_TYPE,FGLM.V_CATEGORY_DESC FROM SETUP_GL_BAL_TYPE_MAPPING SGBTM,FSI_GL_LOOKUP_MASTER FGLM "
					+ " WHERE SGBTM.V_TABLE_NAME = '"
					+ tblName
					+ "'"
					+ " AND FGLM.V_CATEGORY_ID =SGBTM.V_BALANCE_TYPE "
					+ " AND FGLM.V_LOOKUP_CD = '2' ";

			cargo = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
			resultSet = (DACRecordSet) cargo.getPayLoadObject();
			String colVal = "";

			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				balColMap.put(resultSet.fetchElement(1),
						resultSet.fetchElement(2));
				resultSet.moveNext();
			}

			retVal += "<select name=\"selBalType\" id=\"selBalType\" class=\"mndtry option contrlOption\" onchange=\"changeIsChangedFlag()\">";
			retVal += "<option value= \"\">Select</option>";
			// retVal += "<option value= \"-1\">Select</option>";

			for (Map.Entry entry : balColMap.entrySet()) {
				retVal += "<option value= \"" + entry.getKey() + "\">"
						+ entry.getValue() + "</option>";
			}
			retVal += "</select>";
			break;
		}
		case 7: // GL Type Filter based on GL Book Selected.
		{
			GL35Logger.logThis(
					"Case 7 - GL Type Filter based on GL Book Selected ... ",
					Priority.DEBUG_INT);

			String sUserId = request.getParameter("userId");
			// request.getParameter("bookHierCode")

			Set<String> glTypeSet = new HashSet<String>();

			Cargo cargo7a;
			DACRecordSet resultSet;

			GL35Logger.logThis("Calling PKG_MATADATA_INFO.GETLEAFCODE()...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery7a = new StringBuffer(
					"SELECT PKG_MATADATA_INFO.GETLEAFCODE('"
							+ request.getParameter("bookHierCode")
							+ "') FROM DUAL");
			cargo7a = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery7a.toString(), false);
			resultSet1 = (DACRecordSet) cargo7a.getPayLoadObject();
			String sGlBookCd = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sGlBookCd = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}
			// String sGlHierCode = request.getParameter("glHierCode");
			// String sGlCodeColName = ReconUtil.getHierAttributeCode(infoDom,
			// sUserId, sGlHierCode );

			String tblName = "";

			StringBuffer sqlQry = new StringBuffer(
					"SELECT V_TABLE_NAME FROM SETUP_GL_BOOKS WHERE ");
			sqlQry.append(" V_GL_BOOK = '"
					+ request.getParameter("bookHierCode") + "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQry.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				tblName = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			GL35Logger.logThis("Getting ColNames from SETUP_GL_BOOKS...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery1b = new StringBuffer(
					"SELECT V_GL_HCY_DIM_TABLE_NAME,V_GL_HCY_GL_BOOK_COL_NAME,V_GL_HCY_GL_TYPE_COL_NAME FROM SETUP_GL_SOURCE WHERE ");
			sqlQuery1b.append(" V_TABLE_NAME = '" + tblName + "'");
			cargo7a = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1b.toString(), false);
			resultSet1 = (DACRecordSet) cargo7a.getPayLoadObject();

			String sDimTableName = "";
			String sBookColName = "";
			String sGlTypeColName = "";

			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sDimTableName = resultSet1.fetchElement(1);
				sBookColName = resultSet1.fetchElement(2);
				sGlTypeColName = resultSet1.fetchElement(3);
				resultSet1.moveNext();
			}

			GL35Logger.logThis("Querying for GL Types for Selected book...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery7b = new StringBuffer("SELECT DISTINCT("
					+ sGlTypeColName + ") FROM " + sDimTableName + " WHERE ");
			sqlQuery7b.append(sBookColName + " = '" + sGlBookCd + "'");
			GL35Logger.logThis("Query is .. " + sqlQuery7b);

			cargo7a = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery7b.toString(), false);
			resultSet = (DACRecordSet) cargo7a.getPayLoadObject();
			String colVal = "";

			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				glTypeSet.add(resultSet.fetchElement(1));
				resultSet.moveNext();
			}

			String glTypeCode = GlobalUtil.getParamValue("GL_TYPE_HIERCODE",
					infoDom);
			LinkedHashMap<String, String> glType = GlobalUtil.getHierNodeDesc(
					infoDom, sUserId, glTypeCode);

			retVal += "<select name=\"selGlType\" id=\"selGlType\" class=\"mndtry option contrlOption\"  onchange=\"genericAjaxCall(1,$('glBookType').value);changeIsChangedFlag();\">";
			retVal += "<option value= \"\">Select</option>";
			// retVal += "<option value= \"-1\">Select</option>";
			retVal += "<option value= \"ALL\">All</option>";

			for (String entry : glTypeSet) {
				retVal += "<option value= \"" + entry + "\">"
						+ glType.get(entry) + "</option>";
			}
			retVal += "</select>";
			break;
		}

		case 8:// GL Book Population based on Legal Entity and Consolidation
				// Type.
		{
			String legEntUniqCode = request.getParameter("legEntCode");
			String consolType = request.getParameter("consol");

			GL35Logger
					.logThis(
							"Case 8 - GL Book Population based on Legal Entity and Consolidation Type...",
							Priority.DEBUG_INT);

			GL35Logger.logThis("Calling PKG_MATADATA_INFO.GETLEAFCODE()...",
					Priority.DEBUG_INT);

			
			StringBuffer sqlQuery8a = new StringBuffer(
					"SELECT PKG_MATADATA_INFO.GETLEAFCODE('" + legEntUniqCode
							+ "') FROM DUAL");
			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery8a.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			String legEntCode = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				legEntCode = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			StringBuffer sqlQuery8 = new StringBuffer(
					"SELECT SGBM.V_GL_BOOK FROM SETUP_GL_BOOK_MAPPING SGBM "
							+ "INNER JOIN SETUP_GL_BOOKS SGB ON PKG_MATADATA_INFO.GETLEAFCODE(SGB.V_GL_BOOK) = SGBM.V_GL_BOOK "
							+ " WHERE SGBM.V_LV_CODE = '"
							+ legEntCode + "' AND "
							+ " SGBM.V_CONSOLIDATION_TYPE = '" + consolType
							+ "'");
			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery8.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			String sGlBookCd = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sGlBookCd = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			String bookHierCode = GlobalUtil.getParamValue("GLBOOK_TYPE_HIERCODE"
					, infoDom);
			String sGlBookUniqCd = GlobalUtil.getHierUniqCodeFromLeafCode(
					sGlBookCd,
					bookHierCode, infoDom);

			StringBuffer sqlQuery8b = new StringBuffer(
					"SELECT V_GL_BOOK_DESC FROM DIM_GL_BOOK WHERE V_GL_BOOK_CODE = '"
							+ sGlBookCd + "'");
			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery8b.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			String sGlBookDesc = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sGlBookDesc = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			retVal = sGlBookDesc + "!~!" + sGlBookUniqCd;

			break;

		}
		case 9: // Dynamic Value Select
		{
			GL35Logger.logThis("Case 9- Dynamic Value select...",
					Priority.DEBUG_INT);
			// inputStream = new StringBufferInputStream("");
			String page = request.getParameter("page");
			infoDom = request.getParameter("Info");

			if (page.toString().equalsIgnoreCase("form_filter")) {

				String expression = request.getParameter("expr");
				String stabname = request.getParameter("tabname");
				String screenval = "NO";
				String strColumn = "";
				String values = "";
				int rowcnt = 0;
				if (expression == null || "".equals(expression.trim())
						|| "null".equalsIgnoreCase(expression.trim())) {
					expression = " 1=1 ";
				}

				if (stabname.indexOf("~") != -1) {
					screenval = "YES";
					String temp = "";
					temp = stabname;
					stabname = temp.substring(0, temp.indexOf("~"));
					strColumn = temp.substring((temp.indexOf("~") + 1));

				}
				boolean chkstatus = false;

				String vQRychk = "SELECT 1 FROM " + stabname + " WHERE "
						+ expression;

				try {
					Cargo prObjCargo1 = SMSServices.executeQuery(infoDom,
							vQRychk, false);
					DACRecordSet prObjDACRS = (DACRecordSet) prObjCargo1
							.getPayLoadObject();
					chkstatus = prObjDACRS.isSuccessQuery();

					if (screenval.equalsIgnoreCase("YES")) {
						vQRychk = "SELECT  DISTINCT " + strColumn + " FROM "
								+ stabname + " WHERE " + expression
								+ " ORDER BY " + strColumn;
						prObjCargo1 = SMSServices.executeQuery(infoDom,
								vQRychk, false);
						prObjDACRS = (DACRecordSet) prObjCargo1
								.getPayLoadObject();
						while (!prObjDACRS.EOF()
								&& prObjDACRS.getRowCount() > 0) {
							if (rowcnt == 0)
								values = prObjDACRS.fetchElement(1);
							else
								values = values + "^"
										+ prObjDACRS.fetchElement(1);

							rowcnt = rowcnt + 1;

							prObjDACRS.moveNext();
						}

						if (prObjDACRS.getRowCount() == 0)
							values = "-";
						else
							values = values.replaceAll("&", " ");
					}
				} catch (Exception e) {
					e.printStackTrace();
					try {
						// response.getWriter().write("<message8>"+chkstatus+"</message8>".trim());
						retVal = "" + chkstatus + "";
						screenval = "NO";
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
					// System.out.println("ERROR WHILE GETTING THE PRIMARY KEY INFORMATION");
					// return vColumnString;
				}
				try {
					if (screenval.equalsIgnoreCase("YES")) {
						// response.getWriter().write("<message8>"+values+"</message8>".trim());
						retVal = values.trim();
					} else {
						// response.getWriter().write("<message8>"+chkstatus+"</message8>".trim());
						retVal = "" + chkstatus + "";
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		}

		case 10: // Default Value Expressions
		{
			GlobalUtil globalUtil = new GlobalUtil();
			// String langCode = "US";
			String langCode = ActiveReconAction.getSession().get("lclPostFix")
					.toString();
			Map<String, String> defValExprsn, defValDropDown = new LinkedHashMap<String, String>();// Default
																									// Values
																									// Expression
																									// Dropdown.
			retVal = "{";

			defValDropDown = globalUtil.getLookUpData("11", langCode, infoDom);
			retVal += "\"defValDropDown\" : {";
			int count = 0;
			for (Map.Entry<String, String> e : defValDropDown.entrySet()) {
				if (!(count == 0))
					retVal += ",";
				retVal += "\"" + e.getKey() + "\" : \"" + e.getValue() + "\"";
				++count;
			}
			retVal += "},";

			defValExprsn = globalUtil.getLookUpData("12", langCode, infoDom);
			retVal += "\"defValExprns\" : {";
			count = 0;
			for (Map.Entry<String, String> e : defValExprsn.entrySet()) {
				if (!(count == 0))
					retVal += ",";
				retVal += "\"" + e.getKey() + "\" : \"" + e.getValue() + "\"";
				++count;
			}
			retVal += "}}";
			break;
		}

		case 11: // Check if Default Values is required for any Target Entity.
		{
			String trgtTables = request.getParameter("trgtEntTabs");
			
			Map<String, String> tpList = new LinkedHashMap<String, String>();
			Set<String> tabList = new HashSet<String>();
			DACRecordSet prObjDACRS;

			tpList = getTpList(infoDom);
			for (String tabName : trgtTables.split(",")) {
				if (!(tabName.equals("")) || (tabName != null)) {
					@SuppressWarnings({ "unchecked" })
					LinkedHashMap<String, String> colMap = GlobalUtil
							.getAllColMap(tabName, infoDom);

					ArrayList<String> setup_Colsvec = new ArrayList<String>();
					try {

						// String sql2 =
						// "SELECT upper(V_EXPOSURE_ID_COL_NAME),upper(V_MIS_DATE_COL_NAME) FROM SETUP_PRODUCT_PROCESSORS WHERE UPPER(V_TABLE_NAME) =UPPER('"
						String sql2 = "SELECT UPPER(V_EXPOSURE_ID_COL_NAME) FROM   SETUP_PRODUCT_PROCESSORS WHERE   UPPER(V_TABLE_NAME) = UPPER('"
								+ tabName
								+ "') UNION SELECT   UPPER(V_MIS_DATE_COL_NAME) FROM   SETUP_PRODUCT_PROCESSORS WHERE   UPPER(V_TABLE_NAME) = UPPER('"
								+ tabName
								+ "') UNION SELECT   UPPER(SRDCM.V_DIMENSION_COL_NAME) FROM   SETUP_GL_RECON_DIMENSIONS SGRD INNER JOIN SETUP_RECON_DIM_COL_MAP SRDCM ON   SGRD.V_DIMENSION_HCY_CODE = SRDCM.V_DIMENSION_HCY_CODE WHERE   SGRD.F_RECON_OR_MANDATORY  = 'M' AND SRDCM.V_PP_OR_GL = 'PP' AND SRDCM.V_PP_GL_TABLE_NAME = UPPER('"
								+ tabName + "')";

						GL35Logger.logThis("Query is ..." + sql2,
								Priority.DEBUG_INT);

						Cargo prObjCargo1 = SMSServices.executeQuery(infoDom,
								sql2, false);
						prObjDACRS = (DACRecordSet) prObjCargo1
								.getPayLoadObject();
						while (!prObjDACRS.EOF()
								&& prObjDACRS.getRowCount() > 0) {

							if (prObjDACRS.fetchElement(1) != null
									&& prObjDACRS.fetchElement(1) != "")
								setup_Colsvec.add(prObjDACRS.fetchElement(1));
							if (prObjDACRS.fetchElement(2) != null
									&& prObjDACRS.fetchElement(2) != "")
								setup_Colsvec.add(prObjDACRS.fetchElement(2));
							prObjDACRS.moveNext();
						}

					} catch (Exception e) {
						GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
						e.printStackTrace();
					}

					for (Map.Entry<String, String> e : colMap.entrySet()) {
						if (e.getValue().substring(0, 1).equals("*")
								&& !(setup_Colsvec.contains(e.getKey()
										.toUpperCase()))) {
							if (tabList.add(tabName)) {
								retVal += tpList.get(tabName);
								retVal += ".";
							}
						}
					}
				}
			}

			break;
		}

		default:
			break;
		}

		return retVal;

	}

	public String populateDimTab(String tblSet, String glDataSet,
			String sInfodom, String sUserId) {
		GL35Logger.logThis("Entering populateDimTab...", Priority.DEBUG_INT);

		ReconUtil reconUtil = new ReconUtil();
		String retVal = "";
		Cargo cargo1;
		DACRecordSet resultSet1;

		List<String> dimHierList = reconUtil.getCommonHier(tblSet, glDataSet,
				sInfodom);

		// Loop to populate Table. -->
		// HierCode~Description{*}HierCode~Description
		for (String dimHier : dimHierList) {
			String dimDesc = "";

			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append("SELECT V_DIMENSION_DESC FROM SETUP_GL_RECON_DIMENSIONS WHERE V_DIMENSION_HCY_CODE = '"
					+ dimHier + "'");

			cargo1 = (Cargo) SMSServices.executeQuery(sInfodom,
					sqlQuery.toString(), false);
			resultSet1 = (DACRecordSet) cargo1.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				dimDesc += resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			retVal += dimHier + "~" + dimDesc;
			retVal += "{*}";
		}
		retVal += "!~!";
		// Loop to populate dimList variable for i/p to dimension browser->
		// tabName ~ dimCode,tabName ~ dimCode
		for (String dimHier : dimHierList) {

			String tabName = GlobalUtil
					.getHierTable(sInfodom, sUserId, dimHier);
			retVal += tabName + "~" + dimHier;
			retVal += ",";
		}
		return retVal;
	}

}
