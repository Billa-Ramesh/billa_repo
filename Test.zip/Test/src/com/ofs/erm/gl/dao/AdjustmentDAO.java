/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : AdjustmentDAO.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Priority;

import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.model.AdjustmentSearchBean;
import com.ofs.erm.gl.model.AdjustmentSummaryBean;
import com.ofs.erm.gl.model.MapNameBean;
//import com.sun.net.httpserver.Authenticator.Success;
import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;


public class AdjustmentDAO 
{
	private static int rowId = 0;
	private static List<String> colArray = new ArrayList<String>();
	private static int noOfPagesLoaded = 2;
	@SuppressWarnings("unused")
	private static String searchQuery;

	static {
		colArray.add("AE.V_EXECUTION_IDENTIFIER");
		colArray.add(" MM.V_GL_MAP_NAME");
		colArray.add("GLDATE");
		colArray.add("RECONAMOUNT");
		colArray.add("AE.N_VERSION_NUMBER");
		colArray.add("SUBMISSIONPENDING");
		colArray.add("APPROVALPENDING");
		colArray.add("APPROVED");
		colArray.add("REJECTED");
	}

	public static List<AdjustmentSummaryBean> getAdjData(AdjustmentSearchBean searchBean, String infodom, String authstatus) 
	{
		List<AdjustmentSummaryBean> adjustmentData = new ArrayList<AdjustmentSummaryBean>();
		int count = 1;
		int recordCount = 0;
		
		String[] entryStatus = authstatus.split("~");
		StringBuffer entryStatusString = new StringBuffer();

		for(int k=0;k<entryStatus.length;k++) {
			if(k < entryStatus.length - 1)
				entryStatusString.append("'" + entryStatus[k] + "',");
			else if(k == entryStatus.length - 1)
				entryStatusString.append("'" + entryStatus[k] + "'");
		}

		GL35Logger.logThis("entryStatusString="+entryStatusString, Priority.DEBUG_INT);
		

		if(searchBean == null){
			searchBean = new AdjustmentSearchBean();
			searchBean.setExecutionId("");
			searchBean.setGlDate("");
			searchBean.setMapId("");
			searchBean.setSortCol("");
			searchBean.setSortOrder("");
			searchBean.setStartIndex(1);
			searchBean.setEndIndex(10*noOfPagesLoaded);
		}

		if(searchBean.getRecordCountNeeded() == true) {
			/*System.out.println("iNSIDE searchBean.getRecordCountNeeded() == true");
			GL35Logger.logThis("iNSIDE searchBean.getRecordCountNeeded() == true", Priority.DEBUG_INT);
			String execId = "'%"+searchBean.getExecutionId()+"%'";
			String mapName = "'%"+searchBean.getMapId()+"%'";
			String glDate = searchBean.getGlDate();

			String recordQuery = "SELECT COUNT(1) FROM ( SELECT * FROM FCT_GL_ADJUSTMENT_ENTRIES WHERE (FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER" +
									" LIKE "+execId+" AND FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID LIKE "+mapName+" AND FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS IN (" + entryStatusString + ") AND FCT_GL_ADJUSTMENT_ENTRIES.F_INTRA_GROUP='N' AND " +
									" FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE = COALESCE(TO_DATE('"+glDate+"','MM-DD-YYYY')," +
									" FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE)) GROUP BY FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER," +
									" FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID,FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE)";

			GL35Logger.logThis("recordQuery -- "+recordQuery, Priority.DEBUG_INT);
			GL35Logger.logThis("BEFORE Cargo FindCountCargo", Priority.DEBUG_INT);
			Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,recordQuery,false);
			GL35Logger.logThis("query fired", Priority.DEBUG_INT);
			
			if(FindCountCargo.getErrorFlag())
			{
				GL35Logger.logThis("Error while retrieving from Database - Inside AdjustmentDAO", Priority.DEBUG_INT);
				AdjustmentSummaryBean tempBean = new AdjustmentSummaryBean();
				tempBean.setExecutionIdentifier(null);
				adjustmentData.add(tempBean);
				return adjustmentData;
			}
			else {
				DACRecordSet resultSet =  (DACRecordSet) FindCountCargo.getPayLoadObject();
				GL35Logger.logThis("CARGO RECEIVED", Priority.DEBUG_INT);
				recordCount = Integer.parseInt(resultSet.fetchElement(1));
	
				//GL35Logger.logThis("recordCount RECEIVED - "+recordCount, Priority.DEBUG_INT);
			}*/
		}

		count = 1;


		if((searchBean.getSortOrder() == "") || (searchBean.getSortOrder() == null)) {
			searchBean.setSortOrder("ASC");
			searchBean.setSortCol("2");
		}

		String sortColName = colArray.get(Integer.parseInt(searchBean.getSortCol()));
		String execId = "'%"+searchBean.getExecutionId()+"%'";
		String mapName = "'%"+searchBean.getMapId()+"%'";
		String glDate = "'"+searchBean.getGlDate()+"'";
		StringBuilder searchQuery = new StringBuilder();
		searchQuery.append(" SELECT * ");
		searchQuery.append("    FROM (SELECT ROWNUM RNUM, Z.* ");
		searchQuery.append(" ,COUNT(Z.V_EXECUTION_IDENTIFIER) OVER() CNT ");
		searchQuery.append("    FROM (SELECT DISTINCT AE.V_EXECUTION_IDENTIFIER, ");
		searchQuery.append("         AE.V_GL_MAP_ID, ");
		searchQuery.append("         TO_DATE(TO_CHAR(DIM_DATES.D_CALENDAR_DATE,'MM-DD-YYYY'),'MM-DD-YYYY') AS GLDATE , ");
		searchQuery.append("         ACOLS.TOTAL_EXPOSURE RECONAMOUNT, ");
		searchQuery.append("         AE.N_VERSION_NUMBER, ");
		searchQuery.append("         ACOLS.PENDING SUBMISSIONPENDING, ");
		searchQuery.append("         ACOLS.SUBMITTED APPROVALPENDING, ");
		searchQuery.append("         ACOLS.APPROVED, ");
		searchQuery.append("         ACOLS.REJECTED, ");
		searchQuery.append("         MM.V_GL_MAP_NAME ");
		searchQuery.append("         FROM FCT_GL_ADJUSTMENT_ENTRIES AE, ");
		searchQuery.append("         (SELECT T.V_EXECUTION_IDENTIFIER V_EXECUTION_IDENTIFIER, ");
		searchQuery.append("        T.TOTAL_EXPOSURE TOTAL_EXPOSURE, ");
		searchQuery.append("        NVL(P.PENDING_EXPOSURES,0) PENDING, ");
		searchQuery.append("        NVL(A.APPROVED_EXPOSURES,0) APPROVED, ");
		searchQuery.append("        NVL(S.SUBMITTED_EXPOSURES,0) SUBMITTED, ");
		searchQuery.append("        NVL(R.REJECTED_EXPOSURES,0) REJECTED, ");
		searchQuery.append("        T.V_GL_MAP_ID, ");
		searchQuery.append("        T.N_VERSION_NUMBER ");
		searchQuery.append("   FROM (SELECT V_EXECUTION_IDENTIFIER, SUM(ABS(N_EXPOSURE_AMOUNT)) TOTAL_EXPOSURE,V_GL_MAP_ID ,N_VERSION_NUMBER ");
		searchQuery.append("           FROM FCT_GL_ADJUSTMENT_ENTRIES WHERE F_INTRA_GROUP='N' ");
		searchQuery.append("          GROUP BY V_EXECUTION_IDENTIFIER,V_GL_MAP_ID ,N_VERSION_NUMBER) T ");
		searchQuery.append(" LEFT OUTER JOIN (SELECT V_EXECUTION_IDENTIFIER , SUM(ABS(N_EXPOSURE_AMOUNT)) APPROVED_EXPOSURES,V_GL_MAP_ID,N_VERSION_NUMBER ");
		searchQuery.append("     FROM FCT_GL_ADJUSTMENT_ENTRIES ");
		searchQuery.append("     WHERE V_AUTHORIZATION_STATUS = 'A' ");
		searchQuery.append("     GROUP BY V_EXECUTION_IDENTIFIER,V_GL_MAP_ID,N_VERSION_NUMBER) A  ");
		searchQuery.append("     ON T.V_EXECUTION_IDENTIFIER = A.V_EXECUTION_IDENTIFIER AND T.V_GL_MAP_ID=A.V_GL_MAP_ID AND T.N_VERSION_NUMBER=A.N_VERSION_NUMBER ");
		searchQuery.append(" LEFT OUTER JOIN (SELECT V_EXECUTION_IDENTIFIER, ");
		searchQuery.append("     SUM(ABS(N_EXPOSURE_AMOUNT)) SUBMITTED_EXPOSURES,V_GL_MAP_ID,N_VERSION_NUMBER ");
		searchQuery.append("     FROM FCT_GL_ADJUSTMENT_ENTRIES ");
		searchQuery.append("     WHERE V_AUTHORIZATION_STATUS = 'S' ");
		searchQuery.append("     GROUP BY V_EXECUTION_IDENTIFIER,V_GL_MAP_ID,N_VERSION_NUMBER) S  ");
		searchQuery.append("     ON T.V_EXECUTION_IDENTIFIER = S.V_EXECUTION_IDENTIFIER AND T.V_GL_MAP_ID=S.V_GL_MAP_ID AND T.N_VERSION_NUMBER=S.N_VERSION_NUMBER");
		searchQuery.append(" LEFT OUTER JOIN (SELECT V_EXECUTION_IDENTIFIER, ");
		searchQuery.append("     SUM(ABS(N_EXPOSURE_AMOUNT)) PENDING_EXPOSURES,V_GL_MAP_ID,N_VERSION_NUMBER ");
		searchQuery.append("     FROM FCT_GL_ADJUSTMENT_ENTRIES ");
		searchQuery.append("     WHERE V_AUTHORIZATION_STATUS = 'P' ");
		searchQuery.append("     GROUP BY V_EXECUTION_IDENTIFIER,V_GL_MAP_ID,N_VERSION_NUMBER) P  ");
		searchQuery.append("     ON T.V_EXECUTION_IDENTIFIER = P.V_EXECUTION_IDENTIFIER AND T.V_GL_MAP_ID=P.V_GL_MAP_ID AND T.N_VERSION_NUMBER=P.N_VERSION_NUMBER ");
		searchQuery.append(" LEFT OUTER JOIN (SELECT V_EXECUTION_IDENTIFIER, ");
		searchQuery.append("     SUM(ABS(N_EXPOSURE_AMOUNT)) REJECTED_EXPOSURES,V_GL_MAP_ID,N_VERSION_NUMBER ");
		searchQuery.append("     FROM FCT_GL_ADJUSTMENT_ENTRIES ");
		searchQuery.append("     WHERE V_AUTHORIZATION_STATUS = 'R' ");
		searchQuery.append("     GROUP BY V_EXECUTION_IDENTIFIER,V_GL_MAP_ID,N_VERSION_NUMBER) R ON  ");
		searchQuery.append("     T.V_EXECUTION_IDENTIFIER = R.V_EXECUTION_IDENTIFIER AND T.V_GL_MAP_ID=R.V_GL_MAP_ID AND T.N_VERSION_NUMBER=R.N_VERSION_NUMBER) ACOLS, ");
		searchQuery.append("     FSI_GL_MAPPING_MASTER MM,DIM_DATES ");
		searchQuery.append("   WHERE (ACOLS.V_EXECUTION_IDENTIFIER=AE.V_EXECUTION_IDENTIFIER AND ACOLS.N_VERSION_NUMBER=AE.N_VERSION_NUMBER AND ACOLS.V_GL_MAP_ID=AE.V_GL_MAP_ID) ");
		searchQuery.append("     AND (MM.V_GL_MAP_ID=AE.V_GL_MAP_ID AND MM.N_VERSION_NUMBER=AE.N_VERSION_NUMBER) ");
		searchQuery.append("     AND (DIM_DATES.N_DATE_SKEY=AE.N_DATE_SKEY) ");
		searchQuery.append("     AND (AE.V_AUTHORIZATION_STATUS IN (" + entryStatusString + "))  ");
		searchQuery.append("     AND (AE.F_INTRA_GROUP = 'N')  ");
		searchQuery.append("     AND (AE.V_EXECUTION_IDENTIFIER LIKE "+execId+") ");
		searchQuery.append("     AND (AE.V_GL_MAP_ID LIKE  "+mapName+") ");
		searchQuery.append("     AND (DIM_DATES.D_CALENDAR_DATE = COALESCE(TO_DATE("+glDate+", 'MM-DD-YYYY'),DIM_DATES.D_CALENDAR_DATE)) ");
		searchQuery.append("     ORDER BY "+sortColName+" "+searchBean.getSortOrder()+") Z ");
		//searchQuery.append("           WHERE (ROWNUM <= "+searchBean.getEndIndex()+")) ");
		searchQuery.append(" ) ");
		searchQuery.append("   WHERE RNUM >= "+searchBean.getStartIndex()+" AND RNUM <= "+searchBean.getEndIndex()+" ");
		/*String searchQuery = "SELECT * FROM ( SELECT ROWNUM RNUM,T.* FROM (SELECT A.*,M.V_GL_MAP_NAME,E.F_AUTO_APPROVAL FROM "+
		"(SELECT FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID,"+
		"TO_DATE(TO_CHAR(FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE,'MM-DD-YYYY'),'MM-DD-YYYY') AS GLDATE,"+
		"SUM(FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT) AS RECONAMOUNT,FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,"+
		"SUM(CASE FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS "+
		"WHEN 'P' THEN FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT ELSE 0 END) AS SUBMISSIONPENDING,"+
		"SUM(CASE FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS "+
		"WHEN 'S' THEN FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT ELSE 0 END) AS APPROVALPENDING,"+
		"SUM(CASE FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS "+
		"WHEN 'A' THEN FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT ELSE 0 END) AS APPROVED,"+
		"SUM(CASE FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS "+
		"WHEN 'R' THEN FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT ELSE 0 END) AS REJECTED "+
		"FROM FCT_GL_ADJUSTMENT_ENTRIES "+
		"WHERE("+
		"      (FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER LIKE "+execId+") AND (FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS IN (" + entryStatusString + ")) AND (FCT_GL_ADJUSTMENT_ENTRIES.F_INTRA_GROUP='N') AND  (FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID LIKE "+mapName+") AND "+ 
		"      (FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE = COALESCE(TO_DATE("+glDate+",'MM-DD-YYYY'),FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE))"+
		"     ) "+
		"GROUP BY FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID,FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,"+
		"FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE ) A,"+
		"FSI_GL_MAPPING_MASTER M,FSI_GL_EXECUTION_MASTER E "+
		"WHERE ((A.V_GL_MAP_ID=M.V_GL_MAP_ID) AND (m.n_version_number = A.N_VERSION_NUMBER) and (A.V_EXECUTION_IDENTIFIER = E.V_EXECUTION_IDENTIFIER)) "+
		"ORDER BY "+sortColName+" "+searchBean.getSortOrder()+" ) T WHERE (ROWNUM <= "+searchBean.getEndIndex()+") ) WHERE RNUM >= "+searchBean.getStartIndex()+" ";*/
		GL35Logger.logThis("Adj DAO: searchQuery="+searchQuery.toString(), Priority.DEBUG_INT);
		
		try{
			Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,searchQuery.toString(),false);
			DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();

			GL35Logger.logThis("searchQuery FIRED ", Priority.DEBUG_INT);
			rowId = searchBean.getStartIndex() - 1;

			while (!resultSet.EOF()) {
				AdjustmentSummaryBean asb = new AdjustmentSummaryBean();
				asb.setExecutionIdentifier(resultSet.fetchElement(2));
				asb.setMapId(resultSet.fetchElement(3));
				String[] tempDate = resultSet.fetchElement(4).split(" ");
				GL35Logger.logThis("resultSet.fetchElement(4)="+resultSet.fetchElement(4), Priority.DEBUG_INT);
				String[] tempDate1 = tempDate[0].split("-");
				String glDateNew = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
				GL35Logger.logThis("glDateNew="+glDateNew, Priority.DEBUG_INT);
				asb.setGlDate(glDateNew);
				asb.setReconAmount(resultSet.fetchElement(5));
				asb.setVersionNumber(resultSet.fetchElement(6));
				asb.setAmountSubmissionPending(resultSet.fetchElement(7));
				asb.setAmountApprovalPending(resultSet.fetchElement(8));
				asb.setAmountApproved(resultSet.fetchElement(9));
				asb.setAmountRejected(resultSet.fetchElement(10));
				asb.setMapName(resultSet.fetchElement(11));
				asb.setRowId(rowId);
				asb.setCheckBoxString("checkedCNew('" +rowId + "')");
				asb.setRecordCount(Integer.parseInt(resultSet.fetchElement(12)));
				//asb.setAutoApproved(resultSet.fetchElement(12));
				adjustmentData.add(asb);
				rowId++;
				GL35Logger.logThis("ADDING TO BEAN -- "+rowId, Priority.DEBUG_INT);
				resultSet.moveNext();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return adjustmentData;
	}

	public static List<MapNameBean> getMapArray(String infodom) 
	{
		List<MapNameBean> mapArray = new ArrayList<MapNameBean>();
		String query = "SELECT M.V_GL_MAP_ID,M.V_GL_MAP_NAME FROM FSI_GL_MAPPING_MASTER M ";
		try{
			Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,query,false);
			DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();

			rowId = 0;

			while(!resultSet.EOF()) {
				MapNameBean tempBean = new MapNameBean();
				tempBean.setMapId(resultSet.fetchElement(1));
				tempBean.setMapName(resultSet.fetchElement(2));
				mapArray.add(tempBean);
				rowId++;
				resultSet.moveNext();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

		return mapArray;

	}


}

