/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          :  GlobalSettingsDAO.java
* Title         :
* Description   :
* @author       : Pallavi Reddy 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.dao;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import umm.bi.ClsUEntHierarchy;

import com.iflex.fic.client.BusinessMetaData;
import com.iflex.fic.client.SMSServices;
import com.iflex.fic.client.SecureBusinessMetaData;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.iflex.fic.global.GlobalParameters;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GLUtil;
import com.ofs.erm.gl.global.GlobalUtil;

public class GlobalSettingsDAO {

	 boolean rtnval= false;
	  Connection con = null;
     Statement smt = null;
     ResultSet rs = null;
	
	
	public String SaveDetails(String infodom,Vector v1) 
	{
	 

	  String rtnStr="";
	  
	 
		      	   /**  Tables inserted are  
		      	    *  
		      	    *   SETUP_PRODUCT_PROCESSORS
						setup_pp_gl_code
						SETUP_PP_BALANCE_COLUMNS
						SETUP_GL_BOOKS
						SETUP_GL_BAL_TYPE_MAPPING
						SETUP_GL_RECON_DIMENSIONS
						SETUP_RECON_DIM_COL_MAP
					* 
					*/
		  String[] vSqlArray = (String[])v1.toArray(new String[v1.size()]);
		  Cargo insertCargo = (Cargo) SMSServices.executeBatch(infodom,vSqlArray,true);
		  if (insertCargo == null || insertCargo.getErrorFlag())
   	       { 
			//  rtnStr = insertCargo.getPayLoadObject().toString();//"Error Saving Settings";
			  rtnStr = "Error Saving Settings";

			  
	  //	updateAuditTrail(infodom,user_id,"GL_MAPPING_MASTER",return_msg,"ERROR",map_id,"","");

	           }
             else
	         {  rtnStr = "Saved Successfully";
	         
	         }
	  
	  
		
		return rtnStr;
	}
	public Vector getPPinsertQry (LinkedHashMap ppstsM,String ppdetails,String ppglbalStr,String ppbalancecol)
	{
		Vector ppInsvec= new Vector();
		Vector delppVec = new Vector();
		 String action = "";
		  Set ppySet = ppstsM.keySet(); 
		  
		  String key1="";
	       Iterator iter = ppstsM.keySet().iterator();
	       
	       while(iter.hasNext())
	       {
	    	   key1 = iter.next().toString();
	    	   if(ppstsM.get(key1).equals("delete"))
	    		   delppVec.add(key1);
	       }
			     if(ppdetails !=null && !(ppdetails.equalsIgnoreCase("")))
			     {
				   String test[] = ppdetails.split("},");
				   LinkedHashMap lMap = new LinkedHashMap();
				   String tmpStr="";
				   Map ppMap = new LinkedHashMap();
				   
				  StringBuffer qryStr = new StringBuffer();
					
				  
				   for(int i=0;i<test.length;i++)
				   {    qryStr = new StringBuffer();
					   ppMap = new LinkedHashMap();
				   
					    tmpStr = test[i].toString();
				   
				  //  if(i==0)
				    //{
				    	
				    	tmpStr = tmpStr.substring(1);
				    	
				    //}
				    
				    if(i==(test.length-1))
				      {
				    	//tmpStr = tmpStr.substring(1);
				    	tmpStr = tmpStr.substring(0,tmpStr.length()-1);
				      }
				    
				    
				    String[] test1 = tmpStr.split(",");
				    for(int k=0;k<test1.length;k++)
				    {
				    	String[] t_1 = test1[k].split(":");
				    	if(t_1.length>1)
				    	{
				    	if(t_1[1].indexOf("-")!=-1)
				    		ppMap.put(t_1[0], t_1[1].substring(0,t_1[1].indexOf("-")));	
					    	else
					    		ppMap.put(t_1[0], t_1[1]);
				    	}else
				    	ppMap.put(t_1[0],"");
				    }
				    if(ppMap.get("phytab") != null)
				    {
				      String pptabname = ppMap.get("phytab").toString();
				     
				      if(ppySet.contains(pptabname))
				      {
				    	   action = ppstsM.get(pptabname).toString();
				    	   if(action.equalsIgnoreCase("new"))
				    	   {
				    		   qryStr.append("INSERT INTO SETUP_PRODUCT_PROCESSORS (V_TABLE_NAME,V_LOGIC_TABLE_NAME,V_DATASET_CODE,");
							   qryStr.append("V_EXPOSURE_ID_COL_NAME,V_COUNTERPARTY_ID_COL_NAME,V_MIS_DATE_COL_NAME,V_CREATED_USER,D_CREATED_DATE ) VALUES ('");
							   qryStr.append(ppMap.get("phytab")+"','"+ppMap.get("logtab")+"','"+ppMap.get("datasetcd")+"','"+ppMap.get("expid")+"','"+ppMap.get("custid")+"','"+ppMap.get("extdate")+"','"+ppMap.get("crtuser")+"',to_date('"+ppMap.get("crtdate")+"','mm/dd/yyyy'))");
							   ppInsvec.add(qryStr.toString());
				    	   }else if(action.equalsIgnoreCase("edit"))
				    	   {
				    		   qryStr.append(" UPDATE SETUP_PRODUCT_PROCESSORS SET ");
				    		   if(ppMap.get("logtab")!=null && ppMap.get("logtab")!="" && !(ppMap.get("logtab").equals("null")))
				    			   qryStr.append("  V_LOGIC_TABLE_NAME ='"+ppMap.get("logtab")+"'  , ");
				    		   qryStr.append(" V_DATASET_CODE = '"+ppMap.get("datasetcd")+"',");
							   qryStr.append(" V_EXPOSURE_ID_COL_NAME ='"+ppMap.get("expid")+"',V_COUNTERPARTY_ID_COL_NAME = '"+ppMap.get("custid")+"',V_MIS_DATE_COL_NAME = '"+ppMap.get("extdate")+"',");
							   qryStr.append(" V_MODIFIED_USER ='"+ppMap.get("moduser")+"',D_MODIFIED_DATE = to_date('"+ppMap.get("moddate")+"','mm/dd/yyyy')");
							   qryStr.append(" WHERE V_TABLE_NAME = '"+ppMap.get("phytab")+"' ");
							   ppInsvec.add(qryStr.toString());
				    	   }
				    	
				    	   
				    	   GL35Logger.logThis("ddddddddddddd......."+action+"ppMap.get(phytab).."+ppMap.get("phytab"));
				      }
				      
				      
				      
				      
				    }
				   
				     
					
				    //FilterServiceJSONClient.
					
				    
				   }
				   
			    }
			  String[] str23;
			     String[] str123;
			     String tabname="";
			     String qry="";
			     String[] ballogname = new String[2];
			     String[] tmpballogname = new String[2];
			     String[] insglcols = new String[2];
			  if(ppglbalStr !=null && !(ppglbalStr.equalsIgnoreCase("")))
				 {
				  /**setup_pp_gl_code V_TABLE_NAME
				      V_GL_CODE_COL_NAME
					  V_GL_CODE_LOGIC_COL_NAME
					  V_GL_BOOK_COL_NAME
					  V_GL_BOOK_LOGIC_COL_NAME   **/ 
					 GL35Logger.logThis("ppglbalStr..."+ppglbalStr);
				  Vector glcodeVec = new Vector();
				  
				   String[] strbal = ppglbalStr.split("#");
				   String tmpgl="";
				     for(int r=0;r<strbal.length;r++)
				     { 
				    	 if(strbal[r].indexOf(":")!=-1)
				    	 {
				    		 tabname = strbal[r].substring(0,strbal[r].indexOf(":"));
				    		 str123 = strbal[r].substring(strbal[r].indexOf(":")+1).split(",");
				    		 GL35Logger.logThis("tabname..."+tabname);
				    		 GL35Logger.logThis("str123..."+str123);
				    		 for(int j=0;j<str123.length;j++)
				    		 {
				    			// if(str123[j].indexOf("~")!=-1)
				    			// {
				    				 qry="";
				    				 GL35Logger.logThis("final qry333.."+str123[j]);
				    				 ballogname = str123[j].split("~");
				    				 GL35Logger.logThis("final ballogname.."+ballogname);
				    				 for(int k=0;k<ballogname.length;k++)
				    	    		 {// String[] inscol = ballogname[k].split("-");
				    			
				    				 if(ppySet.contains(tabname))
								      { 
				    					 GL35Logger.logThis("final ballogname[k].."+ballogname[k]); 
				    					 tmpgl =ballogname[k];
				    					 
				    					 GL35Logger.logThis("final tmpgl."+tmpgl); 
				    					 insglcols[0] = tmpgl.substring(0,tmpgl.indexOf("-"));
				    					 insglcols[1]= tmpgl.substring(tmpgl.indexOf("-")+1);
				    					 GL35Logger.logThis("final insglcols."+insglcols[0]); 
				    					  action = ppstsM.get(tabname).toString();
				    					    if(action.equalsIgnoreCase("new"))
								    	   {
								    		  
				    				           qry ="INSERT INTO setup_pp_gl_code( V_TABLE_NAME,V_GL_CODE_COL_NAME,V_GL_CODE_LOGIC_COL_NAME)VALUES ('"+tabname+"','"+insglcols[0]+"','"+insglcols[1]+"')"; 
				    				           ppInsvec.add(qry);
								    	   } else if(action.equalsIgnoreCase("edit"))
				  				    	   {
								    		  // String[] glcol =ballogname[k].split("-");
								    		 
								    		
								    		   qry = "   merge into setup_pp_gl_code t using (select 1 from DUAL) s "+
								    		         " on (t.v_table_name = '"+tabname+"' and t.v_gl_code_col_name = '"+insglcols[0]+"')"+
								    		         " when matched then  update set t.v_gl_code_logic_col_name = '"+insglcols[1]+"'"+
								    		         " when not matched then insert (v_table_name, v_gl_code_col_name, v_gl_code_logic_col_name)"+
								    		         " values ('"+tabname+"','"+insglcols[0]+"','"+insglcols[1]+"') ";
								    		   glcodeVec.add("'"+insglcols[0]+"'");
								    		   ppInsvec.add(qry); 
								    		  
				  				    	   }
				    				 
				    				 
				    				 
				    				  
								      }
				    	    		 }
			//	    				
				    			// }
				    			    			 
				    		 }
				    		 
				    		 if(glcodeVec!=null && glcodeVec.size()>0)
					    		{
					    			String glcols ="";
					    			glcols = glcodeVec.toString();
					    			glcols = glcols.substring(glcols.indexOf("[")+1,glcols.indexOf("]"));
					    			 qry = " DELETE FROM setup_pp_gl_code WHERE v_table_name = '"+tabname+"' AND v_gl_code_col_name NOT IN ("+glcols+") ";
						    		
					    			 ppInsvec.add(qry);
					    			
					    			
					    		}
				    		 
				    		
				    	 }
				     }
				 }
			  
			  if(ppbalancecol !=null && !(ppbalancecol.equalsIgnoreCase("")))
				 { 
				  
				   
				 /**   SETUP_PP_BALANCE_COLUMNS
				    V_TABLE_NAME
					V_BALANCE_COL_NAME
					V_BALANCE_LOGIC_COL_NAME  **/
				  Vector blVec = new Vector();
				  str23 = ppbalancecol.split("#");
				  String tmpbal="";
				     for(int r=0;r<str23.length;r++)
				     { 
				    	 if(str23[r].indexOf(":")!=-1)
				    	 {
				    		 tabname = str23[r].substring(0,str23[r].indexOf(":"));
				    		 str123 = str23[r].substring(str23[r].indexOf(":")+1).split(",");
				    		
				    		// GL35Logger.logThis("final quesry is..."+qry);
				    		 String sBal = "";
				    		 blVec = new Vector();
				    		 for(int j=0;j<str123.length;j++)
				    		 {
				    			 GL35Logger.logThis("final query is..."+str123[j]);
				    			 if(str123[j].indexOf("-")!=-1)
				    			 {
				    				 tmpbal = str123[j].toString();
				    				
				    				 tmpballogname[0] = tmpbal.substring(0,tmpbal.indexOf("-"));
				    				 tmpballogname[1]= tmpbal.substring(tmpbal.indexOf("-")+1);
				    				 GL35Logger.logThis("final query is..."+str123[j]);
				    				 qry ="";
				    				 if(ppySet.contains(tabname))
								      { 
				    					 
				    					  action = ppstsM.get(tabname).toString();
								    	   if(action.equalsIgnoreCase("new"))
								    	   {
				    				         qry ="INSERT INTO SETUP_PP_BALANCE_COLUMNS( V_TABLE_NAME,V_BALANCE_COL_NAME,V_BALANCE_LOGIC_COL_NAME)VALUES ('"+tabname+"','"+tmpballogname[0]+"','"+tmpballogname[1]+"')";
				    				         ppInsvec.add(qry);
								    	   
								    	   }  else if(action.equalsIgnoreCase("edit"))
				  				    	   {
								    		 // qry ="UPDATE SETUP_PP_BALANCE_COLUMNS SET V_BALANCE_COL_NAME ='"+ballogname[0]+"',V_BALANCE_LOGIC_COL_NAME  ='"+ballogname[1]+"' WHERE V_TABLE_NAME ='"+tabname+"'";
								    		   qry = " merge into SETUP_PP_BALANCE_COLUMNS t  "+
								    		         " using (select 1 from DUAL) s "+
								    		         " on (t.v_table_name = '"+tabname+"' and t.v_balance_col_name = '"+tmpballogname[0]+"') "+
								    		         " when matched then "+
								    		         " update set t.v_balance_logic_col_name ='"+tmpballogname[1]+"' "+
								    		         " when not matched then  "+
								    		         " insert(v_table_name, v_balance_col_name, v_balance_logic_col_name)  "+
								    		         " values('"+tabname+"','"+tmpballogname[0]+"','"+tmpballogname[1]+"') ";
								    		   
								    		   blVec.add("'"+tmpballogname[0]+"'");
								    		   ppInsvec.add(qry);
								    		   
				  				    	   }
								    	   GL35Logger.logThis("final quesry is..."+qry);   
				    				       
								      }
				    			   
				    			 }
				    		 }
				    		 
				    		if(blVec!=null && blVec.size()>0)
				    		{
				    			String balcols ="";
				    			 balcols = blVec.toString();
				    			 balcols = balcols.substring(balcols.indexOf("[")+1,balcols.indexOf("]"));
				    			 qry = " DELETE FROM SETUP_PP_BALANCE_COLUMNS WHERE v_table_name = '"+tabname+"' AND v_balance_col_name NOT IN ("+balcols+") ";
					    		
				    			 ppInsvec.add(qry);
				    			
				    			
				    		}
				    	 }
				    	 
				    	
				     }
					 
				 }
			 
			 if(delppVec!=null && delppVec.size()>0)
			 { GL35Logger.logThis("final quesry is..."+delppVec.toString());   
				 for (int k=0;k<delppVec.size();k++)
				 {
					 
					 ppInsvec.add(" DELETE FROM setup_pp_gl_code WHERE V_TABLE_NAME = '"+delppVec.get(k)+"' ");
					 ppInsvec.add(" DELETE FROM SETUP_PP_BALANCE_COLUMNS WHERE V_TABLE_NAME = '"+delppVec.get(k)+"' ");
					 ppInsvec.add(" DELETE FROM SETUP_PRODUCT_PROCESSORS WHERE V_TABLE_NAME = '"+delppVec.get(k)+"' "); 
				 }
				 
							 
			 }
		
		return ppInsvec;
	}
	
	public Vector getGLinsertQry (String infodom,LinkedHashMap glstsM,String gldetails)
	{
		Vector glInsvec= new Vector();
		LinkedHashMap setpMap= new LinkedHashMap();
		/** get the 'INTRA GROUP','GL TYPE','GL BOOK' from the reveleus_parameter_master table**/
		
		  String sQry ="select v_param_code,V_PARAM_VALUE from reveleus_parameter_master t where t.v_param_code in ('INTRA GROUP','GL TYPE','GL BOOK')";

		  Cargo rtnCargo = (Cargo) SMSServices.executeQuery(infodom,sQry ,false);
		
		  DACRecordSet resSet = (DACRecordSet) rtnCargo.getPayLoadObject();
	    	 while (!resSet.EOF() && resSet.getRowCount()>0 )
		    	{
	    		 setpMap.put(resSet.fetchElement(1), resSet.fetchElement(2));
	    		 
	    		 resSet.moveNext();
		    	}
		
		/**  **/
		Vector delglVec = new Vector();
		 String action = "";
		  Set glSet = glstsM.keySet();
		  
		  Iterator iter = glstsM.keySet().iterator();
	       String key1="";
	       while(iter.hasNext())
	       {
	    	   key1 = iter.next().toString();
	    	   if(glstsM.get(key1).equals("delete"))
	    		   delglVec.add(key1);
	       }
		 if(gldetails !=null && !(gldetails.equalsIgnoreCase("")))
		 {
		   
		   String gltest[] = gldetails.split("},");
		   LinkedHashMap glMap = new LinkedHashMap();
		   String gltmpStr="";
		   LinkedHashMap phylogMap = new LinkedHashMap();
		  // Map gl_Map = new LinkedHashMap();
		   
		   StringBuffer glqryStr = new StringBuffer();
			String balQry="";
		  
		   for(int i=0;i<gltest.length;i++)
		   {    
			   glqryStr = new StringBuffer();
		        glMap = new LinkedHashMap();
		       
		        phylogMap = new LinkedHashMap();
		   gltmpStr = gltest[i].toString();
		   
		  //  if(i==0)
		    //{
		    	
		   gltmpStr = gltmpStr.substring(1);
		    	
		    //}
		    
		    if(i==(gltest.length-1))
		      {
		    	//tmpStr = tmpStr.substring(1);
		    	gltmpStr = gltmpStr.substring(0,gltmpStr.length()-1);
		      }
		    
		    
		    String[] test1 = gltmpStr.split(",");
		    for(int k=0;k<test1.length;k++)
		    {
		    	String[] t_1 = test1[k].split(":");
		    	
		    	
		    	if(t_1.length>1)
	    		{
		    		if(t_1[1].indexOf("-")!=-1)
		    		{
	    		    	 glMap.put(t_1[0], t_1[1].substring(0,t_1[1].indexOf("-")));	
	    		    	 phylogMap.put(t_1[0], t_1[1].substring((t_1[1].indexOf("-")+1)));
		    		}
		    	    else
		    	         glMap.put(t_1[0], t_1[1]);
		    }else
    			 glMap.put(t_1[0], "");
		    }
		   // String uniq = glMap.get("bookcode").toString()+"~"+glMap.get("phytab").toString();
		    String uniq = glMap.get("phytab").toString();
		    String balStr="";
		    String[] balAry ;
		    String[] bookAry ;
		    String[] balValues;
		    String bookval="";
		    if(glSet.contains(uniq))
		      {
		    	   action = glstsM.get(uniq).toString();
		    	   if(action.equalsIgnoreCase("new"))
		    	   {
		                glqryStr.append("INSERT INTO SETUP_GL_SOURCE (V_TABLE_NAME,V_LOGIC_TABLE_NAME,V_DATASET_CODE,V_GL_CODE_COL_NAME,V_GL_CODE_LOGIC_COL_NAME,");
					    glqryStr.append("V_CONSLDTN_FLAG_COL_NAME,V_CONSLDTN_FLAG_LOGIC_COL_NAME,V_GL_HCY_CODE,V_MIS_DATE_COL_NAME,V_MIS_DATE_LOGIC_COL_NAME,V_CREATED_USER,");
					    glqryStr.append("D_CREATED_DATE,V_GL_HCY_DIM_TABLE_NAME,V_GL_HCY_GL_BOOK_COL_NAME,V_GL_HCY_GL_TYPE_COL_NAME,V_GL_HCY_INTRA_GROUP_COL_NAME ) VALUES (");
					    glqryStr.append("'"+glMap.get("phytab")+"','"+glMap.get("logtab")+"','"+glMap.get("datasetcd")+"','"+glMap.get("glcol")+"','"+phylogMap.get("glcol"));
					    glqryStr.append("','"+glMap.get("booktype")+"','"+phylogMap.get("booktype")+"','"+glMap.get("glhiercode")+"','"+glMap.get("gldate")+"','"+phylogMap.get("gldate")+"'");
					    glqryStr.append(",'"+glMap.get("crtuser")+"',to_date('"+glMap.get("crtdate")+"','mm/dd/yyyy'),'"+glMap.get("glhiertable")+"','"+setpMap.get("GL BOOK")+"','"+setpMap.get("GL TYPE")+"','"+setpMap.get("INTRA GROUP")+"')");
					    
					    glInsvec.add(glqryStr.toString());
					    
					    if(glMap.get("bookcode")!=null)
					    {
					    	
					    	bookval = glMap.get("bookcode").toString();
					    	
					    	bookAry =bookval.split("~");
					    	for(int t=0;t<bookAry.length;t++)
					    	{
					    	glqryStr = new StringBuffer();
					    	glqryStr.append("INSERT INTO  SETUP_GL_BOOKS (v_table_name,v_gl_book) values ('"+glMap.get("phytab")+"','"+bookAry[t]+"')");
					    	glInsvec.add(glqryStr.toString());
					    	}
					    }
					    if(glMap.get("balancetype")!=null)
					    {
					    balStr = glMap.get("balancetype").toString();
					    balAry = balStr.split("@");
					     for(int q=0;q<(balAry.length);q++)
					     {
					    	 
					    	 balValues = balAry[q].split("~");
					    	 if(balValues!=null && balValues.length>0)
					    	 {  
					    		 if(balValues[1]!=null && !(balValues[1].equalsIgnoreCase("D")))
					    		 {
					    			 balQry = "INSERT INTO SETUP_GL_BAL_TYPE_MAPPING(V_TABLE_NAME,V_BALANCE_TYPE,V_BALANCE_COL_NAME) VALUES('"+glMap.get("phytab")+"','"+balValues[0]+"','"+balValues[1]+"')";
					    		 
							           glInsvec.add(balQry);
					    		 }
					    	 }
					    	 
					     }
					    					    
					    }
					   // balQry = "INSERT INTO SETUP_GL_BOOKS(V_GL_BOOK,V_TABLE_NAME,V_BALANCE_TYPE,V_BALANCE_COL_NAME) VALUES('"+glMap.get("bookcode")+"','"+glMap.get("phytab")+"','EOP','"+glMap.get("EOP")+"')";
					   // glInsvec.add(balQry);
					    
					 /**   balQry = "INSERT INTO SETUP_GL_BAL_TYPE_MAPPING(V_GL_BOOK,V_TABLE_NAME,V_BALANCE_TYPE,V_BALANCE_COL_NAME) VALUES('"+glMap.get("bookcode")+"','"+glMap.get("phytab")+"','EOP','"+glMap.get("EOP")+"')";
					    glInsvec.add(balQry);
					    balQry = "INSERT INTO SETUP_GL_BAL_TYPE_MAPPING(V_GL_BOOK,V_TABLE_NAME,V_BALANCE_TYPE,V_BALANCE_COL_NAME) VALUES('"+glMap.get("bookcode")+"','"+glMap.get("phytab")+"','M','"+glMap.get("M")+"')";
					    glInsvec.add(balQry);
					    balQry = "INSERT INTO SETUP_GL_BAL_TYPE_MAPPING(V_GL_BOOK,V_TABLE_NAME,V_BALANCE_TYPE,V_BALANCE_COL_NAME) VALUES('"+glMap.get("bookcode")+"','"+glMap.get("phytab")+"','Y','"+glMap.get("Y")+"')";
					    **/
					    
					    
					  //  glInsvec.add(balQry);  
					    	 
				    }else if(action.equalsIgnoreCase("edit"))
			    	{
				    	    glqryStr.append(" UPDATE SETUP_GL_SOURCE SET V_DATASET_CODE = '"+glMap.get("datasetcd")+"' ,V_GL_CODE_COL_NAME ='"+glMap.get("glcol")+"',V_GL_CODE_LOGIC_COL_NAME = '"+phylogMap.get("glcol")+"', ");
				    	    glqryStr.append(" V_MIS_DATE_COL_NAME = '"+glMap.get("gldate")+"',V_MIS_DATE_LOGIC_COL_NAME = '"+phylogMap.get("gldate")+"', V_CONSLDTN_FLAG_COL_NAME = '"+glMap.get("booktype")+"' ,V_CONSLDTN_FLAG_LOGIC_COL_NAME = '"+phylogMap.get("booktype")+"' ,");
						    glqryStr.append(" V_GL_HCY_CODE = '"+glMap.get("glhiercode")+"' ,V_MODIFIED_USER = '"+glMap.get("moduser")+"',D_MODIFIED_DATE = to_date('"+glMap.get("moddate")+"','mm/dd/yyyy')");
						    glqryStr.append(",V_GL_HCY_DIM_TABLE_NAME = '"+glMap.get("glhiertable")+"',V_GL_HCY_GL_BOOK_COL_NAME = '"+setpMap.get("GL BOOK")+"',V_GL_HCY_GL_TYPE_COL_NAME = '"+setpMap.get("GL TYPE")+"',V_GL_HCY_INTRA_GROUP_COL_NAME = '"+setpMap.get("INTRA GROUP")+"' ");
						    glqryStr.append(" WHERE  V_TABLE_NAME = '"+glMap.get("phytab")+"' ");
						    
						    //V_GL_BOOK = '"+glMap.get("bookcode")+"'
						    glInsvec.add(glqryStr.toString());
						    String chkcodes ="";
						    glInsvec.add(" DELETE FROM SETUP_GL_BOOKS WHERE   V_TABLE_NAME = '"+glMap.get("phytab")+"' ");
						    if(glMap.get("bookcode")!=null)
						    {
						    	bookval = glMap.get("bookcode").toString();
						    	
						    	bookAry =bookval.split("~");
						    	for(int t=0;t<bookAry.length;t++)
						    	{
						    	glqryStr = new StringBuffer();
						     	glqryStr.append("INSERT INTO  SETUP_GL_BOOKS (v_table_name,v_gl_book) values ('"+glMap.get("phytab")+"','"+bookAry[t]+"')");
						    /**	glqryStr.append(" merge into SETUP_GL_BOOKS t  using (select 1 from DUAL) s   ");
						    	glqryStr.append("on (v_table_name = '"+glMap.get("phytab")+"' when matched then  )  ");
						     	glqryStr.append("update set v_gl_book = '"+bookAry[t]+"' ");
						    	glqryStr.append("when not matched then insert(v_table_name,v_gl_book)   ");
						    	glqryStr.append(" values('"+glMap.get("phytab")+"','"+bookAry[t]+"') ");
				    	**/
						    	
						    	glInsvec.add(glqryStr.toString());
						    	}
						    }
						    if(glMap.get("balancetype")!=null)
						    {
						    balStr = glMap.get("balancetype").toString();
						    balAry = balStr.split("@");
						     for(int q=0;q<(balAry.length);q++)
						     {
						    	
						    	 balValues = balAry[q].split("~");
						    	 if(balValues!=null && balValues.length>0)
						    	 {
						    		 
						    		 if(balValues[1].equalsIgnoreCase("D"))
							    	 {	
						    			 
						    			  balQry = " DELETE SETUP_GL_BAL_TYPE_MAPPING where   v_table_name = '"+glMap.get("phytab")+"' and  "+
						    			           " V_BALANCE_TYPE = '"+balValues[0]+"'  ";
						    			 
						    			  glInsvec.add(balQry);
							    	 }else
							    	 {
						    		   balQry = "   merge into SETUP_GL_BAL_TYPE_MAPPING t    "+
					    		         "  using (select 1 from DUAL) s  "+
					    		         "  on (   t.v_table_name = '"+glMap.get("phytab")+"' and t.V_BALANCE_TYPE = '"+balValues[0]+"')  "+
					    		         " when matched then "+
					    		         "  update set t.V_BALANCE_COL_NAME = '"+balValues[1]+"'  "+
					    		         " when not matched then  "+
					    		         "  insert(v_table_name, V_BALANCE_TYPE, V_BALANCE_COL_NAME)    "+
					    		         "  values('"+glMap.get("phytab")+"','"+balValues[0]+"','"+balValues[1]+"') ";
					    	
						    		//   balQry = "UPDATE SETUP_GL_BAL_TYPE_MAPPING SET V_BALANCE_COL_NAME = '"+balValues[1]+"'  WHERE V_GL_BOOK = '"+glMap.get("bookcode")+"' AND V_TABLE_NAME = '"+glMap.get("phytab")+"' AND V_BALANCE_TYPE ='"+balValues[0]+"'";
						    		   glInsvec.add(balQry);
							    	 }
								          
						    	 }
						    	 
						     }
						    					    
						    }
						    
						    
						    
						  /**
						      balQry = "UPDATE SETUP_GL_BAL_TYPE_MAPPING SET V_BALANCE_COL_NAME = '"+glMap.get("EOP")+"'  WHERE V_GL_BOOK = '"+glMap.get("bookcode")+"' AND V_TABLE_NAME = '"+glMap.get("phytab")+"' AND V_BALANCE_TYPE ='EOP'";
						      glInsvec.add(balQry);
						      balQry = "UPDATE SETUP_GL_BAL_TYPE_MAPPING SET V_BALANCE_COL_NAME = '"+glMap.get("M")+"'  WHERE V_GL_BOOK = '"+glMap.get("bookcode")+"' AND V_TABLE_NAME = '"+glMap.get("phytab")+"' AND V_BALANCE_TYPE ='M'";
						      glInsvec.add(balQry);
						      balQry = "UPDATE SETUP_GL_BAL_TYPE_MAPPING SET V_BALANCE_COL_NAME = '"+glMap.get("Y")+"'  WHERE V_GL_BOOK = '"+glMap.get("bookcode")+"' AND V_TABLE_NAME = '"+glMap.get("phytab")+"' AND V_BALANCE_TYPE ='Y'";
						      glInsvec.add(balQry); 
						    
						     */
			    	}
		    // GL35Logger.logThis("qryStr......."+glqryStr);
		    //FilterServiceJSONClient.
			// qryVector.add(glqryStr.toString());
		      }
		   
		   }
		 }
		 String glsrc= "";
		 if(delglVec!=null && delglVec.size()>0)
		 {
			 for (int k=0;k<delglVec.size();k++)
			 {
				  glsrc= delglVec.get(k).toString();
				  if(glsrc!=null && glsrc.indexOf("~")!=-1)
				  {
				  String[] glv = glsrc.split("~");
				  glInsvec.add(" DELETE FROM SETUP_GL_BAL_TYPE_MAPPING WHERE  V_TABLE_NAME = '"+glv[1]+"' ");
				  glInsvec.add(" DELETE FROM SETUP_GL_BOOKS WHERE V_GL_BOOK = '"+glv[0]+"' AND V_TABLE_NAME = '"+glv[1]+"' ");
					
				  }
			 }
			 
						 
		 } 
	 
	 
		
		return glInsvec;
		
	}
	public String getPPdetails(String sinfodom,Map dsmap)
	{
		 //  String ppQry = "SELECT V_TABLE_NAME,V_LOGIC_TABLE_NAME,V_DATASET_CODE,V_EXPOSURE_ID_COL_NAME,V_COUNTERPARTY_ID_COL_NAME,V_MIS_DATE_COL_NAME,V_CREATED_USER,TO_CHAR(D_CREATED_DATE,'mm/dd/yyyy'),V_MODIFIED_USER,TO_CHAR(D_MODIFIED_DATE,'mm/dd/yyyy')  FROM SETUP_PRODUCT_PROCESSORS ";
		  String ppQry = " select V_TABLE_NAME,MAX(V_LOGIC_TABLE_NAME),MAX(V_DATASET_CODE),MAX(V_EXPOSURE_ID_COL_NAME),MAX(V_COUNTERPARTY_ID_COL_NAME),MAX(V_MIS_DATE_COL_NAME), "+
		                 " MAX(V_CREATED_USER),MAX(D_CREATED_DATE),MAX(V_MODIFIED_USER),MAX(D_MODIFIED_DATE),  MAX(v_gl_code_col_name)  as glcolumn,"+
		                 "   MAX(v_balance_col_name) as balancecolumn FROM "+
		                 " (  SELECT V_TABLE_NAME,V_LOGIC_TABLE_NAME,V_DATASET_CODE,V_EXPOSURE_ID_COL_NAME,V_COUNTERPARTY_ID_COL_NAME, V_MIS_DATE_COL_NAME, V_CREATED_USER, to_char(D_CREATED_DATE, 'mm/dd/yyyy') D_CREATED_DATE, "+
		                 "  V_MODIFIED_USER,to_char(D_MODIFIED_DATE, 'mm/dd/yyyy') D_MODIFIED_DATE,NULL AS v_gl_code_col_name, "+
		                 " NULL AS v_balance_col_name FROM SETUP_PRODUCT_PROCESSORS "+
		                 " union all select v_table_name,NULL AS V_LOGIC_TABLE_NAME,NULL AS V_DATASET_CODE,NULL AS V_EXPOSURE_ID_COL_NAME,NULL AS V_COUNTERPARTY_ID_COL_NAME, "+
		                 " NULL AS V_MIS_DATE_COL_NAME,NULL AS V_CREATED_USER,NULL AS D_CREATED_DATE,NULL AS V_MODIFIED_USER,NULL AS D_MODIFIED_DATE, "+
		                 "  ltrim(sys_connect_by_path(v_gl_code_col_name||'-'||V_GL_CODE_LOGIC_COL_NAME,','),',') v_gl_code_col_name,"+
		                 "  NULL AS v_balance_col_name  from ( select row_number() over (partition by v_table_name order by v_gl_code_col_name) r, "+
		                 "  count(v_gl_code_col_name) over (partition by v_table_name) cnt,s.*  from setup_pp_gl_code s ) s1  where level = cnt   "+
		                 "  connect by v_table_name = prior v_table_name and r = prior r - 1  union all "+
		                 "  select v_table_name,NULL AS V_LOGIC_TABLE_NAME,NULL AS V_DATASET_CODE,NULL AS V_EXPOSURE_ID_COL_NAME,NULL AS V_COUNTERPARTY_ID_COL_NAME, "+
		                 " NULL AS V_MIS_DATE_COL_NAME,NULL AS V_CREATED_USER,NULL AS D_CREATED_DATE,NULL AS V_MODIFIED_USER,NULL AS D_MODIFIED_DATE,NULL AS v_gl_code_col_name, "+
		                 "  ltrim(sys_connect_by_path(v_balance_col_name||'-'||v_balance_logic_col_name,','),',') v_balance_col_name from  ( select row_number() over (partition by v_table_name order by v_balance_col_name) r, "+
		                 "  count(v_balance_col_name) over (partition by v_table_name) cnt,s.*   from SETUP_PP_BALANCE_COLUMNS s ) s1  where level = cnt         "+
		                 "  connect by v_table_name = prior v_table_name and r = prior r - 1  ) PP_DETAILS group by v_table_name order by 1  ";
		                 
		   StringBuffer sb = new StringBuffer();
		   String ppval="";
		   int i = 0;
		   try{
				sb.append("{");
				sb.append("\"ppdetails\": {");
				
				Cargo cortCargo = (Cargo) SMSServices.executeQuery(sinfodom,ppQry,false);
		    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
		
				
		    	 while (!rs.EOF() && rs.getRowCount()>0 )
		    	 {	
					if(i > 0) {
						sb.append(", ");
					}
					
					 sb.append("\""+i+"\": [");
					 sb.append("{\"phytab\": " + "\"" +  rs.fetchElement(1)+ "\"" + "}, ");
					 sb.append("{\"logtab\": " + "\"" +  rs.fetchElement(2)+ "\"" + "}, ");
					 sb.append("{\"datasetcd\": " + "\"" +rs.fetchElement(3) + "\"" + "}, ");
					 sb.append("{\"expid\": " + "\"" + rs.fetchElement(4)+ "\"" + "}, ");
					 sb.append("{\"custid\": " + "\"" +  rs.fetchElement(5)+ "\"" + "}, ");
					 sb.append("{\"extdate\": " + "\"" +rs.fetchElement(6) + "\"" + "}, ");
					 sb.append("{\"crtuser\": " + "\"" + rs.fetchElement(7)+ "\"" + "}, ");
					 sb.append("{\"crtdate\": " + "\"" +rs.fetchElement(8) + "\"" + "}, ");
					 sb.append("{\"moduser\": " + "\"" + rs.fetchElement(9)+ "\"" + "}, ");
					 sb.append("{\"moddate\": " + "\"" + rs.fetchElement(10)+ "\"" + "}, ");
					 sb.append("{\"datasetdesc\": " + "\"" +dsmap.get(rs.fetchElement(3))+ "\"" + "}, ");
					 sb.append("{\"glcolumn\": " + "\"" + rs.fetchElement(11)+ "\"" + "}, ");
					 sb.append("{\"balancecolumn\": " + "\"" + rs.fetchElement(12)+ "\"" + "} ");
				
					 sb.append("]");	
		 		
					
					i = i+1;
					rs.moveNext();
				}
				sb.append("}");
				sb.append("}");
			
		            
			
			
			
			if(i>0)
			{
				ppval = sb.toString();
				GL35Logger.logThis("ppval..."+ppval);
				//FSAPPLogger.logMessage(tpConstants.LOG_APP_NAME,"termsval...."+termsval, Priority.INFO);
			}
			
			
		   } catch (Exception sqle) {
				
				sqle.printStackTrace();
					
			}
	return ppval;
	}	
	
	public String getGLdetails(String sinfodom,Map dsmap,String hiercode,String userid,String locale)
	{
		//   String ppQry = "SELECT V_GL_BOOK,V_TABLE_NAME,V_LOGIC_TABLE_NAME,V_DATASET_CODE,V_GL_CODE_COL_NAME,V_GL_BOOK_COL_NAME,V_GL_HCY_CODE,V_CREATED_USER,TO_CHAR(D_CREATED_DATE,'mm/dd/yyyy'),V_MODIFIED_USER,TO_CHAR(D_MODIFIED_DATE,'mm/dd/yyyy')  FROM SETUP_GL_BOOKS ";
		 String ppQry = " SELECT GL_FNL.*,LTRIM(SYS_CONNECT_BY_PATH(V_GL_BOOK,'@'),'@') V_GL_BOOK_LST FROM (SELECT GL.*, "+
			            " ROW_NUMBER() OVER(PARTITION BY V_TABLE_NAME ORDER BY V_GL_BOOK) ROW_N,COUNT(*) OVER(PARTITION BY V_TABLE_NAME) B_CNT, "+
			            " LTRIM(REPLACE(SYS_CONNECT_BY_PATH(V_BALANCE_TYPE || '$' || V_BALANCE_COL_NAME,'@'),'$','~'),'@') BAL_TYPE_COL_NAME "+
			            " FROM (SELECT B.V_GL_BOOK,S.V_TABLE_NAME,S.V_LOGIC_TABLE_NAME,S.V_DATASET_CODE,S.V_GL_CODE_COL_NAME || '-' || S.V_GL_CODE_LOGIC_COL_NAME, "+
			            " S.V_CONSLDTN_FLAG_COL_NAME || '-' || S.V_CONSLDTN_FLAG_LOGIC_COL_NAME,S.V_GL_HCY_CODE,S.V_CREATED_USER, "+
			            " TO_CHAR(S.D_CREATED_DATE, 'mm/dd/yyyy'), S.V_MODIFIED_USER,TO_CHAR(S.D_MODIFIED_DATE, 'mm/dd/yyyy'), "+
			            " M.V_BALANCE_TYPE, M.V_BALANCE_COL_NAME,V_MIS_DATE_COL_NAME || '-' || S.V_MIS_DATE_LOGIC_COL_NAME,s.v_gl_hcy_dim_table_name, "+
			            " ROW_NUMBER() OVER(PARTITION BY S.V_TABLE_NAME,B.V_GL_BOOK ORDER BY V_BALANCE_TYPE) RN, "+
			            " COUNT(*) OVER(PARTITION BY S.V_TABLE_NAME,B.V_GL_BOOK) CNT, I.DESCRIPTION "+
			            " FROM SETUP_GL_SOURCE S,SETUP_GL_BOOKS B, SETUP_GL_BAL_TYPE_MAPPING M, FSI_GL_LEDGER_INDICATOR_MLS I  WHERE S.V_TABLE_NAME = B.V_TABLE_NAME "+
			            " AND S.V_TABLE_NAME = M.V_TABLE_NAME AND I.MLS_CD ='"+locale+"' AND S.n_Ledger_Ind = i.n_ledger_indicator) GL   WHERE CNT = LEVEL   CONNECT BY PRIOR V_TABLE_NAME = V_TABLE_NAME "+
			            " AND PRIOR V_GL_BOOK = V_GL_BOOK  AND PRIOR RN = RN + 1 ) GL_FNL WHERE B_CNT = LEVEL "+
		                " CONNECT BY PRIOR V_TABLE_NAME = V_TABLE_NAME   AND PRIOR ROW_N = ROW_N + 1 ";

		  StringBuffer sb = new StringBuffer();
		   String glval="";
		   int i = 0;
		  
		  
		   LinkedHashMap bookMap = new LinkedHashMap(); 
		   bookMap = GlobalUtil.getHierNodeDesc(sinfodom, userid, hiercode);
		   
		   try{
				sb.append("{");
				sb.append("\"gldetails\": {");
				
				Cargo cortCargo = (Cargo) SMSServices.executeQuery(sinfodom,ppQry,false);
		    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
			
				String balval="";
				String glhierdesc="";
				
				 while (!rs.EOF() && rs.getRowCount()>0 )
			    	{
				
					
					if(i > 0) {
						sb.append(", ");
					}
					String bookddet ="";
					glhierdesc = GLUtil.getHierarchyDesc(sinfodom, userid, rs.fetchElement(7));
					String bookval = rs.fetchElement("V_GL_BOOK_LST");
					GL35Logger.logThis("bookMap..."+bookMap.toString());
					GL35Logger.logThis("bookval..."+bookval);
					 sb.append("\""+i+"\": [");
					if(bookval!=null &&  bookval!="")
					{
						 if(bookval.indexOf("@")!=-1)
						 {
							 String[] books = bookval.split("@"); 
							  for(int k=0;k<books.length;k++)
							  {  
								  if(bookMap.get(books[k])!=null &&  bookMap.get(books[k])!="")
									   bookddet =  bookddet+books[k]+"~"+ bookMap.get(books[k])+"{*}";
									 else 
									   bookddet =  bookddet+books[k]+"~"+ books[k]+"{*}";
							     
							  }
						 }else
						 {
							 if(bookMap.get(bookval)!=null &&  bookMap.get(bookval)!="")
								    bookddet = bookval+"~"+ bookMap.get(bookval)+"{*}";
								 else 
									bookddet = bookval+"~"+ bookval+"{*}";
								
						 }
						 sb.append("{\"booktype\": " + "\"" + bookddet+ "\"" + "}, ");
					}else
						 sb.append("{\"booktype\": " + "\"" + "-"+ "\"" + "}, ");
					
					GL35Logger.logThis("bookddet..."+bookddet);
					 sb.append("{\"phytab\": " + "\"" +  rs.fetchElement(2)+ "\"" + "}, ");
					 sb.append("{\"logtab\": " + "\"" +rs.fetchElement(3) + "\"" + "}, ");
					 sb.append("{\"dataset\": " + "\"" + rs.fetchElement(4)+ "\"" + "}, ");
					 sb.append("{\"glcol\": " + "\"" + rs.fetchElement(5)+ "\"" + "}, ");
					 sb.append("{\"booktype\": " + "\"" + rs.fetchElement(6)+ "\"" + "}, ");
					 sb.append("{\"glhiercode\": " + "\"" + rs.fetchElement(7)+ "\"" + "}, ");
					 sb.append("{\"crtuser\": " + "\"" + rs.fetchElement(8)+ "\"" + "}, ");
					 sb.append("{\"crtdate\": " + "\"" +rs.fetchElement(9) + "\"" + "}, ");
					 sb.append("{\"moduser\": " + "\"" + rs.fetchElement(10)+ "\"" + "}, ");
					 sb.append("{\"moddate\": " + "\"" + rs.fetchElement(11)+ "\"" + "}, ");
					 sb.append("{\"glhierdesc\": " + "\"" + glhierdesc+ "\"" + "}, ");
					 sb.append("{\"gldate\": " + "\"" + rs.fetchElement(14)+ "\"" + "}, ");
					 sb.append("{\"datasetdesc\": " + "\"" +dsmap.get(rs.fetchElement(4))+ "\"" + "}, ");
					 sb.append("{\"glhiertable\": " + "\"" + rs.fetchElement(15)+ "\"" + "}, ");
					 sb.append("{\"balancetype\": " + "\"" + rs.fetchElement(20)+ "\"" + "}, ");
					 sb.append("{\"ledgerIndicator\": " + "\"" + rs.fetchElement("DESCRIPTION")+ "\"" + "} ");
					
					
					 sb.append("]");	
		 		
					
					i = i+1;
					rs.moveNext();
				}
				sb.append("}");
				sb.append("}");
			
		
			
			
			
			if(i>0)
			{
				glval = sb.toString();
				GL35Logger.logThis("GLval..."+glval);
				//FSAPPLogger.logMessage(tpConstants.LOG_APP_NAME,"termsval...."+termsval, Priority.INFO);
			}
			
			
		   } catch (Exception sqle) {
				
				sqle.printStackTrace();
					
			}
	return glval;
	}
	public int isPPmapexists(String infodom,String ppname,String dscs,String alldscode,String locale)
	{
		int ppcount=0;
		 String ppQry = "select count(1)  from FSI_GL_MAPPING_MASTER m ,FSI_GL_MAP_RECON_TARGETS p"+
                        " where m.v_gl_map_id = p.v_gl_map_id and m.n_version_number = p.n_version_number and "+
                        " p.v_table_name = '"+ppname+"'  and m.F_IS_DELETED ='N'";
		 try
		 {
		   
			Cargo cortCargo = (Cargo) SMSServices.executeQuery(infodom,ppQry,false);
	    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
	    	 while (!rs.EOF() && rs.getRowCount()>0 ){
					if(rs.fetchElement(1)!="" && rs.fetchElement(1) !=null)
					ppcount = Integer.parseInt(rs.fetchElement(1));
					
					rs.moveNext();
					
				}
	    	 GL35Logger.logThis("ppQry..."+ppQry+"..ppcount.."+ppcount);
	    	 if(ppcount==0)
	    	 {
	    		 
	    		 //Check if the PP Dataset dimensions are mapped to Recon DImeniosn
	    		 ppcount = GlobalSettingsDAO.getPPBookDSMap(infodom, dscs, alldscode, locale);
	    		 
	    	 }
				GL35Logger.logThis("ppQry..."+ppQry+"..ppcount.."+ppcount);
		    }catch (Exception sqle) {					
					sqle.printStackTrace();
						
				}
		return ppcount;
	}
	
	
	public int isGLbooktypeexists(String infodom,String booktype,String dscs,String alldscode,String locale)
	{
		 int bookcount=0;
		 String book_code="";
		 String tmpcode= "";
			 tmpcode = booktype.toUpperCase();
		   String books[] =  tmpcode.split("~");
		   for(int k=0;k<books.length;k++)
		   {
			   if(k==0)
				   book_code = "'"+books[k]+"'";
			   else if (k==books.length-1)
				   book_code =book_code+",'"+books[k]+"'";
			  
		   }
		   GL35Logger.logThis("book_code..."+book_code);
		 String bookQry = "select count(1) from FSI_GL_MAPPING_MASTER where upper(v_gl_book) in ("+book_code+")  and F_IS_DELETED ='N' ";
                      
		 try
		 {
		
			Cargo cortCargo = (Cargo) SMSServices.executeQuery(infodom,bookQry,false);
	    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
	    	 while (!rs.EOF() && rs.getRowCount()>0 ) {
					if(rs.fetchElement(1)!="" && rs.fetchElement(1) !=null)
					bookcount = Integer.parseInt(rs.fetchElement(1));
					rs.moveNext();
				}
	    	 
	    	 GL35Logger.logThis("bookQry..."+bookQry+"..ppcount.."+bookcount);
	    	 if(bookcount ==0)
	    	 {
	    		 
	    		 //Check if the PP Dataset dimensions are mapped to Recon DImeniosn
	    		 bookcount = GlobalSettingsDAO.getPPBookDSMap(infodom, dscs, alldscode, locale);
	    		 
	    	 }
				GL35Logger.logThis("bookQry..."+bookQry+".bookcount.."+bookcount);
				
				
		    }catch (Exception sqle) {
					
					sqle.printStackTrace();
						
				}
		return bookcount;
	}
	public int isGLbookcolumnexists(String infodom,String glcolumn,String stabname)
	{
		 int glcdbkcount=0;
		 glcolumn = glcolumn.toUpperCase();
		 String bookQry = " select count(1) from FSI_GL_MAP_RECON_TARGETS t1, fsi_gl_mapping_master t2 "
			              +" where t1.v_gl_map_id = t2.v_gl_map_id and t1.n_version_number = t2.n_version_number  and t2.f_is_deleted = 'N' "
			              +"  and upper(t1.v_gl_code_col_name) IN ("+glcolumn+")   and upper(v_table_name) = upper('"+stabname+"')";
                      
		 try
		 {
		   
			Cargo cortCargo = (Cargo) SMSServices.executeQuery(infodom,bookQry,false);
	    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
	    	 while (!rs.EOF() && rs.getRowCount()>0 ) {
					if(rs.fetchElement(1)!="" && rs.fetchElement(1) !=null)
						glcdbkcount = Integer.parseInt(rs.fetchElement(1));
					rs.moveNext();
				}
	    	 
	    	 GL35Logger.logThis("bookQry..."+bookQry+"..ppcount.."+glcdbkcount);
	    	
				
		    }catch (Exception sqle) {
					
					sqle.printStackTrace();
						
				}
		return glcdbkcount;
	}
	public int isBalanceexists(String infodom,String table,String bals)
	{
		 int balancecount=0;
		  StringBuffer sbQry = new StringBuffer();     
		  bals = bals.toUpperCase();
		  sbQry.append(" SELECT COUNT(1) FROM  ");
		  sbQry.append(" ( SELECT TRIM(T3.V_BALANCE_COL_NAME)  COL ,T3.V_TABLE_NAME  TAB FROM  FSI_GL_MAPPING_MASTER  T2, ");
		  sbQry.append(" FSI_GL_MAP_RECON_TARGETS T3 ");
		  sbQry.append(" WHERE T2.F_IS_DELETED ='N' AND T2.V_GL_MAP_ID = T3.V_GL_MAP_ID AND T2.N_VERSION_NUMBER = T3.N_VERSION_NUMBER ");
		  sbQry.append(" AND upper(T3.V_TABLE_NAME) = upper('"+table+"') ");
		  sbQry.append(" UNION ");
		  sbQry.append(" SELECT TRIM(T4.V_BALANCE_COL_NAME),T4.V_TABLE_NAME FROM FSI_GL_MAPPING_MASTER  T2, ");
		  sbQry.append(" FSI_GL_MAPPING_PP_ALLOC_DTLS T4 ");
		  sbQry.append(" WHERE T2.F_IS_DELETED ='N' AND T2.V_GL_MAP_ID = T4.V_GL_MAP_ID AND T2.N_VERSION_NUMBER = T4.N_VERSION_NUMBER ");
		  sbQry.append(" AND upper(T4.V_TABLE_NAME) = upper('"+table+"')) T5 ,SETUP_PP_BALANCE_COLUMNS  B WHERE T5.TAB = B.V_TABLE_NAME AND TRIM(T5.COL)= TRIM(B.V_BALANCE_COL_NAME) ");
		  sbQry.append(" AND upper(T5.COL)  IN ("+bals+") AND upper(B.V_BALANCE_COL_NAME) IN  ("+bals+") ");
		  try
		 {
		   
			Cargo cortCargo = (Cargo) SMSServices.executeQuery(infodom,sbQry.toString(),false);
	    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
	    	 while (!rs.EOF() && rs.getRowCount()>0 ) {
					if(rs.fetchElement(1)!="" && rs.fetchElement(1) !=null)
						balancecount = Integer.parseInt(rs.fetchElement(1));
					rs.moveNext();
				}
				GL35Logger.logThis("isBalanceexists..."+sbQry.toString()+".bookcount.."+balancecount);
		    }catch (Exception sqle) {
					
					sqle.printStackTrace();
						
				}
		return balancecount;
	}
	public int isGLHierused(String infodom,String glhiercd,String bookcd)
	{
		 int mapcount=0;
		  StringBuffer sbQry = new StringBuffer();     
		  sbQry.append(" SELECT COUNT(1) FROM FSI_GL_MAPPING_MASTER M,FSI_GL_MAPPING_GL_CODES C WHERE M.V_GL_MAP_ID = C.V_GL_MAP_ID AND ");
		  sbQry.append("  M.N_VERSION_NUMBER = C.N_VERSION_NUMBER AND M.F_IS_DELETED = 'N' AND UPPER(C.V_GL_BOOK) = UPPER('"+bookcd+"')" );
		  sbQry.append(" AND UPPER(SUBSTR(C.V_GL_CODE,INSTR(C.V_GL_CODE, '[') + 1,INSTR(C.V_GL_CODE, ']') - 2)) = UPPER('"+glhiercd+"')");
	try
		 {
		   
			Cargo cortCargo = (Cargo) SMSServices.executeQuery(infodom,sbQry.toString(),false);
	    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
	    	 while (!rs.EOF() && rs.getRowCount()>0 ) {
					if(rs.fetchElement(1)!="" && rs.fetchElement(1) !=null)
						mapcount = Integer.parseInt(rs.fetchElement(1));
					rs.moveNext();
				}
				GL35Logger.logThis("isBalanceexists..."+sbQry.toString()+".bookcount.."+mapcount);
		    }catch (Exception sqle) {
					
					sqle.printStackTrace();
						
				}
		return mapcount;
	}
	
	public static int isDimesionexists(String infodom,Vector dims)
	{
		 int dimcount=0;
		 String codestr="";
		// Vector dimvec = new Vector();
		  StringBuffer sbQry = new StringBuffer();   
		  if(dims!=null && dims.size()>0)
		  {
			  for(int k=0;k<dims.size();k++)
			  {
				  if(dims.size()==1)
					  codestr = "'"+dims.get(k)+"'";
				 
				  if(dims.size()>1)
				  {
					  if(k==(dims.size()-1))
					   codestr = codestr+"'"+dims.get(k)+"'";
					  else
						  codestr = codestr+"'"+dims.get(k)+"',";  
					  
				  }
				  
				  
				  
				  
			  }
		  
		  }
		  sbQry.append(" SELECT COUNT(1) FROM( ");
		  sbQry.append(" SELECT F.V_DIMENSION_HCY_CODE FROM FSI_GL_MAPPING_DIMENSIONS F,FSI_GL_MAPPING_MASTER M ");
		  sbQry.append(" WHERE F.V_GL_MAP_ID =  M.V_GL_MAP_ID AND F.N_VERSION_NUMBER = M.N_VERSION_NUMBER AND M.F_IS_DELETED ='N' AND F.V_DIMENSION_HCY_CODE IN ("+codestr+") ");
		  sbQry.append(" UNION  SELECT  V_DIMENSION_HCY_CODE FROM FSI_SETUP_GL_DIMENSIONS  S WHERE S.V_DIMENSION_HCY_CODE IN ("+codestr+")) ");
		
		try
		 {
		   
			Cargo cortCargo = (Cargo) SMSServices.executeQuery(infodom,sbQry.toString(),false);
	    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
	    	 while (!rs.EOF() && rs.getRowCount()>0 ) {
					if(rs.fetchElement(1)!="" && rs.fetchElement(1) !=null)
						dimcount = Integer.parseInt(rs.fetchElement(1));
					rs.moveNext();
				}
				GL35Logger.logThis("isDimesionexists..."+sbQry.toString()+".dimcount.."+dimcount);
		    }catch (Exception sqle) {
					
					sqle.printStackTrace();
						
				}
		return dimcount;
	}
	
	public static int isLEhierexists(String infodom,String ledim)
	{
		
		int lecnt =0;
		StringBuffer sbQry = new StringBuffer();   
		  sbQry.append("  SELECT COUNT(1) FROM  FSI_GL_MAPPING_MASTER M  WHERE M.F_IS_DELETED ='N' AND  M.V_ENTITY_CODE LIKE '["+ledim+"]%'");
		 
		try
		 {
		   
			Cargo cortCargo = (Cargo) SMSServices.executeQuery(infodom,sbQry.toString(),false);
	    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
	    	 while (!rs.EOF() && rs.getRowCount()>0 ) {
					if(rs.fetchElement(1)!="" && rs.fetchElement(1) !=null)
						lecnt = Integer.parseInt(rs.fetchElement(1));
					rs.moveNext();
				}
				GL35Logger.logThis("isLEhierexists..."+sbQry.toString()+".dimcount.."+lecnt);
		    }catch (Exception sqle) {
					
					sqle.printStackTrace();
						
				}
		return lecnt;
		
		
	}
		
	public String getdimensions(String sinfodom,String suserid,String locale)
	{
		   String ppQry = "SELECT V_DIMENSION_HCY_CODE,F_RECON_OR_MANDATORY,V_DIMENSION_DESC,V_DIMENSION_LOOKUP_CD  FROM SETUP_GL_RECON_DIMENSIONS ";
		   StringBuffer sb = new StringBuffer();
		   String dimval="";
		   int i = 0;
		   try{
			     
			    Cargo cr;
		   
				sb.append("{");
				sb.append("\"dimensions\": {");
				
				Cargo cortCargo = (Cargo) SMSServices.executeQuery(sinfodom,ppQry,false);
		    	DACRecordSet rs = (DACRecordSet) cortCargo.getPayLoadObject();
				
				
		    	 while (!rs.EOF() && rs.getRowCount()>0 ) {
					
					
					cr = SecureBusinessMetaData.getMetaDataObjectFromServer(sinfodom,suserid,  rs.fetchElement(1), GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,new Locale(locale));
					
				
				
					if (cr != null && !cr.getErrorFlag())
					{
						
						ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr.getPayLoadObject();
						if(hierarchy!=null)
							{
						
						if(i > 0)
							sb.append(", ");
						
						     sb.append("\""+i+"\": [");
							 sb.append("{\"dimtab\": " + "\"" + hierarchy.getEntityCode()+ "\"" + "}, ");
							 sb.append("{\"dimcode\": " + "\"" +  rs.fetchElement(1)+ "\"" + "}, ");
							 sb.append("{\"flag\": " + "\"" +  rs.fetchElement(2)+ "\"" + "}, ");
							 sb.append("{\"desc\": " + "\"" +rs.fetchElement(3) + "\"" + "}, ");
							 sb.append("{\"lookupcode\": " + "\"" + rs.fetchElement(4)+ "\"" + "} ");
						
							 sb.append("]");	
				 		
							
							i = i+1;
							
							}
					}
					
					
					rs.moveNext();
					
				}
				sb.append("}");
				sb.append("}");
			
		
			
			
			
			if(i>0)
			{
				dimval = sb.toString();
				GL35Logger.logThis("ppval..."+dimval);
				//FSAPPLogger.logMessage(tpConstants.LOG_APP_NAME,"termsval...."+termsval, Priority.INFO);
			}
			
			
		   } catch (Exception sqle) {
				
				sqle.printStackTrace();
					
			}
	return dimval;
	}
	public static int getPPBookDSMap(String sInfodom,String srcDS,String allDs,String locale)
	{
		int cnt = 0;
		   Vector srcHiers  = new Vector();
		    Vector v1 = new Vector();
		    
		    srcHiers = getHierarchies(srcDS,sInfodom,locale);
		     String dsAr[] = allDs.split(",");
	          String dstmcode ="";
	          Vector alldsHiers = new Vector();
	          for(int ds=0;ds<dsAr.length;ds++)
	          { 
	        	  v1 = new Vector();
	        	  dstmcode =dsAr[ds];
	        	  GL35Logger.logThis("dstmcode..."+dstmcode);
	        	  v1 = getHierarchies(dstmcode,sInfodom,locale);
	        	//  GL35Logger.logThis("v11111111111111..."+v1.toString());
	        	  alldsHiers.addAll(v1);
	        	  
	          }
	          Vector fnlhiers= new Vector();
	          GL35Logger.logThis("src..."+srcHiers.toString());
	          GL35Logger.logThis("all..."+alldsHiers.toString());
	          if(!alldsHiers.containsAll(srcHiers))
	          {
	        	  GL35Logger.logThis("deson not caontin all");
	        	  for(int d=0;d<srcHiers.size();d++)
	        	  {
	        		  if(!alldsHiers.contains(srcHiers.get(d)))
	        		  {
	        			  fnlhiers.add(srcHiers.get(d));  
	        		  }
	        		  
	        		  
	        	  }
	        	  GL35Logger.logThis("remmm..."+fnlhiers.toString());
	              int hiercnt= 0;
	              hiercnt = GlobalSettingsDAO.isDimesionexists(sInfodom,fnlhiers);
	              GL35Logger.logThis("hiercnt..."+hiercnt);
	              if(hiercnt>0)
	            	  cnt =-1;
	            	  
	          
	          }
		return cnt;
	}
	
	public String getDimesionmap(String sinfodom,String shiercode)
	{
		//   String mapQry = "SELECT V_PP_OR_GL,V_PP_GL_TABLE_NAME,V_DIMENSION_COL_NAME||'-'||V_DIMENSION_LOGIC_COL_NAME FROM SETUP_RECON_DIM_COL_MAP  WHERE V_DIMENSION_HCY_CODE ='"+shiercode.trim()+"' ";
		   String mapQry = "SELECT V_PP_OR_GL,V_PP_GL_TABLE_NAME,V_DIMENSION_COL_NAME||'-'||V_DIMENSION_LOGIC_COL_NAME,V_DIMENSION_HCY_CODE FROM SETUP_RECON_DIM_COL_MAP ";
		   StringBuffer sb = new StringBuffer();
		   String dimval="";
		   int i = 0;
		  
			     
			  
		   sb.append("{");
			sb.append("\"dimmap\": {");
			   
				  Cargo rtnCargo = (Cargo) SMSServices.executeQuery(sinfodom,mapQry ,false);
				
				  DACRecordSet resSet = (DACRecordSet) rtnCargo.getPayLoadObject();
			    	 while (!resSet.EOF() && resSet.getRowCount()>0 )
				    	{
					
						
						if(i > 0)
							sb.append(", ");
						
						     sb.append("\""+i+"\": [");
							 sb.append("{\"type\": " + "\"" + resSet.fetchElement(1)+ "\"" + "}, ");
							 sb.append("{\"tabname\": " + "\"" + resSet.fetchElement(2)+ "\"" + "}, ");
							 sb.append("{\"colname\": " + "\"" + resSet.fetchElement(3)+ "\"" + "}, ");
							 sb.append("{\"dimcode\": " + "\"" + resSet.fetchElement(4)+ "\"" + "} ");
							
							 sb.append("]");	
				 		
							
							i = i+1;
							
							resSet.moveNext();
					}
					
					
				
					
				
				sb.append("}");
				sb.append("}");
			
		
			
			
			
			if(i>0)
			{
				dimval = sb.toString();
				GL35Logger.logThis("ppval..."+dimval);
				//FSAPPLogger.logMessage(tpConstants.LOG_APP_NAME,"termsval...."+termsval, Priority.INFO);
			}
			
			
		  
	return dimval;
	}
	public static Vector getHierarchies(String  vDscode,String infodom,String locale)
	{
		Vector hierVec = new Vector();
		Cargo retCargo = BusinessMetaData.getMappedHierarchies(vDscode, infodom,new Locale(locale));
	 //	Cargo retCargo = BusinessMetaData.getMappedHierarchies(vDscode, infodom, new Locale(locale));
	 //	GL35Logger.logThis("hierarchy......."+retCargo.getErrorFlag());
	 	if(retCargo!=null && !(retCargo.getErrorFlag()))
		{
			
			
			Vector  vecHcy = (Vector) retCargo.getPayLoadObject();

				Vector vecHierarchyNodes = null;
				ClsUEntHierarchy hierarchy;
				
				for(int inLoop = 0; inLoop < vecHcy.size(); inLoop++)
				{


					hierarchy = (ClsUEntHierarchy)vecHcy.elementAt(inLoop);
					hierVec.add(hierarchy.getCode());
				//	GL35Logger.logThis("hierarchy..22....."+hierarchy.getCode());
					
					
				}
			
			
		
	}
		
		return hierVec;
	}
}
