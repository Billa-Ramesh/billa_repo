/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : CorrectionDAO.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Priority;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.model.AdjustmentSearchBean;
import com.ofs.erm.gl.model.AdjustmentSummaryBean;
import com.ofs.erm.gl.model.CorrectionSummaryBean;
import com.ofs.erm.gl.model.MapNameBean;

public class CorrectionDAO 
{
	private static int rowId = 0;
	private static List<String> colArray = new ArrayList<String>();
	private static int noOfPagesLoaded = 2;
	@SuppressWarnings("unused")
	private static String searchQuery;

	static {
		colArray.add("A.V_EXECUTION_IDENTIFIER");
		colArray.add("M.V_GL_MAP_NAME");
		colArray.add("A.N_VERSION_NUMBER");
		colArray.add("A.D_CALENDAR_DATE");
		colArray.add("A.RECONAMOUNT");
		//colArray.add("A.CORRECTIONAMOUNT");
	}

	public static List<CorrectionSummaryBean> getCorrectionData(AdjustmentSearchBean searchBean, String infodom, String summpage) 
	{
		//summpage : correctionSummary,correctionSummaryApproval
		List<CorrectionSummaryBean> correctionData = new ArrayList<CorrectionSummaryBean>();
		int recordCount = 0;

		if(searchBean == null){
			searchBean = new AdjustmentSearchBean();
			searchBean.setExecutionId("");
			searchBean.setGlDate("");
			searchBean.setMapId("");
			searchBean.setSortCol("");
			searchBean.setSortOrder("");
			searchBean.setStartIndex(1);
			searchBean.setEndIndex(10*noOfPagesLoaded);
		}

		if(searchBean.getRecordCountNeeded() == true) {/*
			GL35Logger.logThis("DAO:getRecordCount Loop", Priority.DEBUG_INT);
			String execId = "'%"+searchBean.getExecutionId()+"%'";
			String mapName = "'%"+searchBean.getMapId()+"%'";
			String glDate = "'"+searchBean.getGlDate()+"'";
			String recordQuery ="";
			if(summpage.equalsIgnoreCase("correctionSummary")){
				recordQuery = "SELECT COUNT(1) FROM (" +
						"SELECT A.V_EXECUTION_IDENTIFIER,A.V_GL_MAP_ID,A.FIC_MIS_DATE," +
						//"CASE " +
						//"WHEN ((A.V_EXECUTION_IDENTIFIER = C.V_EXECUTION_IDENTIFIER) AND (A.V_GL_MAP_ID = C.V_GL_MAP_ID) " +
						//"AND (A.FIC_MIS_DATE = C.FIC_MIS_DATE)) THEN C.CORRAMOUNT ELSE 0 END AS CORRECTIONAMOUNT," +
						"A.RECONAMOUNT AS RECONAMOUNT,A.N_VERSION_NUMBER FROM " +
						"(SELECT FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID," +
						"FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE,SUM(ABS(FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT)) AS RECONAMOUNT," +
						"FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER ,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_ADJUSTMENT_ENTRIES.F_INTRA_GROUP," +
						" SUM(FCT_GL_ADJUSTMENT_ENTRIES.N_CONTRA_GL_AMOUNT) AS N_CONTRA_GL_AMOUNT FROM FCT_GL_ADJUSTMENT_ENTRIES " +
						"GROUP BY FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID," +
						"FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE,FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_ADJUSTMENT_ENTRIES.F_INTRA_GROUP) A " +
						"FULL OUTER JOIN " +
						"(SELECT FCT_GL_CORRECTION_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_CORRECTION_ENTRIES.V_GL_MAP_ID," +
						"FCT_GL_CORRECTION_ENTRIES.FIC_MIS_DATE," +
						//"SUM(FCT_GL_CORRECTION_ENTRIES.N_CORRECTION_AMOUNT) AS CORRAMOUNT," +
						"FCT_GL_CORRECTION_ENTRIES.N_VERSION_NUMBER FROM FCT_GL_CORRECTION_ENTRIES " +
						"GROUP BY FCT_GL_CORRECTION_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_CORRECTION_ENTRIES.V_GL_MAP_ID," +
						"FCT_GL_CORRECTION_ENTRIES.FIC_MIS_DATE,FCT_GL_CORRECTION_ENTRIES.N_VERSION_NUMBER) C " +
						"ON ((A.V_EXECUTION_IDENTIFIER = C.V_EXECUTION_IDENTIFIER) AND (A.V_GL_MAP_ID = C.V_GL_MAP_ID) AND " +
						"(A.FIC_MIS_DATE = C.FIC_MIS_DATE) AND (A.N_VERSION_NUMBER = C.N_VERSION_NUMBER) )WHERE " +
						"((A.V_EXECUTION_IDENTIFIER LIKE "+execId+") AND (A.V_GL_MAP_ID LIKE "+mapName+") AND (A.V_AUTHORIZATION_STATUS='A') AND (A.F_INTRA_GROUP='N') AND ((A.N_CONTRA_GL_AMOUNT <> 0) OR (A.N_CONTRA_GL_AMOUNT IS NULL)) AND " +
						"(A.FIC_MIS_DATE = COALESCE(TO_DATE("+glDate+",'MM-DD-YYYY'),A.FIC_MIS_DATE)) " +
						" ))";
			}else if(summpage.equalsIgnoreCase("correctionSummaryApproval")){
				recordQuery = "SELECT COUNT(1) FROM (" +
						"SELECT A.V_EXECUTION_IDENTIFIER,A.V_GL_MAP_ID,A.FIC_MIS_DATE," +
						//"CASE " +
						//"WHEN ((A.V_EXECUTION_IDENTIFIER = C.V_EXECUTION_IDENTIFIER) AND (A.V_GL_MAP_ID = C.V_GL_MAP_ID) " +
						//"AND (A.FIC_MIS_DATE = C.FIC_MIS_DATE)) THEN C.CORRAMOUNT ELSE 0 END AS CORRECTIONAMOUNT," +
						"A.RECONAMOUNT AS RECONAMOUNT,A.N_VERSION_NUMBER FROM " +
						"(SELECT FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID," +
						"FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE,SUM(ABS(FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT)) AS RECONAMOUNT," +
						"FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS FROM FCT_GL_ADJUSTMENT_ENTRIES " +
						"GROUP BY FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID," +
						"FCT_GL_ADJUSTMENT_ENTRIES.FIC_MIS_DATE,FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS) A " +
						"FULL OUTER JOIN " +
						"(SELECT FCT_GL_CORRECTION_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_CORRECTION_ENTRIES.V_GL_MAP_ID," +
						"FCT_GL_CORRECTION_ENTRIES.FIC_MIS_DATE," +
						//"SUM(FCT_GL_CORRECTION_ENTRIES.N_CORRECTION_AMOUNT) AS CORRAMOUNT," +
						"FCT_GL_CORRECTION_ENTRIES.N_VERSION_NUMBER ,FCT_GL_CORRECTION_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_CORRECTION_ENTRIES.F_INTRA_GROUP FROM FCT_GL_CORRECTION_ENTRIES " +
						"GROUP BY FCT_GL_CORRECTION_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_CORRECTION_ENTRIES.V_GL_MAP_ID," +
						"FCT_GL_CORRECTION_ENTRIES.FIC_MIS_DATE,FCT_GL_CORRECTION_ENTRIES.N_VERSION_NUMBER,FCT_GL_CORRECTION_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_CORRECTION_ENTRIES.F_INTRA_GROUP) C " +
						"ON ((A.V_EXECUTION_IDENTIFIER = C.V_EXECUTION_IDENTIFIER) AND (A.V_GL_MAP_ID = C.V_GL_MAP_ID) AND " +
						"(A.FIC_MIS_DATE = C.FIC_MIS_DATE) AND (A.N_VERSION_NUMBER = C.N_VERSION_NUMBER) )WHERE " +
						"((A.V_EXECUTION_IDENTIFIER LIKE "+execId+") AND (A.V_GL_MAP_ID LIKE "+mapName+") AND (C.V_AUTHORIZATION_STATUS='S') AND (A.V_AUTHORIZATION_STATUS='A') AND C.F_INTRA_GROUP='N' AND " +
						"(A.FIC_MIS_DATE = COALESCE(TO_DATE("+glDate+",'MM-DD-YYYY'),A.FIC_MIS_DATE)) " +
						" ))";
			}
			
			GL35Logger.logThis("recordQuery="+recordQuery, Priority.DEBUG_INT);

			Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,recordQuery,false);
			
			if(FindCountCargo.getErrorFlag())
			{
				GL35Logger.logThis("Error while retrieving from Database - Inside AdjustmentDAO", Priority.DEBUG_INT);
				CorrectionSummaryBean tempBean = new CorrectionSummaryBean();
				tempBean.setExecutionIdentifier(null);
				correctionData.add(tempBean);
				return correctionData;
			}
			else {
				DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
				recordCount = Integer.parseInt(resultSet.fetchElement(1));
			}
		*/}



		if((searchBean.getSortOrder() == "") || (searchBean.getSortOrder() == null)) {
			searchBean.setSortOrder("ASC");
			searchBean.setSortCol("2");
		}

		String sortColName = colArray.get(Integer.parseInt(searchBean.getSortCol()));
		String execId = "'%"+searchBean.getExecutionId()+"%'";
		String mapName = "'%"+searchBean.getMapId()+"%'";
		String glDate = "'"+searchBean.getGlDate()+"'";
		
		String searchQuery = "";
		if(summpage.equalsIgnoreCase("correctionSummary")){
			searchQuery = "SELECT * FROM ( SELECT ROWNUM RNUM, T.*,COUNT(T.V_EXECUTION_IDENTIFIER) over() cnt FROM (SELECT A.*,M.V_GL_MAP_NAME FROM " +
					"(SELECT A.V_EXECUTION_IDENTIFIER,A.V_GL_MAP_ID,A.D_CALENDAR_DATE," +
					/*"CASE " +
					"WHEN ((A.V_EXECUTION_IDENTIFIER = C.V_EXECUTION_IDENTIFIER) AND (A.V_GL_MAP_ID = C.V_GL_MAP_ID) AND " +
					"(A.FIC_MIS_DATE = C.FIC_MIS_DATE)) THEN C.CORRAMOUNT ELSE 0 END " +
					"AS CORRECTIONAMOUNT," +*/
					"A.RECONAMOUNT AS RECONAMOUNT,A.N_VERSION_NUMBER FROM " +
					"(SELECT FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID," +
					"DIM_DATES.D_CALENDAR_DATE,SUM(ABS(FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT)) AS RECONAMOUNT," +
					"FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_ADJUSTMENT_ENTRIES.F_INTRA_GROUP," +
					" SUM(FCT_GL_ADJUSTMENT_ENTRIES.N_CONTRA_GL_AMOUNT) AS N_CONTRA_GL_AMOUNT,FCT_GL_ADJUSTMENT_ENTRIES.N_DATE_SKEY FROM FCT_GL_ADJUSTMENT_ENTRIES " +
					" inner JOIN DIM_DATES ON DIM_DATES.N_DATE_SKEY = FCT_GL_ADJUSTMENT_ENTRIES.N_DATE_SKEY "+
					" GROUP BY FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID," +
					"DIM_DATES.D_CALENDAR_DATE,FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_ADJUSTMENT_ENTRIES.F_INTRA_GROUP,FCT_GL_ADJUSTMENT_ENTRIES.N_DATE_SKEY) A " +
					"FULL OUTER JOIN (SELECT FCT_GL_CORRECTION_ENTRIES.V_EXECUTION_IDENTIFIER," +
					"FCT_GL_CORRECTION_ENTRIES.V_GL_MAP_ID,FCT_GL_CORRECTION_ENTRIES.N_DATE_SKEY," +
					//"SUM(FCT_GL_CORRECTION_ENTRIES.N_CORRECTION_AMOUNT) AS CORRAMOUNT," +
					"FCT_GL_CORRECTION_ENTRIES.N_VERSION_NUMBER FROM FCT_GL_CORRECTION_ENTRIES " +
					"GROUP BY FCT_GL_CORRECTION_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_CORRECTION_ENTRIES.V_GL_MAP_ID," +
					"FCT_GL_CORRECTION_ENTRIES.N_DATE_SKEY,FCT_GL_CORRECTION_ENTRIES.N_VERSION_NUMBER) C " +
					"ON ((A.V_EXECUTION_IDENTIFIER = C.V_EXECUTION_IDENTIFIER) AND (A.V_GL_MAP_ID = C.V_GL_MAP_ID) AND " +
					"(A.N_DATE_SKEY = C.N_DATE_SKEY) AND (A.N_VERSION_NUMBER = C.N_VERSION_NUMBER) ) " +
					"WHERE ((A.V_EXECUTION_IDENTIFIER LIKE "+execId+") AND (A.V_GL_MAP_ID LIKE "+mapName+") AND (A.V_AUTHORIZATION_STATUS='A' AND A.F_INTRA_GROUP='N') AND  ((A.N_CONTRA_GL_AMOUNT <> 0) OR (A.N_CONTRA_GL_AMOUNT IS NULL)) AND " +
					"(A.D_CALENDAR_DATE = COALESCE(TO_DATE("+glDate+",'MM-DD-YYYY'),A.D_CALENDAR_DATE)) ) ) A," +
					"FSI_GL_MAPPING_MASTER M WHERE ((A.V_GL_MAP_ID=M.V_GL_MAP_ID) AND M.N_VERSION_NUMBER = A.N_VERSION_NUMBER) ORDER BY "+sortColName+" "+ searchBean.getSortOrder() +" ) T " +
					"   ) WHERE RNUM >= "+searchBean.getStartIndex()+" AND RNUM <= "+searchBean.getEndIndex()+" ";
			
		}else if(summpage.equalsIgnoreCase("correctionSummaryApproval")){
			searchQuery = "SELECT * FROM ( SELECT ROWNUM RNUM, T.*,COUNT(T.V_EXECUTION_IDENTIFIER) over() cnt FROM (SELECT A.*,M.V_GL_MAP_NAME FROM " +
					"(SELECT A.V_EXECUTION_IDENTIFIER,A.V_GL_MAP_ID,A.D_CALENDAR_DATE," +
					/*"CASE " +
					"WHEN ((A.V_EXECUTION_IDENTIFIER = C.V_EXECUTION_IDENTIFIER) AND (A.V_GL_MAP_ID = C.V_GL_MAP_ID) AND " +
					"(A.FIC_MIS_DATE = C.FIC_MIS_DATE)) THEN C.CORRAMOUNT ELSE 0 END " +
					"AS CORRECTIONAMOUNT," +*/
					"A.RECONAMOUNT AS RECONAMOUNT,A.N_VERSION_NUMBER FROM " +
					"(SELECT FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID," +
					"DIM_DATES.D_CALENDAR_DATE,SUM(ABS(FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT)) AS RECONAMOUNT," +
					"FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_ADJUSTMENT_ENTRIES.N_DATE_SKEY FROM FCT_GL_ADJUSTMENT_ENTRIES " +
					" inner JOIN DIM_DATES ON DIM_DATES.N_DATE_SKEY = FCT_GL_ADJUSTMENT_ENTRIES.N_DATE_SKEY "+
					"GROUP BY FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID," +
					"DIM_DATES.D_CALENDAR_DATE,FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_ADJUSTMENT_ENTRIES.N_DATE_SKEY) A " +
					"FULL OUTER JOIN (SELECT FCT_GL_CORRECTION_ENTRIES.V_EXECUTION_IDENTIFIER," +
					"FCT_GL_CORRECTION_ENTRIES.V_GL_MAP_ID,FCT_GL_CORRECTION_ENTRIES.N_DATE_SKEY," +
					//"SUM(FCT_GL_CORRECTION_ENTRIES.N_CORRECTION_AMOUNT) AS CORRAMOUNT," +
					"FCT_GL_CORRECTION_ENTRIES.N_VERSION_NUMBER,FCT_GL_CORRECTION_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_CORRECTION_ENTRIES.F_INTRA_GROUP FROM FCT_GL_CORRECTION_ENTRIES " +
					"GROUP BY FCT_GL_CORRECTION_ENTRIES.V_EXECUTION_IDENTIFIER,FCT_GL_CORRECTION_ENTRIES.V_GL_MAP_ID," +
					"FCT_GL_CORRECTION_ENTRIES.N_DATE_SKEY,FCT_GL_CORRECTION_ENTRIES.N_VERSION_NUMBER,FCT_GL_CORRECTION_ENTRIES.V_AUTHORIZATION_STATUS,FCT_GL_CORRECTION_ENTRIES.F_INTRA_GROUP) C " +
					"ON ((A.V_EXECUTION_IDENTIFIER = C.V_EXECUTION_IDENTIFIER) AND (A.V_GL_MAP_ID = C.V_GL_MAP_ID) AND " +
					"(A.N_DATE_SKEY = C.N_DATE_SKEY) AND (A.N_VERSION_NUMBER = C.N_VERSION_NUMBER) ) " +
					"WHERE ((A.V_EXECUTION_IDENTIFIER LIKE "+execId+") AND (A.V_GL_MAP_ID LIKE "+mapName+")  AND (C.V_AUTHORIZATION_STATUS='S') AND (A.V_AUTHORIZATION_STATUS='A') AND C.F_INTRA_GROUP='N' AND " +
					"(A.D_CALENDAR_DATE = COALESCE(TO_DATE("+glDate+",'MM-DD-YYYY'),A.D_CALENDAR_DATE)) ) ) A," +
					"FSI_GL_MAPPING_MASTER M WHERE ((A.V_GL_MAP_ID=M.V_GL_MAP_ID) AND M.N_VERSION_NUMBER = A.N_VERSION_NUMBER) ORDER BY "+sortColName+" "+ searchBean.getSortOrder() +" ) T " +
					" ) WHERE RNUM >= "+searchBean.getStartIndex()+" AND RNUM<="+searchBean.getEndIndex()+" ";
			
		}
		
		GL35Logger.logThis(searchQuery, Priority.DEBUG_INT);

		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,searchQuery,false);
		DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();

		rowId = searchBean.getStartIndex() - 1;

		while (!resultSet.EOF()) {
			CorrectionSummaryBean csb = new CorrectionSummaryBean();
			csb.setExecutionIdentifier(resultSet.fetchElement(2));
			csb.setMapId(resultSet.fetchElement(3));
			String[] tempDate = resultSet.fetchElement(4).split(" ");
			String[] tempDate1 = tempDate[0].split("-");
			String glDateNew = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
			csb.setGlDate(glDateNew);
			csb.setMapName(resultSet.fetchElement(7));
			csb.setReconAmount(resultSet.fetchElement(5));
			//csb.setCorrectionAmount(resultSet.fetchElement(5));
			csb.setVersionNumber(resultSet.fetchElement(6));
			csb.setRowId(rowId);
			csb.setCheckBoxString("checkedCNew('" +rowId + "')");
			csb.setRecordCount(Integer.parseInt(resultSet.fetchElement(8)));
			correctionData.add(csb);
			rowId++;
			resultSet.moveNext();
		}
		GL35Logger.logThis("Correction List Size:"+correctionData.size(), Priority.DEBUG_INT);

		return correctionData;
	}

	public static List<MapNameBean> getMapArray(String infodom) 
	{
		List<MapNameBean> mapArray = new ArrayList<MapNameBean>();
		String query = "SELECT M.V_GL_MAP_ID,M.V_GL_MAP_NAME FROM FSI_GL_MAPPING_MASTER M ";

		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,query,false);
		DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();

		rowId = 0;

		while(!resultSet.EOF()) {
			MapNameBean tempBean = new MapNameBean();
			tempBean.setMapId(resultSet.fetchElement(1));
			tempBean.setMapName(resultSet.fetchElement(2));
			mapArray.add(tempBean);
			rowId++;
			resultSet.moveNext();
		}
		return mapArray;

	}

}
