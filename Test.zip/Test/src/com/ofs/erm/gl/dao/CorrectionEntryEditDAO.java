/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : CorrectionEntryEditDAO.java
* Title         :
* Description   :
* @author       : Sandeep 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.dao;

/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;*/
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Priority;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
//import com.iflex.fic.global.GlobalParameters;
import com.ofs.erm.gl.global.GL35Logger;
//import com.ofs.erm.gl.model.AdjDefaultValueBean;
import com.ofs.erm.gl.model.CorrecEntryEditSummaryBean;
//import com.ofs.erm.gl.model.CorrectionSummaryBean;
//import com.ofs.erm.gl.model.EditPageEntryBean;
//import com.ofs.erm.gl.model.PPListBean;
import com.ofs.erm.gl.global.GLCommon;


public class CorrectionEntryEditDAO {

	private static int rowId = 0;
	//private static List<String> colArray = new ArrayList<String>();
	//private static int noOfPagesLoaded = 2;
	@SuppressWarnings("unused")
	private static String searchQuery;
	
	static {
		//colArray.add("a.v_execution_identifier");
		//colArray.add("m.v_gl_map_name");
		//colArray.add("GlDate");
		//colArray.add("gl_correction_entries.n_exposure_amount");
	}
	
	@SuppressWarnings("finally")
	public static String getAmountColumnVal(String adjExposureId,String corrExposureId,String sInfodom ){
		String retVal="-";
		try{
			/*String qry1 = "select max(v_pp_table_name),max(v_pp_balance_col_name) from fct_gl_correction_entries where " +
					" v_adj_exposure_id='"+adjExposureId+"' and " +
					" v_corr_exposure_id='"+corrExposureId+"'";*/
			String qry1 = "SELECT V_SOURCE_PP_TABLE_NAME,V_SOURCE_PP_BALANCE_COL_NAME FROM FCT_GL_ADJUSTMENT_ENTRIES WHERE V_ADJ_EXPOSURE_ID='"+adjExposureId+"'";
			String tabName="",colName="";
			Cargo cr1 = (Cargo) SMSServices.executeQuery(sInfodom, qry1, false);
			DACRecordSet rs1 = (DACRecordSet)cr1.getPayLoadObject();
			while(!rs1.EOF()){
				tabName=rs1.fetchElement(1);
				colName=rs1.fetchElement(2);
				rs1.moveNext();
			}
			
			String qry2 = "SELECT max(v_exposure_id_col_name) FROM SETUP_PRODUCT_PROCESSORS WHERE upper(V_TABLE_NAME) = upper('"+tabName+"')";
			String expColName="";
			Cargo cr2 = (Cargo)SMSServices.executeQuery(sInfodom, qry2, false);
			DACRecordSet rs2 = (DACRecordSet)cr2.getPayLoadObject();
			while(!rs2.EOF()){
				expColName=rs2.fetchElement(1);
				rs2.moveNext();
			}
			
			String qry3 = "select "+colName+" from "+tabName+" where "+expColName+"='"+corrExposureId+"'";
			Cargo cr3 = (Cargo)SMSServices.executeQuery(sInfodom, qry3, false);
			DACRecordSet rs3 = (DACRecordSet)cr3.getPayLoadObject();
			while(!rs3.EOF()){
				retVal=rs3.fetchElement(1);
				rs3.moveNext();
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			GL35Logger.logThis("Exception Occured : "+e.getStackTrace(), Priority.ERROR_INT);
		}finally{
			return retVal;
		}
		
		/*STG_LOAN_CONTRACTS,N_EOP_BAL*/ //select max(v_pp_table_name),max(v_pp_balance_col_name) from fct_gl_correction_entries  where v_adj_exposure_id='GL_MAP001_7167'
				/*V_ACCOUNT_NUMBER*/ //SELECT v_exposure_id_col_name  FROM SETUP_PRODUCT_PROCESSORS  WHERE upper(V_TaBLe_NAME) = upper('STG_LOAN_CONTRACTS')
				/*amount column*/ //select N_EOP_BAL from STG_LOAN_CONTRACTS where V_ACCOUNT_NUMBER='GL_MAP001_7167'

	}
	
	public static List<CorrecEntryEditSummaryBean> getCorrectionData(String adjExposureId,String sInfodom,String page) {
		
		List<CorrecEntryEditSummaryBean> correcEntryEditSummaryBeanList = new ArrayList<CorrecEntryEditSummaryBean>();
		CorrecEntryEditSummaryBean correcEntryEditSummaryBean = new CorrecEntryEditSummaryBean();
	    String attribute_ValCols="";//logicalColName=Value=dataType=phyColName
	    String attribute_Val="";
	    //List correctionIDLst= new ArrayList<String>();
		try {
			StringBuilder queryFctCorrection = new StringBuilder();
			queryFctCorrection.append(" SELECT v_pp_logic_table_name, v_pp_table_name, v_pp_balance_logic_col_name, v_pp_balance_col_name,n_correction_id,");
			queryFctCorrection.append(" v_corr_exposure_id,n_correction_amount,v_user_comments,v_authorization_status,v_created_user, d_created_date, v_modified_user, d_modified_date,v_override_gl_code,v_auth_comments ");
			queryFctCorrection.append(",lm.v_category_desc ");
			queryFctCorrection.append(" FROM fct_gl_correction_entries  ce ");
			queryFctCorrection.append(" left outer join fsi_gl_lookup_master lm on lm.v_category_id=ce.v_authorization_status and lm.v_lookup_cd=14 ");
			queryFctCorrection.append(" WHERE V_ADJ_EXPOSURE_ID='"+adjExposureId+"' ");
		 	if(page.equalsIgnoreCase("approveEdit")){
		 		queryFctCorrection.append(" AND v_authorization_status = 'S' ");
		 	}
		 	queryFctCorrection.append(" ORDER BY d_created_date");
		 GL35Logger.logThis(queryFctCorrection.toString(), Priority.INFO_INT);
		 Cargo crFctCorrection = (Cargo) SMSServices.executeQuery(sInfodom, queryFctCorrection.toString(), false);
		 DACRecordSet rsFctCorrection = (DACRecordSet) crFctCorrection.getPayLoadObject();
		 GL35Logger.logThis("rsFctCorrection.getRowCount() : "+rsFctCorrection.getRowCount(),Priority.INFO_INT);
		 
		 if(rsFctCorrection.getRowCount()>0)
		 {
			 while(!rsFctCorrection.EOF()){
				 correcEntryEditSummaryBean = new CorrecEntryEditSummaryBean();
				 correcEntryEditSummaryBean.setRowId(rsFctCorrection.getCursorPosition()-1);
				 correcEntryEditSummaryBean.setTransactionEntity(rsFctCorrection.fetchElement(1));
				 correcEntryEditSummaryBean.setTransactionEntityPhysical(rsFctCorrection.fetchElement(2));
				 correcEntryEditSummaryBean.setBalanceColumn(rsFctCorrection.fetchElement(3));
				 correcEntryEditSummaryBean.setBalanceColumnPhysical(rsFctCorrection.fetchElement(4));
				 correcEntryEditSummaryBean.setCorrectionId(rsFctCorrection.fetchElement(5));
				 correcEntryEditSummaryBean.setCorrectionExpsoureId(rsFctCorrection.fetchElement(6));
				 //getAmountColumnVal
				 correcEntryEditSummaryBean.setOriginalAmt(getAmountColumnVal(adjExposureId,rsFctCorrection.fetchElement(6),sInfodom));
				 correcEntryEditSummaryBean.setCorrectionAmt(rsFctCorrection.fetchElement(7));
				 correcEntryEditSummaryBean.setSubmissionComments(rsFctCorrection.fetchElement(8));
				 correcEntryEditSummaryBean.setAuthStatus(rsFctCorrection.fetchElement(9));
				 correcEntryEditSummaryBean.setCreatedUser(rsFctCorrection.fetchElement(10));
				 correcEntryEditSummaryBean.setCreatedDate(rsFctCorrection.fetchElement(11));
				 correcEntryEditSummaryBean.setModifiedUser(rsFctCorrection.fetchElement(12));
				 correcEntryEditSummaryBean.setModifiedDate(rsFctCorrection.fetchElement(13));
				 correcEntryEditSummaryBean.setCorrectionGLCode(rsFctCorrection.fetchElement(14));
				 correcEntryEditSummaryBean.setCorrectionGLCodeDef(getConsoGlcode(adjExposureId, sInfodom));
				 correcEntryEditSummaryBean.setAuthStatusDesc(rsFctCorrection.fetchElement(16));
				 
				 if(page.equalsIgnoreCase("approveEdit")){
					 correcEntryEditSummaryBean.setAuthComments(rsFctCorrection.fetchElement(15));
				 }
				 
				 
				// correctionIDLst.add(rsFctCorrection.fetchElement(5));
				 String queryCorrectionAttr = " SELECT v_attribute_col_name,coalesce(v_override_value,v_col_value),V_COL_DATA_TYPE FROM fsi_corr_entry_attributes WHERE n_correction_id='"+rsFctCorrection.fetchElement(5)+"'";
				 GL35Logger.logThis("[DEBUG]queryCorrectionAttr:"+queryCorrectionAttr, Priority.DEBUG_INT);
				 
				 Cargo crCorrectionAttr = (Cargo) SMSServices.executeQuery(sInfodom, queryCorrectionAttr, false);
				 DACRecordSet rsCorrectionAttr = (DACRecordSet) crCorrectionAttr.getPayLoadObject();
				 attribute_ValCols="";
				 attribute_Val="";
				 while(!rsCorrectionAttr.EOF()){
					String[] logicalTabCol = GLCommon.getLogicalTabColName(sInfodom,rsFctCorrection.fetchElement(2) , rsCorrectionAttr.fetchElement(1));
					 
			    	if(rsCorrectionAttr.getCursorPosition()==1){
			    		attribute_ValCols = logicalTabCol[1]+"="+rsCorrectionAttr.fetchElement(2)+"="+rsCorrectionAttr.fetchElement(3)+"="+rsCorrectionAttr.fetchElement(1);
			    		attribute_Val	  =	logicalTabCol[1]+"="+rsCorrectionAttr.fetchElement(2);
			    	}else{
			    		attribute_ValCols += ","+logicalTabCol[1]+"="+rsCorrectionAttr.fetchElement(2)+"="+rsCorrectionAttr.fetchElement(3)+"="+rsCorrectionAttr.fetchElement(1);
			    		attribute_Val	  +=	","+logicalTabCol[1]+"="+rsCorrectionAttr.fetchElement(2);
			    	}
			    	rsCorrectionAttr.moveNext();
				 }
				 GL35Logger.logThis("[DEBUG]attribute_Val:"+attribute_Val, Priority.DEBUG_INT);
				 GL35Logger.logThis("[DEBUG]attribute_ValCols:"+attribute_ValCols, Priority.DEBUG_INT);
				 correcEntryEditSummaryBean.setAttributeVal(attribute_Val);
				 correcEntryEditSummaryBean.setAttributeValCols(attribute_ValCols);
				 correcEntryEditSummaryBean.setAdjustmentExposureId(adjExposureId);
			     correcEntryEditSummaryBeanList.add(correcEntryEditSummaryBean);
				 rsFctCorrection.moveNext();
			 }
			 

			 
		 }
		 else
		 {if(page.equalsIgnoreCase("approveEdit")){ }else{
			 String authStatusLookupDesc="-";
			 try{
				 
			 String lookupQuery="  select lm.v_category_desc from fsi_gl_lookup_master lm where lm.v_lookup_cd=14 and lm.v_category_id='P'";
			 Cargo lookupQueryCr = (Cargo)SMSServices.executeQuery(sInfodom,lookupQuery,false);
			 DACRecordSet lookupQueryRS = (DACRecordSet)lookupQueryCr.getPayLoadObject();
			 while(!lookupQueryRS.EOF()){
				 authStatusLookupDesc=lookupQueryRS.fetchElement(1);
				 lookupQueryRS.moveNext();
			 }
			 }catch(Exception e){
				 
			 }
			 
			 //ArrayList<String> solo_gl_codes = new ArrayList<String>();
			 //solo_gl_codes=(ArrayList<String>) getConsoGlcode(adjExposureId,sInfodom);
			
			correcEntryEditSummaryBean.setCorrectionGLCode(getConsoGlcode(adjExposureId,sInfodom));
			correcEntryEditSummaryBean.setCorrectionGLCodeDef(correcEntryEditSummaryBean.getCorrectionGLCode());
			
			String query = " SELECT v_source_pp_table_name, v_source_pp_balance_col_name  FROM fct_gl_adjustment_entries "+
						   " WHERE v_adj_exposure_id='"+adjExposureId+"'";//GL_MAP5225_2514
			Cargo cargo = (Cargo) SMSServices.executeQuery(sInfodom,query,false);
			DACRecordSet resultSet = (DACRecordSet) cargo.getPayLoadObject();
	 
			GL35Logger.logThis("correction list query -------- "+query, Priority.INFO_INT);
			rowId = 0;
			 
			while(!resultSet.EOF()) {
				String[] logicalTabColNameArray= GLCommon.getLogicalTabColName(sInfodom, resultSet.fetchElement(1), resultSet.fetchElement(2));
		    	correcEntryEditSummaryBean.setTransactionEntity(logicalTabColNameArray[0]);
		    	correcEntryEditSummaryBean.setTransactionEntityPhysical(resultSet.fetchElement(1));
		    	
		    	correcEntryEditSummaryBean.setBalanceColumn(logicalTabColNameArray[1]);
		    	correcEntryEditSummaryBean.setBalanceColumnPhysical(resultSet.fetchElement(2));
		    	correcEntryEditSummaryBean.setRowId(rowId);
		    	rowId++;
		    	GL35Logger.logThis("rowId="+rowId, Priority.INFO_INT);
		    	resultSet.moveNext();
			}
			 
		    String query2 = "  SELECT v_default_col_name,COALESCE(v_override_value,v_default_col_value), v_default_col_data_type FROM fsi_adj_entry_attributes WHERE v_adj_exposure_id='"+adjExposureId+"'";
		    Cargo cargo2 = (Cargo) SMSServices.executeQuery(sInfodom, query2, false);
		    DACRecordSet resultset2 = (DACRecordSet) cargo2.getPayLoadObject();

		    GL35Logger.logThis("[CorrectionEntryEditDAO] fsi_adj_entry_attributes->getRowCount() : "+resultset2.getRowCount(), Priority.INFO_INT);
		    while(!resultset2.EOF()){
		    	String[] logicalTabCol = GLCommon.getLogicalTabColName(sInfodom, resultSet.fetchElement(1), resultset2.fetchElement(1));
		    	if(resultset2.getCursorPosition()==1){
		    		attribute_ValCols = logicalTabCol[1]+"="+resultset2.fetchElement(2)+"="+resultset2.fetchElement(3)+"="+resultset2.fetchElement(1);
		    		attribute_Val	  =	logicalTabCol[1]+"="+resultset2.fetchElement(2);
		    	}
		    	else{
		    		attribute_ValCols += ","+logicalTabCol[1]+"="+resultset2.fetchElement(2)+"="+resultset2.fetchElement(3)+"="+resultset2.fetchElement(1);
		    		attribute_Val	  +=	","+logicalTabCol[1]+"="+resultset2.fetchElement(2);
		    	}
		    	resultset2.moveNext();
		    }
		    GL35Logger.logThis("[CorrectionEntryEditDAO] fsi_adj_entry_attributes->getRowCount() : "+resultset2.getRowCount(), Priority.INFO_INT);
			correcEntryEditSummaryBean.setAttributeVal(attribute_Val);
			correcEntryEditSummaryBean.setAttributeValCols(attribute_ValCols);
			correcEntryEditSummaryBean.setAdjustmentExposureId(adjExposureId);
			correcEntryEditSummaryBean.setAuthStatusDesc(authStatusLookupDesc);
		    correcEntryEditSummaryBeanList.add(correcEntryEditSummaryBean);
		 }
		 }
		 
		 GL35Logger.logThis("correcEntryEditSummaryBeanList Data Size="+correcEntryEditSummaryBeanList.size(), Priority.INFO_INT);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			GL35Logger.logThis("Exception Occured"+e.getStackTrace(), Priority.ERROR_INT);
			GL35Logger.logThis("Exception Occured"+e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
		}
		return correcEntryEditSummaryBeanList;
		
	}
	
	 /*method for getting the Correction GL Code's*/
	 public static ArrayList<String> getConsoGlcode(String adjExposureId,String sInfodom){
		String Qry1="SELECT v_gl_map_id,v_gl_code,n_version_number FROM fct_gl_adjustment_entries WHERE V_ADJ_EXPOSURE_ID='"+adjExposureId+"'";
		String gl_map_id="";
		String mapVerNo = "";
		String gl_code="";
		ArrayList<String> solo_gl_codes = new ArrayList<String>();
		Cargo cr1=(Cargo)SMSServices.executeQuery(sInfodom, Qry1, false);
		DACRecordSet rs1=(DACRecordSet)cr1.getPayLoadObject();
		while(!rs1.EOF()) {
			gl_map_id=rs1.fetchElement(1);
			gl_code=rs1.fetchElement(2);
			mapVerNo=rs1.fetchElement(3);
			rs1.moveNext();
		}

		String Qry2="SELECT 1 FROM fsi_gl_mapping_master WHERE v_gl_map_id='"+gl_map_id+"'"+
				" AND upper(V_RECON_TYPE)='A' and upper(V_CONSOLIDATION_TYPE)='C' and upper(V_RECON_DEFINITION_LEVEL)='G' "+
				" AND n_version_number="+mapVerNo;
		Cargo cr2=(Cargo)SMSServices.executeQuery(sInfodom, Qry2, false);
		DACRecordSet rs2=(DACRecordSet)cr2.getPayLoadObject();
		if(rs2.getRowCount()>0){
			String Qry3="SELECT V_SOLO_GL_CODE FROM SETUP_GL_CODE_MAPPING WHERE V_CONSOLIDATION_GL_CODE='"+gl_code+"'";
			Cargo cr3 = (Cargo)SMSServices.executeQuery(sInfodom, Qry3, false);
			DACRecordSet rs3 = (DACRecordSet) cr3.getPayLoadObject();
			while(!rs3.EOF()){
				solo_gl_codes.add(rs3.fetchElement(1));
				rs3.moveNext();
			}
		}
		return solo_gl_codes;
	}
	
	public static String setCorrectionEntrySpecMulti(String[] selectedExposureIds,String sInfodom){
		String retMsg = "";
		boolean chkF=true;
		String checkQry="";
		String updQry="";
		Vector<String> vUpdQry = new Vector<String>();
		try{
			//SELECT 1 FROM fct_gl_correction_entries WHERE v_authorization_status IN('P','R') AND V_ADJ_EXPOSURE_ID ='GL_MAP001_7169';
			
			for(String adjExpId:selectedExposureIds){
				checkQry="SELECT 1 FROM fct_gl_correction_entries WHERE v_authorization_status IN('P','R') AND V_ADJ_EXPOSURE_ID ='"+adjExpId+"'";
				Cargo cr = (Cargo)SMSServices.executeQuery(sInfodom, checkQry, false);
				DACRecordSet rs = (DACRecordSet)cr.getPayLoadObject();
				if(rs.getRowCount()==0){
					chkF=false;
				}
			}
			if(chkF){
				for(String adjExpId:selectedExposureIds){
					updQry=" UPDATE fct_gl_correction_entries SET v_authorization_status='S' ,v_user_comments=coalesce(v_user_comments,'Submitted') WHERE v_authorization_status IN('P','R') AND V_ADJ_EXPOSURE_ID ='"+adjExpId+"'";
					vUpdQry.add(updQry);
					//vector=updQry;
				}
				for(String qryStr:vUpdQry)	GL35Logger.logThis(qryStr, Priority.INFO_INT);
				
				String[] sbVectorArray = (String[])vUpdQry.toArray(new String[vUpdQry.size()]);
				
				Cargo cr = SMSServices.executeBatch(sInfodom,sbVectorArray,true);
				GL35Logger.logThis("executeBatch cargo for setCorrectionEntrySpecMulti returned : "+cr,Priority.INFO_INT);

				if (cr != null && !cr.getErrorFlag()){
					GL35Logger.logThis( "Successfull submitted - Cargo Returned : "+cr, Priority.INFO_INT);
					retMsg="true";
				}else{
					GL35Logger.logThis( "Failed to submit - Cargo Returned : "+cr, Priority.WARN_INT);
					retMsg="error";
				}
			}else{
				retMsg="false";//one or more adjustment entries selected are not saved
			}
			
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		return retMsg;
	}
	
	public static String authCorrectionEditMulti(String sInfodom,String sUserId,String selectedAdjExposureIds,String authStatus){
		String retMsg="";
		Vector<String> vAuthCorrectionEditAry=new Vector<String>();
		String auth_comments="";
		if(authStatus.equalsIgnoreCase("A")) auth_comments="Approved";
		else auth_comments="Rejected";
		try{
			String[] selectedAdjExposureIdsAry = selectedAdjExposureIds.split("~");
			for(String adjExpId:selectedAdjExposureIdsAry){
				String qry1="select n_correction_id,v_corr_exposure_id from fct_gl_correction_entries where v_adj_exposure_id='"+adjExpId+"' and v_authorization_status='S'";
				Cargo cr1 = (Cargo) SMSServices.executeQuery(sInfodom, qry1, false);
				DACRecordSet rs1 = (DACRecordSet) cr1.getPayLoadObject();
				while(!rs1.EOF()){
					String corrId = rs1.fetchElement(1);
					String corrExpId = rs1.fetchElement(2);
					String qry2="update fct_gl_correction_entries set v_auth_comments='"+auth_comments+"',v_modified_user='"+sUserId+"',d_modified_date=SYSDATE where n_correction_id='"+corrId+"' ";
					vAuthCorrectionEditAry.add(qry2);
					StringBuilder qry3= new StringBuilder();
					qry3.append(" INSERT INTO FSI_GL_INTERMEDIATE_CORR_AUTH ");
					qry3.append(" (n_correction_id, v_adj_exposure_id,v_corr_exposure_id,v_authorization_status,v_auth_user,v_auth_comments,d_authorized_date)VALUES(  ");
					qry3.append(" "+corrId+",  ");
					qry3.append(" '"+adjExpId+"', ");
					qry3.append(" '"+corrExpId+"',  ");
					qry3.append(" '"+authStatus+"',  ");
					qry3.append(" '"+sUserId+"',  ");
					qry3.append(" '"+auth_comments+"',  ");
					qry3.append(" SYSDATE)  ");
					vAuthCorrectionEditAry.add(qry3.toString());
					rs1.moveNext();
				}
				
			}
			
			GL35Logger.logThis("INSERT/UPDATE Queries for Correction Entry Approval : ", Priority.INFO_INT);
			for(String qryStr:vAuthCorrectionEditAry)	GL35Logger.logThis(qryStr, Priority.INFO_INT);
			
			String[] sbVectorArray = (String[])vAuthCorrectionEditAry.toArray(new String[vAuthCorrectionEditAry.size()]);
			Cargo cr = SMSServices.executeBatch(sInfodom,sbVectorArray,true);
			GL35Logger.logThis("executeBatch cargo for authCorrectionEditMulti returned : "+cr,Priority.INFO_INT);
			if (cr != null && !cr.getErrorFlag()){
				if(authStatus.equalsIgnoreCase("A") || authStatus.equalsIgnoreCase("R")){
					GL35Logger.logThis( "Insert/Update Successfull - Cargo Returned : "+cr, Priority.INFO_INT);
					retMsg="";
					String triggerDT = "SELECT PKG_GLRECON_PROCESSING.fn_corr_auth FROM dual";
					
					Cargo triggerDTcr = (Cargo) SMSServices.executeQuery(sInfodom,triggerDT,false);
					GL35Logger.logThis("function query fired....", Priority.DEBUG_INT);
					GL35Logger.logThis("Cargo Returned : "+triggerDTcr, Priority.DEBUG_INT);
	
					DACRecordSet triggerDTrs = (DACRecordSet) triggerDTcr.getPayLoadObject();
					GL35Logger.logThis("ResultSet returned : "+triggerDTrs.fetchElement(1), Priority.DEBUG_INT);
	
					if(triggerDTrs.fetchElement(1).equals("1")) retMsg = "SUCCESS";
					else if(triggerDTrs.fetchElement(1).equals("0")) retMsg = "FAIL";
					else retMsg = triggerDTrs.fetchElement(1);
				}else{
					 retMsg = "SUCCESS"; 
				}
			}else{
				GL35Logger.logThis( "Insert/Update Failed - Cargo Returned : "+cr, Priority.WARN_INT);
				retMsg="FAIL";
			}
			
		}catch(Exception e){
			e.printStackTrace();
			GL35Logger.logThis("Exception occured : "+e.getLocalizedMessage(), Priority.ERROR_INT);
			retMsg="ERROR";
		}
		return retMsg;
	}
	
	/*
	 * corr_exposure_id+"~"+correction_id+"~"+auth_comments
	 * authStatus:'S'/'A'/'R'
	 * */
	public static String authCorrectionEdit(String sInfodom,String sUserId,String[] authCorr_Values,String selectedExposureId,String authStatus){
		String retMsg="";
		Vector<String> vAuthCorrectionEditAry=new Vector<String>();
		try{
			for(int i=0; i<authCorr_Values.length;i++){
				String[] authCorr_ValuesAry = authCorr_Values[i].split("~");
				String corr_exposure_id=authCorr_ValuesAry[0];
				String correction_id=authCorr_ValuesAry[1];
				String auth_comments=authCorr_ValuesAry[2];
				if(auth_comments=="-") auth_comments="";
				if(authStatus.equalsIgnoreCase("S")){
					StringBuilder updQry = new StringBuilder();
					updQry.append(" UPDATE fct_gl_correction_entries ");
					updQry.append(" SET ");
					updQry.append(" v_auth_comments='"+auth_comments+"' ");
					updQry.append(" ,v_modified_user='"+sUserId+"', ");
					updQry.append(" d_modified_date=SYSDATE ");
					//if(authStatus.equalsIgnoreCase("A") || authStatus.equalsIgnoreCase("R")){
					//updQry.append(" ,v_auth_user='"+sUserId+"', ");
					//updQry.append(" d_authorized_date=SYSDATE ");
					//updQry.append(" v_authorization_status='"+authStatus+"' ");
					//}
					updQry.append(" WHERE n_correction_id="+correction_id+" ");
					vAuthCorrectionEditAry.add(updQry.toString());
				}
				 
				if(authStatus.equalsIgnoreCase("A") || authStatus.equalsIgnoreCase("R")){
					if("".equals(auth_comments) || "-".equals(auth_comments)) {
						if(authStatus.equalsIgnoreCase("A")) auth_comments="Approved";
						else auth_comments="Rejected";
					}
					StringBuilder insrtQry = new StringBuilder();
					insrtQry.append(" INSERT INTO FSI_GL_INTERMEDIATE_CORR_AUTH ");
					insrtQry.append(" (n_correction_id, v_adj_exposure_id,v_corr_exposure_id,v_authorization_status,v_auth_user,v_auth_comments,d_authorized_date)VALUES( ");
					insrtQry.append(" "+correction_id+", ");
					insrtQry.append(" '"+selectedExposureId+"', ");
					insrtQry.append(" '"+corr_exposure_id+"', ");
					insrtQry.append(" '"+authStatus+"', ");
					insrtQry.append(" '"+sUserId+"', ");
					insrtQry.append(" '"+auth_comments+"', ");
					insrtQry.append(" SYSDATE ");
					insrtQry.append(" ) ");
					vAuthCorrectionEditAry.add(insrtQry.toString());
				}
			}
			GL35Logger.logThis("INSERT/UPDATE Queries for Correction Entry Approval : ", Priority.INFO_INT);
			for(String qryStr:vAuthCorrectionEditAry)	GL35Logger.logThis(qryStr, Priority.INFO_INT);
			
			String[] sbVectorArray = (String[])vAuthCorrectionEditAry.toArray(new String[vAuthCorrectionEditAry.size()]);
			Cargo cr = SMSServices.executeBatch(sInfodom,sbVectorArray,true);
			GL35Logger.logThis("executeBatch cargo for authCorrectionEdit returned : "+cr,Priority.INFO_INT);

			if (cr != null && !cr.getErrorFlag()){
				if(authStatus.equalsIgnoreCase("A") || authStatus.equalsIgnoreCase("R")){
					GL35Logger.logThis( "Insert/Update Successfull - Cargo Returned : "+cr, Priority.INFO_INT);
					retMsg="";
					String triggerDT = "SELECT PKG_GLRECON_PROCESSING.fn_corr_auth FROM dual";
					
					Cargo triggerDTcr = (Cargo) SMSServices.executeQuery(sInfodom,triggerDT,false);
					GL35Logger.logThis("function query fired....", Priority.DEBUG_INT);
					GL35Logger.logThis("Cargo Returned : "+triggerDTcr, Priority.DEBUG_INT);
	
					DACRecordSet triggerDTrs = (DACRecordSet) triggerDTcr.getPayLoadObject();
					GL35Logger.logThis("ResultSet returned : "+triggerDTrs.fetchElement(1), Priority.DEBUG_INT);
	
					if(triggerDTrs.fetchElement(1).equals("1")) retMsg = "SUCCESS";
					else if(triggerDTrs.fetchElement(1).equals("0")) retMsg = "FAIL";
					else retMsg = triggerDTrs.fetchElement(1);
				}else{
					 retMsg = "SUCCESS"; 
				}
			}else{
				GL35Logger.logThis( "Insert/Update Failed - Cargo Returned : "+cr, Priority.WARN_INT);
				retMsg="FAIL";
			}
		}catch (Exception e) {
			e.printStackTrace();
			GL35Logger.logThis("Exception occured : "+e.getLocalizedMessage(), Priority.ERROR_INT);
			retMsg="ERROR";
		}
		return retMsg;
	}
	
	
	/**
	 * This function is used to insert/update data into FCT_GL_CORRECTION_ENTRY and FSI_CORR_ENTRY_ATTRIBUTES table
	 * @Param sInfodom
	 * @Param sUserId
	 * @Param selectedExposureId : Adjustment Exposure ID selected as String
	 * @Param editedCorrecEntrySpecArray : Correction Entry data as String[] 0 - rowid,
	 * 1 - transactionEntity
	 * 2 - transactionEntityPhysical
	 * 3 - balanceColumn
	 * 4 - balanceColumnPhysical
	 * 5 - attribute Values (eg: 7,USGAAP,0.08)
	 * 6 - attribute name, attribute value, data type, attribute physical name (eg: =0.08=NUMBER=N_APR_RATE,=USGAAP=VARCHAR2=V_GAAP_CODE)
	 * 7 - Correction Exposure ID
	 * 8 - Correction GL Code
	 * 9 - Correction Amount
	 * 10- Submission Comments
	 * 11- correction ID
	 * 12- adjustment Exposure ID
	 * @return Status as Boolean
	 */
	
	public static String setCorrectionEntrySpec(String selectedExposureId, String[] editedCorrecEntrySpecArray, 
			String sInfodom, String sUserId,String submitStatus,String mapId,String mapVersionNumber){
		String retStatus = "false";
		try{
			//String[] editedCorrecEntrySpecArray2 = editedCorrecEntrySpecArray;
			List<String> dimColList = new ArrayList<String>();
			dimColList = EditPageDAO.populateDimensionsHeaderArray(mapId, sInfodom, mapVersionNumber);
			String dimColNames = "";
			for(String str:dimColList){
				dimColNames+=str.split("~")[1]+",";
			}
			GL35Logger.logThis("Dimension Columns for mapId "+mapId+" and  mapVersionNumber "+mapVersionNumber+" are : dimColNames="+dimColNames, Priority.DEBUG_INT);
			
			Vector<String> sbVector = new Vector<String>();
			String corrIdSeq = "";
			
			/* code to validate the correction exp ID's against the adj exp ID's with DT FN_CORRECTION_ENTRY_VALIDATION - START */
			boolean validate_flag=false;
			ArrayList<String> alRetVal = new ArrayList<String>();
			Map<String,String> mapRetVal = new HashMap<String, String>();
			for(int i=0; i<editedCorrecEntrySpecArray.length;i++){
				String[] editedCorrecEntrySpecArray2 = editedCorrecEntrySpecArray[i].split("~");
				
				String Qry1="SELECT v_gl_code FROM fct_gl_adjustment_entries WHERE V_ADJ_EXPOSURE_ID='"+selectedExposureId+"'";
				String gl_code="";
				String gl_codeFinal="";
				//ArrayList<String> solo_gl_codes = new ArrayList<String>();
				Cargo cr1=(Cargo)SMSServices.executeQuery(sInfodom, Qry1, false);
				DACRecordSet rs1=(DACRecordSet)cr1.getPayLoadObject();
				while(!rs1.EOF()) {
					gl_code=rs1.fetchElement(1);
					rs1.moveNext();
				}
				if("".equals(editedCorrecEntrySpecArray2[8])){
					gl_codeFinal=gl_code;
				}else{
					gl_codeFinal=editedCorrecEntrySpecArray2[8];
				}
				//P_V_ADJ_EXP_ID  in VARCHAR2 , P_V_CORR_EXP_ID in VARCHAR2 , P_V_GL_CODE IN VARCHAR2, P_V_VALIDATION_LEVEL in VARCHAR2 DEFAULT 'M' )
				String vQry="select FN_CORRECTION_ENTRY_VALIDATION('"+selectedExposureId+"','"+editedCorrecEntrySpecArray2[7]+"','"+gl_codeFinal+"',null) from dual";
				GL35Logger.logThis("Validate Query : "+vQry, Priority.INFO_INT);
				Cargo vCr=(Cargo) SMSServices.executeQuery(sInfodom, vQry, true);
				DACRecordSet vRs = (DACRecordSet) vCr.getPayLoadObject();
				String retVal="";
				
				//al.contains(arg0)
				while(!vRs.EOF()){
					//alRetVal.add(vRs.fetchElement(1));
					mapRetVal.put(editedCorrecEntrySpecArray2[7], vRs.fetchElement(1));
					vRs.moveNext();
				}
				/*RETURN ('1') if success 
          		failed and GL level - RETURN ('0'); 
          		failed and Map level - RETURN ('-1');*/
				
				//P_V_ADJ_EXP_ID  in VARCHAR2,P_V_CORR_EXP_ID in VARCHAR2,P_V_GL_CODE IN VARCHAR2,P_V_VALIDATION_LEVEL in VARCHAR2 DEFAULT 'M'
			}
			if(mapRetVal.containsValue("0") || mapRetVal.containsValue("-1")){
				if(mapRetVal.containsValue("0")){
					retStatus="G~";
				}else{
					retStatus="M~";
				}
				
				for(String key:mapRetVal.keySet()){
					if(mapRetVal.get(key).equals("0") || mapRetVal.get(key).equals("-1")){
						retStatus+=key+",";
					}
				}
				validate_flag=true;
				retStatus=retStatus.substring(0, retStatus.length()-1);
				GL35Logger.logThis("Validate Failed and returned status : "+retStatus, Priority.INFO_INT);
				return retStatus;
			}else if(mapRetVal.containsValue("1")){
				validate_flag=false;
			}else{
				for(String key:mapRetVal.keySet()){
					if(mapRetVal.get(key).equals("0") || mapRetVal.get(key).equals("-1") || mapRetVal.get(key).equals("1")){
						
					}else{
						retStatus=mapRetVal.get(key);
					}
				}
				GL35Logger.logThis("Error while Validating - DT returned : "+retStatus, Priority.WARN_INT);
				return retStatus;
			}
			/* code to validate the correction exp ID's against the adj exp ID's with DT FN_CORRECTION_ENTRY_VALIDATION - END */
			
			for(int i=0; i<editedCorrecEntrySpecArray.length;i++){
				String[] editedCorrecEntrySpecArray2 = editedCorrecEntrySpecArray[i].split("~");
				GL35Logger.logThis("[DEBUG]"+editedCorrecEntrySpecArray[i], Priority.DEBUG_INT);
				GL35Logger.logThis("editedCorrecEntrySpecArray2.length "+editedCorrecEntrySpecArray2.length,Priority.INFO_INT);
				GL35Logger.logThis("Correction Id : "+editedCorrecEntrySpecArray2[11],Priority.INFO_INT);
				String subComments = editedCorrecEntrySpecArray2[10];
				if(submitStatus.equalsIgnoreCase("S")){
					if("".equals(subComments)){
						subComments="Submitted";	
					}
				}
				if(editedCorrecEntrySpecArray2[11].equals("-999")){
					//String[] logicalTabColNameArray= GLCommon.getLogicalTabColName(sInfodom, editedCorrecEntrySpecArray2[], editedCorrecEntrySpecArray2[]);
					String getCorrIDQry = "SELECT seq_gl_correctionid.NEXTVAL FROM dual";
					Cargo crGetCorrIdQry = (Cargo) SMSServices.executeQuery(sInfodom, getCorrIDQry, false);
					DACRecordSet rsGetCorrIdQry = (DACRecordSet) crGetCorrIdQry.getPayLoadObject();
					while(!rsGetCorrIdQry.EOF()){
						corrIdSeq = rsGetCorrIdQry.fetchElement(1);
						rsGetCorrIdQry.moveNext();
					}
					
					StringBuilder sb = new StringBuilder();
					sb.append(" INSERT INTO fct_gl_correction_entries(n_correction_id,  ");
					sb.append(" v_execution_identifier,  ");
					sb.append(" v_gl_map_id,  ");
					sb.append(" n_version_number,  ");
					sb.append(" v_gl_code,  ");
					sb.append(dimColNames);
					/*sb.append(" V_ENTITY_CODE,  ");
					sb.append(" V_ISO_CURRENCY_CD,  ");
					sb.append(" v_prod_code,  ");
					sb.append(" v_business_unit_code,  ");
					sb.append(" v_acct_branch_code,  ");
					sb.append(" v_cust_class_code,  ");
					sb.append(" V_ORG_UNIT_CODE,  ");*/
					sb.append(" v_pp_table_name,  ");
					sb.append(" v_pp_logic_table_name,  ");
					sb.append(" v_pp_balance_col_name,  ");
					sb.append(" v_pp_balance_logic_col_name,  ");
					sb.append(" N_DATE_SKEY,  ");
					sb.append(" v_adj_exposure_id,  ");
					sb.append(" v_corr_exposure_id,  ");
					sb.append(" n_correction_amount,  ");
					sb.append(" v_created_user,  ");
					sb.append(" d_created_date,  ");
					sb.append(" v_user_comments,  ");
					sb.append(" v_authorization_status,  ");
					sb.append(" f_intra_group,V_OVERRIDE_GL_CODE) ");
					sb.append("  (SELECT "+corrIdSeq+", v_execution_identifier,v_gl_map_id,n_version_number,v_gl_code, ");
					sb.append(dimColNames);
					//sb.append(" V_ENTITY_CODE, V_ISO_CURRENCY_CD, v_prod_code, v_business_unit_code, v_acct_branch_code, v_cust_class_code, V_ORG_UNIT_CODE , ");
					sb.append(" v_source_pp_table_name , ");
					sb.append(" '"+editedCorrecEntrySpecArray2[1]+"', ");
					sb.append(" v_source_pp_balance_col_name , ");
					sb.append(" '"+editedCorrecEntrySpecArray2[3]+"', ");
					sb.append(" N_DATE_SKEY, v_adj_exposure_id , ");
					sb.append(" '"+editedCorrecEntrySpecArray2[7]+"', ");
					sb.append(" "+editedCorrecEntrySpecArray2[9]+", ");
					sb.append(" '"+sUserId+"', ");
					sb.append(" SYSDATE, ");
					sb.append(" '"+subComments+"', ");
					sb.append(" '"+submitStatus+"',F_INTRA_GROUP ");
					sb.append(" ,'"+editedCorrecEntrySpecArray2[8]+"' ");
					sb.append("  FROM fct_gl_adjustment_entries a WHERE v_adj_exposure_id='"+selectedExposureId+"') ");
					//GL35Logger.logThis("fct_gl_correction_entry insert query : "+sb.toString(), Priority.INFO_INT);
					//Cargo cr = (Cargo) SMSServices.e
					sbVector.add(sb.toString());
					if(!"".equals(editedCorrecEntrySpecArray2[6].trim())){

					String[] defaultValArray = editedCorrecEntrySpecArray2[6].split(",");
					GL35Logger.logThis("[DEBUG]"+editedCorrecEntrySpecArray2[6], Priority.DEBUG_INT);
					GL35Logger.logThis("[DEBUG]"+defaultValArray.length, Priority.DEBUG_INT);
					for(int j=0;j<defaultValArray.length;j++){
						GL35Logger.logThis("[DEBUG]"+defaultValArray[j], Priority.DEBUG_INT);
						String[] defaultValArray2 = defaultValArray[j].split("=");
						//GL35Logger.logThis("[DEBUG]"+defaultValArray2.toString(), Priority.DEBUG_INT);
						GL35Logger.logThis("[DEBUG]"+defaultValArray2[1], Priority.DEBUG_INT);
						StringBuilder sb2 = new StringBuilder();
						//=0.08=NUMBER=N_APR_RATE,=2=NUMBER=N_PD_PERCENT,=USGAAP=VARCHAR2=V_GAAP_CODE,=N=CHAR=F_ACC_HEALTH_INS_FLG
						/*INSERT INTO FSI_CORR_ENTRY_ATTRIBUTES 
						(N_CORRECTION_ID, V_ATTRIBUTE_COL_NAME, V_COL_VALUE, V_OVERRIDE_VALUE, V_COL_DATA_TYPE, F_NEW_ATTRIBUTE ) 
						values(42,
						'F_ACC_HEALTH_INS_FLG',
						NVL((SELECT COALESCE(v_override_value,v_default_col_value) FROM fsi_adj_entry_attributes 
						WHERE v_adj_exposure_id='GL_MAP5225_2511' AND v_default_col_name='F_ACC_HEALTH_INS_FLG'),'YES'),

						sb2.append(" CASE WHEN (SELECT COUNT(*) FROM fsi_adj_entry_attributes  ");
						sb2.append(" WHERE v_adj_exposure_id='"+selectedExposureId+"' AND v_default_col_name='"+defaultValArray2[3]+"')>0 ");
						sb2.append(" THEN '"+defaultValArray2[1]+"' ");
						sb2.append(" ELSE NULL END, ");
						'CHAR',
						sb2.append(" CASE WHEN (SELECT COUNT(*) FROM fsi_adj_entry_attributes  ");
						sb2.append(" WHERE v_adj_exposure_id='"+selectedExposureId+"' AND v_default_col_name='"+defaultValArray2[3]+"')>0 ");
						sb2.append(" THEN 'N' ");
						sb2.append(" ELSE 'Y' END ");
						) */
						sb2.append(" INSERT INTO FSI_CORR_ENTRY_ATTRIBUTES ");
						sb2.append(" (N_CORRECTION_ID, V_ATTRIBUTE_COL_NAME, V_COL_VALUE, V_OVERRIDE_VALUE, V_COL_DATA_TYPE, F_NEW_ATTRIBUTE ) ");
						//sb2.append(" (SELECT "+corrIdSeq+",V_DEFAULT_COL_NAME,V_DEFAULT_COL_VALUE,'',V_DEFAULT_COL_DATA_TYPE,NULL FROM FSI_ADJ_ENTRY_ATTRIBUTES) ");
						sb2.append(" values("+corrIdSeq+",'"+defaultValArray2[3]+"'," );
						sb2.append(" NVL((SELECT COALESCE(v_override_value,v_default_col_value) FROM fsi_adj_entry_attributes "); 
						sb2.append(" WHERE v_adj_exposure_id='"+selectedExposureId+"' AND v_default_col_name='"+defaultValArray2[3]+"'),'"+defaultValArray2[1]+"') " );
						sb2.append(",");
						
						sb2.append(" CASE WHEN (SELECT COUNT(*) FROM fsi_adj_entry_attributes  ");
						sb2.append(" WHERE v_adj_exposure_id='"+selectedExposureId+"' AND v_default_col_name='"+defaultValArray2[3]+"')>0 ");
						sb2.append(" THEN '"+defaultValArray2[1]+"' ");
						sb2.append(" ELSE NULL END ");
						
						sb2.append(",'"+defaultValArray2[2]+"'," );
						sb2.append(" CASE WHEN (SELECT COUNT(*) FROM fsi_adj_entry_attributes  ");
						sb2.append(" WHERE v_adj_exposure_id='"+selectedExposureId+"' AND v_default_col_name='"+defaultValArray2[3]+"')>0 ");
						sb2.append(" THEN 'N' ");
						sb2.append(" ELSE 'Y' END ");

						sb2.append(") ");
						//GL35Logger.logThis("FSI_CORR_ENTRY_ATTRIBUTES insert query : "+sb2.toString(), Priority.INFO_INT);
						sbVector.add(sb2.toString());
					}
					
					}else{
						GL35Logger.logThis("No Default Value Attributes for the correction ID", Priority.DEBUG_INT);
					}
				}
				else{
					String updFctCorrecQry = "update fct_gl_correction_entries set v_corr_exposure_id='"+editedCorrecEntrySpecArray2[7]+"' ," +
							" n_correction_amount="+editedCorrecEntrySpecArray2[9]+", " +
							" v_user_comments='"+subComments+"',v_authorization_status='"+submitStatus+"'  " +
							" ,v_modified_user='"+sUserId+"' "+
							" , d_modified_date=SYSDATE "+
							" where n_correction_id="+editedCorrecEntrySpecArray2[11];
					sbVector.add(updFctCorrecQry);
					String delCorrecAttr = "DELETE FROM FSI_CORR_ENTRY_ATTRIBUTES WHERE N_CORRECTION_ID="+editedCorrecEntrySpecArray2[11]+"";
					sbVector.add(delCorrecAttr);
					if(!"".equals(editedCorrecEntrySpecArray2[6])){
					String[] defaultValArray = editedCorrecEntrySpecArray2[6].split(",");
					for(int j=0;j<defaultValArray.length;j++){
						String[] defaultValArray2 = defaultValArray[j].split("=");//=0.08=NUMBER=N_APR_RATE,=USGAAP=VARCHAR2=V_GAAP_CODE
						StringBuilder sb2 = new StringBuilder();
						//String chkUpdCorrecAttr = "select * from FSI_CORR_ENTRY_ATTRIBUTES where N_CORRECTION_ID="+editedCorrecEntrySpecArray2[11]+" and V_ATTRIBUTE_COL_NAME='"+defaultValArray2[3]+"' ";
						//Cargo crChkUpdCorrecAttr = (Cargo) SMSServices.executeQuery(sInfodom, chkUpdCorrecAttr, false);
						//DACRecordSet rsChkUpdCorrecAttr = (DACRecordSet) crChkUpdCorrecAttr.getPayLoadObject();
						//if(rsChkUpdCorrecAttr.getRowCount()>0){
							//sb2.append(" UPDATE fsi_corr_entry_attributes SET v_override_value='"+defaultValArray2[1]+"' WHERE n_correction_id="+editedCorrecEntrySpecArray2[11]+" AND v_attribute_col_name='"+defaultValArray2[3]+"' ");
							//update
						//}else{
							//insert
							sb2.append(" INSERT INTO FSI_CORR_ENTRY_ATTRIBUTES ");
							sb2.append(" (N_CORRECTION_ID, V_ATTRIBUTE_COL_NAME, V_COL_VALUE, V_OVERRIDE_VALUE, V_COL_DATA_TYPE, F_NEW_ATTRIBUTE ) ");
							sb2.append(" values("+editedCorrecEntrySpecArray2[11]+",'"+defaultValArray2[3]+"'," );
							sb2.append(" NVL((SELECT COALESCE(v_override_value,v_default_col_value) FROM fsi_adj_entry_attributes "); 
							sb2.append(" WHERE v_adj_exposure_id='"+selectedExposureId+"' AND v_default_col_name='"+defaultValArray2[3]+"'),'"+defaultValArray2[1]+"') " );
							sb2.append(",");

							sb2.append(" CASE WHEN (SELECT COUNT(*) FROM fsi_adj_entry_attributes  ");
							sb2.append(" WHERE v_adj_exposure_id='"+selectedExposureId+"' AND v_default_col_name='"+defaultValArray2[3]+"')>0 ");
							sb2.append(" THEN '"+defaultValArray2[1]+"' ");
							sb2.append(" ELSE NULL END ");

							sb2.append(",'"+defaultValArray2[2]+"'," );
							sb2.append(" CASE WHEN (SELECT COUNT(*) FROM fsi_adj_entry_attributes  ");
							sb2.append(" WHERE v_adj_exposure_id='"+selectedExposureId+"' AND v_default_col_name='"+defaultValArray2[3]+"')>0 ");
							sb2.append(" THEN 'N' ");
							sb2.append(" ELSE 'Y' END ");

							sb2.append(") ");
						//}
						//String updCorrecAttr="";
						sbVector.add(sb2.toString());
					}
					}else{
						GL35Logger.logThis("No Default Value Attributes for the correction ID", Priority.DEBUG_INT);
					}
				}
			}
			GL35Logger.logThis("INSERT/UPDATE Queries for Correction Entry Specification : ", Priority.INFO_INT);
			for(String qryStr:sbVector)	GL35Logger.logThis(qryStr, Priority.INFO_INT);
			
			String[] sbVectorArray = (String[])sbVector.toArray(new String[sbVector.size()]);
			
			Cargo cr = SMSServices.executeBatch(sInfodom,sbVectorArray,true);
			GL35Logger.logThis("executeBatch cargo for setCorrectionEntrySpec returned : "+cr,Priority.INFO_INT);

			if (cr != null && !cr.getErrorFlag()){
				GL35Logger.logThis( "setCorrectionEntrySpec Insertion Successfull - Cargo Returned : "+cr, Priority.INFO_INT);
				retStatus="true";
			  //	result=" Task Filter Data Insertion Successfull - Cargo Returned : "+cr;
			}else{
				GL35Logger.logThis( " setCorrectionEntrySpec Insertion Failed - Cargo Returned : "+cr, Priority.WARN_INT);
			  	//result="Task Filter Data Insertion Failed - Cargo Returned : "+cr;
			}
		}catch (Exception e) {
			e.printStackTrace();
			GL35Logger.logThis("Exception occured : "+e.getLocalizedMessage(), Priority.ERROR_INT);
		}
		return retStatus;
	}
	
}

