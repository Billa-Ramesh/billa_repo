/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GlobalParamAddDAO.java
* Title         :
* Description   :
* @author       : Deepak Dagar 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.ofs.erm.gl.model.GlobalParamAddBean;
import org.apache.log4j.Priority;
import com.ofs.erm.gl.global.GL35Logger;

public class GlobalParamAddDAO 
{

	
	public static String insertGlobalParameter(GlobalParamAddBean addBean,String infodom) {
			String status = "false";
			GL35Logger.logThis("Inside insertGlobalParameter of GlobalParamAddDao", Priority.DEBUG_INT);
			String selectedDate = "'"+addBean.getSelectedDate()+"'";
			String selectedMonth = "'"+addBean.getSelectedMonth()+"'";
			String createdUser = "'"+addBean.getCreatedUser()+"'";
			String createdDate = "'"+addBean.getCreationDate()+"'";
			
			String tempModifiedUser = addBean.getModifiedUser();
			if((tempModifiedUser == "")||(tempModifiedUser == null))
			{
				tempModifiedUser = "-";
			}
			
			String tempModifiedDate = addBean.getModificationDate();
			
			
			String modifiedUser = "'"+tempModifiedUser+"'";
			String modificationDate = "'"+tempModifiedDate+"'";
			String selectedLegalEntity = "'"+addBean.getLegEntityCode()+"'";
			
			//String query = "INSERT INTO SETUP_LE_FINANCIAL_CYCLE(V_ENTITY_CODE,V_CONSOLIDATION_TYPE,N_FIN_YEAR_CLOSE_MONTH,N_FIN_YEAR_CLOSE_DATE,V_CREATED_USER,D_CREATED_DATE,V_MODIFIED_USER,D_MODIFIED_DATE) VALUES("+selectedLegalEntity+","+selectedConsolType+","+selectedMonth+","+selectedDate+","+createdUser+",to_date("+createdDate+",'mm/dd/yyyy'),"+modifiedUser+",to_date("+modificationDate+",'mm/dd/yyyy'))" ;
			String query = "INSERT INTO SETUP_LE_FINANCIAL_CYCLE(V_ENTITY_CODE,N_FIN_YEAR_CLOSE_MONTH,N_FIN_YEAR_CLOSE_DATE,V_CREATED_USER,D_CREATED_DATE) VALUES("+selectedLegalEntity+","+selectedMonth+","+selectedDate+","+createdUser+",to_date("+createdDate+",'mm/dd/yyyy'))" ;
			
			GL35Logger.logThis("Query = "+query, Priority.DEBUG_INT);
			status = "false:NEW";
			Cargo FindCountCargo = (Cargo) SMSServices.executeUpdate(infodom,query);
			
			if(FindCountCargo.getErrorFlag())
			{
				//System.out.println("Error while inserting into the table");
				GL35Logger.logThis("Error while inserting into the table", Priority.DEBUG_INT);
			}
			else
			{
				status = "true:NEW";
				GL35Logger.logThis("Successfully Inserted", Priority.DEBUG_INT);
				//System.out.println("Successfully Inserted");
			}
			return status;
	}
	
	public static String updateGlobalParameter(GlobalParamAddBean addBean,String infodom) {
		String status = "false";
		GL35Logger.logThis("Inside updateGlobalParameter of GlobalParamAddDao", Priority.DEBUG_INT);
		String selectedDate = "'"+addBean.getSelectedDate()+"'";
		String selectedMonth = "'"+addBean.getSelectedMonth()+"'";
		String tempselectedLegalEntity = addBean.getLegEntityCode();
		String  selectedLegalEntity = "'"+tempselectedLegalEntity.split(" ")[0]+"'";
		String modifiedUser = "'"+addBean.getModifiedUser()+"'";
		String modificationDate = "'"+addBean.getModificationDate()+"'";
		
		String query = "UPDATE SETUP_LE_FINANCIAL_CYCLE SET SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_MONTH = "+selectedMonth+",SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_DATE ="+selectedDate+",SETUP_LE_FINANCIAL_CYCLE.V_MODIFIED_USER ="+modifiedUser+",SETUP_LE_FINANCIAL_CYCLE.D_MODIFIED_DATE = to_date("+modificationDate+",'mm/dd/yyyy') WHERE (SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE ="+selectedLegalEntity+" )" ;
		//System.out.println("query = "+query);
		GL35Logger.logThis("Query = "+query, Priority.DEBUG_INT);
		status = "false:EDIT";
		Cargo FindCountCargo = (Cargo) SMSServices.executeUpdate(infodom,query);
		
		if(FindCountCargo.getErrorFlag())
		{
			//System.out.println("Error while updating the table");
			GL35Logger.logThis("Error while updating the table", Priority.DEBUG_INT);
		}
		else
		{
			status = "true:EDIT";
			//System.out.println("Successfully Updated");
			GL35Logger.logThis("Successfully Updated", Priority.DEBUG_INT);
		}
		return status;
}
}
