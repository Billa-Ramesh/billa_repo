/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GlobalParamDao.java
* Title         :
* Description   :
* @author       : Deepak Dagar 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TreeMap;
import java.util.Vector;

import org.apache.log4j.Priority;

import umm.bi.ClsUEntHierarchy;
import umm.bi.ClsUEntHierarchyNode;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.client.SecureBusinessMetaData;
import com.iflex.fic.ficml.JSPInitBean;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.iflex.fic.global.GlobalParameters;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GLCommon;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.GlobalParamAddBean;
import com.ofs.erm.gl.model.GlobalParamSearchBean;
import com.ofs.erm.gl.model.GlobalParamSummaryBean;

public class GlobalParamDao 
{
	private static int rowId = 1;
	private static List<String> colArray = new ArrayList<String>();
	private static LinkedHashMap hierMap = new LinkedHashMap();
	public static int noOfPagesLoaded = 2;
	@SuppressWarnings("unused")
	private static String searchQuery;

	static {
		colArray.add("SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE");
		colArray.add("SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_MONTH");
		colArray.add("SETUP_LE_FINANCIAL_CYCLE.V_CREATED_USER");
		colArray.add("SETUP_LE_FINANCIAL_CYCLE.D_CREATED_DATE");
		colArray.add("SETUP_LE_FINANCIAL_CYCLE.V_MODIFIED_USER");
		colArray.add("SETUP_LE_FINANCIAL_CYCLE.D_MODIFIED_DATE");
		//JSPInitBean jp = new JSPInitBean();     
	//	JSPInitBean.defaultInitialize("D:\\GL Recon v3.5\\");
	}
    public static Vector getExistingLEs(String sinfodom,String suserid)
    {
    	Vector leVec = new Vector();
    	GL35Logger.logThis("getExistingLEs .."+sinfodom, Priority.DEBUG_INT);
    	String recordQuery = "SELECT V_ENTITY_CODE FROM SETUP_LE_FINANCIAL_CYCLE ";
		
		Cargo LECargo = (Cargo) SMSServices.executeQuery(sinfodom,recordQuery,false);
		DACRecordSet resultSet = (DACRecordSet) LECargo.getPayLoadObject();
		
		 while (!resultSet.EOF() && resultSet.getRowCount()>0 ) 
		{
			leVec.addElement(resultSet.fetchElement(1));

			resultSet.moveNext();
		
		}
    	return leVec;
    }
	public static List<GlobalParamSummaryBean> getGlobalParamData(GlobalParamSearchBean searchBean,String infodom, String userId,String locale) 
	{
		GL35Logger.logThis("legalEntity getGlobalParamData", Priority.DEBUG_INT);
		List<GlobalParamSummaryBean> globalParamData = new ArrayList<GlobalParamSummaryBean>();
		int recordCount = 0;
		String nodedesc="";
		LinkedHashMap<String,GlobalParamSummaryBean> LEmap = new LinkedHashMap<String,GlobalParamSummaryBean>();
		if(searchBean == null){
			searchBean = new GlobalParamSearchBean();
			searchBean.setSearchLegalEntity("");
			searchBean.setSortOrder("");
			searchBean.setStartIndex(1);
			searchBean.setEndIndex(10*noOfPagesLoaded);
		}
		GL35Logger.logThis(" getGlobalParamData isRecordCountNeeded..."+searchBean.isRecordCountNeeded(), Priority.DEBUG_INT);
		if(searchBean.isRecordCountNeeded() == true) {
			//System.out.println("DAO:getRecordCount Loop");

			String legalEntity = searchBean.getSearchLegalEntity();
			
			GL35Logger.logThis("legalEntity .."+legalEntity, Priority.DEBUG_INT);
			 if(legalEntity !=null && !(legalEntity.equals("")))
				    legalEntity = "'"+legalEntity+"'";
			 else
				     legalEntity =  "'%"+legalEntity+"%'";

			String recordQuery = "SELECT COUNT(1) FROM ( SELECT * FROM SETUP_LE_FINANCIAL_CYCLE WHERE (SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE "
				+ "LIKE "+legalEntity+" ) )";
			//System.out.println(recordQuery);


			Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,recordQuery,false);

			if(FindCountCargo.getErrorFlag())
			{
				GL35Logger.logThis("Error while quering the Database - Inside GlobalParamDao", Priority.DEBUG_INT);

			}
			else {
				DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
				recordCount = Integer.parseInt(resultSet.fetchElement(1));
			}
		}

		if((searchBean.getSortOrder() == "") || (searchBean.getSortOrder() == null)) {
			searchBean.setSortOrder("DESC");
			searchBean.setSortCol("4");
		}
		
		String sortColName = searchBean.getSortCol();
		GL35Logger.logThis(" getGlobalParamData sortColName.."+sortColName, Priority.DEBUG_INT);
			if(sortColName!=null && !(sortColName.equalsIgnoreCase("")))
				sortColName = colArray.get(Integer.parseInt(searchBean.getSortCol()));
		String sortColName1 = "";
		String legalEntity = searchBean.getSearchLegalEntity();
	
		 if(legalEntity !=null && !(legalEntity.equals("")))
			    legalEntity = "'"+legalEntity+"'";
		 else
			     legalEntity =  "'%"+legalEntity+"%'";
		StringBuffer searchQuery = new StringBuffer();
		searchQuery.append("SELECT * FROM ( SELECT ROWNUM RNUM, A.* FROM (");

	/**	searchQuery.append("SELECT SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE,"
				+"SETUP_LE_FINANCIAL_CYCLE.V_CONSOLIDATION_TYPE,SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_MONTH,SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_DATE,FSI_GL_LOOKUP_MASTER.V_CATEGORY_DESC,SETUP_LE_FINANCIAL_CYCLE.V_CREATED_USER,SETUP_LE_FINANCIAL_CYCLE.D_CREATED_DATE,SETUP_LE_FINANCIAL_CYCLE.V_MODIFIED_USER,SETUP_LE_FINANCIAL_CYCLE.D_MODIFIED_DATE "
				+ " FROM SETUP_LE_FINANCIAL_CYCLE, FSI_GL_LOOKUP_MASTER WHERE (");
 **/
				searchQuery.append("SELECT SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE,"
						+"SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_MONTH,SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_DATE,SETUP_LE_FINANCIAL_CYCLE.V_CREATED_USER,SETUP_LE_FINANCIAL_CYCLE.D_CREATED_DATE,SETUP_LE_FINANCIAL_CYCLE.V_MODIFIED_USER,SETUP_LE_FINANCIAL_CYCLE.D_MODIFIED_DATE "
						+ " FROM SETUP_LE_FINANCIAL_CYCLE  WHERE (");

		searchQuery.append("SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE LIKE "+legalEntity+"  )");


		if(searchBean.getSortCol()!=null && !(searchBean.getSortCol().equalsIgnoreCase("")) && Integer.parseInt(searchBean.getSortCol())== 2){
			sortColName1 = "SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_DATE";
			searchQuery.append("ORDER BY "+sortColName+" "+searchBean.getSortOrder() +","+sortColName1+" "+searchBean.getSortOrder() +" NULLS LAST ) A WHERE ROWNUM <= "+searchBean.getEndIndex()+" ) WHERE RNUM >= "+searchBean.getStartIndex()+" ");
			//System.out.println(searchQuery);
			GL35Logger.logThis(searchQuery.toString(), Priority.DEBUG_INT);
		}
		else 
		{
			if(sortColName != null && !(sortColName.equalsIgnoreCase("")))
					searchQuery.append("ORDER BY "+sortColName+" "+searchBean.getSortOrder()+") A WHERE ROWNUM <= "+searchBean.getEndIndex()+" ) WHERE RNUM >= "+searchBean.getStartIndex()+" ");
			else
				searchQuery.append("ORDER BY SETUP_LE_FINANCIAL_CYCLE.D_CREATED_DATE DESC) A WHERE ROWNUM <= "+searchBean.getEndIndex()+" ) WHERE RNUM >= "+searchBean.getStartIndex()+" ");
			//System.out.println(searchQuery);
			GL35Logger.logThis(searchQuery.toString(), Priority.DEBUG_INT);
		}




		//System.out.println("Global Param Query Fired");
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,searchQuery.toString(),false);

		if(FindCountCargo.getErrorFlag())
		{
			GL35Logger.logThis("Error while quering the Database - Inside GlobalParamDao", Priority.DEBUG_INT);

		}
		else
		{
			DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
			//System.out.println("Global Param Cargo Received");
			rowId = searchBean.getStartIndex() - 1;


			String hiercode = GlobalUtil.getLegalHierCode(infodom);
			hierMap = GLCommon.getHierNodes(infodom,userId,hiercode,locale);
           
			while (!resultSet.EOF()) {
			
				GlobalParamSummaryBean gpsb = new GlobalParamSummaryBean();
				if(hierMap.get(resultSet.fetchElement(2))!=null && hierMap.get(resultSet.fetchElement(2)) !="")
				    nodedesc = (String)hierMap.get(resultSet.fetchElement(2));
				 else
				    nodedesc = resultSet.fetchElement(2);
				gpsb.setLegalEntity(nodedesc);
				gpsb.setLegalEntityCode(resultSet.fetchElement(2));
				//gpsb.setConsolType(resultSet.fetchElement(3));
				String tempMonth = resultSet.fetchElement(3);
				String tempDate = resultSet.fetchElement(4);
				String finYearCloseDate = tempMonth+"/"+tempDate;
				gpsb.setFinYearCloseDate(finYearCloseDate);
			//	gpsb.setConsolTypeDesc(resultSet.fetchElement(6));
			//	recordCount = resultSet.getRowCount();
				String tempCreatedBy = resultSet.fetchElement(5);
				if(tempCreatedBy == null)
					tempCreatedBy = "-";
				gpsb.setCreatedBy(tempCreatedBy);

				String tempCreateDate = resultSet.fetchElement(6);
				if(tempCreateDate == null)
				{
					tempCreateDate = "-";
					gpsb.setCreationDate(tempCreateDate);
				}
				else
				{
					String[] tempDate0 = tempCreateDate.split(" ");
					String[] tempDate1 = tempDate0[0].split("-");
					String creationDate = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
					gpsb.setCreationDate(creationDate);
				}
				String tempModifiedBy = resultSet.fetchElement(7);
				if(tempModifiedBy == null)
					tempModifiedBy = "-";
				gpsb.setModifiedBy(tempModifiedBy);

				String modDateString = resultSet.fetchElement(8);
				if(modDateString == null)
					gpsb.setModificationDate("-");
				else {
					String[] tempDate0 = modDateString.split(" ");
					String[] tempDate1 = tempDate0[0].split("-");
					String modificationDate = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
					gpsb.setModificationDate(modificationDate);
				}



				gpsb.setRecordCount(recordCount);
				gpsb.setRowId(rowId);
				globalParamData.add(gpsb);
			//	LEmap.put((String)hierMap.get(resultSet.fetchElement(2)), gpsb);
				resultSet.moveNext();
				rowId++;
			}
		}	
		
		if(searchBean.getSortCol()!=null && !(searchBean.getSortCol().equalsIgnoreCase("")) && (sortColName.equalsIgnoreCase("SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE")))
		  
			{
			
			searchQuery = new StringBuffer();
			searchQuery.append("SELECT * FROM ( SELECT ROWNUM RNUM, A.* FROM (");
			searchQuery.append("SELECT SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE,"
					+"SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_MONTH,SETUP_LE_FINANCIAL_CYCLE.N_FIN_YEAR_CLOSE_DATE,SETUP_LE_FINANCIAL_CYCLE.V_CREATED_USER,SETUP_LE_FINANCIAL_CYCLE.D_CREATED_DATE,SETUP_LE_FINANCIAL_CYCLE.V_MODIFIED_USER,SETUP_LE_FINANCIAL_CYCLE.D_MODIFIED_DATE "
					+ " FROM SETUP_LE_FINANCIAL_CYCLE  WHERE (");

	        searchQuery.append("SETUP_LE_FINANCIAL_CYCLE.V_ENTITY_CODE LIKE "+legalEntity+"  )");
	    	searchQuery.append("ORDER BY "+sortColName+" "+searchBean.getSortOrder()+" NULLS LAST ) A  )  ");
	    	FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,searchQuery.toString(),false);

			if(FindCountCargo.getErrorFlag())
			{
				GL35Logger.logThis("Error while quering the Database - Inside GlobalParamDao", Priority.DEBUG_INT);

			}
			else
			{
				DACRecordSet resultSetLE = (DACRecordSet) FindCountCargo.getPayLoadObject();
				
				while (!resultSetLE.EOF()) {
					
					GlobalParamSummaryBean gpsb = new GlobalParamSummaryBean();
					
					if(hierMap.get(resultSetLE.fetchElement(2))!=null && hierMap.get(resultSetLE.fetchElement(2)) !="")
					    nodedesc = (String)hierMap.get(resultSetLE.fetchElement(2));
					 else
					    nodedesc = resultSetLE.fetchElement(2);
					gpsb.setLegalEntity(nodedesc);
					
					
					//gpsb.setLegalEntity((String)hierMap.get(resultSetLE.fetchElement(2)));
					gpsb.setLegalEntityCode(resultSetLE.fetchElement(2));
					//gpsb.setConsolType(resultSet.fetchElement(3));
					String tempMonth = resultSetLE.fetchElement(3);
					String tempDate = resultSetLE.fetchElement(4);
					String finYearCloseDate = tempMonth+"/"+tempDate;
					gpsb.setFinYearCloseDate(finYearCloseDate);
				//	gpsb.setConsolTypeDesc(resultSet.fetchElement(6));
				//	recordCount = resultSetLE.getRowCount();
					String tempCreatedBy = resultSetLE.fetchElement(5);
					if(tempCreatedBy == null)
						tempCreatedBy = "-";
					gpsb.setCreatedBy(tempCreatedBy);

					String tempCreateDate = resultSetLE.fetchElement(6);
					if(tempCreateDate == null)
					{
						tempCreateDate = "-";
						gpsb.setCreationDate(tempCreateDate);
					}
					else
					{
						String[] tempDate0 = tempCreateDate.split(" ");
						String[] tempDate1 = tempDate0[0].split("-");
						String creationDate = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
						gpsb.setCreationDate(creationDate);
					}
					String tempModifiedBy = resultSetLE.fetchElement(7);
					if(tempModifiedBy == null)
						tempModifiedBy = "-";
					gpsb.setModifiedBy(tempModifiedBy);

					String modDateString = resultSetLE.fetchElement(8);
					if(modDateString == null)
						gpsb.setModificationDate("-");
					else {
						String[] tempDate0 = modDateString.split(" ");
						String[] tempDate1 = tempDate0[0].split("-");
						String modificationDate = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
						gpsb.setModificationDate(modificationDate);
					}



					gpsb.setRecordCount(recordCount);
					gpsb.setRowId(rowId);
					globalParamData.add(gpsb);
					LEmap.put((String)hierMap.get(resultSetLE.fetchElement(2)), gpsb);
					resultSetLE.moveNext();
					rowId++;
				}
				int stsrtInx = searchBean.getStartIndex();
				int endInx = searchBean.getEndIndex();
				int cnt=1;
			 if(LEmap!=null && LEmap.size()>0) 
			  {globalParamData = new ArrayList<GlobalParamSummaryBean>();
	    		  List mapKeys = new ArrayList(LEmap.keySet());

                 if(searchBean.getSortOrder()!="" && !(searchBean.getSortOrder().equalsIgnoreCase("")) && searchBean.getSortOrder().equalsIgnoreCase("ASC") )
	    		   Collections.sort(mapKeys);
                 else
                 {
                	 Comparator comparator = Collections.reverseOrder();
                	 Collections.sort(mapKeys,comparator);
                 }
                  
                 System.out.println("cnt..."+cnt+"..stsrtInx.."+stsrtInx+"..endInx.."+endInx);
                 
				 for(int k=0;k<mapKeys.size();k++)
				 {
					// System.out.println("l.hierMap..."+mapKeys.get(k));
					 if (hierMap.containsValue(mapKeys.get(k)) && cnt>=stsrtInx && cnt<=endInx)
					 {
					
						GlobalParamSummaryBean gpsb = (GlobalParamSummaryBean)LEmap.get(mapKeys.get(k));
						 System.out.println("22.hierMap..."+LEmap.get(mapKeys.get(k))+"..rowid.."+gpsb.getRowId());
						gpsb.setRowId(cnt);
						 System.out.println("33hierMap..."+LEmap.get(mapKeys.get(k))+"..rowid.."+gpsb.getRowId());
					     globalParamData.add(gpsb);
					     cnt =  cnt+1;
					 }else
					 {
						 //System.out.println("33.hierMap..."+LEmap.get(mapKeys.get(k))); 
						 cnt =  cnt+1;
					 }
						 
				}
		      }
				
			
		         }
			}
		GL35Logger.logThis("Global Param List Size:"+globalParamData.size(), Priority.DEBUG_INT);
		//System.out.println("Global Param List Size:"+globalParamData.size());
		return globalParamData;

	}

	public static String deleteRows(String[] legEntityArray, String infodom, String userId,String locale) {

		//String infodom = "GLRINF";
		String status = "false";
		StringBuffer selectedLEs = new StringBuffer();
		StringBuffer checkQuery = new StringBuffer();
	
		HashMap<String, Integer> legEntMap = new HashMap<String, Integer>();
		StringBuffer failedLEs = new StringBuffer();
		String hiercode = GlobalUtil.getLegalHierCode(infodom);
		hierMap = GLCommon.getHierNodes(infodom,userId,hiercode,locale);

		for(int i=0;i<legEntityArray.length;i++)
		{
			if(i<legEntityArray.length-1)
				selectedLEs.append("'"+legEntityArray[i].split(" ")[0] + "',");
			else
				selectedLEs.append("'"+legEntityArray[i].split(" ")[0] + "'");
		}
		
		checkQuery.append("SELECT COUNT(1),M.V_ENTITY_CODE FROM FSI_GL_MAPPING_MASTER M WHERE M.V_ENTITY_CODE IN ");
		checkQuery.append("(" + selectedLEs.toString() + ")");
		checkQuery.append(" GROUP BY M.V_ENTITY_CODE");
		
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,checkQuery.toString(),false);
		if(FindCountCargo.getErrorFlag())
		{
			GL35Logger.logThis("Error while quering the Database with INFODOM:" + infodom + " and QUERY: " + checkQuery.toString(), Priority.DEBUG_INT);
		}
		else
		{
			DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
			
			while (!resultSet.EOF()) {
				legEntMap.put(resultSet.fetchElement(2), Integer.parseInt(resultSet.fetchElement(1)));
				resultSet.moveNext();
			}
		}

		for(int i=0;i<legEntityArray.length;i++)
		{
			if(legEntMap.get(legEntityArray[i].split(" ")[0]) == null) {
				status = "true";
				StringBuffer query = new StringBuffer();
				query.append("DELETE FROM SETUP_LE_FINANCIAL_CYCLE WHERE V_ENTITY_CODE =");
				String temp = legEntityArray[i].split(" ")[0];
				query.append("'"+temp+"'");

			//	query.append(" AND V_CONSOLIDATION_TYPE = ");

			//	temp = consolArray[i].split(" ")[1];
			//	query.append("'"+temp+"')");

				GL35Logger.logThis(query.toString(), Priority.DEBUG_INT);

				String finalQuery = query.toString();

				FindCountCargo = (Cargo) SMSServices.executeUpdate(infodom,finalQuery);

				if(FindCountCargo.getErrorFlag())
				{
					status = "false";
					GL35Logger.logThis("Error while deleting rows from the table", Priority.DEBUG_INT);
				}
				else
				{
					GL35Logger.logThis("Successfully Deleted!", Priority.DEBUG_INT);
				}
			}
			else {
				status = "true:constraint";
				failedLEs.append(hierMap.get(legEntityArray[i].split(" ")[0]) + "@@");
			}
		}

		GL35Logger.logThis("Exiting delete function", Priority.DEBUG_INT);
		return status+"~!"+failedLEs.toString();
	}

}

