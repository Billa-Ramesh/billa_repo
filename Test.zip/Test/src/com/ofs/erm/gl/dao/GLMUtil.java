/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : GLMUtil.java
Created By            : Rahul Manoharan 
Created On            : July 10th, 2012
Application Name      : General Ledger v3.5
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/

package com.ofs.erm.gl.dao;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Priority;

import umm.bi.ClsUEntHierarchy;

import com.iflex.fic.client.BusinessMetaData;
import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.iflex.fic.global.GlobalParameters;
import com.ofs.erm.gl.action.GLMAction;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.GLMModel;
import com.opensymphony.xwork2.Action;

@SuppressWarnings("deprecation")
public class GLMUtil {
 
	public String getFormData(GLMModel glmModel, String infoDom,
			GLMAction glmAction) {
		
	 
	try{
		GL35Logger.logThis("Getting Form Values for GLM Edit...",Priority.DEBUG_INT);  
		DACRecordSet resultSet1;
		Cargo cargo;
		String glAcntCode = glmModel.getGlCode();
		
			StringBuffer sqlQuery = new StringBuffer(
					"SELECT V_GL_ACCOUNT_NAME,V_GL_ACCOUNT_CODE,V_GL_PARENT_ACCOUNT_CODE,V_GL_BOOK_CODE,V_GL_TYPE,F_INTRA_GROUP,V_CREATED_BY,TO_CHAR(D_CREATED_DATE, 'MM-DD-YY'),V_LAST_MODIFIED_BY,TO_CHAR(D_LAST_MODIFIED_DATE, 'MM-DD-YY'),F_DIFF_AUTO_APPROVE_FLAG");
		sqlQuery.append(" FROM DIM_GL_ACCOUNT WHERE V_GL_ACCOUNT_CODE = '"+glAcntCode +"'");

		cargo = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery.toString(), false);
		resultSet1 = (DACRecordSet) cargo.getPayLoadObject();

		while (!resultSet1.EOF() && resultSet1.getRowCount() > 0){
			glmModel.setGlAcntName(resultSet1.fetchElement(1));
			glmModel.setGlCode(resultSet1.fetchElement(2));
			
			String glHierCode = GlobalUtil.getParamValue("GL_CODE_HIERCODE", infoDom);
			glmModel.setPrntGlAcntName(GlobalUtil.getHierUniqCodeFromLeafCode(resultSet1.fetchElement(3), glHierCode, infoDom));
			
			String hierCode = GlobalUtil.getParamValue("GLBOOK_TYPE_HIERCODE", infoDom);
			glmModel.setGlBook(GlobalUtil.getHierUniqCodeFromLeafCode(resultSet1.fetchElement(4), hierCode, infoDom));
			
			glmModel.setGlBookDesc(GlobalUtil.getHierDescription(infoDom, GLMAction.userId, hierCode, glmModel.getGlBook()));
			
			glmModel.setGlType(resultSet1.fetchElement(5));
			glmModel.setIntraGrp(resultSet1.fetchElement(6));
			glmModel.setCreatedBy(resultSet1.fetchElement(7));
			glmModel.setCreatedDate(resultSet1.fetchElement(8));
			glmModel.setModifiedBy(resultSet1.fetchElement(9));
			glmModel.setModifiedDate(resultSet1.fetchElement(10));
			glmModel.setIsAutoApprove(resultSet1.fetchElement(11));
			
			glmModel.setPrntGlAcntNameDisp(resultSet1.fetchElement(3)); 
			
			DACRecordSet resultSet1a;
			Cargo cargo1a;
			StringBuffer sqlQuery1a = new StringBuffer("SELECT DGA.V_GL_ACCOUNT_NAME FROM DIM_GL_ACCOUNT DGA WHERE DGA.V_GL_ACCOUNT_CODE = '"+resultSet1.fetchElement(3)+"'");
			cargo1a = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery1a.toString(), false);
			resultSet1a = (DACRecordSet) cargo1a.getPayLoadObject();
			while (!resultSet1a.EOF() && resultSet1a.getRowCount() > 0){
				glmModel.setPrntGlAcntNameDesc(resultSet1a.fetchElement(1));
				resultSet1a.moveNext();
			}
			
				resultSet1.moveNext();
		}
	} catch(Exception e){
		GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
		e.printStackTrace();
		return Action.ERROR;
	}
		
		return Action.SUCCESS;
	}

	public String processAjax(String infoDom, int mode, GLMAction glmAction, HttpServletRequest request) {
		
		String retVal = "";
		DACRecordSet resultSet1;
		Cargo cargo;
		
		switch(mode){
		case 1: //Check Duplicate GLCode / GL Account
		{
			String bookCode = request.getParameter("bookCode");
			String fldValue = request.getParameter("fldValue").split("~~")[0];
			String colName = "";
			
			String what = request.getParameter("fldValue").split("~~")[2];
			if(what.equals("1")){
				colName = "V_GL_ACCOUNT_NAME";
			}
			else if(what.equals("2")){
				colName = "V_GL_ACCOUNT_CODE";
			}
			
			String sGlBook = getLeafCode(bookCode,infoDom);
			
			StringBuffer sqlQry = new StringBuffer("SELECT COUNT(*) FROM DIM_GL_ACCOUNT WHERE ");
			sqlQry.append(colName + "='" + fldValue + "' AND V_GL_BOOK_CODE ='"
					+ sGlBook + "'");
			cargo = (Cargo) SMSServices.executeQuery(infoDom, sqlQry.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			String sCount = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0){
				sCount = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			if(Integer.parseInt(sCount)> 0){
				retVal = "true" + "~~" + request.getParameter("fldValue").split("~~")[1];				
				 break;
			}
			else{
				retVal = "false" + "~~" + request.getParameter("fldValue").split("~~")[1];				
				 break;
			}
		}

		case 2: // GL Type Filter based on GL Book Selected.
		{
			GL35Logger.logThis(
					"Case 2 - GL Type Filter based on GL Book Selected ... ",
					Priority.DEBUG_INT);

			String sUserId = request.getParameter("userId");
			// request.getParameter("bookHierCode")

			Set<String> glTypeSet = new HashSet<String>();

			Cargo cargo7a;
			DACRecordSet resultSet;

			GL35Logger.logThis("Calling PKG_MATADATA_INFO.GETLEAFCODE()...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery7a = new StringBuffer(
					"SELECT PKG_MATADATA_INFO.GETLEAFCODE('"
							+ request.getParameter("bookHierCode")
							+ "') FROM DUAL");
			cargo7a = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery7a.toString(), false);
			resultSet1 = (DACRecordSet) cargo7a.getPayLoadObject();
			String sGlBookCd = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sGlBookCd = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}
			// String sGlHierCode = request.getParameter("glHierCode");
			// String sGlCodeColName = ReconUtil.getHierAttributeCode(infoDom,
			// sUserId, sGlHierCode );

			String tblName = "";

			StringBuffer sqlQry = new StringBuffer(
					"SELECT V_TABLE_NAME FROM SETUP_GL_BOOKS WHERE ");
			sqlQry.append(" V_GL_BOOK = '"
					+ request.getParameter("bookHierCode") + "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQry.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				tblName = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			GL35Logger.logThis("Getting ColNames from SETUP_GL_BOOKS...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery1b = new StringBuffer(
					"SELECT V_GL_HCY_DIM_TABLE_NAME,V_GL_HCY_GL_BOOK_COL_NAME,V_GL_HCY_GL_TYPE_COL_NAME FROM SETUP_GL_SOURCE WHERE ");
			sqlQuery1b.append(" V_TABLE_NAME = '" + tblName + "'");
			cargo7a = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1b.toString(), false);
			resultSet1 = (DACRecordSet) cargo7a.getPayLoadObject();

			String sDimTableName = "";
			String sBookColName = "";
			String sGlTypeColName = "";

			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sDimTableName = resultSet1.fetchElement(1);
				sBookColName = resultSet1.fetchElement(2);
				sGlTypeColName = resultSet1.fetchElement(3);
				resultSet1.moveNext();
			}

			GL35Logger.logThis("Querying for GL Types for Selected book...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery7b = new StringBuffer("SELECT DISTINCT("
					+ sGlTypeColName + ") FROM " + sDimTableName + " WHERE ");
			sqlQuery7b.append(sBookColName + " = '" + sGlBookCd + "'");
			GL35Logger.logThis("Query is .. " + sqlQuery7b);

			cargo7a = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery7b.toString(), false);
			resultSet = (DACRecordSet) cargo7a.getPayLoadObject();
			String colVal = "";

			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				glTypeSet.add(resultSet.fetchElement(1));
				resultSet.moveNext();
			}

			String glTypeCode = GlobalUtil.getParamValue("GL_TYPE_HIERCODE",
					infoDom);
			LinkedHashMap<String, String> glType = GlobalUtil.getHierNodeDesc(
					infoDom, sUserId, glTypeCode);

			retVal += "<select name=\"glType\" id=\"glType\" class=\"mndtry option contrlOption\"  onchange=\"genericAjaxCall(3,$('glBook').value);changeIsChangedFlag();\" >";
			retVal += "<option value= \"\">Select</option>";
			// retVal += "<option value= \"-1\">Select</option>";
			// retVal += "<option value= \"ALL\">All</option>";

			for (String entry : glTypeSet) {
				retVal += "<option value= \"" + entry + "\">"
						+ glType.get(entry) + "</option>";
			}
			retVal += "</select>";
			break;
		}

		case 3: // Gl Code List Fetching
		{
			GL35Logger.logThis("Case 3- Gl Code List Fetching...",
					Priority.DEBUG_INT);
			GL35Logger.logThis("Get the GL Hierarchy Code...",
					Priority.DEBUG_INT);

			String tblName = "";
			String sGlHierCode = "";

			StringBuffer sqlQry = new StringBuffer(
					"SELECT V_TABLE_NAME FROM SETUP_GL_BOOKS WHERE ");
			sqlQry.append(" V_GL_BOOK = '"
					+ request.getParameter("bookHierCode") + "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQry.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				tblName = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}

			StringBuffer sqlQuery1 = new StringBuffer(
					"SELECT V_DATASET_CODE,V_GL_HCY_CODE FROM SETUP_GL_SOURCE WHERE ");
			sqlQuery1.append(" V_TABLE_NAME = '" + tblName + "'");

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				retVal = resultSet1.fetchElement(1) + "~@~"
						+ resultSet1.fetchElement(2);
				sGlHierCode = resultSet1.fetchElement(2);
				resultSet1.moveNext();
			}
			retVal += "!~!"; // Separator for GlCodes List

			GL35Logger.logThis("Get the GL Codes...", Priority.DEBUG_INT);

			GL35Logger.logThis("Calling PKG_MATADATA_INFO.GETLEAFCODE()...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery1a = new StringBuffer(
					"SELECT PKG_MATADATA_INFO.GETLEAFCODE('"
							+ request.getParameter("bookHierCode")
							+ "') FROM DUAL");
			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1a.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			String sGlBookCode = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sGlBookCode = resultSet1.fetchElement(1);
				resultSet1.moveNext();
			}
			String sGlCodeColName = GlobalUtil.getHierAttributeCode(infoDom,
					request.getParameter("userId"), sGlHierCode);

			GL35Logger.logThis("Getting ColNames from SETUP_GL_BOOKS...",
					Priority.DEBUG_INT);
			StringBuffer sqlQuery1b = new StringBuffer(
					"SELECT V_GL_HCY_DIM_TABLE_NAME,V_GL_HCY_GL_BOOK_COL_NAME,V_GL_HCY_GL_TYPE_COL_NAME,V_GL_HCY_INTRA_GROUP_COL_NAME FROM SETUP_GL_SOURCE WHERE ");
			sqlQuery1b.append("  V_TABLE_NAME = '" + tblName + "'");
			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1b.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();

			String sDimTableName = "";
			String sBookColName = "";
			String sGlTypeColName = "";
			String sIntraGrpColName = "";
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				sDimTableName = resultSet1.fetchElement(1);
				sBookColName = resultSet1.fetchElement(2);
				sGlTypeColName = resultSet1.fetchElement(3);
				sIntraGrpColName = resultSet1.fetchElement(4);
				resultSet1.moveNext();
			}

			GL35Logger.logThis("Finally...Getting List of GLCodes...",
					Priority.DEBUG_INT);

			String glTypeCode = request.getParameter("glTypeCode");
			if (glTypeCode.equals("ALL")) {
				glTypeCode = "%%";
			}
			StringBuffer sqlQuery1c = new StringBuffer("SELECT "
					+ sGlCodeColName + " FROM " + sDimTableName + " WHERE ");
			sqlQuery1c.append(sBookColName + " = '" + sGlBookCode + "' AND ");
			sqlQuery1c.append(sGlTypeColName + " LIKE '" + glTypeCode
					+ "' AND " + sIntraGrpColName + "= 'N'");
			GL35Logger.logThis("Query is .. " + sqlQuery1c);

			cargo = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQuery1c.toString(), false);
			resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {

				retVal += resultSet1.fetchElement(1);
				retVal += "~@~";
				resultSet1.moveNext();
			}

			break;
		}

		default:
			break;
		}
		
		return retVal;
	}
 
	public String createGLM(GLMModel glmModel, String infoDom,
			GLMAction glmAction) {

		try{
			GL35Logger.logThis("GLM Add Entry...",Priority.DEBUG_INT);
			DACRecordSet resultSet1;
			Cargo cargo;
			String sGlAcntCode = glmModel.getGlCode();
			
			Cargo cargo1;
			DACRecordSet resultSet;
			String sqlQry = "";

			sqlQry = "SELECT SEQ_DIM_GL_ACCOUNT.NEXTVAL FROM DUAL";

			cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQry, false);
			resultSet = (DACRecordSet) cargo1.getPayLoadObject();
			int iAccntSKey = 0;

			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				iAccntSKey = Integer.parseInt(resultSet.fetchElement(1));
				resultSet.moveNext();
			}

			
			String sGlBook = getLeafCode(glmModel.getGlBook(),infoDom);
			//String sGlAcntCode = getLeafCode(glmModel.getGlCode(),infoDom);
			String sPrntGlCode = getLeafCode(glmModel.getPrntGlAcntName(),infoDom);
			
			StringBuffer sqlQuery = new StringBuffer(
					"Insert into DIM_GL_ACCOUNT (N_GL_ACCOUNT_SKEY,N_GL_ACCOUNT_ID,V_GL_ACCOUNT_NAME,V_GL_ACCOUNT_CODE,V_GL_PARENT_ACCOUNT_CODE,V_GL_BOOK_CODE,V_GL_TYPE,F_INTRA_GROUP,V_CREATED_BY,D_CREATED_DATE,F_DIFF_AUTO_APPROVE_FLAG,F_LATEST_RECORD_INDICATOR)");
			sqlQuery.append(" VALUES( ");
			sqlQuery.append( iAccntSKey+","+iAccntSKey+",'"+glmModel.getGlAcntName()+"','"+sGlAcntCode+"','"
					+sPrntGlCode+"','" + sGlBook +"','"
					+glmModel.getGlType()+"','"+glmModel.getIntraGrp()+"','"
					+glmModel.getCreatedBy()+"',TO_DATE('"+glmModel.getCreatedDate()+"','MM-DD-YY'),'"
					+ glmModel.getIsAutoApprove() + "','Y')");
			

			cargo = (Cargo) SMSServices.executeUpdate(infoDom, sqlQuery.toString());
			if (!cargo.getErrorFlag()) {
				GL35Logger.logThis(cargo.getPayLoadObject().toString(), Priority.DEBUG_INT);
				try{
					String retVal = hierResaveForGLM(infoDom);
					if(retVal != "Success"){
						GL35Logger.logThis("Hierarchy Resave Failure", Priority.ERROR_INT);
						return Action.ERROR;
					}
				}
				catch(Exception e){
					GL35Logger.logThis("Hierarchy Resave Failure", Priority.ERROR_INT);
					return Action.ERROR;
				}
				return Action.SUCCESS;
			} else {
				GL35Logger.logThis(cargo.getPayLoadObject().toString(), Priority.ERROR_INT);
				return Action.ERROR;
			}
		}catch(Exception e){
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
			return Action.ERROR;
		}
		
	}

	public String updateGLM(GLMModel glmModel, String infoDom,
			GLMAction glmAction) {
		try{ 
			GL35Logger.logThis("GLM Update...",Priority.DEBUG_INT);
			DACRecordSet resultSet1;
			Cargo cargo;			
			String sGlAcntCode = glmModel.getGlCode();
			
			String sGlBook = getLeafCode(glmModel.getGlBook(),infoDom);
			//String sGlAcntCode = getLeafCode(glmModel.getGlCode(),infoDom);
			String sPrntGlCode = getLeafCode(glmModel.getPrntGlAcntName(),infoDom);
	
	
			StringBuffer sqlQuery = new StringBuffer("UPDATE DIM_GL_ACCOUNT SET ");			
			sqlQuery.append("V_GL_ACCOUNT_NAME = '" + glmModel.getGlAcntName()
					+ "',V_GL_PARENT_ACCOUNT_CODE='"
 + sPrntGlCode
					+ "',V_GL_BOOK_CODE='" + sGlBook + "',V_GL_TYPE='"
					+glmModel.getGlType()+"',F_INTRA_GROUP='"+glmModel.getIntraGrp()+"',V_LAST_MODIFIED_BY='"
					+glmModel.getModifiedBy() + "',D_LAST_MODIFIED_DATE=TO_DATE('"+glmModel.getModifiedDate()+"','MM-DD-YY'),F_DIFF_AUTO_APPROVE_FLAG='"
					+glmModel.getIsAutoApprove()+"' WHERE V_GL_ACCOUNT_CODE='"+sGlAcntCode+"'");
			

			cargo = (Cargo) SMSServices.executeUpdate(infoDom, sqlQuery.toString());
			if (!cargo.getErrorFlag()) {
				GL35Logger.logThis(cargo.getPayLoadObject().toString(), Priority.DEBUG_INT);
				try{
					String retVal = hierResaveForGLM(infoDom);
					if(retVal != "Success"){
						GL35Logger.logThis("Hierarchy Resave Failure", Priority.ERROR_INT);
						return Action.ERROR;
					}
				}
				catch(Exception e){
					GL35Logger.logThis("Hierarchy Resave Failure", Priority.ERROR_INT);
					return Action.ERROR;
				}
				return Action.SUCCESS;
			} else {
				GL35Logger.logThis(cargo.getPayLoadObject().toString(), Priority.ERROR_INT);
				return Action.ERROR;
			}
		}catch(Exception e){
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
			return Action.ERROR;
		}
	}

	private String hierResaveForGLM(String infoDom) {		
	       /*Hier Resave*/
		GL35Logger.logThis("Entering hierResave for GLM...",Priority.DEBUG_INT);
		String hierCode = GlobalUtil.getParamValue("GL_CODE_HIERCODE", infoDom);
		String langCode = GLMAction.getSession().get("lclPostFix").toString();
		Cargo crForHierarcy = BusinessMetaData.getMetaDataObjectFromServer(
				infoDom, hierCode, GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,
				GlobalParameters.AUTHORIZED_VERSION, new Locale(langCode));
     
     GL35Logger.logThis("XQX GlobalParameters.AUTHORIZED_VERSION="+GlobalParameters.AUTHORIZED_VERSION);
     
     ClsUEntHierarchy argHierObj=(ClsUEntHierarchy)crForHierarcy.getPayLoadObject();
     argHierObj.setAutoAuthorization(true);
     GL35Logger.logThis("argHierObj--->"+argHierObj.getCode());
     
		String retVal = BusinessMetaData.maintainMetaDataObject(infoDom,
				GlobalParameters.OPERATION_UPDATE,
				GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,
				GlobalParameters.AUTHORIZED_VERSION, argHierObj, new Locale(
						langCode));
     
     GL35Logger.logThis("resave........-->"+retVal);
     String rtn = "";
     if (retVal == null) {
     		rtn = "Error";
     } else {
        		rtn = "Success";
     }
		return rtn;		
	}

	public String getLeafCode(String uniqCode, String infoDom){
		
		String sLeafCode = GLMSummaryDAO.getLeafNode(infoDom, uniqCode);
		return sLeafCode;
	}
}
