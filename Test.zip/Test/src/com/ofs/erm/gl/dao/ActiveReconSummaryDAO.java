/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.

--------------------------------------------------------------------------------------------------------
File Name             : ActiveReconSummaryDAO.java
Created By            : Manoj Cherukumalli 
Created On            : April 26th, 2012
Application Name      : General Ledger 
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/
package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Priority;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GLCommon;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.ReconSearchBean;
import com.ofs.erm.gl.model.ReconSummaryBean;

public class ActiveReconSummaryDAO 
{
	private static int rowId = 0;
	private static List<String> colArray = new ArrayList<String>();
	private static LinkedHashMap hierMap = new LinkedHashMap();
	public static int noOfPagesLoaded = 2;
	@SuppressWarnings("unused")
	private static String searchQuery;

	static {
		colArray.add("FSI_GL_MAPPING_MASTER.V_GL_MAP_NAME");
		colArray.add("FSI_GL_MAPPING_MASTER.V_ENTITY_CODE");
		colArray.add("FSI_GL_MAPPING_MASTER.V_CONSOLIDATION_TYPE");
		colArray.add("FSI_GL_MAPPING_MASTER.V_CREATED_USER");
		colArray.add("FSI_GL_MAPPING_MASTER.D_VERSION_CREATED_DATE");
		colArray.add("FSI_GL_MAPPING_MASTER.N_VERSION_NUMBER");
	}

	public static List<ReconSummaryBean> getReconData(ReconSearchBean searchBean, String infodom,String userId) 
	{
		List<ReconSummaryBean> reconData = new ArrayList<ReconSummaryBean>();
		int count = 1;
		int recordCount = 0;

		if(searchBean == null){
			searchBean = new ReconSearchBean();
			searchBean.setSearchName("");
			searchBean.setSearchLegalEntity("");
			searchBean.setSearchReconType("");
			searchBean.setSearchConsolType("");
			searchBean.setSortOrder("");
			searchBean.setStartIndex(1);
			searchBean.setEndIndex(10*noOfPagesLoaded);
		}
		String legalEntity = GlobalUtil.getHierUniqCodeFromLeafCode(
				searchBean.getSearchLegalEntity(),
				GlobalUtil.getLegalHierCode(infodom), infodom);
		if (legalEntity.equals("") || null == legalEntity) {
			legalEntity = "%%";
		}
		if(searchBean.isRecordCountNeeded() == true) {
			GL35Logger.logThis("DAO:getRecordCount Loop", Priority.DEBUG_INT);
			String name = "'%"+searchBean.getSearchName()+"%'";
			// legalEntity = "'%" + searchBean.getSearchLegalEntity() + "%'";
			String reconType = "'%"+searchBean.getSearchReconType()+"%'";
			String consolType = "'%"+searchBean.getSearchConsolType()+"%'";
			
			String recordQuery = "SELECT COUNT(1) FROM ( SELECT * FROM FSI_GL_MAPPING_MASTER WHERE (FSI_GL_MAPPING_MASTER.V_GL_MAP_NAME LIKE "+name+" AND FSI_GL_MAPPING_MASTER.V_ENTITY_CODE "
					+ "LIKE '"
					+ legalEntity
					+ "' AND FSI_GL_MAPPING_MASTER.V_CONSOLIDATION_TYPE LIKE "
					+ consolType
					+ "  AND F_IS_DELETED <> 'Y'  AND FSI_GL_MAPPING_MASTER.V_RECON_TYPE = 'A') )";
			GL35Logger.logThis(recordQuery, Priority.DEBUG_INT);
			Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,recordQuery,false);
			
			if(FindCountCargo.getErrorFlag())
			{
				GL35Logger.logThis("Error while retrieving from Database - Inside DAO", Priority.DEBUG_INT);
				ReconSummaryBean tempBean = new ReconSummaryBean();
				tempBean.setMapId(null);
				reconData.add(tempBean);
				GL35Logger.logThis("bean added", Priority.DEBUG_INT);
				return reconData;
			}
			else {
				DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
				recordCount = Integer.parseInt(resultSet.fetchElement(1));
			}
		}

		count = 1;


		if((searchBean.getSortOrder() == "") || (searchBean.getSortOrder() == null)) {
			searchBean.setSortOrder("DESC");
			searchBean.setSortCol("4");
		}

		String sortColName = colArray.get(Integer.parseInt(searchBean.getSortCol()));
		if (searchBean.getSortCol().equals("5")) {
			sortColName = colArray.get(0) + " " + searchBean.getSortOrder()
					+ " ," + sortColName + " " + searchBean.getSortOrder();
		} else if (searchBean.getSortCol().equals("0")) {
			sortColName = sortColName + " " + searchBean.getSortOrder() + " ,"
					+ colArray.get(5) + " " + searchBean.getSortOrder();
		} else
			sortColName = sortColName + " " + searchBean.getSortOrder();
		String name = "'%"+searchBean.getSearchName()+"%'";
		// legalEntity = "'%" + searchBean.getSearchLegalEntity() + "%'";
		String reconType = "'%"+searchBean.getSearchReconType()+"%'";
		String consolType = "'%"+searchBean.getSearchConsolType()+"%'";
		
		StringBuffer searchQuery = new StringBuffer();

		searchQuery.append("SELECT * FROM ( SELECT ROWNUM RNUM, A.* FROM (");
		searchQuery
				.append("SELECT FSI_GL_MAPPING_MASTER.V_GL_MAP_NAME, "
				+"FSI_GL_MAPPING_MASTER.V_ENTITY_CODE,FSI_GL_MAPPING_MASTER.V_CONSOLIDATION_TYPE,FSI_GL_MAPPING_MASTER.V_CREATED_USER,"
				+ "FSI_GL_MAPPING_MASTER.D_VERSION_CREATED_DATE,FSI_GL_LOOKUP_MASTER.V_CATEGORY_DESC,FSI_GL_MAPPING_MASTER.V_GL_MAP_ID,FSI_GL_MAPPING_MASTER.N_VERSION_NUMBER"
				+ " FROM FSI_GL_MAPPING_MASTER, FSI_GL_LOOKUP_MASTER WHERE (");

		searchQuery.append("FSI_GL_MAPPING_MASTER.V_GL_MAP_NAME LIKE "+name+" AND FSI_GL_MAPPING_MASTER.V_ENTITY_CODE "
						+ "LIKE '"
						+ legalEntity
						+ "' AND FSI_GL_MAPPING_MASTER.V_CONSOLIDATION_TYPE LIKE "
						+ consolType
						+ " AND FSI_GL_LOOKUP_MASTER.V_CATEGORY_ID = "
						+
				"FSI_GL_MAPPING_MASTER.V_CONSOLIDATION_TYPE AND FSI_GL_LOOKUP_MASTER.V_LOOKUP_CD = '15' AND F_IS_DELETED <> 'Y' AND FSI_GL_MAPPING_MASTER.V_RECON_TYPE = 'A') ");

		searchQuery.append("ORDER BY " + sortColName);
		searchQuery.append(" ) A WHERE ROWNUM <= " + searchBean.getEndIndex()
				+ " ) WHERE RNUM >= " + searchBean.getStartIndex() + " ");
		GL35Logger.logThis(searchQuery.toString(), Priority.DEBUG_INT);

		GL35Logger.logThis("Recon Query Fired", Priority.DEBUG_INT);
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,searchQuery.toString(),false);
		DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		GL35Logger.logThis("Recon Cargo Received", Priority.DEBUG_INT);
		rowId = searchBean.getStartIndex() - 1;
		
		String hiercode = GlobalUtil.getLegalHierCode(infodom);
	    hierMap = GLCommon.getHierNodes(infodom,userId,hiercode);
	    GL35Logger.logThis("hierCode="+hiercode, Priority.DEBUG_INT);
	    GL35Logger.logThis("hierMap.size()="+hierMap.size(), Priority.DEBUG_INT);

		while (!resultSet.EOF()) {
			ReconSummaryBean rsb = new ReconSummaryBean();
		    rsb.setName(resultSet.fetchElement(2));
		    rsb.setLegalEntity((String)hierMap.get(resultSet.fetchElement(3)));
		    rsb.setConsolType(resultSet.fetchElement(4));
		    rsb.setCreatedBy(resultSet.fetchElement(5));
		    String tempCreateDate = resultSet.fetchElement(6);
		    String[] tempDate = tempCreateDate.split(" ");
		    String[] tempDate1 = tempDate[0].split("-");
		    String creationDate = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
		    rsb.setCreationDate(creationDate);
		    rsb.setCheckBoxString("checkedCNew('" +rowId + "')");
		    rsb.setRecordCount(recordCount);
		    rsb.setRowId(rowId);
		    rsb.setConsolDesc(resultSet.fetchElement(7));
		    rsb.setMapId(resultSet.fetchElement(8));
		    rsb.setVersionNumber(resultSet.fetchElement(9));
		    reconData.add(rsb);
		    rowId++;
		    resultSet.moveNext();
		}
		GL35Logger.logThis("Recon List Size:"+reconData.size(), Priority.DEBUG_INT);

		return reconData;

	}
	
}
