/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : AdjEntryEditDAO.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.Priority;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.AdjDefaultValueBean;

public class AdjEntryEditDAO {
	private static int rowId = 0;
	private static int noOfDimensions = 10;
	private static List<String> colArray = new ArrayList<String>();
	private static List<String> dimensionsHeaderArray = new ArrayList<String>();
	private static int noOfPagesLoaded = 2;
	@SuppressWarnings("unused")
	private static String searchQuery;

	static {
		colArray.add("gl_adjustment_entries.v_exposure_id");
		colArray.add("gl_adjustment_entries.n_exposure_amount");
		colArray.add("gl_adjustment_entries.f_authorization_status");

		// Add all dimensions Column Names
		dimensionsHeaderArray.add("GL Code");
		dimensionsHeaderArray.add("Currency");
		dimensionsHeaderArray.add("Legal Entity");
		dimensionsHeaderArray.add("Product");	
		dimensionsHeaderArray.add("Business");
		dimensionsHeaderArray.add("Account Branch");
		dimensionsHeaderArray.add("Customer Class");
		dimensionsHeaderArray.add("Cost Centre");
	}

	public static List<AdjDefaultValueBean> getDefaultValues(String adjExposureId, String infodom) {
		List<AdjDefaultValueBean> defaultValueData = new ArrayList<AdjDefaultValueBean>();
		String ppTargetTableName = "";

		String ppTargetTableQuery = "SELECT F.V_PP_TABLE_NAME FROM FCT_GL_ADJUSTMENT_ENTRIES F WHERE F.V_ADJ_EXPOSURE_ID = '"+ adjExposureId +"'";
		GL35Logger.logThis("ppTargetTable query -------- "+ppTargetTableQuery, Priority.DEBUG_INT);

		GL35Logger.logThis("BEFORE Cargo FindCountCargo", Priority.DEBUG_INT);
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,ppTargetTableQuery,false);
		GL35Logger.logThis("ppTargetTableQuery  fired", Priority.DEBUG_INT);
		DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		GL35Logger.logThis("CARGO RECEIVED", Priority.DEBUG_INT);

		ppTargetTableName = resultSet.fetchElement(1);

		GL35Logger.logThis("ppTargetTableName RECEIVED - "+ppTargetTableName, Priority.DEBUG_INT);

		String query = "SELECT V_DEFAULT_COL_NAME,V_DEFAULT_COL_VALUE,V_OVERRIDE_VALUE FROM " +
		"FSI_ADJ_ENTRY_ATTRIBUTES WHERE V_ADJ_EXPOSURE_ID = '"+ adjExposureId +"'";

		GL35Logger.logThis("defaultValue query -------- "+query, Priority.DEBUG_INT);

		FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,query,false);
		GL35Logger.logThis("defaultValue query fired", Priority.DEBUG_INT);
		resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		GL35Logger.logThis("CARGO RECEIVED", Priority.DEBUG_INT);

		rowId = 0;
		while(!resultSet.EOF()) {
			AdjDefaultValueBean tempBean = new AdjDefaultValueBean();
			tempBean.setColumnName(resultSet.fetchElement(1));
			String columnLogicalName = "";
			try{
				columnLogicalName = GlobalUtil.getLogicalColName(resultSet.fetchElement(1), ppTargetTableName, infodom);
			}catch (Exception e) {
				GL35Logger.logThis("Exception occured when getting col logical name - "+resultSet.fetchElement(1)+ppTargetTableName+infodom, Priority.DEBUG_INT);
				columnLogicalName = "Exception";
				e.printStackTrace();
			}
			GL35Logger.logThis("columnLogicalName="+columnLogicalName, Priority.DEBUG_INT);
			tempBean.setColumnLogicalName(columnLogicalName);
			tempBean.setColumnDefaultValue(resultSet.fetchElement(2));
			tempBean.setColumnOverrideValue(resultSet.fetchElement(3));
			tempBean.setRowId(rowId);
			rowId++;
			GL35Logger.logThis("rowId="+rowId, Priority.DEBUG_INT);
			defaultValueData.add(tempBean);
			resultSet.moveNext();
		}

		GL35Logger.logThis("defalutValue Data Size="+defaultValueData.size(), Priority.DEBUG_INT);
		return defaultValueData;

	}

	@SuppressWarnings("finally")
	public static boolean setDefaultValues(String[] submittedExposureIdsArray,String[] editedDefValueArray, 
			String infodom,String userId,boolean defValueEditNeeded,boolean submitFlag) {
		if(submitFlag) GL35Logger.logThis("in setDefaultValues for SUBMIT and submitFlag:"+submitFlag,Priority.INFO_INT);
		else GL35Logger.logThis("in setDefaultValues for SAVE and submitFlag:"+submitFlag,Priority.INFO_INT);
		GL35Logger.logThis("",Priority.INFO_INT);
		GL35Logger.logThis("in AdjEntryEdit DAO: setDefaultValues params infodom="+infodom+"&submittedExposureIdsArray="+submittedExposureIdsArray.toString()
				+"&editedDefValueArray="+editedDefValueArray.toString()+"&userId="+userId+"&defValueEditNeeded="+defValueEditNeeded, Priority.DEBUG_INT);
		boolean status = false;
		Vector<String> vUpdtQry = new Vector<String>();
		String adjExposureIds = "";
		String authStatus="P";
		if(submitFlag) authStatus="S";
		try{
			for(int i=0;i<submittedExposureIdsArray.length;i++) {
				if(i == submittedExposureIdsArray.length-1)
					adjExposureIds += "'"+submittedExposureIdsArray[i].split("~")[0] + "'";
				else
					adjExposureIds += "'"+submittedExposureIdsArray[i].split("~")[0] + "',";
			}
			GL35Logger.logThis("adjExposureIds="+adjExposureIds, Priority.DEBUG_INT);
	
			if(defValueEditNeeded == true) {
				String query = "UPDATE FSI_ADJ_ENTRY_ATTRIBUTES SET V_OVERRIDE_VALUE = CASE V_DEFAULT_COL_NAME ";
				int ctr=0;
	
				for(int i=0;i<editedDefValueArray.length;i++) {
					String[] tempArray = editedDefValueArray[i].split("~");
					if(tempArray.length>1){
						//try {
						query += "WHEN '" + tempArray[0] + "' THEN '" + tempArray[1] + "' ";
						ctr++;
					//}catch(ArrayIndexOutOfBoundsException e) {
						//query += "WHEN '" + tempArray[0] + "' THEN '' ";
					//}
					}
				}
				query += "END WHERE V_ADJ_EXPOSURE_ID IN (" + adjExposureIds + ")";
	
				GL35Logger.logThis("defaultValue query -------- "+query, Priority.DEBUG_INT);
				if(ctr>0)
				vUpdtQry.add(query);
				/*Cargo FindCountCargo = (Cargo) SMSServices.executeUpdate(infodom,query);
				GL35Logger.logThis("defaultValue update query fired", Priority.DEBUG_INT);
				if(FindCountCargo.getErrorFlag()){
					GL35Logger.logThis("Error while updating the default values", Priority.DEBUG_INT);
					status = false;
				}else{
					GL35Logger.logThis("SUCCESS", Priority.DEBUG_INT);
					status = true;
				}*/
			}
			/*
			   UPDATE FCT_GL_ADJUSTMENT_ENTRIES
			     SET FCT_GL_ADJUSTMENT_ENTRIES.V_MODIFIED_USER = 'GLUSER',FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS = '"+authStatus+"',
			         FCT_GL_ADJUSTMENT_ENTRIES.D_MODIFIED_DATE = SYSDATE,
			         FCT_GL_ADJUSTMENT_ENTRIES.V_USER_COMMENTS = CASE
			         FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID WHEN 'GL_285_9341' THEN '' END
			   WHERE FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID IN ('GL_285_9341')
			 * */
			String commentsQuery = "UPDATE FCT_GL_ADJUSTMENT_ENTRIES SET FCT_GL_ADJUSTMENT_ENTRIES.V_MODIFIED_USER = '"+ userId +"'," +
			"FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS = '"+authStatus+"'," +
			"FCT_GL_ADJUSTMENT_ENTRIES.D_MODIFIED_DATE = SYSDATE," +
			"FCT_GL_ADJUSTMENT_ENTRIES.V_USER_COMMENTS = CASE FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID ";
			String tempString = "";
	
			for(int i=0;i<submittedExposureIdsArray.length;i++) {
				String[] tempArray = submittedExposureIdsArray[i].split("~");
				try {
					if((submitFlag) && ("".equals(tempArray[2]))){
						commentsQuery += "WHEN '" + tempArray[0] + "' THEN 'Submitted' ";	
					}
					else{
						commentsQuery += "WHEN '" + tempArray[0] + "' THEN '" + tempArray[2] + "' ";	
					}
				}catch(ArrayIndexOutOfBoundsException e) {
					GL35Logger.logThis("Entering blank comments for exposureId="+tempArray[0], Priority.DEBUG_INT);
					commentsQuery += "WHEN '" + tempArray[0] + "' THEN '' ";
				}
				if(i < (submittedExposureIdsArray.length-1))
					tempString = tempString + "'" + tempArray[0] + "',";
				else
					tempString = tempString + "'" + tempArray[0] + "'";
			}
			commentsQuery += "END WHERE FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID IN ("+ tempString +")";
			GL35Logger.logThis("commentsQuery -------- "+commentsQuery, Priority.DEBUG_INT);
			vUpdtQry.add(commentsQuery);
			GL35Logger.logThis("UPDATE Queries for Adjustment Entry Specification : ", Priority.INFO_INT);
			for(String qryStr:vUpdtQry)	GL35Logger.logThis(qryStr, Priority.INFO_INT);
			
			String[] vUpdtQryAry = (String[])vUpdtQry.toArray(new String[vUpdtQry.size()]);
			Cargo cr =(Cargo) SMSServices.executeBatch(infodom, vUpdtQryAry, true);
			GL35Logger.logThis("executeBatch cargo for Adjustment Entry Specification returned : "+cr,Priority.INFO_INT);
			if (cr != null && !cr.getErrorFlag()){
				GL35Logger.logThis( "Adjustment Entry Specification update Successfull - Cargo Returned : "+cr, Priority.INFO_INT);
				status=true;
			}else{
				GL35Logger.logThis( " Adjustment Entry Specification update Failed - Cargo Returned : "+cr, Priority.WARN_INT);
				status=false;
			}
	
			/*Cargo FindCountCargo = (Cargo) SMSServices.executeUpdate(infodom,commentsQuery);
			GL35Logger.logThis("defaultValue update query fired", Priority.DEBUG_INT);
			if(FindCountCargo.getErrorFlag()){
				GL35Logger.logThis("Error while running commentsQuery", Priority.DEBUG_INT);
				status = false;
			}else{
				GL35Logger.logThis("SUCCESS", Priority.DEBUG_INT);
				status = true;
			}*/
			
		}catch(Exception e){
			GL35Logger.logThis("Exception occured in setDefaultValues : "+e.getLocalizedMessage(), Priority.ERROR_INT);
			status=false;
			e.printStackTrace();
		}finally{
			GL35Logger.logThis("status returned : "+status, Priority.INFO_INT);
			return status;
		}
	}

	public static boolean submitAdjustmentData(String[] submittedExposureIdsArray, String infodom, String userId,String authStatus) {
		boolean status = false;

		String query = "UPDATE FCT_GL_ADJUSTMENT_ENTRIES SET FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS = '"+authStatus+"'," +
		"FCT_GL_ADJUSTMENT_ENTRIES.V_MODIFIED_USER = '"+ userId +"',FCT_GL_ADJUSTMENT_ENTRIES.D_MODIFIED_DATE = SYSDATE," +
		"FCT_GL_ADJUSTMENT_ENTRIES.V_USER_COMMENTS = CASE FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID ";

		String tempString = "";

		for(int i=0;i<submittedExposureIdsArray.length;i++) {
			String[] tempArray = submittedExposureIdsArray[i].split("~");
			try{
				query += "WHEN '" + tempArray[0] + "' THEN '" + tempArray[2] + "' ";
			}catch(ArrayIndexOutOfBoundsException e) {
				GL35Logger.logThis("No comments for exposure="+tempArray[0], Priority.DEBUG_INT);
				query += "WHEN '" + tempArray[0] + "' THEN '' ";
			}
			if(i < (submittedExposureIdsArray.length-1))
				tempString = tempString + "'" + tempArray[0] + "',";
			else
				tempString = tempString + "'" + tempArray[0] + "'";
		}
		query += "END WHERE FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID IN ("+ tempString +")";

		GL35Logger.logThis("submission query -------- "+query, Priority.DEBUG_INT);

		Cargo FindCountCargo = (Cargo) SMSServices.executeUpdate(infodom,query);
		GL35Logger.logThis("defaultValue update query fired", Priority.DEBUG_INT);
		if(FindCountCargo.getErrorFlag())
		{
			GL35Logger.logThis("Error while updating the default values", Priority.DEBUG_INT);
		}
		else
		{
			GL35Logger.logThis("SUCCESS", Priority.DEBUG_INT);
			status = true;
		}
		return status;
	}

	public static boolean modifyApproverComments(String[] submittedExposureIdsArray, String infodom,String userId) {
		GL35Logger.logThis("in AdjEntryEdit DAO: modifyApproverComments method", Priority.DEBUG_INT);
		boolean status = false;

		String query = "UPDATE FCT_GL_ADJUSTMENT_ENTRIES SET FCT_GL_ADJUSTMENT_ENTRIES.V_MODIFIED_USER = '"+ userId +"'," +
		"FCT_GL_ADJUSTMENT_ENTRIES.D_MODIFIED_DATE = SYSDATE," +
		"FCT_GL_ADJUSTMENT_ENTRIES.V_AUTH_COMMENTS = CASE FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID ";

		String tempString = "";

		for(int i=0;i<submittedExposureIdsArray.length;i++) {
			String[] tempArray = submittedExposureIdsArray[i].split("~");
			try{
				query += "WHEN '" + tempArray[0] + "' THEN '" + tempArray[2] + "' ";
			}catch(ArrayIndexOutOfBoundsException e) {
				GL35Logger.logThis("Entering blank comments for exposure="+tempArray[0], Priority.DEBUG_INT);
				query += "WHEN '" + tempArray[0] + "' THEN '' ";
			}
			if(i < (submittedExposureIdsArray.length-1))
				tempString = tempString + "'" + tempArray[0] + "',";
			else
				tempString = tempString + "'" + tempArray[0] + "'";
		}
		query += "END WHERE FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID IN ("+ tempString +")";

		GL35Logger.logThis("submission query -------- "+query, Priority.DEBUG_INT);

		Cargo FindCountCargo = (Cargo) SMSServices.executeUpdate(infodom,query);
		GL35Logger.logThis("submission update query fired", Priority.DEBUG_INT);
		if(FindCountCargo.getErrorFlag())
		{
			GL35Logger.logThis("Error while updating the default values", Priority.DEBUG_INT);
		}
		else
		{
			GL35Logger.logThis("SUCCESS", Priority.DEBUG_INT);
			status = true;
		}
		return status;
	}

	public static String authorizeAdjEntries(String[] submittedExposureIdsArray, String infodom, String userId) {
		GL35Logger.logThis("in AdjEntryEdit DAO: authorizeAdjEntries infodom="+infodom+"&submittedExposureIdsArray="+submittedExposureIdsArray.toString(), Priority.DEBUG_INT);
		String status = "";

		
		Vector<String> sbVector = new Vector<String>();
		for(int i=0;i<submittedExposureIdsArray.length;i++) {
			String[] tempArray = submittedExposureIdsArray[i].split("~");
			String auth_comments="";
			if(tempArray.length>2) 
				auth_comments=tempArray[2];
			else
				auth_comments="";
			
			if("".equals(auth_comments) || "-".equals(auth_comments)) {
				if(tempArray[1].equalsIgnoreCase("A")) auth_comments="Approved";
				else auth_comments="Rejected";
			}
			
			
			//String commentsStr ="";
			String insertQuery = "INSERT INTO FSI_GL_INTERMEDIATE_ADJ_AUTH VALUES ";
			//if(tempArray[1].equalsIgnoreCase("A")) commentsStr="Approved";
			//else commentsStr="Rejected";
			//try{
				/*commentsStr=tempArray[2];
				GL35Logger.logThis("commentsStr1="+commentsStr, Priority.INFO_INT);
				if("".equals(commentsStr)){
					if(tempArray[1].equalsIgnoreCase("A")) commentsStr="Approved";
					else commentsStr="Rejected";
					GL35Logger.logThis("commentsStr2="+commentsStr, Priority.INFO_INT);
				}*/
				//GL35Logger.logThis("commentsStr3="+commentsStr, Priority.INFO_INT);
				//if(i < (submittedExposureIdsArray.length-1))
					//insertQuery += "('"+tempArray[0]+"','"+tempArray[1]+"','"+ userId +"','"+tempArray[2]+"',SYSDATE),";
				//else
					//insertQuery += "('"+tempArray[0]+"','"+tempArray[1]+"','"+ userId +"','"+tempArray[2]+"',SYSDATE)";
				//sbVector.add(insertQuery);
			//}catch(ArrayIndexOutOfBoundsException e) {

				//GL35Logger.logThis("Blank comments for exposure="+tempArray[0], Priority.DEBUG_INT);
				//if(i < (submittedExposureIdsArray.length-1))
					//insertQuery += "('"+tempArray[0]+"','"+tempArray[1]+"','"+ userId +"','"+commentsStr+"',SYSDATE),";
				//else
					insertQuery += "('"+tempArray[0]+"','"+tempArray[1]+"','"+ userId +"','"+auth_comments+"',SYSDATE)";
				sbVector.add(insertQuery);
			//}
		}	 
		GL35Logger.logThis("INSERT Queries for Adjustment Entry intermediate table : ", Priority.INFO_INT);
		for(String qryStr:sbVector)	GL35Logger.logThis(qryStr, Priority.INFO_INT);
		
		String[] sbVectorArray = (String[])sbVector.toArray(new String[sbVector.size()]);
		
		Cargo FindCountCargo = SMSServices.executeBatch(infodom,sbVectorArray,true);
		//GL35Logger.logThis("insert query -------- "+insertQuery, Priority.DEBUG_INT);

		//Cargo FindCountCargo = (Cargo) SMSServices.executeUpdate(infodom,insertQuery);
		GL35Logger.logThis("insertQuery fired", Priority.DEBUG_INT);

		if(FindCountCargo.getErrorFlag())
		{
			GL35Logger.logThis("Error while updating the intermediate table", Priority.DEBUG_INT);
			status = "Error while updating the intermediate table";
		}
		else
		{
			String processQuery = "SELECT PKG_GLRECON_PROCESSING.fn_adj_auth FROM dual";	

			Cargo FindCountCargo1 = (Cargo) SMSServices.executeQuery(infodom,processQuery,false);
			GL35Logger.logThis("processQuery  fired", Priority.DEBUG_INT);
			DACRecordSet resultSet1 = (DACRecordSet) FindCountCargo1.getPayLoadObject();
			GL35Logger.logThis("CARGO RECEIVED", Priority.DEBUG_INT);

			GL35Logger.logThis("resultSet.fetchElement(1)="+resultSet1.fetchElement(1), Priority.DEBUG_INT);

			if(resultSet1.fetchElement(1).equals("1"))
				status = "SUCCESS";
			else if(resultSet1.fetchElement(1).equals("0"))
				status = "FAIL";
			else
				status = resultSet1.fetchElement(1);
		}
		GL35Logger.logThis("Approval Status = "+status, Priority.DEBUG_INT);
		return status;
	}

}



