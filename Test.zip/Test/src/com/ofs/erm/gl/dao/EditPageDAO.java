/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : EditPageDAO.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Priority;

import umm.bi.ClsUEntHierarchy;
import umm.bi.ClsUEntHierarchyNode;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.client.SecureBusinessMetaData;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.iflex.fic.global.GlobalParameters;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GLCommon;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.EditPageSearchBean;
import com.ofs.erm.gl.model.EditPageSummaryBean;
import com.ofs.erm.gl.model.EleBrDimInputListBean;
import com.ofs.erm.gl.model.MapNameBean;
import com.ofs.erm.gl.model.PPListBean;

public class EditPageDAO { 
	private static int rowId = 0;
	private static int noOfDimensions = 10;
	private static List<String> colArray = new ArrayList<String>();
	private static List<String> dimensionsHeaderArray = new ArrayList<String>();
	private static int noOfPagesLoaded = 2;
	@SuppressWarnings("unused")
	private static String searchQuery;

	static {
		colArray.add("FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID");
		colArray.add("FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT");
		colArray.add("FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS");
		colArray.add("FCT_GL_ADJUSTMENT_ENTRIES.V_GL_CODE");
		colArray.add("CORRECTION_AMOUNT");
	}

	public static List<PPListBean> getPPList(PPListBean ppListBean, String infodom) 
	{
		List<PPListBean> ppDataList = new ArrayList<PPListBean>();
		int count = 1;
		int recordCount = 0;

		if(ppListBean == null){
			ppListBean = new PPListBean();
			ppListBean.setExecId("");
			ppListBean.setGlDate("");
			ppListBean.setMapName("");
			ppListBean.setVersionNumber("");
		}


		String execId = "'%"+ppListBean.getExecId()+"%'";
		String mapName = "'%"+ppListBean.getMapName()+"%'";
		String glDate = "'"+ppListBean.getGlDate()+"'";
		String versionNumber = "'"+ppListBean.getVersionNumber()+"'";


		String query = "SELECT DISTINCT L.V_PP_LOGIC_TABLE_NAME,L.V_PP_BALANCE_LOGIC_COL_NAME FROM FCT_GL_ADJUSTMENT_ENTRIES L  " +
		" inner JOIN dim_dates ON dim_dates.n_date_skey = L.N_DATE_SKEY "+
		" WHERE L.V_EXECUTION_IDENTIFIER LIKE "+execId+" AND L.V_GL_MAP_ID LIKE "+mapName+" AND " +
		" dim_dates.d_calendar_date = TO_DATE("+glDate+", 'MM/DD/YYYY') AND L.N_VERSION_NUMBER = "+versionNumber+"  AND L.F_INTRA_GROUP='N'";

		GL35Logger.logThis(query, Priority.DEBUG_INT);
		GL35Logger.logThis("Adj Entry Edit DAO -- Entering Cargo Services for PP List", Priority.DEBUG_INT);
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,query,false);
		DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		GL35Logger.logThis("Adj Entry Edit DAO -- Received Payload", Priority.DEBUG_INT);
		rowId = 0;

		while(!(resultSet.EOF())) {
			PPListBean ppb = new PPListBean();

			ppb.setPpName(resultSet.fetchElement(1));
			ppb.setGlReconCol(resultSet.fetchElement(2));

			ppb .setRowId(rowId);
			ppb.setCheckBoxString("checkedCNew('" +rowId + "')");

			ppDataList.add(ppb);
			rowId++;

			resultSet.moveNext();
		}

		GL35Logger.logThis("ppDataList.size()="+ppDataList.size(), Priority.DEBUG_INT);
		return ppDataList;
	}

    public static String getDimensionArray(String manDim, String version ,String infodom) 
    {
          String tempDim = "";
          if(manDim.split("@")[0].equals("Y"))
                tempDim = "M";
          else if(manDim.split("@")[0].equals("N"))
                tempDim = "R";

          List<MapNameBean> mapArray = new ArrayList<MapNameBean>();

          String resDimensionArrayStr = new String();
          List<EleBrDimInputListBean> list = new ArrayList<EleBrDimInputListBean>();
          StringBuffer dimOut = new StringBuffer();
          String query = "";

          /**query = "SELECT SGS.V_GL_HCY_CODE,GMC.N_VERSION_NUMBER FROM SETUP_GL_BOOKS GB,FSI_GL_MAPPING_GL_CODES GMC , SETUP_GL_SOURCE SGS " +
          " WHERE GB.V_GL_BOOK = GMC.V_GL_BOOK  AND SGS.V_TABLE_NAME=GB.V_TABLE_NAME AND GMC.V_GL_MAP_ID = '"+ manDim.split("@")[1] +"' ORDER BY GMC.N_VERSION_NUMBER DESC";
          GL35Logger.logThis("query -------- "+query, Priority.DEBUG_INT);

          GL35Logger.logThis("Adj Entry Edit DAO -- Entering Cargo Services for Dimensions Array", Priority.DEBUG_INT);
          Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,query,false);
          DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
          GL35Logger.logThis("Adj Entry Edit DAO -- Received Payload", Priority.DEBUG_INT);

          dimOut.append(resultSet.fetchElement(1) + "~" + "GL Code~TRUE" + "@#$");
          **/
          Vector dimvec = new Vector();
          
          String dimQuery= " select R.V_DIMENSION_HCY_CODE,R.V_DIMENSION_DESC, case when R.F_RECON_OR_MANDATORY = 'M' then 'TRUE'  "+
                       " else 'FALSE' end from setup_gl_recon_dimensions R,FSI_GL_MAPPING_DIMENSIONS D "+
                       " where D.V_DIMENSION_HCY_CODE = R.V_DIMENSION_HCY_CODE AND  d.V_GL_MAP_ID ='"+manDim.split("@")[1]+"' "+
                       " and d.N_VERSION_NUMBER ='"+version+"' AND R.F_RECON_OR_MANDATORY ='"+tempDim+"'";
          
          GL35Logger.logThis("Edit DAO -- Entering Cargo Services for Dimensions Array; dimQuery="+dimQuery, Priority.DEBUG_INT);
          Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,dimQuery,false);
          DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
          

          while(!(resultSet.EOF())) {
                dimOut.append(resultSet.fetchElement(1)+"~"+resultSet.fetchElement(2)+"~"+resultSet.fetchElement(3)+"@#$");
                EleBrDimInputListBean tempEleBrDimBean = new EleBrDimInputListBean();
                tempEleBrDimBean.setDimensionCode(resultSet.fetchElement(1));
                tempEleBrDimBean.setDimensionDesc(resultSet.fetchElement(2));
                tempEleBrDimBean.setMandatoryDim(Boolean.parseBoolean(resultSet.fetchElement(3)));
                list.add(tempEleBrDimBean);
                rowId++;

                resultSet.moveNext();
          }
          GL35Logger.logThis("dimOut="+dimOut, Priority.DEBUG_INT);
          return dimOut.toString();

    }


	public static List<EditPageSummaryBean> getAdjustmentData(EditPageSearchBean searchBean, String infodom,String userId) {
		List<EditPageSummaryBean> adjustmentData = new ArrayList<EditPageSummaryBean>();
		int count = 1;
		int recordCount = 0;
	  try{
		if(searchBean == null){
			searchBean = new EditPageSearchBean();
			searchBean.setExecutionId("");
			searchBean.setGlDate("");
			searchBean.setMapId("");
			searchBean.setVersionNumber("");
			searchBean.setSortCol("");
			searchBean.setSortOrder("");
			searchBean.setStartIndex(1);
			searchBean.setEndIndex(5*noOfPagesLoaded);
			searchBean.setDimSearchNeeded(false);
			searchBean.setContraGLCheckNeeded(false);
			searchBean.setCorrStatus(false);
		}

		StringBuffer dimSearchQueryString = new StringBuffer();

		if(searchBean.isDimSearchNeeded() == true) {
			GL35Logger.logThis("In Edit Page DAO : dim search Required -- "+searchBean.getSelectedDimValues(), Priority.DEBUG_INT);
			String selectedDimValues = searchBean.getSelectedDimValues();

			List<String> hierCodeList = new ArrayList<String>();
			StringBuffer hierCodeQueryString = new StringBuffer();
			Map<String, String> hierValueMap = new HashMap<String, String>();

			String [] selectedDimValuesArray = selectedDimValues.split("#@");

			for(int i=0;i<selectedDimValuesArray.length;i++) {
				hierCodeList.add(selectedDimValuesArray[i].split("~#")[0]);
				String [] tempHierValuesArray = selectedDimValuesArray[i].split("~#")[1].split("~");
				StringBuffer tempHierValuesString = new StringBuffer();
				for(int k=0;k<tempHierValuesArray.length-1;k++)
					tempHierValuesString.append("'" + tempHierValuesArray[k] + "',");
				tempHierValuesString.append("'" + tempHierValuesArray[tempHierValuesArray.length-1] + "'");
				hierValueMap.put(selectedDimValuesArray[i].split("~#")[0].split("#")[0], tempHierValuesString.toString());
			}

			for(int i=0;i<hierCodeList.size()-1;i++) {
				if(hierCodeList.get(i).split("#")[1].equals("GL Code")) {
					dimSearchQueryString.append(" AND fct_gl_adjustment_entries.v_gl_code IN (") ;
					dimSearchQueryString.append(hierValueMap.get(hierCodeList.get(i).split("#")[0]));
					dimSearchQueryString.append(")");
				}
				else if(!(hierCodeList.get(i).split("#")[1].equals("GL Code"))) {
					hierCodeQueryString.append("'"+ hierCodeList.get(i).split("#")[0] +"',");
				}
			}
			if(hierCodeList.get(hierCodeList.size()-1).split("#")[1].equals("GL Code")) {
				dimSearchQueryString.append(" AND fct_gl_adjustment_entries.v_gl_code IN (") ;
				dimSearchQueryString.append(hierValueMap.get(hierCodeList.get(hierCodeList.size()-1).split("#")[0]));
				dimSearchQueryString.append(")");
			}
			else if(!(hierCodeList.get(hierCodeList.size()-1).split("#")[1].equals("GL Code"))) {
				hierCodeQueryString.append("'"+ hierCodeList.get(hierCodeList.size()-1).split("#")[0]+"'");
			}

			String hierCodeQuery = "SELECT GD.V_DIMENSION_COL_NAME,SD.V_DIMENSION_HCY_CODE FROM SETUP_GL_RECON_DIMENSIONS SD," +
			"FSI_SETUP_GL_DIMENSIONS GD WHERE SD.V_DIMENSION_HCY_CODE = GD.V_DIMENSION_HCY_CODE AND " +
			"SD.V_DIMENSION_HCY_CODE IN ("+hierCodeQueryString+")";

			GL35Logger.logThis("hierCodeQuery="+hierCodeQuery, Priority.DEBUG_INT);

			if(!(hierCodeQueryString.equals(""))) {
				GL35Logger.logThis("BEFORE Cargo FindCountCargo", Priority.DEBUG_INT);
				Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,hierCodeQuery,false);
				DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
				GL35Logger.logThis("CARGO RECEIVED", Priority.DEBUG_INT);

				while (!resultSet.EOF()) {
					dimSearchQueryString.append(" AND FCT_GL_ADJUSTMENT_ENTRIES." + resultSet.fetchElement(1) + " IN (") ;
					dimSearchQueryString.append(hierValueMap.get(resultSet.fetchElement(2)));
					dimSearchQueryString.append(")");
					resultSet.moveNext();
				}
			}    
		}
		

		GL35Logger.logThis("dimSearchQueryString="+dimSearchQueryString, Priority.DEBUG_INT);
		String[] entryStatus = searchBean.getEntryStatus().split("~");
		StringBuffer entryStatusString = new StringBuffer();
		for(int k=0;k<entryStatus.length;k++) {
			if(k < entryStatus.length - 1)
				entryStatusString.append("'" + entryStatus[k] + "',");
			else if(k == entryStatus.length - 1)
				entryStatusString.append("'" + entryStatus[k] + "'");
		}
		GL35Logger.logThis("entryStatusString="+entryStatusString, Priority.DEBUG_INT);
		String execId = "'"+searchBean.getExecutionId()+"'";
		String mapName = "'"+searchBean.getMapId()+"'";
		String glDate = searchBean.getGlDate();
		String versionNumber =  "'"+searchBean.getVersionNumber()+"'";
		String contraGLCheck = " AND ((FCT_GL_ADJUSTMENT_ENTRIES.N_CONTRA_GL_AMOUNT <> 0) OR (FCT_GL_ADJUSTMENT_ENTRIES.N_CONTRA_GL_AMOUNT IS NULL)) ";
		
		
		if(searchBean.getRecordCountNeeded() == true) {
			GL35Logger.logThis("iNSIDE searchBean.getRecordCountNeeded() == true", Priority.DEBUG_INT);
			String corrTabName = "";
			String corrDistinctRows = "";
			if(searchBean.getCorrStatus() == true){
				corrTabName=",FCT_GL_CORRECTION_ENTRIES ";
				corrDistinctRows=" DISTINCT FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID ";
			}
			StringBuffer recordQuery = new StringBuffer();

			recordQuery.append("SELECT COUNT(1) FROM ( SELECT " );
			if(searchBean.getCorrStatus() == true){
				recordQuery.append(" DISTINCT FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID ");
			}else{
				recordQuery.append(" * ");
			}
			recordQuery.append(" FROM FCT_GL_ADJUSTMENT_ENTRIES,dim_dates" );
			if(searchBean.getCorrStatus() == true){
				recordQuery.append(",FCT_GL_CORRECTION_ENTRIES "); 
			}
			recordQuery.append(" WHERE ((dim_dates.n_date_skey=FCT_GL_ADJUSTMENT_ENTRIES.n_Date_Skey) AND FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER " );
			recordQuery.append(" LIKE "+execId+" AND FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID LIKE "+mapName+" AND " );
			recordQuery.append(" dim_dates.d_calendar_date = COALESCE(TO_DATE('"+glDate+"','MM-DD-YYYY')," );
			recordQuery.append(" dim_dates.d_calendar_date) AND FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER = "+versionNumber+" AND (FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS IN (" + entryStatusString + ")) AND " );
			recordQuery.append(" FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT BETWEEN '"+searchBean.getSearchExpAmountLowerBound()+"' AND '"+searchBean.getSearchExpAmountUpperBound()+"'  ");
			
			if(searchBean.isContraGLCheckNeeded() == true) {
				recordQuery.append(contraGLCheck);
			}
			if(searchBean.isDimSearchNeeded() == true){
				recordQuery.append(dimSearchQueryString);
			}

			String[] selectedPPArray = searchBean.getSelectedPPArray(); 

			if(!(selectedPPArray[0].equals("Nill"))) {
				recordQuery.append("AND FCT_GL_ADJUSTMENT_ENTRIES.V_PP_LOGIC_TABLE_NAME IN (");

				for(int k=0;k<selectedPPArray.length-1;k++) {
					recordQuery.append("'"+ selectedPPArray[k] +"',");
					GL35Logger.logThis("selectedPPArray[k]="+selectedPPArray[k], Priority.DEBUG_INT);
				}
				recordQuery.append("'"+ selectedPPArray[selectedPPArray.length-1] +"'");
				recordQuery.append(")");
			}
			if(searchBean.getCorrStatus() == true){
				recordQuery.append(" AND (FCT_GL_CORRECTION_ENTRIES.V_ADJ_EXPOSURE_ID=FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID AND FCT_GL_CORRECTION_ENTRIES.V_AUTHORIZATION_STATUS='S') ");
			}
			recordQuery.append(") )");
			
			GL35Logger.logThis(recordQuery.toString(), Priority.DEBUG_INT);
			GL35Logger.logThis("BEFORE Cargo FindCountCargo", Priority.DEBUG_INT);
			Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,recordQuery.toString(),false);
			DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
			GL35Logger.logThis("CARGO RECEIVED", Priority.DEBUG_INT);
			recordCount = Integer.parseInt(resultSet.fetchElement(1));
			GL35Logger.logThis("recordCount RECEIVED - "+recordCount, Priority.DEBUG_INT);
		}

		count = 1;
		if((searchBean.getSortOrder() == "") || (searchBean.getSortOrder() == null)) {
			searchBean.setSortOrder("ASC");
			searchBean.setSortCol("2");
		}

		String sortColName = colArray.get(Integer.parseInt(searchBean.getSortCol()));
		/*String execId = "'"+searchBean.getExecutionId()+"'";
		String mapName = "'"+searchBean.getMapId()+"'";
		String glDate = "'"+searchBean.getGlDate()+"'";
		String versionNumber =  "'"+searchBean.getVersionNumber()+"'";*/
		//String[] entryStatus = searchBean.getEntryStatus().split("~");
		//StringBuffer entryStatusString = new StringBuffer();
		String corrTabName = "";
		
		/*for(int k=0;k<entryStatus.length;k++) {
			if(k < entryStatus.length - 1)
				entryStatusString.append("'" + entryStatus[k] + "',");
			else if(k == entryStatus.length - 1)
				entryStatusString.append("'" + entryStatus[k] + "'");
		}
		GL35Logger.logThis("entryStatusString="+entryStatusString, Priority.DEBUG_INT);*/

		dimensionsHeaderArray = populateDimensionsHeaderArray(searchBean.getMapId(),infodom,searchBean.getVersionNumber());
		StringBuffer queryColName = new StringBuffer();
		for(int k=0;k<dimensionsHeaderArray.size();k++) {
			queryColName.append("FCT_GL_ADJUSTMENT_ENTRIES." + dimensionsHeaderArray.get(k).split("~")[1]+",");
			GL35Logger.logThis("HCY CODE for "+dimensionsHeaderArray.get(k).split("~")[0] +"is:"+dimensionsHeaderArray.get(k).split("~")[2], Priority.DEBUG_INT);
		}
		GL35Logger.logThis("queryColName="+queryColName, Priority.DEBUG_INT);

		StringBuffer searchQuery = new StringBuffer();
		searchQuery.append(" SELECT * FROM ( SELECT ROWNUM RNUM, A.* FROM (SELECT " );
		if(searchBean.getCorrStatus() == true){
			searchQuery.append(" DISTINCT ");
		}
		searchQuery.append(" FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID,");
		searchQuery.append(" FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT,FSI_GL_LOOKUP_MASTER.V_CATEGORY_DESC,FCT_GL_ADJUSTMENT_ENTRIES.V_GL_CODE," +queryColName);
		searchQuery.append(" FCT_GL_ADJUSTMENT_ENTRIES.V_USER_COMMENTS,FCT_GL_ADJUSTMENT_ENTRIES.V_AUTH_COMMENTS,FCT_GL_ADJUSTMENT_ENTRIES.V_CREATED_USER,");
		searchQuery.append(" FCT_GL_ADJUSTMENT_ENTRIES.D_CREATED_DATE,FCT_GL_ADJUSTMENT_ENTRIES.V_MODIFIED_USER,FCT_GL_ADJUSTMENT_ENTRIES.D_MODIFIED_DATE,");
		searchQuery.append(" FCT_GL_ADJUSTMENT_ENTRIES.V_PP_LOGIC_TABLE_NAME");
		if(searchBean.getCorrChk()){
			searchQuery.append(" ,NVL(CA.CORRECTION_AMOUNT,0) CORRECTION_AMOUNT ");
		}
		searchQuery.append("  FROM FCT_GL_ADJUSTMENT_ENTRIES");
		//searchQuery.append(" ,FSI_GL_LOOKUP_MASTER ");
		if(searchBean.getCorrStatus()){
			searchQuery.append(" INNER JOIN FCT_GL_CORRECTION_ENTRIES ON FCT_GL_CORRECTION_ENTRIES.V_ADJ_EXPOSURE_ID = FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID  ");
		}
		if(searchBean.getCorrChk()){
			searchQuery.append(" LEFT OUTER JOIN (SELECT v_adj_exposure_id, SUM(N_CORRECTION_AMOUNT) CORRECTION_AMOUNT,V_AUTHORIZATION_STATUS FROM FCT_GL_CORRECTION_ENTRIES ");
			searchQuery.append(" WHERE V_AUTHORIZATION_STATUS= 'A' GROUP BY v_adj_exposure_id,V_AUTHORIZATION_STATUS) CA ON CA.V_ADJ_EXPOSURE_ID = FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID");
		}
		searchQuery.append(" LEFT OUTER JOIN FSI_GL_LOOKUP_MASTER ON FSI_GL_LOOKUP_MASTER.V_CATEGORY_ID=FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS AND FSI_GL_LOOKUP_MASTER.V_LOOKUP_CD = '14' ");
		searchQuery.append(" inner JOIN DIM_DATES ON DIM_DATES.N_DATE_SKEY=FCT_GL_ADJUSTMENT_ENTRIES.N_DATE_SKEY ");
		searchQuery.append(" WHERE ");
		searchQuery.append(" (FCT_GL_ADJUSTMENT_ENTRIES.V_EXECUTION_IDENTIFIER LIKE "+execId+" AND FCT_GL_ADJUSTMENT_ENTRIES.V_GL_MAP_ID LIKE ");
		searchQuery.append(""+mapName+" AND ");
		//searchQuery.append(" FSI_GL_LOOKUP_MASTER.V_CATEGORY_ID=FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS ");
		//searchQuery.append(" AND FSI_GL_LOOKUP_MASTER.V_LOOKUP_CD = '14' AND ");
		searchQuery.append(" DIM_DATES.D_CALENDAR_DATE = COALESCE(TO_DATE('"+glDate+"','MM-DD-YYYY'),");
		searchQuery.append(" DIM_DATES.D_CALENDAR_DATE) AND FCT_GL_ADJUSTMENT_ENTRIES.N_VERSION_NUMBER = "+versionNumber+" ");
		searchQuery.append(" AND (FCT_GL_ADJUSTMENT_ENTRIES.V_AUTHORIZATION_STATUS IN (" + entryStatusString + "))  AND ");
		searchQuery.append(" FCT_GL_ADJUSTMENT_ENTRIES.N_EXPOSURE_AMOUNT BETWEEN '"+searchBean.getSearchExpAmountLowerBound()+"' AND '"+searchBean.getSearchExpAmountUpperBound()+"' ");

		if(searchBean.isContraGLCheckNeeded()) {
			searchQuery.append(contraGLCheck);
		}
		
		if(searchBean.isDimSearchNeeded()){
			searchQuery.append(dimSearchQueryString);
		}
		String[] selectedPPArray = searchBean.getSelectedPPArray(); 

		if(!(selectedPPArray[0].equals("Nill"))) {
			searchQuery.append("AND FCT_GL_ADJUSTMENT_ENTRIES.V_PP_LOGIC_TABLE_NAME IN (");

			for(int k=0;k<selectedPPArray.length-1;k++) {
				searchQuery.append("'"+ selectedPPArray[k] +"',");
				GL35Logger.logThis("selectedPPArray[k]="+selectedPPArray[k], Priority.DEBUG_INT);
			}
			searchQuery.append("'"+ selectedPPArray[selectedPPArray.length-1] +"'");
			searchQuery.append(")");
		}
		
		if(searchBean.getCorrStatus()){
			//searchQuery.append(" AND (FCT_GL_CORRECTION_ENTRIES.V_ADJ_EXPOSURE_ID=FCT_GL_ADJUSTMENT_ENTRIES.V_ADJ_EXPOSURE_ID AND FCT_GL_CORRECTION_ENTRIES.V_AUTHORIZATION_STATUS='S') ");
			searchQuery.append(" AND (FCT_GL_CORRECTION_ENTRIES.V_AUTHORIZATION_STATUS='S') ");
		}

		searchQuery.append(" ) order by "+sortColName+" "+searchBean.getSortOrder()+" ) a " +
		"where rownum <= "+searchBean.getEndIndex()+") where rnum >= "+searchBean.getStartIndex()+" ");

		GL35Logger.logThis("Edit DAO: searchQuery="+searchQuery, Priority.DEBUG_INT);

		List<LinkedHashMap> dimensionValueList = new ArrayList<LinkedHashMap>();

		GL35Logger.logThis("BEFORE Cargo FindCountCargo", Priority.DEBUG_INT);
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,searchQuery.toString(),false);
		GL35Logger.logThis("search query fired", Priority.DEBUG_INT);
		
		if(!(FindCountCargo.getErrorFlag())) {
		DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		GL35Logger.logThis("CARGO RECEIVED", Priority.DEBUG_INT);

		rowId = searchBean.getStartIndex() - 1;
		
		while (!resultSet.EOF()) {
			if(rowId == (searchBean.getStartIndex() - 1)) {/*for header row*/
				GL35Logger.logThis("Edit DAO -- Populating the Dimesions header array", Priority.DEBUG_INT);
				EditPageSummaryBean asb = new EditPageSummaryBean();
				asb.setExposureId("--");
				asb.setExposureAmount(0);
				asb.setStatus(resultSet.fetchElement(4));
				asb.setGlCode(resultSet.fetchElement(5));
				List<String> tempDimArray = new ArrayList<String>(); // mandatory dimensions
				List<String> tempDimArrayOpt = new ArrayList<String>(); // optional dimensions
				int j = 0;
				//for(int k=5;k<=12;k++) {
				for(int k=6;k<6+dimensionsHeaderArray.size();k++) {
					//if(!((resultSet.fetchElement(k)== null) ) ) {
						//if(!((resultSet.fetchElement(k).equals(""))))		
						//{
							if(dimensionsHeaderArray.get(j).split("~")[3].equalsIgnoreCase("R")){
								tempDimArrayOpt.add(dimensionsHeaderArray.get(j).split("~")[0]);
								LinkedHashMap tempMap = GLCommon.getHierNodes(infodom,userId, dimensionsHeaderArray.get(j).split("~")[2]);
								GL35Logger.logThis("tempMap size="+tempMap.size(), Priority.DEBUG_INT);
								dimensionValueList.add(tempMap);
								GL35Logger.logThis("Dimension-"+(tempDimArrayOpt.size()-1)+" is: "+tempDimArrayOpt.get(tempDimArrayOpt.size()-1), Priority.DEBUG_INT);
							}else{
								tempDimArray.add(dimensionsHeaderArray.get(j).split("~")[0]);
								LinkedHashMap tempMap = GLCommon.getHierNodes(infodom,userId, dimensionsHeaderArray.get(j).split("~")[2]);
								GL35Logger.logThis("tempMap size="+tempMap.size(), Priority.DEBUG_INT);
								dimensionValueList.add(tempMap);
								GL35Logger.logThis("Dimension-"+(tempDimArray.size()-1)+" is: "+tempDimArray.get(tempDimArray.size()-1), Priority.DEBUG_INT);
							}
						//}
					//}
					//else {
						//dimensionValueList.add(null);
					//}
					j++;
				}
				GL35Logger.logThis("Total No of header dimensions="+tempDimArray.size(), Priority.DEBUG_INT);
				asb.setDimensionsArray(tempDimArray);
				GL35Logger.logThis("tempDimArray : "+tempDimArray.toString(), Priority.DEBUG_INT);
				GL35Logger.logThis("tempDimArrayOpt : "+tempDimArrayOpt.toString(), Priority.DEBUG_INT);
				asb.setDimensionsArrayOpt(tempDimArrayOpt);
				asb.setRowId(0);
				asb.setRecordCount(recordCount);
				adjustmentData.add(asb);
			}

			EditPageSummaryBean asb = new EditPageSummaryBean();
			asb.setExposureId(resultSet.fetchElement(2));
			asb.setExposureAmount(Double.parseDouble(resultSet.fetchElement(3)));
			asb.setStatus(resultSet.fetchElement(4));
			asb.setGlCode(resultSet.fetchElement(5));
			List<String> tempDimArray = new ArrayList<String>(); // mandatory dimensions
			List<String> tempDimArrayOpt = new ArrayList<String>(); // optional dimensions
			int j = 0;
			//for(int k=5;k<=12;k++) {
			for(int k=6;k<6+dimensionsHeaderArray.size();k++) {
				//if(!((resultSet.fetchElement(k)== null) ) ) {
					//if(!((resultSet.fetchElement(k).equals("")))) {
				//GL35Logger.logThis("k is :"+k, Priority.DEBUG_INT);
				String uniqueNodeCodeVal = GlobalUtil.getHierUniqCodeFromLeafCode(resultSet.fetchElement(k),dimensionsHeaderArray.get(j).split("~")[2], infodom);
					if(dimensionsHeaderArray.get(j).split("~")[3].equalsIgnoreCase("R")){
						String dimLogicalValue = (String) dimensionValueList.get(j).get(uniqueNodeCodeVal);
						GL35Logger.logThis("dimLogicalValue="+dimLogicalValue, Priority.DEBUG_INT);
						if(dimLogicalValue == null){
							tempDimArrayOpt.add(resultSet.fetchElement(k));
						}else{
							tempDimArrayOpt.add(dimLogicalValue);
						}
						GL35Logger.logThis("Dimension-"+(tempDimArrayOpt.size()-1)+" is: "+tempDimArrayOpt.get(tempDimArrayOpt.size()-1), Priority.DEBUG_INT);
					}else{
						String dimLogicalValue = (String) dimensionValueList.get(j).get(uniqueNodeCodeVal);
						GL35Logger.logThis("dimLogicalValue="+dimLogicalValue, Priority.DEBUG_INT);
						if(dimLogicalValue == null){
							tempDimArray.add(resultSet.fetchElement(k));
						}else{
							tempDimArray.add(dimLogicalValue);
						}
						GL35Logger.logThis("Dimension-"+(tempDimArray.size()-1)+" is: "+tempDimArray.get(tempDimArray.size()-1), Priority.DEBUG_INT);
					}
					//}
				//}
				j++;
			}
			GL35Logger.logThis("Total No of bean-"+rowId+" dimensions="+tempDimArray.size(), Priority.DEBUG_INT);
			asb.setDimensionsArray(tempDimArray);
			GL35Logger.logThis("tempDimArray : "+tempDimArray.toString(), Priority.DEBUG_INT);
			GL35Logger.logThis("tempDimArrayOpt : "+tempDimArrayOpt.toString(), Priority.DEBUG_INT);
			asb.setDimensionsArrayOpt(tempDimArrayOpt);
			asb.setUserComments(resultSet.fetchElement("V_USER_COMMENTS"));
			asb.setApproverComments(resultSet.fetchElement("V_AUTH_COMMENTS"));
			asb.setCreatedBy(resultSet.fetchElement("V_CREATED_USER"));
			asb.setCreationDate(resultSet.fetchElement("D_CREATED_DATE"));
			asb.setModifiedBy(resultSet.fetchElement("V_MODIFIED_USER"));
			asb.setModificationDate(resultSet.fetchElement("D_MODIFIED_DATE"));
			asb.setPPLogTableName(resultSet.fetchElement("V_PP_LOGIC_TABLE_NAME"));
			if(searchBean.getCorrChk()){
				asb.setCorrectionAmount(resultSet.fetchElement("CORRECTION_AMOUNT"));
			}
			asb.setRowId(rowId);
			asb.setRecordCount(recordCount);
			adjustmentData.add(asb);
			rowId++;
			resultSet.moveNext();
		}
		}
		else {
			String errorMsg = (String) FindCountCargo.getPayLoadObject();
			String errorStr = "";
			int oraIndex = errorMsg.indexOf("ORA");
			if(oraIndex >= 0) {
				errorStr = "Error while fetching Adjustment Data !@ "+ errorMsg.substring(oraIndex, errorMsg.length());
			}
			else {
				errorStr = "Error while fetching Adjustment Data !@ "+ errorMsg;
			}
			
			EditPageSummaryBean asb = new EditPageSummaryBean();
			asb.setExposureId(null);
			asb.setStatus(errorStr);
			adjustmentData.add(asb);
			GL35Logger.logThis("Error while fetching Adjustment Data and errorStr="+errorStr, Priority.DEBUG_INT);
		}
		
		GL35Logger.logThis("Data size : "+adjustmentData.size(), Priority.DEBUG_INT);
		//setDimensionsArrayOpt
		//getDimensionsArrayOpt();
		//GL35Logger.logThis("setDimensionsArrayOpt="+getDimensionsArrayOpt(), Priority.DEBUG_INT);
		return adjustmentData;
	  }catch(Exception e){
		e.printStackTrace();
		GL35Logger.logThis("Exception occured"+e.getLocalizedMessage(), Priority.DEBUG_INT);
		return adjustmentData;
	  }
	}

	/* function to get the dimensions list for populating the Adj entry spec block*/
	public static List<String> populateDimensionsHeaderArray(String mapId,String infodom,String versionNo) 
	{
		List<String> headerArray = new ArrayList<String>();

		/*String query = "SELECT SGS.V_GL_HCY_CODE,GMC.N_VERSION_NUMBER FROM SETUP_GL_BOOKS GB,FSI_GL_MAPPING_GL_CODES GMC , SETUP_GL_SOURCE SGS " +
		" WHERE GB.V_GL_BOOK = GMC.V_GL_BOOK  AND GB.V_TABLE_NAME = SGS.V_TABLE_NAME AND GMC.V_GL_MAP_ID = '"+ mapId +"' ORDER BY GMC.N_VERSION_NUMBER DESC";
		GL35Logger.logThis("query -------- "+query, Priority.DEBUG_INT);

		GL35Logger.logThis("Adj Entry Edit DAO -- Entering Cargo Services for populateDimensionsHeaderArray", Priority.DEBUG_INT);
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,query,false);
		DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		GL35Logger.logThis("Adj Entry Edit DAO -- Received Payload", Priority.DEBUG_INT);

		headerArray.add("GL Code~V_GL_CODE"+"~"+resultSet.fetchElement(1));

		query = "SELECT SD.V_DIMENSION_DESC,GD.V_DIMENSION_COL_NAME,SD.V_DIMENSION_HCY_CODE,SD.F_RECON_OR_MANDATORY  FROM SETUP_GL_RECON_DIMENSIONS SD," +
		"FSI_SETUP_GL_DIMENSIONS GD WHERE SD.V_DIMENSION_HCY_CODE = GD.V_DIMENSION_HCY_CODE " +
		"ORDER BY SD.F_RECON_OR_MANDATORY ASC"; 
		GL35Logger.logThis("query -------- "+query, Priority.DEBUG_INT);

		GL35Logger.logThis("Adj Entry Edit DAO -- Entering Cargo Services for populateDimensionsHeaderArray", Priority.DEBUG_INT);
		FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,query,false);
		resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		GL35Logger.logThis("Adj Entry Edit DAO -- Received Payload", Priority.DEBUG_INT);

		rowId = 0;

		while(!(resultSet.EOF())) {
			headerArray.add(resultSet.fetchElement(1)+"~"+resultSet.fetchElement(2)+"~"+resultSet.fetchElement(3)+"~"+resultSet.fetchElement(4));
			resultSet.moveNext();
		}*/
		StringBuilder sbSql = new StringBuilder();
		sbSql.append("SELECT RD.V_DIMENSION_DESC,GD.V_DIMENSION_COL_NAME,RD.V_DIMENSION_HCY_CODE,RD.F_RECON_OR_MANDATORY ");
		sbSql.append(" FROM FSI_GL_MAPPING_DIMENSIONS MD  ");
		sbSql.append(" LEFT OUTER JOIN SETUP_GL_RECON_DIMENSIONS RD ON RD.V_DIMENSION_HCY_CODE=MD.V_DIMENSION_HCY_CODE ");
		sbSql.append(" LEFT OUTER JOIN FSI_SETUP_GL_DIMENSIONS GD ON GD.V_DIMENSION_HCY_CODE=MD.V_DIMENSION_HCY_CODE ");
		sbSql.append(" WHERE MD.V_GL_MAP_ID = '"+mapId+"' AND MD.N_VERSION_NUMBER = "+versionNo+" ");
		sbSql.append(" ORDER BY RD.F_RECON_OR_MANDATORY ");
		Cargo cr = (Cargo)SMSServices.executeQuery(infodom, sbSql.toString(), false);
		DACRecordSet rs = (DACRecordSet)cr.getPayLoadObject();
		while(!rs.EOF()){
			headerArray.add(rs.fetchElement(1)+"~"+rs.fetchElement(2)+"~"+rs.fetchElement(3)+"~"+rs.fetchElement(4));
			rs.moveNext();
		}

		return headerArray;
	}

}
