/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.

--------------------------------------------------------------------------------------------------------
File Name             : GLMSummaryDAO.java
Created By            : Rahul M 
Created On            : April 26th, 2012
Application Name      : General Ledger 
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/

package com.ofs.erm.gl.dao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Priority;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.GLMSearchBean;
import com.ofs.erm.gl.model.GLMSummaryBean;

public class GLMSummaryDAO {
	
	private static int rowId = 0;
	private static List<String> colArray = new ArrayList<String>();
	public static int noOfPagesLoaded = 2;
	@SuppressWarnings("unused")
	private static String searchQuery;
	private static LinkedHashMap<String, String> glTypeMap;

	static {
		colArray.add("DGA.V_GL_ACCOUNT_NAME");
		colArray.add("DGA.V_GL_ACCOUNT_CODE");
		colArray.add("DGA.V_GL_ACCOUNT_NAME");
		colArray.add("DGA.V_GL_PARENT_ACCOUNT_CODE");
		colArray.add("DGA.V_GL_BOOK_CODE");
		colArray.add("DGA.V_GL_TYPE");
		colArray.add("DGA.F_INTRA_GROUP");
		colArray.add("DGA.V_CREATED_BY");
		colArray.add("DGA.D_CREATED_DATE");
		colArray.add("DGA.V_LAST_MODIFIED_BY");
		colArray.add("DGA.D_LAST_MODIFIED_DATE"); 
		colArray.add("DGA.F_DIFF_AUTO_APPROVE_FLAG");
	}
	public static List<GLMSummaryBean> getGLMData(GLMSearchBean searchBean,
			String infodom, String userId) {
		// TODO Auto-generated method stub
		
		List<GLMSummaryBean> glmList = new ArrayList<GLMSummaryBean>();
		
		String glTypeCode = GlobalUtil.getParamValue("GL_TYPE_HIERCODE", infodom); 
		glTypeMap = GlobalUtil.getHierNodeDesc(infodom, userId, glTypeCode);
		
		int count = 1;
		int recordCount = 0;

		if(searchBean == null){
			searchBean = new GLMSearchBean();
			searchBean.setSearchGLAcntName("");
			searchBean.setSearchGLBook("");
			searchBean.setSearchGLType("");
			searchBean.setSearchIntraGrp("");
			searchBean.setSearchparentGLAcntName("");
			searchBean.setSortOrder("");
			searchBean.setStartIndex(1);
			searchBean.setEndIndex(10*noOfPagesLoaded);
		}
		
		/*Process Input Variables*/
		String glAcntName = searchBean.getSearchGLAcntName();
		String glBook = searchBean.getSearchGLBook();
		String parentGlAcntName = searchBean.getSearchparentGLAcntName();

		String glType = "'" + searchBean.getSearchGLType() + "'";
		if (glType.equals("''"))
			glType = "'%%'";

		String intraGrp = "'" + searchBean.getSearchIntraGrp() + "'";
		if (intraGrp.equals("''"))
			intraGrp = "'%%'";

		glAcntName = "'" + getLeafNode(infodom, glAcntName) + "'";
		if (glAcntName.equals("''"))
			glAcntName = "'%%'";
		
		glBook = "'" + getLeafNode(infodom, glBook) + "'";
		if (glBook.equals("''"))
			glBook = "'%%'";

		parentGlAcntName = "'" + getLeafNode(infodom, parentGlAcntName) + "'";
		if (parentGlAcntName.equals("''"))
			parentGlAcntName = "'%%'";

		if (glType.equals("'ALL'")) {
			glType = "'%%'";
		}
		
		if(searchBean.isRecordCountNeeded() == true) {
			GL35Logger.logThis("DAO:getRecordCount Loop", Priority.DEBUG_INT);

			
			String recordQuery = "SELECT COUNT(1) FROM ( SELECT * FROM DIM_GL_ACCOUNT WHERE (DIM_GL_ACCOUNT.V_GL_ACCOUNT_CODE LIKE "
					+ glAcntName
					+ " AND DIM_GL_ACCOUNT.V_GL_BOOK_CODE "
					+ "LIKE "
					+ glBook
					+ " AND DIM_GL_ACCOUNT.V_GL_TYPE LIKE "
					+ glType
					+ "  AND DIM_GL_ACCOUNT.F_INTRA_GROUP LIKE "
					+ intraGrp
					+ "  AND (DIM_GL_ACCOUNT.V_GL_PARENT_ACCOUNT_CODE LIKE "
					+ parentGlAcntName + "";
			if(("'%%'").equals(parentGlAcntName)){
				recordQuery += " OR DIM_GL_ACCOUNT.V_GL_PARENT_ACCOUNT_CODE IS NULL ";
			}
			recordQuery +=") ) )";
			GL35Logger.logThis(recordQuery, Priority.DEBUG_INT);
			Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,recordQuery,false);
			
			if(FindCountCargo.getErrorFlag())
			{
				GL35Logger.logThis("Error while retrieving from Database - Inside DAO", Priority.DEBUG_INT);
				GLMSummaryBean tempBean = new GLMSummaryBean();
				glmList.add(tempBean);
				GL35Logger.logThis("bean added", Priority.DEBUG_INT);
				return glmList;
			}
			else {
				DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
				recordCount = Integer.parseInt(resultSet.fetchElement(1));
			}
		}

		count = 1;

		if((searchBean.getSortOrder() == "") || (searchBean.getSortOrder() == null)) {
			searchBean.setSortOrder("DESC");
			searchBean.setSortCol("1");
		}

		String sortColName = colArray.get(Integer.parseInt(searchBean
				.getSortCol()));

		StringBuffer searchQuery = new StringBuffer();

		searchQuery.append("SELECT * FROM ( SELECT ROWNUM RNUM, A.* FROM (");
		searchQuery
				.append("SELECT NVL(DGA.V_GL_ACCOUNT_NAME,'-'),"
						+ "NVL(DGA.V_GL_ACCOUNT_CODE,'-'),NVL(DGA.V_GL_PARENT_ACCOUNT_CODE,'-'),NVL(DGA.V_GL_BOOK_CODE,'-'),"
						+ "NVL(DGA.V_GL_TYPE,'-'),NVL(DGA.F_INTRA_GROUP,'-'),NVL(DGA.V_CREATED_BY,'-'),NVL(DGA.D_CREATED_DATE,''),NVL(DGA.V_LAST_MODIFIED_BY,'-'),NVL(DGA.D_LAST_MODIFIED_DATE,''),NVL(DGA.F_DIFF_AUTO_APPROVE_FLAG,'-')"
				+ " FROM DIM_GL_ACCOUNT DGA WHERE (");

		searchQuery.append("DGA.V_GL_ACCOUNT_CODE LIKE " + glAcntName
				+ " AND DGA.V_GL_BOOK_CODE "
 + "LIKE " + glBook
				+ " AND DGA.V_GL_TYPE LIKE " + glType
				+ "  AND DGA.F_INTRA_GROUP LIKE " + intraGrp
				+ "  AND (DGA.V_GL_PARENT_ACCOUNT_CODE LIKE "
				+ parentGlAcntName + "");
		
		if(("'%%'").equals(parentGlAcntName)){
			searchQuery.append(" OR DGA.V_GL_PARENT_ACCOUNT_CODE IS NULL");
		}
		searchQuery.append(" ) ) ORDER BY UPPER("+sortColName+") "+ searchBean.getSortOrder() +") A WHERE ROWNUM <= "+searchBean.getEndIndex()+" ) WHERE RNUM >= "+searchBean.getStartIndex()+" ");
		GL35Logger.logThis(searchQuery.toString(), Priority.DEBUG_INT);

		GL35Logger.logThis("GLM Query Fired", Priority.DEBUG_INT);
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,searchQuery.toString(),false);
		DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		GL35Logger.logThis("GLM Cargo Received", Priority.DEBUG_INT);
		rowId = searchBean.getStartIndex() - 1;
		
		
		
		while (!resultSet.EOF()) {
			String parentGLName = "",parentGLCode  = "";
			if (!(resultSet.fetchElement(4) == null || resultSet
					.fetchElement(4).equals("-"))) {
				parentGLCode = resultSet.fetchElement(4);			
				String query1 = "SELECT DGA.V_GL_ACCOUNT_NAME FROM DIM_GL_ACCOUNT DGA WHERE DGA.V_GL_ACCOUNT_CODE = '"+parentGLCode+"'";
				Cargo cargo1 = (Cargo) SMSServices.executeQuery(infodom,query1.toString(),false);
				DACRecordSet resultSet1 = (DACRecordSet) cargo1.getPayLoadObject();
				while (!resultSet1.EOF()) {
					parentGLName = resultSet1.fetchElement(1);
					resultSet1.moveNext();
				}
			}
			else{
				parentGLName = "-";
				parentGLCode = "-";
			}
				
			GLMSummaryBean glmsb = new GLMSummaryBean();

			glmsb.setGlAcntName(resultSet.fetchElement(2));
			glmsb.setGlAcntCode(resultSet.fetchElement(3));
			glmsb.setParentGLAcntName(parentGLName);
			glmsb.setParentGLCode(parentGLCode);
			glmsb.setGlBook(resultSet.fetchElement(5));
			glmsb.setGlType(glTypeMap.get(resultSet.fetchElement(6)));
			glmsb.setIntraGrp(resultSet.fetchElement(7)); 
			if ((resultSet.fetchElement(8) == null || resultSet.fetchElement(8)
					.equals(""))) {
				glmsb.setCreatedBy("-");
			} else
				glmsb.setCreatedBy(resultSet.fetchElement(8));

			if ((resultSet.fetchElement(9) == null || resultSet.fetchElement(9)
					.equals(""))) {
				glmsb.setCreatedDate("-");
			} else
			
			{			
				String tempCreateDate = resultSet.fetchElement(9);
			    String[] tempDate = tempCreateDate.split(" ");
			    String[] tempDate1 = tempDate[0].split("-");
			    String creationDate = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
			    glmsb.setCreatedDate(creationDate);
			}
			if((resultSet.fetchElement(10) == null || resultSet.fetchElement(10).equals(""))){
				glmsb.setModifiedBy("-");
			}
			else{
				glmsb.setModifiedBy(resultSet.fetchElement(10));	
			}
			
			if((resultSet.fetchElement(11) == null || resultSet.fetchElement(11).equals(""))){
				glmsb.setModifiedDate("-");
			}
			else
			{			
				String tempCreateDate = resultSet.fetchElement(11);
			    String[] tempDate = tempCreateDate.split(" ");
			    String[] tempDate1 = tempDate[0].split("-");
			    String modifiedDate = tempDate1[1]+"/"+tempDate1[2]+"/"+tempDate1[0];
			    glmsb.setModifiedDate(modifiedDate);
			}
			
			glmsb.setIsAutoApprove(resultSet.fetchElement(12));		    
		    glmsb.setCheckBoxString("checkedCNew('" +rowId + "')");
		    glmsb.setRecordCount(recordCount);
		    glmsb.setRowId(rowId);
		    glmList.add(glmsb);
		    rowId++;
		    resultSet.moveNext();
		}
		GL35Logger.logThis("GLM List Size:"+glmList.size(), Priority.DEBUG_INT);

		
		return glmList;
	}
	
	public static String getLeafNode(String infoDom, String hierUniqCode) {
		// TODO Auto-generated method stub
		
		if(hierUniqCode.equals("") || ("'%%'").equals(hierUniqCode)){
			return "";
		}
		
		GL35Logger.logThis("Calling PKG_MATADATA_INFO.GETLEAFCODE()...",Priority.DEBUG_INT);
		StringBuffer sqlQuery1a = new StringBuffer("SELECT PKG_MATADATA_INFO.GETLEAFCODE('"+hierUniqCode+"') FROM DUAL");
		Cargo cargo = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery1a.toString(), false);
		DACRecordSet resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
		String sLeafCode = "";
		while (!resultSet1.EOF() && resultSet1.getRowCount() > 0){
			sLeafCode = resultSet1.fetchElement(1);
			resultSet1.moveNext();
		}

		return sLeafCode;
	}

}
