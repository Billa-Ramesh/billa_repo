/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : AdjDefaultValueBean.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.model;

public class AdjDefaultValueBean 
{
	private String columnName;
	private String columnLogicalName;
	private String columnDefaultValue;
	private String columnOverrideValue;
	private String userComments;
	private int rowId;
	
	public AdjDefaultValueBean() {
		// TODO Auto-generated constructor stub
	}
	
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getColumnLogicalName() {
		return columnLogicalName;
	}

	public void setColumnLogicalName(String columnLogicalName) {
		this.columnLogicalName = columnLogicalName;
	}

	public String getColumnDefaultValue() {
		return columnDefaultValue;
	}
	public void setColumnDefaultValue(String columnDefaultValue) {
		this.columnDefaultValue = columnDefaultValue;
	}
	public String getColumnOverrideValue() {
		return columnOverrideValue;
	}
	public void setColumnOverrideValue(String columnOverrideValue) {
		this.columnOverrideValue = columnOverrideValue;
	}

	public String getUserComments() {
		return userComments;
	}

	public void setUserComments(String userComments) {
		this.userComments = userComments;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}
	
	
}
