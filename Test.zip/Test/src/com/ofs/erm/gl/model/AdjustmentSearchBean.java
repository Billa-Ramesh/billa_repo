/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : AdjustmentSearchBean.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.model;

public class AdjustmentSearchBean 
{
	private String executionId;
	private String glDate;
	private String mapId;
	private String sortOrder;
	private String sortCol;
	private int startIndex;
	private int endIndex;
	private boolean recordCountNeeded;
	private boolean mapArrayNeeded;
	
	public AdjustmentSearchBean() {
		// TODO Auto-generated constructor stub
	}
	
	public String getExecutionId() {
		return executionId;
	}
	public void setExecutionId(String executionId) {
		this.executionId = executionId;
	}
	public String getGlDate() {
		return glDate;
	}
	public void setGlDate(String glDate) {
		this.glDate = glDate;
	}
	public String getMapId() {
		return mapId;
	}
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSortCol() {
		return sortCol;
	}
	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	public boolean getRecordCountNeeded() {
		return recordCountNeeded;
	}

	public void setRecordCountNeeded(boolean recordCountNeeded) {
		this.recordCountNeeded = recordCountNeeded;
	}

	public boolean isMapArrayNeeded() {
		return mapArrayNeeded;
	}

	public void setMapArrayNeeded(boolean mapArrayNeeded) {
		this.mapArrayNeeded = mapArrayNeeded;
	}
	
}
