/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GlobalParamSearchBean.java
* Title         :
* Description   :
* @author       : Deepak Dagar 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.model;

public class GlobalParamSearchBean {
	
	
	private String searchLegalEntity;
	private String sortOrder;
	private String sortCol;
	private int startIndex;
	private int endIndex;
	private boolean recordCountNeeded;
	
	public GlobalParamSearchBean() {
		// TODO Auto-generated constructor stub
	}
	
	public String getSearchLegalEntity() {
		return searchLegalEntity;
	}
	public void setSearchLegalEntity(String searchLegalEntity) {
		this.searchLegalEntity = searchLegalEntity;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSortCol() {
		return sortCol;
	}
	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	public boolean isRecordCountNeeded() {
		return recordCountNeeded;
	}
	public void setRecordCountNeeded(boolean recordCountNeeded) {
		this.recordCountNeeded = recordCountNeeded;
	}
	

}

