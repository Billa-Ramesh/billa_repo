/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : CorrectionSummaryBean.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.model;

public class CorrectionSummaryBean 
{
	private String executionIdentifier,mapName,checkBoxString,mapId,versionNumber;
	private String glDate;
	private String reconAmount,correctionAmount;
	private int rowId;
	private int recordCount;
	
	public CorrectionSummaryBean() {
		// TODO Auto-generated constructor stub
	}

	public String getExecutionIdentifier() {
		return executionIdentifier;
	}

	public void setExecutionIdentifier(String executionIdentifier) {
		this.executionIdentifier = executionIdentifier;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String getCheckBoxString() {
		return checkBoxString;
	}

	public void setCheckBoxString(String checkBoxString) {
		this.checkBoxString = checkBoxString;
	}

	public String getGlDate() {
		return glDate;
	}

	public void setGlDate(String glDate) {
		this.glDate = glDate;
	}

	public String getReconAmount() {
		return reconAmount;
	}

	public void setReconAmount(String reconAmount) {
		this.reconAmount = reconAmount;
	}

	public String getCorrectionAmount() {
		return correctionAmount;
	}

	public void setCorrectionAmount(String correctionAmount) {
		this.correctionAmount = correctionAmount;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public String getMapId() {
		return mapId;
	}

	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	public String getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	
	
}
