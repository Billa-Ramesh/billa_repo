/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : GLMSearchBean.java
Created By            : Rahul Manoharan 
Created On            : July 10th, 2012
Application Name      : General Ledger v3.5
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/

package com.ofs.erm.gl.model;

public class GLMSearchBean {
	
	private String searchGLAcntName;
	private String searchparentGLAcntName;
	private String searchGLBook;
	private String searchGLType;
	private String searchIntraGrp;
	private String sortOrder;
	private String sortCol;
	private int startIndex;
	private int endIndex;
	private boolean recordCountNeeded;
	
	public String getSearchGLAcntName() {
		return searchGLAcntName;
	}
	public void setSearchGLAcntName(String searchGLAcntName) {
		this.searchGLAcntName = searchGLAcntName;
	}
	public String getSearchparentGLAcntName() {
		return searchparentGLAcntName;
	}
	public void setSearchparentGLAcntName(String searchparentGLAcntName) {
		this.searchparentGLAcntName = searchparentGLAcntName;
	}
	public String getSearchGLBook() {
		return searchGLBook;
	}
	public void setSearchGLBook(String searchGLBook) {
		this.searchGLBook = searchGLBook;
	}
	public String getSearchGLType() {
		return searchGLType;
	}
	public void setSearchGLType(String searchGLType) {
		this.searchGLType = searchGLType;
	}
	public String getSearchIntraGrp() {
		return searchIntraGrp;
	}
	public void setSearchIntraGrp(String searchIntraGrp) {
		this.searchIntraGrp = searchIntraGrp;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSortCol() {
		return sortCol;
	}
	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	public boolean isRecordCountNeeded() {
		return recordCountNeeded;
	}
	public void setRecordCountNeeded(boolean recordCountNeeded) {
		this.recordCountNeeded = recordCountNeeded;
	}

}
