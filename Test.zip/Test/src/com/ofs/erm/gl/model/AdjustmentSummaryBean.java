/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : AdjustmentSummaryBean.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.model;

public class AdjustmentSummaryBean 
{
	private String executionIdentifier,mapName,mapId,checkBoxString,versionNumber;
	private String glDate,autoApproved;
	private String reconAmount,amountSubmissionPending,amountApprovalPending,amountApproved,amountRejected;
	private int rowId;
	private int recordCount;
	
	public AdjustmentSummaryBean() {
		// TODO Auto-generated constructor stub
	}
	
	public String getExecutionIdentifier() {
		return executionIdentifier;
	}
	public void setExecutionIdentifier(String executionIdentifier) {
		this.executionIdentifier = executionIdentifier;
	}
	public String getMapName() {
		return mapName;
	}
	public void setMapName(String mapName) {
		this.mapName = mapName;
	}
	public String getMapId() {
		return mapId;
	}

	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	public String getGlDate() {
		return glDate;
	}
	public void setGlDate(String glDate) {
		this.glDate = glDate;
	}
	public String getAutoApproved() {
		return autoApproved;
	}

	public void setAutoApproved(String autoApproved) {
		this.autoApproved = autoApproved;
	}

	public String getReconAmount() {
		return reconAmount;
	}
	public void setReconAmount(String reconAmount) {
		this.reconAmount = reconAmount;
	}
	public String getAmountSubmissionPending() {
		return amountSubmissionPending;
	}
	public void setAmountSubmissionPending(String amountSubmissionPending) {
		this.amountSubmissionPending = amountSubmissionPending;
	}
	public String getAmountApprovalPending() {
		return amountApprovalPending;
	}
	public void setAmountApprovalPending(String amountApprovalPending) {
		this.amountApprovalPending = amountApprovalPending;
	}
	public String getAmountApproved() {
		return amountApproved;
	}
	public void setAmountApproved(String amountApproved) {
		this.amountApproved = amountApproved;
	}
	public String getAmountRejected() {
		return amountRejected;
	}
	public void setAmountRejected(String amountRejected) {
		this.amountRejected = amountRejected;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getCheckBoxString() {
		return checkBoxString;
	}

	public void setCheckBoxString(String checkBoxString) {
		this.checkBoxString = checkBoxString;
	}

	public String getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	
	
}
