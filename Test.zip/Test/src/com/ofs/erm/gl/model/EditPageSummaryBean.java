/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : EditPageSummaryBean.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.model;

import java.util.List;

public class EditPageSummaryBean 
{
	private String exposureId;
	private double exposureAmount;
	private String status;
	private List<String> dimensionsArray;
	private List<String> dimensionsArrayOpt;
	private String userComments;
	private String approverComments;
	private String createdBy;
	private String creationDate;
	private String modifiedBy;
	private String modificationDate;
	private String pPLogTableName;
	private String glCode;
//	private String glCode;
//	private String legalEntity;
//	private String currency;
//	private String product;
//	private String business;
//	private String accountBranch;
//	private String customerClass;
//	private String costCentre;
	private int recordCount;
	private int rowId;
	private String correctionAmount;
	
	public EditPageSummaryBean() {
		// TODO Auto-generated constructor stub
	}

	public String getExposureId() {
		return exposureId;
	}

	public void setExposureId(String exposureId) {
		this.exposureId = exposureId;
	}

	public double getExposureAmount() {
		return exposureAmount;
	}

	public void setExposureAmount(double exposureAmount) {
		this.exposureAmount = exposureAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getDimensionsArray() {
		return dimensionsArray;
	}

	public void setDimensionsArray(List<String> dimensionsArray) {
		this.dimensionsArray = dimensionsArray;
	}

	public List<String> getDimensionsArrayOpt() {
		return dimensionsArrayOpt;
	}

	public void setDimensionsArrayOpt(List<String> dimensionsArrayOpt) {
		this.dimensionsArrayOpt = dimensionsArrayOpt;
	}

	public String getUserComments() {
		return userComments;
	}

	public void setUserComments(String userComments) {
		this.userComments = userComments;
	}

	public String getApproverComments() {
		return approverComments;
	}

	public void setApproverComments(String approverComments) {
		this.approverComments = approverComments;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(String modificationDate) {
		this.modificationDate = modificationDate;
	}

	public String getPPLogTableName() {
		return pPLogTableName;
	}

	public void setPPLogTableName(String logTableName) {
		pPLogTableName = logTableName;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getGlCode() {
		return glCode;
	}

	public void setGlCode(String glCode) {
		this.glCode = glCode;
	}

	public String getCorrectionAmount() {
		return correctionAmount;
	}

	public void setCorrectionAmount(String correctionAmount) {
		this.correctionAmount = correctionAmount;
	}
	
	
}
