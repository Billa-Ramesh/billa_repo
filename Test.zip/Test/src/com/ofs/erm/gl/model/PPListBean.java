/****************************************************************************************************
This source is part of the General Ledger Software System and is copyrighted by Oracle Financial Services Software Limited.
All rights reserved.  No part of this work may be reproduced, stored in a retrieval system, adopted or
transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording
or otherwise, translated in any language or computer language, without the prior written permission of
Oracle Financial Services Software Limited.
Oracle Financial Services Software Limited, 10-11, SDF I, SEEPZ, Andheri (East), MUMBAI - 400 096, INDIA

Copyright &cp; 2010-2012  by Oracle Financial Services Software Limited.
--------------------------------------------------------------------------------------------------------
File Name             : PPListBean.java
Created By            : Manoj Cherukumalli 
Created On            : April 26th, 2012
Application Name      : General Ledger 
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/
package com.ofs.erm.gl.model;

public class PPListBean {
	
	public String getGlReconCol() {
		return glReconCol;
	}

	public void setGlReconCol(String glReconCol) {
		this.glReconCol = glReconCol;
	}

	public String getExecId() {
		return execId;
	}

	public void setExecId(String execId) {
		this.execId = execId;
	}

	public String getGlDate() {
		return glDate;
	}

	public void setGlDate(String glDate) {
		this.glDate = glDate;
	}




	public String getPpName() {
		return ppName;
	}

	public void setPpName(String ppName) {
		this.ppName = ppName;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getCheckBoxString() {
		return checkBoxString;
	}

	public void setCheckBoxString(String checkBoxString) {
		this.checkBoxString = checkBoxString;
	}

	private String ppName;
	private String glReconCol;
	private String execId;
	private String glDate;
	private String mapName;
	private String versionNumber;

	private String checkBoxString;
	private int rowId;
	public String getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}


}
