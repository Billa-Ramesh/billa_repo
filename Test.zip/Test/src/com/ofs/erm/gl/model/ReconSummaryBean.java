/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : ReconSummaryBean.java
Created By            : Manoj Cherukumalli 
Created On            : April 26th, 2012
Application Name      : General Ledger 
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/
package com.ofs.erm.gl.model;

public class ReconSummaryBean 
{
	private String name;
	private String legalEntity;
	private String consolType;
	private String reconType;
	private String selfAndDescendant;
	private String createdBy;
	private String creationDate;
	private String modifiedBy;
	private String modificationDate;
	private String checkBoxString;
	private int recordCount;
	private int rowId;
	private String versionNumber;
	private String consolDesc;
	private String mapId;
	
	public String getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}

	public ReconSummaryBean() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getConsolDesc() {
		return consolDesc;
	}

	public void setConsolDesc(String consolDesc) {
		this.consolDesc = consolDesc;
	}

	public String getLegalEntity() {
		return legalEntity;
	}

	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}

	public String getConsolType() {
		return consolType;
	}

	public void setConsolType(String consolType) {
		this.consolType = consolType;
	}

	public String getReconType() {
		return reconType;
	}

	public void setReconType(String reconType) {
		this.reconType = reconType;
	}

	public String getSelfAndDescendant() {
		return selfAndDescendant;
	}

	public void setSelfAndDescendant(String selfAndDescendant) {
		this.selfAndDescendant = selfAndDescendant;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(String modificationDate) {
		this.modificationDate = modificationDate;
	}

	public String getCheckBoxString() {
		return checkBoxString;
	}

	public void setCheckBoxString(String checkBoxString) {
		this.checkBoxString = checkBoxString;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getMapId() {
		return mapId;
	}

	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	
	
}
