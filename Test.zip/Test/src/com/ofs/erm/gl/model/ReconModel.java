/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : ReconModel.java
Created By            : Rahul Manoharan 
Created On            : April 20th, 2012
Application Name      : General Ledger v3.5
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/

package com.ofs.erm.gl.model;

import java.util.List;

public class ReconModel {
	
	//Global Attributes
	private String pageMode;
	private String mapId;
	private String versionNum;
	private String createdUser;
	private String comments;
	private String infoDom;
	private String createdDate;
	private String isActOrPass;
	
	public String getIsActOrPass() {
		return isActOrPass;
	}

	public void setIsActOrPass(String isActOrPass) {
		this.isActOrPass = isActOrPass;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getPageMode() {
		return pageMode;
	}

	public void setPageMode(String pageMode) {
		this.pageMode = pageMode;
	}


	public String getMapId() {
		return mapId;
	}

	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	public String getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(String versionNum) {
		this.versionNum = versionNum;
	}


	public String getInfoDom() {
		return infoDom;
	}

	public void setInfoDom(String infoDom) {
		this.infoDom = infoDom;
	}


	//Common Attributes
	private String name;
	private String desc;
	
	//Settings Attributes
	private String legEntity;
	private String legalEntityDesc;
	private String selConsolType;
	private String selBalType; 
	private String radAdjReq;
	private String radReconDefTyp;
	
	//GL Param Attributes
	private String glBookType;
	private String glBookTypeDesc;
	private String selGlType;
	private String glHierDesc;
	private String glHierCode;
	private String hierarchyCode; //Stores hierarchy code reqd. to fetch GL Code.

	//TP Attributes
	private String selTrsCrn;
	private String selTrsSpc;
	private String posCrctnThr;
	private String negCrctnThr;
	private String adjEntryFloor;
	private String glCodeCol; // Not Used
	private String selAmtCol;
	private String selTpTab;
	private String selGlColForTp; 
	
	//Dimensions Attributes
	private String reconDim;
	private String reconDimCode;
	
	//Allocation Attributes
	private String radAdjAlloc;
	private String radAdjPostTo;
	private String ppTableAlloc;
	private String targetOrAdjusted;
	private String defaultValues;
	private String allocationRatio;
	private String balAmtAlloc;
	private String glAmtCol;
	private String glCol;
	private String selGlColForAllocTp;
	
	//Filter Attributes
	private String tpFilterHierCode;
	private String tpFilterHierNode;
	private String glFilterHierCode;
	private String glFilterHierNode;
	private String txnEntityName;
	
	public ReconModel() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getLegEntity() {
		return legEntity;
	}

	public void setLegEntity(String legEntity) {
		this.legEntity = legEntity;
	}

	public String getSelConsolType() {
		return selConsolType;
	}

	public void setSelConsolType(String selConsolType) {
		this.selConsolType = selConsolType;
	}

	public String getSelBalType() {
		return selBalType;
	}

	public void setSelBalType(String selBalType) {
		this.selBalType = selBalType;
	}

	public String getRadAdjReq() {
		return radAdjReq;
	}

	public void setRadAdjReq(String radAdjReq) {
		this.radAdjReq = radAdjReq;
	}

	public String getRadReconDefTyp() {
		return radReconDefTyp;
	}

	public void setRadReconDefTyp(String radReconDefTyp) {
		this.radReconDefTyp = radReconDefTyp;
	}

	public String getLegalEntityDesc() {
		return legalEntityDesc;
	}

	public void setLegalEntityDesc(String legalEntityDesc) {
		this.legalEntityDesc = legalEntityDesc;
	}

	public String getGlBookTypeDesc() {
		return glBookTypeDesc;
	}

	public void setGlBookTypeDesc(String glBookTypeDesc) {
		this.glBookTypeDesc = glBookTypeDesc;
	}

	public String getGlBookType() {
		return glBookType;
	}

	public void setGlBookType(String glBookType) {
		this.glBookType = glBookType;
	}

	public String getSelGlType() {
		return selGlType;
	}

	public void setSelGlType(String selGlType) {
		this.selGlType = selGlType;
	}

	public String getGlHierDesc() {
		return glHierDesc;
	}

	public void setGlHierDesc(String glHierDesc) {
		this.glHierDesc = glHierDesc;
	}

	public String getHierarchyCode() {
		return hierarchyCode;
	}

	public void setHierarchyCode(String hierarchyCode) {
		this.hierarchyCode = hierarchyCode;
	}

	public String getSelTrsCrn() {
		return selTrsCrn;
	}

	public void setSelTrsCrn(String selTrsCrn) {
		this.selTrsCrn = selTrsCrn;
	}

	public String getSelTrsSpc() {
		return selTrsSpc;
	}

	public void setSelTrsSpc(String selTrsSpc) {
		this.selTrsSpc = selTrsSpc;
	}

	public String getPosCrctnThr() {
		return posCrctnThr;
	}

	public String getReconDimCode() {
		return reconDimCode;
	}

	public void setReconDimCode(String reconDimCode) {
		this.reconDimCode = reconDimCode;
	}

	public void setPosCrctnThr(String posCrctnThr) {
		this.posCrctnThr = posCrctnThr;
	}

	public String getNegCrctnThr() {
		return negCrctnThr;
	}

	public void setNegCrctnThr(String negCrctnThr) {
		this.negCrctnThr = negCrctnThr;
	}

	public String getAdjEntryFloor() {
		return adjEntryFloor;
	}

	public void setAdjEntryFloor(String adjEntryFloor) {
		this.adjEntryFloor = adjEntryFloor;
	}

	public String getTxnEntityName() {
		return txnEntityName;
	}

	public void setTxnEntityName(String txnEntityName) {
		this.txnEntityName = txnEntityName;
	}

	public String getGlCodeCol() {
		return glCodeCol;
	}

	public void setGlCodeCol(String glCodeCol) {
		this.glCodeCol = glCodeCol;
	}

	public String getSelAmtCol() {
		return selAmtCol;
	}

	public void setSelAmtCol(String selAmtCol) {
		this.selAmtCol = selAmtCol;
	}

	public String getSelTpTab() {
		return selTpTab;
	}

	public void setSelTpTab(String selTpTab) {
		this.selTpTab = selTpTab;
	}

	public String getSelGlColForTp() {
		return selGlColForTp;
	}

	public void setSelGlColForTp(String selGlColForTp) {
		this.selGlColForTp = selGlColForTp;
	}

	public String getReconDim() {
		return reconDim;
	}

	public void setReconDim(String reconDim) {
		this.reconDim = reconDim;
	}

	public String getRadAdjAlloc() {
		return radAdjAlloc;
	}

	public void setRadAdjAlloc(String radAdjAlloc) {
		this.radAdjAlloc = radAdjAlloc;
	}

	public String getRadAdjPostTo() {
		return radAdjPostTo;
	}

	public void setRadAdjPostTo(String radAdjPostTo) {
		this.radAdjPostTo = radAdjPostTo;
	}

	public String getPpTableAlloc() {
		return ppTableAlloc;
	}

	public void setPpTableAlloc(String ppTableAlloc) {
		this.ppTableAlloc = ppTableAlloc;
	}

	public String getTargetOrAdjusted() {
		return targetOrAdjusted;
	}

	public void setTargetOrAdjusted(String targetOrAdjusted) {
		this.targetOrAdjusted = targetOrAdjusted;
	}

	public String getDefaultValues() {
		return defaultValues;
	}

	public void setDefaultValues(String defaultValues) {
		this.defaultValues = defaultValues;
	}

	public String getAllocationRatio() {
		return allocationRatio;
	}

	public void setAllocationRatio(String allocationRatio) {
		this.allocationRatio = allocationRatio;
	}

	public String getBalAmtAlloc() {
		return balAmtAlloc;
	}

	public void setBalAmtAlloc(String balAmtAlloc) {
		this.balAmtAlloc = balAmtAlloc;
	}

	public String getGlAmtCol() {
		return glAmtCol;
	}

	public void setGlAmtCol(String glAmtCol) {
		this.glAmtCol = glAmtCol;
	}

	public String getGlCol() {
		return glCol;
	}

	public void setGlCol(String glCol) {
		this.glCol = glCol;
	}

	public String getSelGlColForAllocTp() {
		return selGlColForAllocTp;
	}

	public void setSelGlColForAllocTp(String selGlColForAllocTp) {
		this.selGlColForAllocTp = selGlColForAllocTp;
	}

	public String getGlHierCode() {
		return glHierCode;
	}

	public void setGlHierCode(String glHierCode) {
		this.glHierCode = glHierCode;
	}
	public String getTpFilterHierCode() {
		return tpFilterHierCode;
	}

	public void setTpFilterHierCode(String tpFilterHierCode) {
		this.tpFilterHierCode = tpFilterHierCode;
	}

	public String getTpFilterHierNode() {
		return tpFilterHierNode;
	}

	public void setTpFilterHierNode(String tpFilterHierNode) {
		this.tpFilterHierNode = tpFilterHierNode;
	}

	public String getGlFilterHierCode() {
		return glFilterHierCode;
	}

	public void setGlFilterHierCode(String glFilterHierCode) {
		this.glFilterHierCode = glFilterHierCode;
	}

	public String getGlFilterHierNode() {
		return glFilterHierNode;
	}

	public void setGlFilterHierNode(String glFilterHierNode) {
		this.glFilterHierNode = glFilterHierNode;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String display) {
		this.comments = display;
	}
}
