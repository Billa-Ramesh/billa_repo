/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : GLMSummaryBean.java
Created By            : Rahul Manoharan 
Created On            : July 10th, 2012
Application Name      : General Ledger v3.5
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/

package com.ofs.erm.gl.model;

public class GLMSummaryBean {

	private int recordCount;
	private int rowId;
	private String checkBoxString;
	private String glAcntName;
	private String glAcntCode;
	private String glCode; // Unused
	private String parentGLAcntName;
	private String parentGLCode;
	private String glBook;
	private String glType;
	private String intraGrp;
	private String createdBy;
	private String createdDate;
	private String modifiedBy;
	private String modifiedDate;
	private String isAutoApprove;
	
	public String getIsAutoApprove() {
		return isAutoApprove;
	}
	public void setIsAutoApprove(String isAutoApprove) {
		this.isAutoApprove = isAutoApprove;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public int getRowId() {
		return rowId;
	}
	public void setRowId(int rowId) {
		this.rowId = rowId;
	}
	public String getCheckBoxString() {
		return checkBoxString;
	}
	public void setCheckBoxString(String checkBoxString) {
		this.checkBoxString = checkBoxString;
	}
	public String getGlAcntName() {
		return glAcntName;
	}
	public void setGlAcntName(String glAcntName) {
		this.glAcntName = glAcntName;
	}
	public String getGlAcntCode() {
		return glAcntCode;
	}
	public void setGlAcntCode(String glAcntCode) {
		this.glAcntCode = glAcntCode;
	}
	public String getGlCode() {
		return glCode;
	}
	public void setGlCode(String glCode) {
		this.glCode = glCode;
	}
	public String getParentGLAcntName() {
		return parentGLAcntName;
	}
	public void setParentGLAcntName(String parentGLAcntName) {
		this.parentGLAcntName = parentGLAcntName;
	}
	public String getParentGLCode() {
		return parentGLCode;
	}
	public void setParentGLCode(String parentGLCode) {
		this.parentGLCode = parentGLCode;
	}
	public String getGlBook() {
		return glBook;
	}
	public void setGlBook(String glBook) {
		this.glBook = glBook;
	}
	public String getGlType() {
		return glType;
	}
	public void setGlType(String glType) {
		this.glType = glType;
	}
	public String getIntraGrp() {
		return intraGrp;
	}
	public void setIntraGrp(String intraGrp) {
		this.intraGrp = intraGrp;
	}
	
}
