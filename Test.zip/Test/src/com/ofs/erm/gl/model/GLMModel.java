/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : GLMModel.java
Created By            : Rahul Manoharan 
Created On            : July 10th, 2012
Application Name      : General Ledger v3.5
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/


package com.ofs.erm.gl.model;

public class GLMModel {

	private String glAcntName;
	private String glCode;
	private String glBook;
	private String glBookDesc;
	private String glType;
	private String intraGrp;
	private String prntGlAcntNameDesc;
	private String prntGlAcntName;
	private String prntGlAcntNameDisp;
	private String createdBy;
	private String createdDate;
	private String modifiedBy;
	private String modifiedDate;
	private String isAutoApprove;
	
	
	private String infoDom;
	private String pgMode;
	
	public String getInfoDom() {
		return infoDom;
	}
	public void setInfoDom(String infoDom) {
		this.infoDom = infoDom;
	}
	public String getPgMode() {
		return pgMode;
	}
	public void setPgMode(String pgMode) {
		this.pgMode = pgMode;
	}
	public String getGlAcntName() {
		return glAcntName;
	}
	public void setGlAcntName(String glAcntName) {
		this.glAcntName = glAcntName;
	}
	public String getGlCode() {
		return glCode;
	}
	public void setGlCode(String glCode) {
		this.glCode = glCode;
	}
	public String getGlBook() {
		return glBook;
	}
	public void setGlBook(String glBook) {
		this.glBook = glBook;
	}
	public String getGlBookDesc() {
		return glBookDesc;
	}
	public void setGlBookDesc(String glBookDesc) {
		this.glBookDesc = glBookDesc;
	}
	public String getGlType() {
		return glType;
	}
	public void setGlType(String glType) {
		this.glType = glType;
	}
	public String getIntraGrp() {
		return intraGrp;
	}
	public void setIntraGrp(String intraGrp) {
		this.intraGrp = intraGrp;
	}
	public String getPrntGlAcntNameDesc() {
		return prntGlAcntNameDesc;
	}
	public void setPrntGlAcntNameDesc(String prntGlAcntNameDesc) {
		this.prntGlAcntNameDesc = prntGlAcntNameDesc;
	}
	public String getPrntGlAcntName() {
		return prntGlAcntName;
	}
	public void setPrntGlAcntName(String prntGlAcntName) {
		this.prntGlAcntName = prntGlAcntName;
	}
	public String getPrntGlAcntNameDisp() {
		return prntGlAcntNameDisp;
	}
	public void setPrntGlAcntNameDisp(String prntGlAcntNameDisp) {
		this.prntGlAcntNameDisp = prntGlAcntNameDisp;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getIsAutoApprove() {
		return isAutoApprove;
	}
	public void setIsAutoApprove(String isAutoApprove) {
		this.isAutoApprove = isAutoApprove;
	}
	
}
