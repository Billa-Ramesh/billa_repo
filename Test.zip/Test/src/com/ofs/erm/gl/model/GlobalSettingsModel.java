/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GlobalSettingsModel.java
* Title         :
* Description   :
* @author       : Pallavi Reddy 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.model;

public class GlobalSettingsModel {

	
	private String table_id;
	private String mandatoryDims;
	private String balType;
	private String ppdetails;
	private String gldetails;
	private String dimensions;
	private String bookhiercode;
	private String dimMaps;
	
	public  void setTable_id(String table_id)
	{
		this.table_id = table_id;
	}
	public  String getTable_id()
	{
		return table_id;
		
	}
	public String getMandatoryDims() {
		return mandatoryDims;
	}

	public void setMandatoryDims(String mandatoryDims) {
		this.mandatoryDims = mandatoryDims;
	}
	public String getBalType() {
		return balType;
	}

	public void setBalType(String balType) {
		this.balType = balType;
	}
	public String getPpdetails() {
		return ppdetails;
	}

	public void setPpdetails(String ppdetails) {
		this.ppdetails = ppdetails;
	}
	public String getGldetails() {
		return gldetails;
	}

	public void setGldetails(String gldetails) {
		this.gldetails = gldetails;
	}
	public String getDimensions() {
		return dimensions;
	}

	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}
	public String getBookhiercode() {
		return bookhiercode;
	}
	public void setBookhiercode(String bookhiercode) {
		this.bookhiercode = bookhiercode;
	}
	public String getDimMaps() {
		return dimMaps;
	}
	public void setDimMaps(String dimMaps) {
		this.dimMaps = dimMaps;
	}
	
	
	
}
