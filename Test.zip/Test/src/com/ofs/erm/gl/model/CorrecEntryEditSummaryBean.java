/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : CorrecEntryEditSummaryBean.java
* Title         :
* Description   :
* @author       : Sandeep 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.model;

import java.util.ArrayList;


import org.apache.log4j.Priority;

import com.ofs.erm.gl.global.GL35Logger;

public class CorrecEntryEditSummaryBean {
	private String transactionEntity, balanceColumn, correctionExpsoureId, originalAmt, correctionAmt, submissionComments, adjustmentExposureId;
	private String attributeVal,attributeValCols;
	//private String attributeValDef,attributeValColsDef;
	private int rowId;
	private String transactionEntityPhysical, balanceColumnPhysical;
	private String correctionId;
	private String authStatus;
	private String authComments;
	private String createdUser,modifiedUser,createdDate,modifiedDate;
	private ArrayList<String> CorrectionGLCode=new ArrayList<String>();
	private ArrayList<String> CorrectionGLCodeDef=new ArrayList<String>();
	private String authStatusDesc;

	public String getAuthComments() {
		return authComments;
	}
	public void setAuthComments(String authComments) {
		this.authComments = authComments;
	}
	public ArrayList<String> getCorrectionGLCode() {
		return CorrectionGLCode;
	}
	public void setCorrectionGLCode(ArrayList<String> correctionGLCode) {
		CorrectionGLCode = correctionGLCode;
	}
	public void setCorrectionGLCode(String correctionGLCode) {
		CorrectionGLCode=new ArrayList<String>();
		GL35Logger.logThis("correctionGLCode : "+correctionGLCode, Priority.DEBUG_INT);
		if((!"".equals(correctionGLCode)) && !(correctionGLCode==null)) CorrectionGLCode.add(correctionGLCode);
		System.out.println("CorrectionGLCode.toString() : "+CorrectionGLCode.toString());
		GL35Logger.logThis("CorrectionGLCode.toString() : "+CorrectionGLCode.toString(), Priority.DEBUG_INT);
	}
	public String getCreatedUser() {
		return createdUser;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	public String getModifiedUser() {
		return modifiedUser;
	}
	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getCorrectionId() {
		return correctionId;
	}
	public void setCorrectionId(String correctionId) {
		this.correctionId = correctionId;
	}
	public String getAdjustmentExposureId() {
		return adjustmentExposureId;
	}
	public void setAdjustmentExposureId(String adjustmentExposureId) {
		this.adjustmentExposureId = adjustmentExposureId;
	}
	public String getAttributeVal() {
		return attributeVal;
	}
	public void setAttributeVal(String attributeVal) {
		this.attributeVal = attributeVal;
	}

	public String getAttributeValCols() {
		return attributeValCols;
	}
	public void setAttributeValCols(String attributeValCols) {
		this.attributeValCols = attributeValCols;
	}
	
	public String getTransactionEntityPhysical() {
		return transactionEntityPhysical;
	}

	public void setTransactionEntityPhysical(String transactionEntityPhysical) {
		this.transactionEntityPhysical = transactionEntityPhysical;
	}

	public String getBalanceColumnPhysical() {
		return balanceColumnPhysical;
	}

	public void setBalanceColumnPhysical(String balanceColumnPhysical) {
		this.balanceColumnPhysical = balanceColumnPhysical;
	}
	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getTransactionEntity() {
		return transactionEntity;
	}

	public void setTransactionEntity(String transactionEntity) {
		this.transactionEntity = transactionEntity;
	}

	public String getBalanceColumn() {
		return balanceColumn;
	}

	public void setBalanceColumn(String balanceColumn) {
		this.balanceColumn = balanceColumn;
	}

	public String getCorrectionExpsoureId() {
		return correctionExpsoureId;
	}

	public void setCorrectionExpsoureId(String correctionExpsoureId) {
		this.correctionExpsoureId = correctionExpsoureId;
	}

	public String getOriginalAmt() {
		return originalAmt;
	}

	public void setOriginalAmt(String originalAmt) {
		this.originalAmt = originalAmt;
	}

	public String getCorrectionAmt() {
		return correctionAmt;
	}

	public void setCorrectionAmt(String correctionAmt) {
		this.correctionAmt = correctionAmt;
	}

	public String getSubmissionComments() {
		return submissionComments;
	}

	public void setSubmissionComments(String submissionComments) {
		this.submissionComments = submissionComments;
	}
	public String getAuthStatus() {
		return authStatus;
	}
	public void setAuthStatus(String authStatus) {
		this.authStatus = authStatus;
	}
	/*public String getAttributeValDef() {
		return attributeValDef;
	}
	public void setAttributeValDef(String attributeValDef) {
		this.attributeValDef = attributeValDef;
	}
	public String getAttributeValColsDef() {
		return attributeValColsDef;
	}
	public void setAttributeValColsDef(String attributeValColsDef) {
		this.attributeValColsDef = attributeValColsDef;
	}*/
	public ArrayList<String> getCorrectionGLCodeDef() {
		return CorrectionGLCodeDef;
	}
	public void setCorrectionGLCodeDef(ArrayList<String> correctionGLCodeDef) {
		CorrectionGLCodeDef = correctionGLCodeDef;
	}
	public String getAuthStatusDesc() {
		return authStatusDesc;
	}
	public void setAuthStatusDesc(String authStatusDesc) {
		this.authStatusDesc = authStatusDesc;
	}
	
//correctionList rowId transactionEntity balanceColumn attributeVal correctionExpsoureId originalAmt correctionAmt submissionComments
}
