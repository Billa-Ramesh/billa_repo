/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GLUtil.java
* Title         :
* Description   :
* @author       : Pallavi Reddy 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.global;

import java.util.*;
import java.io.*;

import com.iflex.fic.client.*;

import umm.bi.ClsUEntBIDataSet;
import umm.bi.ClsUEntHierarchy;

import com.iflex.fic.global.*;

import com.ofs.erm.gl.lookup.tableLookup;

public class GLUtil {
	
	
	/**public static ArrayList getAllModelTables(String sInfodom)
	{
		List tablesList = new ArrayList();
		
		
		tableLookup tablookup = null;
		String tab_names=new String();
		String errormsgmeta=new String();
		Vector  Tablenamesfrommetadata = new Vector();
		Tablenamesfrommetadata=returnentities(sInfodom);
		com.iflex.fic.global.Cargo mycargometa = new com.iflex.fic.global.Cargo();
	        mycargometa = com.iflex.fic.client.BusinessMetaData.retrieveAllTechnicalMetadata(sInfodom);

	    try {
	        String temptableStr = null;
	        String tabnamefromentobj = null;
	        Vector payloadVector = (Vector) mycargometa.getPayLoadObject();
	        Vector clsuentVector = null;
	        Vector logicaltables = new Vector();
	        java.util.HashMap map = new java.util.HashMap();

	       for (int i = 0; i < payloadVector.size(); i++) {
	            clsuentVector = ((umm.global.ClsUEntEntityGroup) payloadVector.elementAt(i)).getEntity();


	           for (int fictablecount = 0; fictablecount < Tablenamesfrommetadata.size(); fictablecount++) {
	                temptableStr = (String) Tablenamesfrommetadata.elementAt(fictablecount);
	                for (int j = 0; j < 20; j++) {
	                    tabnamefromentobj = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getCode();
	                    String desc = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getShortDescription();
						//tab_names=tab_names+","+desc;
	                    //map.put(desc,tabnamefromentobj);
	                    //logicaltables.addElement(desc);tabnamefromentobj.
	              
	                   // tablookup = new tableLookup();
	                  //  tablookup.setLogicaltable(desc);
	                 //   tablookup.setPhysicaltable(tabnamefromentobj);
	                    tablesList.add(tabnamefromentobj+"-"+desc);
	                }
	            }
	        }

	       
	    } catch (Exception exp) {
	        System.out.println(exp.getMessage());
	        errormsgmeta = "Error in retriving Logical Column Names from meta data layer";
	        //return null;
	    }

	    return (ArrayList)tablesList;
		
		
	}**/
	public static String getAllModelTables(String sInfodom)
	{
		String rtnStr="-";
		
		
		tableLookup tablookup = null;
		String tab_names=new String();
		String errormsgmeta=new String();
		Vector  Tablenamesfrommetadata = new Vector();
	//	Tablenamesfrommetadata=returnentities(sInfodom);
		com.iflex.fic.global.Cargo mycargometa = new com.iflex.fic.global.Cargo();
	        mycargometa = com.iflex.fic.client.BusinessMetaData.retrieveAllTechnicalMetadata(sInfodom);

	    try {
	        String temptableStr = null;
	        String tabnamefromentobj = null;
	        Vector payloadVector = (Vector) mycargometa.getPayLoadObject();
	        Vector clsuentVector = null;
	        Vector logicaltables = new Vector();
	        java.util.HashMap map = new java.util.HashMap();

	      /** for (int i = 0; i < payloadVector.size(); i++) {
	            clsuentVector = ((umm.global.ClsUEntEntityGroup) payloadVector.elementAt(i)).getEntity();


	           for (int fictablecount = 0; fictablecount < Tablenamesfrommetadata.size(); fictablecount++) {
	                temptableStr = (String) Tablenamesfrommetadata.elementAt(fictablecount);
	                for (int j = 0; j < 20; j++) {
	                    tabnamefromentobj = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getCode();
	                    String desc = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getShortDescription();
						
	                    
	                        if(j==0)
	                    	    rtnStr =tabnamefromentobj+"-"+desc;
	                    	else
	                    		rtnStr = rtnStr+","+tabnamefromentobj+"-"+desc;
	                    		//tab_names=tab_names+","+desc;
	                    //map.put(desc,tabnamefromentobj);
	                    //logicaltables.addElement(desc);tabnamefromentobj.
	              
	                   // tablookup = new tableLookup();
	                  //  tablookup.setLogicaltable(desc);
	                 //   tablookup.setPhysicaltable(tabnamefromentobj);
	                  //  tablesList.add(tabnamefromentobj+"-"+desc);
	                }
	            }
	        }   **/
	        for(int i = 0;i<payloadVector.size();i++) {
                clsuentVector = ((umm.global.ClsUEntEntityGroup)payloadVector.elementAt(i)).getEntity();
                for(int j=0;j<clsuentVector.size();j++) {
                	
                	 tabnamefromentobj = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getCode();
	                    String desc = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getShortDescription();
						
                	  if(j==0)
                  	    rtnStr =tabnamefromentobj+"-"+desc;
                  	else
                  		rtnStr = rtnStr+","+tabnamefromentobj+"-"+desc;   
                }
            }
	       
	    } catch (Exception exp) {
	        System.out.println(exp.getMessage());
	        errormsgmeta = "Error in retriving Logical Column Names from meta data layer";
	        //return null;
	    }

	    return rtnStr;
		
		
	}
	public static  Vector returnentities(String sInfodomName) {
		String errormsgmeta=new String();
		Vector  tablenameVector = new Vector();
      try {
      com.iflex.fic.global.Cargo mycargometa = new com.iflex.fic.global.Cargo();
        mycargometa = com.iflex.fic.client.BusinessMetaData.retrieveAllTechnicalMetadata(sInfodomName);
			Vector clsuentVector = null;
			
           Vector payloadVector = (Vector)mycargometa.getPayLoadObject();			
            for(int i = 0;i<payloadVector.size();i++) {
                clsuentVector = ((umm.global.ClsUEntEntityGroup)payloadVector.elementAt(i)).getEntity();
                for(int j=0;j<clsuentVector.size();j++) {
                    tablenameVector.addElement(((umm.global.ClsUEntEntity)clsuentVector.elementAt(j)).getCode());
                }
            }
            return tablenameVector;
      }catch(Exception excp) {
          System.out.println(excp.getMessage());
          errormsgmeta = "Error in retriving Table Names from meta data layer";
          return tablenameVector;
      }
}
	
	
	public String getLogiColNames(String sInfodomName,String table_name) throws IOException
	{ 
		
	String sToReturn=new String();
	LinkedHashMap logi_phyMap = new LinkedHashMap(); 
	String auto_Pcode=new String();
		com.iflex.fic.global.Cargo mycargometa = new com.iflex.fic.global.Cargo();
	  mycargometa = com.iflex.fic.client.BusinessMetaData.retrieveAllTechnicalMetadata(sInfodomName);
	            Vector tablenameVector;
	            Vector notnull_cols = new Vector();
	            Vector Tablenamesfrommetadata = new Vector();
	            Tablenamesfrommetadata.addElement(table_name);
	             try {
	            String temptableStr = null;
	            String tabnamefromentobj = null;
	            Vector payloadVector = (Vector) mycargometa.getPayLoadObject();
	            Vector clsuentVector = null;
	            Vector attributegroup = null;
	           
	            boolean isnullable;
	            java.util.HashMap map = new java.util.HashMap();

	            for (int i = 0; i < payloadVector.size(); i++) {
	                clsuentVector = ((umm.global.ClsUEntEntityGroup) payloadVector.elementAt(i)).getEntity();

	                for (int fictablecount = 0; fictablecount < Tablenamesfrommetadata.size(); fictablecount++) {
	                    temptableStr = (String) Tablenamesfrommetadata.elementAt(fictablecount);
	                    for (int j = 0; j < clsuentVector.size(); j++) {
	                        tabnamefromentobj = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getCode();
	                        String desc = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getShortDescription();
							sToReturn=desc;
	                                                    if (temptableStr.equalsIgnoreCase(tabnamefromentobj)) {
	                                        attributegroup = ((umm.global.ClsUEntEntity) clsuentVector.elementAt(j)).getAttribute();
	                                      
	                                        for (int k = 0; k < attributegroup.size(); k++) {
	    
	    
	                                    
	    String colname = ((umm.global.ClsUEntAttribute) attributegroup.elementAt(k)).getCode().toString().toUpperCase();
		
		String datatype = ((umm.global.ClsUEntAttribute) attributegroup.elementAt(k)).getAttributeDataType().toString().toUpperCase();
		
	     
	     if(colname.indexOf('.')!=-1)
	     {
	                     colname = colname.substring(colname.indexOf(".")+1);
	     }
	    sToReturn=sToReturn+","+colname;
	    sToReturn=sToReturn+"@"+datatype;
	    logi_phyMap.put(colname.toUpperCase(),((umm.global.ClsUEntAttribute) attributegroup.elementAt(k)).getShortDescription());
	     
	     
	        
	        if(!((umm.global.ClsUEntAttribute)attributegroup.elementAt(k)).getIsMissingAllowed())
	        { 
				notnull_cols.addElement(colname.toUpperCase());                    
	        }
	                                                        

	        if(auto_Pcode.equalsIgnoreCase("0"))
	        {
	                        
	                        
	                        auto_Pcode =((umm.global.ClsUEntAttribute) attributegroup.elementAt(k)).getShortDescription()+"  ("+colname+") ";
	                      
	        }
	        else 
	        {
	                                                           
	                        auto_Pcode = auto_Pcode+","+((umm.global.ClsUEntAttribute) attributegroup.elementAt(k)).getShortDescription()+"  ("+colname+") ";
	          }                        

	   }

	                            break;
	                        }
	                    }
	                }
	            }
	          }catch(Exception excp) {
	              System.out.println(excp.getMessage());
	              auto_Pcode = "Error in retriving Table Names from meta data layer";
	             // return tablenameVector;
	          }
	                     auto_Pcode=auto_Pcode.trim();
					
					    // out.println("<br>"+"auto_Pcode "+auto_Pcode.length()+"<br>");
						//String[] auto_Pcodearr=auto_Pcode.split(",");
						//int i;

						   //for(i=0;i<10;i++)

							 	return sToReturn;
		}
	
	
	public static LinkedHashMap getDataSets(String infodom,String userID){
	    StringBuffer datasets=new StringBuffer();
          LinkedHashMap dsMap = new LinkedHashMap();
	    Cargo retCargo = BusinessMetaData.getBrowserSummary(com.iflex.fic.global.GlobalParameters.BMD_SERVICE_TYPE_DATASET,infodom,userID);
	 //   BusinessMetaData.getbro
	    if(retCargo==null||retCargo.getErrorFlag())
	    {
	        System.out.println("Error while retrieving the datasets : "+retCargo.getPayLoadObject());
	      //  datasets.append(MessageFramework.getMessage("MODEL.FE.ERR_RET_DS"));
	    }
	    else
	    {
	        Vector paramVect = (Vector) retCargo.getPayLoadObject();

	        if(paramVect!=null)
	        {
	            String code,desc;
	            ClsUEntBIDataSet dataset;
	            int noOfParams = paramVect.size();

	           
	            for(int j=0;j<noOfParams;j++)
	            {
	                dataset = (ClsUEntBIDataSet) paramVect.elementAt(j);
	                code=dataset.getCode();
	                desc=dataset.getShortDescription();
	                dsMap.put(code, desc);
	                //System.out.println("Code:"+code+" Desc:"+desc);
	             
	                
	            }
	          
	        }
	    }
	    return dsMap;
	}

	public static String getHierarchyDesc(String sel_infodom, String userid,
			String hiercode) {

		LinkedHashMap<String, String> hierMap = new LinkedHashMap<String, String>();
		String hierdesc= "";
		String nodeId = "";

		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(
				sel_infodom, userid, hiercode,
				GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY);

		if (cr != null && !cr.getErrorFlag()) {
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr
					.getPayLoadObject();
			if (hierarchy != null) {

				
					hierdesc = hierarchy.getShortDescription();

				

			}
		}
		return hierdesc;
	}
}
