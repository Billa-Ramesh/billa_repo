/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GLCommon.java
* Title         :
* Description   :
* @author       : Sandeep 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.global;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

import com.ofs.erm.gl.action.CorrectionEditAction;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.model.GlobalParamAddBean;
import com.ofs.erm.gl.model.LegalEntityBean;

import org.apache.log4j.Priority;

import umm.bi.ClsUEntHierarchy;
import umm.bi.ClsUEntHierarchyNode;
import umm.global.ClsUEntAttribute;
import umm.global.ClsUEntEntity;
import umm.global.ClsUEntEntityGroup;

import com.iflex.fic.client.BusinessMetaData;
import com.iflex.fic.client.SecureBusinessMetaData;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.GlobalParameters;

public class GLCommon {

	private static String sInfodomName;
	private static Cargo mycargometa;
	
	public static Cargo getMycargometa() {
		return mycargometa;
	}

	public static void setMycargometa(Cargo mycargometa) {
		GLCommon.mycargometa = mycargometa;
		GL35Logger.logThis("CARGO SET for mycargometa", Priority.INFO_INT);
	}

	public static String getsInfodomName() {
		return sInfodomName;
	}

	public static void setsInfodomName(String sInfodomName) {
		String langCode = CorrectionEditAction.getSession().get("lclPostFix").toString();
		GL35Logger.logThis("sInfodomName : "+sInfodomName+ "& GLCommon.sInfodomName :"+GLCommon.sInfodomName+" & Locale : "+langCode,Priority.INFO_INT);
		if("".equals(GLCommon.sInfodomName) || GLCommon.sInfodomName==null){
			setMycargometa(BusinessMetaData.retrieveAllTechnicalMetadata(sInfodomName,new Locale(langCode)));
		}else{
			if(!GLCommon.sInfodomName.equalsIgnoreCase(sInfodomName)){
				setMycargometa(BusinessMetaData.retrieveAllTechnicalMetadata(sInfodomName,new Locale(langCode)));
			}
		}
		GLCommon.sInfodomName = sInfodomName;
	}

	
	/**
	 * This function returns the logical table-column names provided the physical table-column names
	 * 
	 * @param infodom 
	 * @param sTabName : Physical Table Name as String
	 * @param sColName : Physical Column Name as String 
	 * @return String[0] : Logical Table Name, String[1] : Logical Column Name
	 */
	public static  String[] getLogicalTabColName(String sInfodomName, String sTabName, String sColName) {
		GL35Logger.logThis(sInfodomName+" & "+sTabName+" & "+sColName, Priority.INFO_INT);
		setsInfodomName(sInfodomName);
		
		String errormsgmeta="";
		Vector<ClsUEntAttribute> clsUEntAttribute = new Vector<ClsUEntAttribute>();
		String sClsUEntAtt = "";
		String sClsUEntEntity = "";
		String[] retArray = new String[2];
		try {
			Cargo mycargometa = new Cargo();
			mycargometa=getMycargometa();
			Vector clsuentVector = null;
			Vector payloadVector = (Vector)mycargometa.getPayLoadObject();			
	        for(int i = 0;i<payloadVector.size();i++) {
	            clsuentVector = ((ClsUEntEntityGroup)payloadVector.elementAt(i)).getEntity();
	            for(int j=0;j<clsuentVector.size();j++) {
	            	if(((ClsUEntEntity)clsuentVector.elementAt(j)).getCode().equalsIgnoreCase(sTabName)){
	            		clsUEntAttribute = ((ClsUEntEntity)clsuentVector.elementAt(j)).getAttribute();
	            		sClsUEntEntity = ((ClsUEntEntity)clsuentVector.elementAt(j)).getShortDescription();
	            		break;
	            	}
	            }
	        }
	        for(ClsUEntAttribute cls :clsUEntAttribute){
	        	//GL35Logger.logThis(cls.getShortDescription(), Priority.INFO_INT);
	        	if(cls.getCode().equalsIgnoreCase(sTabName+"."+sColName)){
	        		sClsUEntAtt = cls.getShortDescription();
	        		break;
	        	}
	        }
	        retArray[0]=sClsUEntEntity;
	        retArray[1]=sClsUEntAtt;
	        return retArray;
		}catch(Exception excp) {
			excp.printStackTrace();
			errormsgmeta = "Error in retriving Table Name/Column Name from meta data layer";
			GL35Logger.logThis("EXCEPTION OCCURED: "+excp.getLocalizedMessage()+" : "+errormsgmeta, Priority.ERROR_INT);
			return retArray;
		}
	}
	
	public static LinkedHashMap getHierNodes(String sel_infodom,String userid ,String hiercode)
	{
		GL35Logger.logThis("Global Param Dao: Get Hierarchy Nodes - "+hiercode, Priority.DEBUG_INT);
		LinkedHashMap hierMap = new LinkedHashMap();
		List<GlobalParamAddBean> legalEntityArray = new ArrayList<GlobalParamAddBean>();
		String nodecode ="";
		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(sel_infodom,userid, hiercode, GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY);
		if (cr != null && !cr.getErrorFlag())
		{
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr.getPayLoadObject();
			if(hierarchy!=null)
			{
				Vector vecHierarchyNodes = null;
				vecHierarchyNodes = hierarchy.getHierarchyNode();
				if(vecHierarchyNodes.size()>0)
				{
					ClsUEntHierarchyNode rootNode = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(0);
				}
				ClsUEntHierarchyNode node;
				int sizeOfHierarchyNodes = vecHierarchyNodes.size();
				for (int i = 1; i < sizeOfHierarchyNodes; i++)
				{
					node = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(i);
					nodecode = node.getUniqueCode();
					//GL35Logger.logThis("getHierNodes...."+nodecode+"node.getShortDescription().."+node.getShortDescription(), Priority.DEBUG_INT);
					GlobalParamAddBean tempbean = new GlobalParamAddBean();
					tempbean.setLegEntityCode(nodecode);
					tempbean.setLegEntityName(node.getShortDescription());
					legalEntityArray.add(tempbean);
					hierMap.put(nodecode,node.getShortDescription());
				}

			}
		}
		return hierMap;
	}
	
	
	public static LinkedHashMap getHierNodes(String sel_infodom,String userid ,String hiercode,String locale)
	{
		GL35Logger.logThis("Global Param Dao: Get Hierarchy Nodes - "+hiercode, Priority.DEBUG_INT);
		LinkedHashMap hierMap = new LinkedHashMap();
		List<GlobalParamAddBean> legalEntityArray = new ArrayList<GlobalParamAddBean>();
		String nodecode ="";
		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(sel_infodom,userid, hiercode, GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,new Locale(locale));
		if (cr != null && !cr.getErrorFlag())
		{
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr.getPayLoadObject();
			if(hierarchy!=null)
			{
				Vector vecHierarchyNodes = null;
				vecHierarchyNodes = hierarchy.getHierarchyNode();
				if(vecHierarchyNodes.size()>0)
				{
					ClsUEntHierarchyNode rootNode = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(0);
				}
				ClsUEntHierarchyNode node;
				int sizeOfHierarchyNodes = vecHierarchyNodes.size();
				for (int i = 1; i < sizeOfHierarchyNodes; i++)
				{
					node = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(i);
					nodecode = node.getUniqueCode();
					GL35Logger.logThis("getHierNodes...."+nodecode+"node.getShortDescription().."+node.getShortDescription(), Priority.DEBUG_INT);
					GlobalParamAddBean tempbean = new GlobalParamAddBean();
					tempbean.setLegEntityCode(nodecode);
					tempbean.setLegEntityName(node.getShortDescription());
					legalEntityArray.add(tempbean);
					hierMap.put(nodecode,node.getShortDescription());
				}

			}
		}
		return hierMap;
	}
	
	public static List<LegalEntityBean> getHierNodesList(String sel_infodom,String userid ,String hiercode)
	{
		GL35Logger.logThis("Global Param DAO: get Hier Nodes"+hiercode+":"+sel_infodom+":"+userid, Priority.DEBUG_INT);
		LinkedHashMap hierMap = new LinkedHashMap();
		List<LegalEntityBean> legalEntityArray = new ArrayList<LegalEntityBean>();
		String nodecode ="";
		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(sel_infodom,userid, hiercode, GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY);
		if (cr != null && !cr.getErrorFlag())
		{
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr.getPayLoadObject();
			if(hierarchy!=null)
			{
				Vector vecHierarchyNodes = null;
				vecHierarchyNodes = hierarchy.getHierarchyNode();
				if(vecHierarchyNodes.size()>0)
				{
					ClsUEntHierarchyNode rootNode = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(0);
				}
				ClsUEntHierarchyNode node;
				int sizeOfHierarchyNodes = vecHierarchyNodes.size();
				for (int i = 1; i < sizeOfHierarchyNodes; i++)
				{
					node = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(i);
					nodecode = node.getCode();
					GL35Logger.logThis("getHierNodes...."+nodecode+"node.getShortDescription().."+node.getShortDescription(), Priority.DEBUG_INT);
					LegalEntityBean tempbean = new LegalEntityBean();
					tempbean.setLeCode(nodecode);
					tempbean.setLeName(node.getShortDescription());
					legalEntityArray.add(tempbean);
					hierMap.put(nodecode,node.getShortDescription());
				}

			}
		}
		return legalEntityArray;
	}
}
