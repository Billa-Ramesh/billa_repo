/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.

--------------------------------------------------------------------------------------------------------
File Name               :  GL35Logger.java
Created By            	:  Sandeep			
Created On          	:  April 9th, 2012
Application Name        :  General Ledger v3.5
Modification History	: 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/
package com.ofs.erm.gl.global;

import org.apache.log4j.Priority;
/*import com.ofs.reveleus.common.FSAPPLogger;*/
  import com.ofs.fsapps.commonapps.core.utill.FSAPPLogger;
/**
 * This class logs all the messages to GL35.log using FSAPPLogger.
 */
public class GL35Logger {
	/**
	 * This method will log all the Messages.
	 * 
	 * @param msg
	 */
	public static void logThis(String msg) {
		StackTraceElement stackEle = new Throwable().fillInStackTrace().getStackTrace()[1];
		FSAPPLogger.logMessage("GL35", "["+stackEle.getClassName().substring(stackEle.getClassName().lastIndexOf(".")+1)+
				"]["+stackEle.getMethodName()+"]"+msg, Priority.toPriority(Priority.DEBUG_INT));
	}

	/**
	 * 
	 * @param msg
	 * @param level
	 */
	public static void logThis(String msg, int level) {
		StackTraceElement stackEle = new Throwable().fillInStackTrace().getStackTrace()[1];
		FSAPPLogger.logMessage("GL35", "["+stackEle.getClassName().substring(stackEle.getClassName().lastIndexOf(".")+1)+
				"]["+stackEle.getMethodName()+"]"+msg, Priority.toPriority(level));
	}

	/**
	 * 
	 * @param t
	 */
	public static void logError(Throwable t) {
		FSAPPLogger.logError("GL35",Priority.FATAL, t.getMessage(), new Exception(t));
	}

}
