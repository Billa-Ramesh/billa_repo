/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.

--------------------------------------------------------------------------------------------------------
File Name             : GlobalUtil.java
Created By            : Rahul Manoharan 
Created On            : April 20th, 2012
Application Name      : General Ledger v3.5
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/

package com.ofs.erm.gl.global;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Priority;

import umm.bi.ClsUEntHierarchy;
import umm.bi.ClsUEntHierarchyNode;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.client.SecureBusinessMetaData;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.iflex.fic.global.GlobalParameters;
import com.opensymphony.xwork2.ActionContext;

public class GlobalUtil {

	public static Map<String, String> getLookUpData(String lookUpCode,
			String langCode, String infoDom) {
		
		GL35Logger.logThis("Entering getLookupData...",Priority.DEBUG_INT);
		String sqlQuery = "";
		Cargo cargo1;
		DACRecordSet resultSet;
		Map<String, String> lookupLHM = new LinkedHashMap<String, String>();
		try{
			sqlQuery += "SELECT A.V_CATEGORY_ID,A.V_CATEGORY_DESC FROM FSI_GL_LOOKUP_MASTER A INNER JOIN FSI_GL_LOOKUP_B B ";
			sqlQuery += " ON B.V_CATEGORY_ID = A.V_CATEGORY_ID ";
			sqlQuery += " INNER JOIN FSI_GL_LOOKUP_TL C ";
			sqlQuery += " ON C.V_CATEGORY_ID = A.V_CATEGORY_ID ";
			sqlQuery += " WHERE C.V_LOOKUP_CD = '" + lookUpCode;
			sqlQuery += "' AND A.V_LOOKUP_CD = '" + lookUpCode;
			sqlQuery += "' AND C.V_LANG_CODE = '" + langCode;
			sqlQuery += "' ORDER BY B.N_SORT_ORDER";
	
			cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery.toString(),
					false);
			resultSet = (DACRecordSet) cargo1.getPayLoadObject();
	
			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				lookupLHM.put(resultSet.fetchElement(1).toString(), resultSet
						.fetchElement(2).toString());
				resultSet.moveNext();
			}
		}
		catch(Exception e){
			e.printStackTrace();
			GL35Logger.logThis(e.getMessage(),Priority.DEBUG_INT);
		}
		
		return lookupLHM;

	}
	
	public static Map<String, String> getLIData(String langCode, String infoDom) {
		
		GL35Logger.logThis("Entering getLIData...",Priority.DEBUG_INT);
		String sqlQuery = "";
		Cargo cargo1;
		DACRecordSet resultSet;
		Map<String, String> ledgerIndicatorHM = new LinkedHashMap<String, String>();
		try{
			sqlQuery += "SELECT C.N_LEDGER_INDICATOR, M.DESCRIPTION "
				+"FROM FSI_GL_LEDGER_INDICATOR_CD C, FSI_GL_LEDGER_INDICATOR_MLS M"
				+" WHERE C.N_LEDGER_INDICATOR = M.N_LEDGER_INDICATOR"
				+" AND M.MLS_CD='"+langCode+"'";
	
			cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery.toString(),false);
			resultSet = (DACRecordSet) cargo1.getPayLoadObject();
			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				ledgerIndicatorHM.put(resultSet.fetchElement("N_LEDGER_INDICATOR").toString(), resultSet
						.fetchElement("DESCRIPTION").toString());
				resultSet.moveNext();
				GL35Logger.logThis("ledger value" + ledgerIndicatorHM.toString());
			}
		}
		catch(Exception e){
			e.printStackTrace();
			GL35Logger.logThis(e.getMessage(),Priority.DEBUG_INT);
		}
		
		return ledgerIndicatorHM;

	}

	/*
	 * Method Returns Column Descriptions Map <ColName,ColDesc> pre-fixed with a
	 * "*" for all non-null able fields in the DB which are not mandatory
	 * dimensions, Exposure Id Cols or Mis Date cols.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static LinkedHashMap getAllColMap(String tabName, String infoDom) {

		GL35Logger.logThis("Entering getAllColMap...", Priority.DEBUG_INT);

		DACRecordSet prObjDACRS;
		ArrayList<String> setup_Colsvec = new ArrayList<String>();
		try {

			// String sql2 =
			// "SELECT upper(V_EXPOSURE_ID_COL_NAME),upper(V_MIS_DATE_COL_NAME) FROM SETUP_PRODUCT_PROCESSORS WHERE UPPER(V_TABLE_NAME) =UPPER('"
			String sql2 = "SELECT UPPER(V_EXPOSURE_ID_COL_NAME) FROM   SETUP_PRODUCT_PROCESSORS WHERE   UPPER(V_TABLE_NAME) = UPPER('"
					+ tabName
					+ "') UNION SELECT   UPPER(V_MIS_DATE_COL_NAME) FROM   SETUP_PRODUCT_PROCESSORS WHERE   UPPER(V_TABLE_NAME) = UPPER('"
					+ tabName
					+ "') UNION SELECT   SRDCM.V_DIMENSION_COL_NAME FROM   SETUP_GL_RECON_DIMENSIONS SGRD INNER JOIN SETUP_RECON_DIM_COL_MAP SRDCM ON   SGRD.V_DIMENSION_HCY_CODE = SRDCM.V_DIMENSION_HCY_CODE WHERE   SGRD.F_RECON_OR_MANDATORY  = 'M' AND SRDCM.V_PP_OR_GL = 'PP' AND SRDCM.V_PP_GL_TABLE_NAME = UPPER('"
					+ tabName + "')";

			GL35Logger.logThis("Query is ..." + sql2, Priority.DEBUG_INT);

			Cargo prObjCargo1 = SMSServices.executeQuery(infoDom, sql2, false);
			prObjDACRS = (DACRecordSet) prObjCargo1.getPayLoadObject();
			while (!prObjDACRS.EOF() && prObjDACRS.getRowCount() > 0) {

				if (prObjDACRS.fetchElement(1) != null
						&& prObjDACRS.fetchElement(1) != "")
					setup_Colsvec.add(prObjDACRS.fetchElement(1));
				if (prObjDACRS.fetchElement(2) != null
						&& prObjDACRS.fetchElement(2) != "")
					setup_Colsvec.add(prObjDACRS.fetchElement(2));
				prObjDACRS.moveNext();
			}

		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
		}

		LinkedHashMap logi_phyMap = new LinkedHashMap();
		LinkedHashMap datatype_phyMap = new LinkedHashMap();

		com.iflex.fic.global.Cargo mycargometa = new com.iflex.fic.global.Cargo();
		mycargometa = com.iflex.fic.client.BusinessMetaData
				.retrieveAllTechnicalMetadata(infoDom);

		Vector Tablenamesfrommetadata = new Vector();
		Tablenamesfrommetadata.addElement(tabName);

		try {
			String temptableStr = null;
			String tabnamefromentobj = null;
			Vector payloadVector = (Vector) mycargometa.getPayLoadObject();
			Vector clsuentVector = null;
			Vector attributegroup = null;

			for (int i = 0; i < payloadVector.size(); i++) {
				clsuentVector = ((umm.global.ClsUEntEntityGroup) payloadVector
						.elementAt(i)).getEntity();

				for (int fictablecount = 0; fictablecount < Tablenamesfrommetadata
						.size(); fictablecount++) {
					temptableStr = (String) Tablenamesfrommetadata
							.elementAt(fictablecount);
					for (int j = 0; j < clsuentVector.size(); j++) {
						tabnamefromentobj = ((umm.global.ClsUEntEntity) clsuentVector
								.elementAt(j)).getCode();
						String desc = ((umm.global.ClsUEntEntity) clsuentVector
								.elementAt(j)).getShortDescription();

						if (temptableStr.equalsIgnoreCase(tabnamefromentobj)) {
							attributegroup = ((umm.global.ClsUEntEntity) clsuentVector
									.elementAt(j)).getAttribute();
							for (int k = 0; k < attributegroup.size(); k++) {

								String colname = ((umm.global.ClsUEntAttribute) attributegroup
										.elementAt(k)).getCode().toString()
										.toUpperCase();

								if (colname.indexOf(".") != -1) {
									colname = colname.substring(colname
											.indexOf(".") + 1);
								}
								if (((umm.global.ClsUEntAttribute) attributegroup
										.elementAt(k)).getIsMissingAllowed()) {
									logi_phyMap
											.put(colname.toString(),
													(((umm.global.ClsUEntAttribute) attributegroup
															.elementAt(k))
															.getShortDescription())
															.toUpperCase()
															.toString());
									datatype_phyMap
											.put(((umm.global.ClsUEntAttribute) attributegroup
													.elementAt(k))
													.getShortDescription(),
													((umm.global.ClsUEntAttribute) attributegroup
															.elementAt(k))
															.getAttributeDataType());
								}
								if (!((umm.global.ClsUEntAttribute) attributegroup
										.elementAt(k)).getIsMissingAllowed()) {
									logi_phyMap
											.put(colname.toString(),
													"*" + (((umm.global.ClsUEntAttribute) attributegroup
															.elementAt(k))
															.getShortDescription())
															.toUpperCase()
															.toString());
									datatype_phyMap
											.put(((umm.global.ClsUEntAttribute) attributegroup
													.elementAt(k))
													.getShortDescription(),
													((umm.global.ClsUEntAttribute) attributegroup
															.elementAt(k))
															.getAttributeDataType());
								}
							}

							break;
						}
					}
				}
			}
		} catch (Exception excp) {
			GL35Logger.logThis(excp.getMessage(), Priority.ERROR_INT);
		}
		return logi_phyMap;
	}

	/*
	 * Method Returns Column Descriptions pre-fixed with a "*" for all non-null
	 * able fields in the DB which are not mandatory dimensions, Exposure Id
	 * Cols or Mis Date cols.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static String getLogicalColName(String phyColName, String tabName,
			String infoDom) {

		GL35Logger.logThis("Entering getLogicalColName...", Priority.DEBUG_INT);

		LinkedHashMap logi_phyMap = new LinkedHashMap();
		logi_phyMap = getAllColMap(tabName, infoDom);
		return logi_phyMap.get(phyColName).toString();
	}

	/*
	 * Returns the Parameter value from Reveleus Parameter Master
	 * 
	 * @return String
	 */
	public static String getParamValue(String paramCode, String infoDom) {
		
		GL35Logger.logThis("Entering getParamValue...",Priority.DEBUG_INT);
		String sqlQString = "SELECT V_PARAM_VALUE FROM REVELEUS_PARAMETER_MASTER WHERE V_PARAM_CODE = '"
				+ paramCode + "'";
		String paramValue = "";
		try {

			Cargo cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
					sqlQString, false);
			DACRecordSet resultSet = (DACRecordSet) cargo1.getPayLoadObject();
			while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
				paramValue = resultSet.fetchElement(1);
				resultSet.moveNext();
			}
		} catch (Exception e) {
			GL35Logger.logThis(e.getMessage(), Priority.ERROR_INT);
			e.printStackTrace();
		}
		return paramValue;
	}

	/*
	 * Get Legal Entity Hierarchy code
	 * 
	 * @return String
	 */
	public static String getLegalHierCode(String infoDom) {
		
		GL35Logger.logThis("Entering getLegalHierCode...",Priority.DEBUG_INT);
		Cargo cargo1;
		DACRecordSet resultSet;
		String retVal = new String();

		String sqlQuery = "SELECT V_DIMENSION_HCY_CODE FROM SETUP_GL_RECON_DIMENSIONS WHERE V_DIMENSION_LOOKUP_CD = 'LEGAL_ENTITY'";
		cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery, false);
		resultSet = (DACRecordSet) cargo1.getPayLoadObject();

		while (!resultSet.EOF() && resultSet.getRowCount() > 0) {
			retVal = resultSet.fetchElement(1);
			resultSet.moveNext();
		}
		return retVal;

	}

	/*
	 * Get the Short Description for every node in the given hierarchy.
	 * 
	 * @return LinkedHashMap
	 */
	public static LinkedHashMap<String,String> getHierNodeDesc(String sel_infodom,
			String userid, String hiercode) {
		
		GL35Logger.logThis("Entering getHierNodeDesc...",Priority.DEBUG_INT);
		LinkedHashMap<String,String> hierMap = new LinkedHashMap<String,String>();

		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(
				sel_infodom, userid, hiercode,
				GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY);
		if (cr != null && !cr.getErrorFlag()) {
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr
					.getPayLoadObject();
			if (hierarchy != null) {
				Vector vecHierarchyNodes = null;
				vecHierarchyNodes = hierarchy.getHierarchyNode();
				if (vecHierarchyNodes.size() > 0) {
					ClsUEntHierarchyNode rootNode = (ClsUEntHierarchyNode) vecHierarchyNodes
							.elementAt(0);
				}
				ClsUEntHierarchyNode node;
				int sizeOfHierarchyNodes = vecHierarchyNodes.size();
				for (int i = 1; i < sizeOfHierarchyNodes; i++) {
					node = (ClsUEntHierarchyNode) vecHierarchyNodes
							.elementAt(i);
					// System.out.println("getHierNodes...."+node.getCode()+"node.getShortDescription().."+node.getShortDescription());
					hierMap.put(node.getCode(), node.getShortDescription());
				}

			}
		}
		return hierMap;
	}
	
	/*
	 * Get the Unique code from REV_BIHIER given the hiercode
	 * 
	 * @return String
	 */
	public static String getHierUniqCodeFromLeafCode(String sLeafCode,String hierCode,String infoDom){
		
		GL35Logger.logThis("Entering getHierUniqCodeFromLeafCode...",Priority.DEBUG_INT);
		
		String sqlQuery = "SELECT UNIQUE_CODE FROM REV_BIHIER WHERE VERSION_NO = 0 AND hier_code = '"+hierCode+"' AND CODE = '"+ sLeafCode +"'";
		DACRecordSet resultSet1;
		Cargo cargo;
		String sUniqCode = "";
		
		cargo = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery.toString(), false);
		resultSet1 = (DACRecordSet) cargo.getPayLoadObject();
		while (!resultSet1.EOF() && resultSet1.getRowCount() > 0){
			sUniqCode = resultSet1.fetchElement(1);
			resultSet1.moveNext();
		}
		GL35Logger.logThis("Returning from getHierUniqCodeFromLeafCode with Unique code..."+sUniqCode,Priority.DEBUG_INT);
		return sUniqCode;
		
	}
	
	/*
	 * Get the Hierarchy Identifier Value given the Hier Node.
	 * 
	 * @return String
	 */
	public static String getHierIdentifiers(String sel_infodom, String userid,
			String hiercode, String hierNode) {
		
		GL35Logger.logThis("Entering getHierIdentifiers...",Priority.DEBUG_INT);
		LinkedHashMap<String, String> hierMap = new LinkedHashMap<String, String>();
		String nodecode = "";
		String nodeId = "";

		String locale = ActionContext.getContext().getSession()
				.get("lclPostFix").toString();

		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(
				sel_infodom, userid, hiercode,
						GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,
						new Locale(locale));

		if (cr != null && !cr.getErrorFlag()) {
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr
					.getPayLoadObject();
			if (hierarchy != null) {
				Vector vecHierarchyNodes = null;
				vecHierarchyNodes = hierarchy.getHierarchyNode();
				if (vecHierarchyNodes.size() > 0) {
					ClsUEntHierarchyNode rootNode = (ClsUEntHierarchyNode) vecHierarchyNodes
							.elementAt(0);
				}
				ClsUEntHierarchyNode node;
				int sizeOfHierarchyNodes = vecHierarchyNodes.size();
				for (int i = 0; i < sizeOfHierarchyNodes; i++) {
					node = (ClsUEntHierarchyNode) vecHierarchyNodes
							.elementAt(i);
					nodecode = node.getCode();

					hierMap.put(nodecode, node.getIdentifierValue());
				}

			}
		}
		return hierMap.get(hierNode).replace("'", "''");
	}

	/*
	 * Get the hierarchy Node Description
	 * 
	 * @return String
	 */
	public static String getHierDescription(String sel_infodom, String userid,
			String hiercode, String hierNode) {

		String locale = ActionContext.getContext().getSession()
				.get("lclPostFix").toString();

		GL35Logger
				.logThis("Entering getHierDescription...", Priority.DEBUG_INT);
		LinkedHashMap<String, String> hierMap = new LinkedHashMap<String, String>();
		String nodecode = "";
		String nodeId = "";

		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(
				sel_infodom, userid, hiercode,
						GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,
						new Locale(locale));

		if (cr != null && !cr.getErrorFlag()) {
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr
					.getPayLoadObject();
			if (hierarchy != null) {

				if (hierNode.equals(""))
					return hierarchy.getShortDescription();

				Vector vecHierarchyNodes = null;
				vecHierarchyNodes = hierarchy.getHierarchyNode();
				if (vecHierarchyNodes.size() > 0) {
					ClsUEntHierarchyNode rootNode = (ClsUEntHierarchyNode) vecHierarchyNodes
							.elementAt(0);
				}
				ClsUEntHierarchyNode node;
				int sizeOfHierarchyNodes = vecHierarchyNodes.size();
				for (int i = 0; i < sizeOfHierarchyNodes; i++) {
					node = (ClsUEntHierarchyNode) vecHierarchyNodes
							.elementAt(i);
					nodecode = node.getUniqueCode(); 

					hierMap.put(nodecode, node.getShortDescription());
				}

			}
		}
		return hierMap.get(hierNode).replace("'", "''");
	}

	/*
	 * Get table on which hierarchy is defined.
	 * 
	 * @return String
	 */
	public static String getHierTable(String sel_infodom, String userid,
			String hiercode) {
		
		GL35Logger.logThis("Entering getHierTable...",Priority.DEBUG_INT);
		LinkedHashMap<String, String> hierMap = new LinkedHashMap<String, String>();
		String hierTable = "";
		String nodeId = "";

		String locale = ActionContext.getContext().getSession()
				.get("lclPostFix").toString();

		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(
				sel_infodom, userid, hiercode,
						GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,
						new Locale(locale));

		if (cr != null && !cr.getErrorFlag()) {
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr
					.getPayLoadObject();
			if (hierarchy != null) {
				hierTable = hierarchy.getEntityCode();				
			}
		}
		return hierTable;
	}
	
	/*
	 * Get Hierarchy Attribute
	 * 
	 * @return String
	 */
	public static String getHierAttributeCode(String sel_infodom,
			String userid, String hiercode) {	
	
		GL35Logger.logThis("Entering getHierAttributeCode...",Priority.DEBUG_INT);
		LinkedHashMap<String, String> hierMap = new LinkedHashMap<String, String>();
		String hierAttrCode = "";
		String nodeId = "";

		String locale = ActionContext.getContext().getSession()
				.get("lclPostFix").toString();

		Cargo cr = SecureBusinessMetaData.getMetaDataObjectFromServer(
				sel_infodom, userid, hiercode,
						GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,
						new Locale(locale));

		if (cr != null && !cr.getErrorFlag()) {
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr
					.getPayLoadObject();
			if (hierarchy != null) {
				hierAttrCode = hierarchy.getAttributeCode();
			}
		}
		return hierAttrCode;
		
		
		//Can use PKG_MATADATA_INFO.GETATTRIBUTECODE('HGL005') also
	}

	/*
	 * Get all Recon and Mandatory dimensions.
	 * 
	 * @return ArrayList
	 */
	public static ArrayList<String> getAllDimensionCodes(String infoDom) {

		StringBuffer sqlQuery1 = new StringBuffer(
				"SELECT A.V_DIMENSION_HCY_CODE,A.V_DIMENSION_DESC ");
		sqlQuery1.append(" FROM SETUP_GL_RECON_DIMENSIONS A");

		DACRecordSet resultSet1;
		ArrayList<String> dimList = new ArrayList<String>();
		Cargo cargo1;

		cargo1 = (Cargo) SMSServices.executeQuery(infoDom,
				sqlQuery1.toString(), false);
		resultSet1 = (DACRecordSet) cargo1.getPayLoadObject();
		while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
			dimList.add(resultSet1.fetchElement(1));
			resultSet1.moveNext();
		}
		return dimList;
	}
}