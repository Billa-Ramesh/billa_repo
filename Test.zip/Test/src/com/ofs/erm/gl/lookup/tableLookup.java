/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : tableLookup.java
* Title         :
* Description   :
* @author       : Pallavi Reddy 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.lookup;
import java.io.Serializable;

public class tableLookup {

	
	private String logicaltable ;
	private String physicaltable ;

	
	public String getLogicaltable() {
		return logicaltable;
	}
	public void setLogicaltable(String logicaltable) {
		this.logicaltable = logicaltable;
	}
	

	public String getPhysicaltable() {
		return physicaltable;
	}
	public void setPhysicaltable(String physicaltable) {
		this.physicaltable = physicaltable;
	}
}
