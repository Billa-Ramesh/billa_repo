/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : AdjustmentAction.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.action;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.dispatcher.Dispatcher;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ofs.erm.gl.dao.AdjustmentDAO;
import com.ofs.erm.gl.model.AdjustmentSearchBean;
import com.ofs.erm.gl.model.AdjustmentSummaryBean;
import com.ofs.erm.gl.model.MapNameBean;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Priority;
import com.ofs.erm.gl.global.GL35Logger;


@SuppressWarnings("serial")
public class AdjustmentAction extends ActionSupport implements
ServletRequestAware, ServletResponseAware {

	private List<AdjustmentSummaryBean> adjustmentList;
	private List<MapNameBean> mapArray;
	private boolean checkBox;
	private String sortCol,sortOrder,searchExecutionId,paginationNumber,currentPage,actionId,searchMapName,searchGLDate,methodName;
	private String authstatus;
	private String infodom;
	private String status;
	private int rowCount;
	protected HttpServletRequest request;
	protected HttpServletResponse response;
	private int noOfPagesLoaded = 2;
	
	public List<AdjustmentSummaryBean> getAdjustmentList() {
		return adjustmentList;
	}
	public void setAdjustmentList(List<AdjustmentSummaryBean> adjustmentList) {
		this.adjustmentList = adjustmentList;
	}
	public List<MapNameBean> getMapArray() {
		return mapArray;
	}
	public void setMapArray(List<MapNameBean> mapArray) {
		this.mapArray = mapArray;
	}
	public boolean isCheckBox() {
		return checkBox;
	}
	public void setCheckBox(boolean checkBox) {
		this.checkBox = checkBox;
	}
	public String getSortCol() {
		return sortCol;
	}
	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSearchExecutionId() {
		return searchExecutionId;
	}
	public void setSearchExecutionId(String searchExecutionId) {
		this.searchExecutionId = searchExecutionId;
	}
	public String getPaginationNumber() {
		return paginationNumber;
	}
	public void setPaginationNumber(String paginationNumber) {
		this.paginationNumber = paginationNumber;
	}
	public String getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	public String getActionId() {
		return actionId;
	}
	public void setActionId(String actionId) {
		this.actionId = actionId;
	}
	public String getSearchMapName() {
		return searchMapName;
	}
	public void setSearchMapName(String searchMapName) {
		this.searchMapName = searchMapName;
	}
	public String getSearchGLDate() {
		return searchGLDate;
	}
	public void setSearchGLDate(String searchGLDate) {
		this.searchGLDate = searchGLDate;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public String getInfodom() {
		return infodom;
	}
	public void setInfodom(String infodom) {
		this.infodom = infodom;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getRowCount() {
		return this.rowCount;
	}
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	public HttpServletResponse getResponse() {
		return response;
	}
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		this.setRequest(arg0);
	}
	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		this.setResponse(arg0);
	}
	
	public String adjustmentSummaryAction() {
		ActionContext context = ActionContext.getContext();
		GL35Logger.logThis("The action name : "+context.getName(),Priority.INFO_INT);
		int paginationNumber = 0;
		int currentPage = 0;
		String authstatus = getAuthstatus();
		String sortCol = getSortCol();
		String sortOrder = getSortOrder();
		String searchExecutionId = getSearchExecutionId();
		String searchMapId = getSearchMapName();
		String searchGlDate = getSearchGLDate();
		String methodName = getMethodName();
		String infodom = getInfodom();
		int startIndex = 0;
		int endIndex = 0;
		AdjustmentSearchBean searchBean = new AdjustmentSearchBean();
		searchBean.setRecordCountNeeded(false);
		adjustmentList = new ArrayList<AdjustmentSummaryBean>();
		
		if(!(getPaginationNumber() == null))
			paginationNumber = Integer.parseInt(getPaginationNumber());
		if(!(getCurrentPage() == null))
			currentPage = Integer.parseInt(getCurrentPage());
		if(sortCol == null)
			sortCol = "";
		if(sortOrder == null)
			sortOrder = "";
		if(searchExecutionId == null)
			searchExecutionId = "";
		if(searchMapId == null)
			searchMapId = "";
		if(searchGlDate == null)
			searchGlDate = "";
		if(authstatus == null)
			authstatus = "";

		if(methodName == null) {
			startIndex = 1;
			endIndex = 2*15;
			searchExecutionId = "";
			searchGlDate = "";
			searchMapId = "";
			sortCol = "";
			sortOrder = "";
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - reset - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getNextPage")) {
			startIndex = (paginationNumber * currentPage) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - getNextPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getPrevPage")) {
			startIndex = (paginationNumber * (currentPage-3)) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - getPrevPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getFirstPage")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - getFirstPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getLastPage")) {
			if((currentPage % 2) == 0) { // 2 here in this if loop is no of pages to load
				startIndex = (paginationNumber * (currentPage - 2)) + 1; 
				endIndex = startIndex + (2*paginationNumber) - 1;
			}
			else {
				startIndex = (paginationNumber * (currentPage - 1)) + 1;
				endIndex = startIndex + ((2-1)*paginationNumber) - 1;
			}
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - getLastPage - "+startIndex+endIndex+paginationNumber+currentPage+sortCol+sortOrder, Priority.DEBUG_INT);
		}
		else if(methodName.equals("search")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - search - "+startIndex+endIndex+paginationNumber+currentPage+searchGlDate+searchExecutionId+searchMapId, Priority.DEBUG_INT);
		}
		else if(methodName.equals("sort")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - sort - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("reset")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			searchExecutionId = "";
			searchGlDate = "";
			searchMapId = "";
			sortCol = "";
			sortOrder = "";
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - reset - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getMapArray")) {
			setMapArray(AdjustmentDAO.getMapArray(infodom));
			GL35Logger.logThis("Map Array Loaded! LENGTH="+getMapArray().size(), Priority.DEBUG_INT);
			return SUCCESS;
		}
		else if(methodName.equals("changePagination")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - change Pagination - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
			
		searchBean.setExecutionId(searchExecutionId);
		searchBean.setGlDate(searchGlDate);
		searchBean.setMapId(searchMapId);
		searchBean.setSortCol(sortCol);
		searchBean.setSortOrder(sortOrder);
		searchBean.setStartIndex(startIndex);
		searchBean.setEndIndex(endIndex);
		
		adjustmentList = AdjustmentDAO.getAdjData(searchBean,infodom,authstatus);
		
		if((methodName == null) ||(methodName.equals("search")) || (methodName.equals("reset"))) {
			if(adjustmentList.size() == 0) {
				GL35Logger.logThis("Zero length Record Set", Priority.DEBUG_INT);
				rowCount = 0;
			}
			else {
				rowCount = adjustmentList.get(0).getRecordCount();
			}
		}
		
		if(!(adjustmentList.size() == 0)) {
			if(adjustmentList.get(0).getExecutionIdentifier() == null) {
				GL35Logger.logThis("Infodom Error..", Priority.DEBUG_INT);
				setStatus("false");
				GL35Logger.logThis("Status = " + getStatus(), Priority.DEBUG_INT);
				return SUCCESS;
			}
		}
		
		return SUCCESS;
	}
	public String getAuthstatus() {
		return authstatus;
	}
	public void setAuthstatus(String authstatus) {
		this.authstatus = authstatus;
	}
	
}
