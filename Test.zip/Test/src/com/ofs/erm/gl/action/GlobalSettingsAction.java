/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GlobalSettingsAction.java
* Title         :
* Description   :
* @author       : Pallavi Reddy 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.action;



import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Vector;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.LinkedHashMap;
import java.io.*;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Priority;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import umm.bi.ClsUEntBIDataSet;

import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.GlobalParameters;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import com.ofs.erm.gl.global.GLUtil;
import com.ofs.erm.gl.model.GlobalSettingsModel;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.dao.GlobalSettingsDAO;
import com.ofs.erm.gl.global.GL35Logger;

public class GlobalSettingsAction extends ActionSupport implements
ModelDriven,ServletRequestAware, ServletResponseAware, SessionAware {
	

	
	private Map session;
	HttpServletRequest request;
	HttpServletResponse response;
	
	String infodom="";
	String userid="";
	String dsStr="";
	LinkedHashMap dsMap = new LinkedHashMap();
	private GlobalSettingsModel prcMdlObj = null;
	
	GlobalSettingsModel glbsModel = new GlobalSettingsModel();

	public Object getModel() {
		return glbsModel;
	}
	public void setSession(Map session) {
		this.session = session;
		
	}
	public Map getSession()   
	{   
		return session;   
	}
	
	public String getInfodom() {
		return infodom;
	}
	
	
	public void setInfodom(String infodom) {
		this.infodom = infodom;
	}
	public String getUserid() {
		return userid;
	}
	
	
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	public String getDsStr() {
		return dsStr;
	}
	
	
	public void setDsStr(String dsStr) {
		this.dsStr = dsStr;
	}
	
	
	
	private String tableList;
	private String mrdyDims;
	private Map<String, String> ledgerIndicatorHM;
	
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
		
	}
	public Map<String, String> getLedgerIndicatorHM() {
		return ledgerIndicatorHM;
	}
	public void setLedgerIndicatorHM(Map<String, String> ledgerIndicatorHM) {
		this.ledgerIndicatorHM = ledgerIndicatorHM;
	}
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
		// TODO Auto-generated method stub
		
	}
	
	public String onLoad() throws Exception
	{
		
		GL35Logger.logThis("from onload method.."+new Date());
		String sLocale="";
		
		sLocale = request.getParameter("locale");
		if (sLocale == null || ("".equals(sLocale.trim()))) 
		{
			
				sLocale = "en_US";
			
		}
		GL35Logger.logThis("from onload method.sLocale."+sLocale);
		/**if(tableList == null || tableList.equals(""))
				{
						tableList =  GLUtil.getAllModelTables(infodom);
						glbsModel.setTable_id(tableList);
						System.out.println("inside get."+new Date());
				}**/
	//	System.out.println("frmo onload method after...."+tableList);
		GL35Logger.logThis("frmo onload userid..."+userid);
		userid = request.getParameter("userid");
		//if(userid!=null && !(userid.equalsIgnoreCase("")))
			
		GL35Logger.logThis("frmo onload 2222  infodom.."+infodom);
		//get the Mandatory dimensions
		GlobalUtil  gUtil = new GlobalUtil();
		String tmpbookcode = GlobalUtil.getParamValue("GLBOOK_TYPE_HIERCODE", infodom);
		GL35Logger.logThis("frmo tmpbookcode.."+tmpbookcode);
	  if(tmpbookcode!=null && !(tmpbookcode.equals("")))
		  glbsModel.setBookhiercode(tmpbookcode);
		Map lookupLHM = new LinkedHashMap();
		lookupLHM = GlobalUtil.getLookUpData("9",sLocale,infodom);
		// Have to handle Null pointer execpe3tion if tyhe llokup table desont hav data
		List<String> keyList = new ArrayList<String>(lookupLHM.keySet());
	//	List<String> valueList = new ArrayList<String>(lookupLHM.values());
		//System.out.println("getting dims");
		GL35Logger.logThis("frmo onload 22..."+new Date());
		 for(int k= 0;k<keyList.size();k++)
		 {
			 if(k==0)
			   mrdyDims = keyList.get(k)+"-"+lookupLHM.get(keyList.get(k))+",";
			 else
				 mrdyDims=mrdyDims+keyList.get(k)+"-"+lookupLHM.get(keyList.get(k))+",";
				 
		 }
		 if(mrdyDims!=null)
		 glbsModel.setMandatoryDims(mrdyDims);
		
		
		 GL35Logger.logThis("getting dims11111.."+glbsModel.getMandatoryDims());
		 Map balMap = new LinkedHashMap();
			dsMap = GLUtil.getDataSets(infodom, userid);
		 balMap = GlobalUtil.getLookUpData("2",sLocale,infodom);
		 List<String> keyList1 = new ArrayList<String>(balMap.keySet());
	//		List<String> valueList1 = new ArrayList<String>(balMap.values());
			
		 String balType="";
		 //System.out.println("balType dims11111.."+balType);
		 for(int k= 0;k<keyList1.size();k++)
		 {
			 if(k==0)
				 balType = keyList1.get(k)+"~"+balMap.get(keyList1.get(k))+",";
			 else
				 balType=balType+keyList1.get(k)+"~"+balMap.get(keyList1.get(k))+",";
				 
		 }
		 GL35Logger.logThis("balType dims11111.."+balType);
		 if(balType!=null)
		 glbsModel.setBalType(balType);
		// setGlbsModel((GlobalSettingsModel)getModel()); 
		 GL35Logger.logThis("frmo onload 44..."+new Date());
		 
		// System.out.println("frmo onload method mandatoryDims...."+mrdyDims.toString());
		 
		 
		 /**  start checking if the settings exist  ***/
		 
		 String ppdetails = "";
		 String gldetails = "";
		 String dimval="";
		 GlobalSettingsDAO gdao = new GlobalSettingsDAO();
		 ppdetails  = gdao.getPPdetails(infodom,dsMap);
		 if(ppdetails!=null)
		 glbsModel.setPpdetails(ppdetails);
		 GL35Logger.logThis("frmo onload ppdeatils..."+ppdetails);
		 
		 /**  end checking if the settings exist   ***/
		 GL35Logger.logThis("frmo onload 55..."+new Date());
		 gldetails = gdao.getGLdetails(infodom,dsMap,tmpbookcode,userid,sLocale);
		 if(gldetails!=null)
		 glbsModel.setGldetails(gldetails);
		 
		 dimval = gdao.getdimensions(infodom,userid,sLocale);
		 if(dimval != null)
		 glbsModel.setDimensions(dimval);
		 GL35Logger.logThis("frmo onload gldeatils..."+gldetails);
		 GL35Logger.logThis("frmo onload 66.."+new Date());
		 String dimmap="";
		 dimmap = gdao.getDimesionmap(infodom,  "");
		 if(dimmap!=null)
			 glbsModel.setDimMaps(dimmap);
		 GL35Logger.logThis("mandatory dims.."+glbsModel.getMandatoryDims());
		  ledgerIndicatorHM = GlobalUtil.getLIData(sLocale, infodom);
		  GL35Logger.logThis("ledger indicator"+ledgerIndicatorHM);
		return "success";
	}
	public String getDimmapinfo() throws Exception
	{
		
		PrintWriter  out = response.getWriter();
		String sHiercode="";
		
		sHiercode = request.getParameter("hiercode");
		String rtnmsg="";
		
		 GlobalSettingsDAO gdao = new GlobalSettingsDAO();
		 rtnmsg = gdao.getDimesionmap(infodom,  sHiercode);
           out.print(rtnmsg);
		
		
	    return NONE;
		
	}
	public String getCommonDimensions()  throws Exception
	{
		GL35Logger.logThis("getCommonDimensions");
		
		GL35Logger.logThis("infodom..332222."+infodom);
		
		GL35Logger.logThis("dsStr..."+dsStr);
	
		
		String dims="";
		String slocale =""; 
		Vector finaldims = new Vector();
		PrintWriter  out = response.getWriter();
		try
		{
			slocale = request.getParameter("locale");
		String Daarr[] = new String[1];
		if(dsStr.indexOf(",")!=-1)
			Daarr = dsStr.split(",");
		else
			Daarr[0] = dsStr;
		Vector listTabs = new Vector();
		ClsUEntBIDataSet objDataset = new ClsUEntBIDataSet();
	    Cargo cr  ;
	    for(int k=0;k<Daarr.length;k++)
	    {
	    cr = com.iflex.fic.client.BusinessMetaData.getMetaDataObjectFromServer(infodom,Daarr[k],GlobalParameters.BMD_SERVICE_TYPE_DATASET, GlobalParameters.AUTHORIZED_VERSION, new Locale(slocale));
	    objDataset = (ClsUEntBIDataSet)cr.getPayLoadObject();

		listTabs = objDataset.getListOfTables();
		GL35Logger.logThis("listTabs......"+listTabs.toString());
	 
		 if(k==0)
		  {
		    	
			 finaldims.addAll(listTabs);
		    	
		  }else
		  {
			  
			 for(int i=0;i<listTabs.size();i++)
			 {
				 if((!finaldims.contains(listTabs.get(i))))
					 finaldims.add(listTabs.get(i));
			 }
		  }
	    }
	    
	    GL35Logger.logThis("finaldims......"+finaldims.toString());
		if(finaldims!=null)
			dims = finaldims.toString();
		
	
		}catch(Exception e)
		{
			
			e.printStackTrace();
		}
		
		out.print(dims);
		
		
	    return NONE;
	}
	
	public String saveSettings()
	{
		GL35Logger.logThis("saveSettings......"); 
		LinkedHashMap ppstsMap = new LinkedHashMap();
		LinkedHashMap glstsMap = new LinkedHashMap();
		LinkedHashMap mdimstsMap = new LinkedHashMap();
		LinkedHashMap rdimstsMap = new LinkedHashMap();
	//	String sLocale = (String) session.get("sourceLang");
		//String gsUsrID = (String)session.get("gsUsrID");
		Vector  qryVector = new Vector();
		 infodom =  request.getParameter("infodom");
		  String isSucccess = "26096";
		 PrintWriter out ;
		 try
		{
			
		
				
			  String ppdetails="";
			  String gldetails="";
			  String mrdyDims="";
			  String recondims ="";
			  String ppglbalStr="";
			  String ppbalancecol="";
			  String ppgldimmap ="";
			  String ppst="";
			  String glst="";
			  String mdimsts="";
		      String rdimsts="";
			  Vector ppQry = new Vector();
			  Vector glQry = new Vector();
			  out = response.getWriter();
			  StringBuffer glqryStr ;
			
			  ppdetails = request.getParameter("ppstr");
			  
			  if (ppdetails == null || "".equals(ppdetails.trim()) || "null".equalsIgnoreCase(ppdetails.trim())) {
				  ppdetails = "";
			}

			  gldetails = request.getParameter("glstr");
			  mrdyDims = request.getParameter("mrdims");
			  recondims = request.getParameter("recondims");
			  ppglbalStr = request.getParameter("glppmap");
			  ppbalancecol = request.getParameter("ppbal");
			  ppgldimmap = request.getParameter("dimmappings");
			  ppst = request.getParameter("ppst");
			  glst = request.getParameter("glsts");
			  mdimsts = request.getParameter("mrdimsts");
			  rdimsts = request.getParameter("rdimsts");
			  
			  
			  ppdetails = ppdetails.replaceAll("null", "");
			  gldetails = gldetails.replaceAll("null", "");
			  mrdyDims = mrdyDims.replaceAll("null", "");
			  recondims = recondims.replaceAll("null", "");
			  ppglbalStr = ppglbalStr.replaceAll("null", "");
			  ppbalancecol = ppbalancecol.replaceAll("null", "");
			  ppgldimmap = ppgldimmap.replaceAll("null", "");
			
			  GlobalSettingsDAO gdao = new GlobalSettingsDAO();
			  
			  GL35Logger.logThis("ppdetails......"+ppdetails); 
			  GL35Logger.logThis("gldetails......"+gldetails);
			  GL35Logger.logThis("mrdyDims......"+mrdyDims); 
			  GL35Logger.logThis("recondims......"+recondims);
			  GL35Logger.logThis("ppglbalStr......"+ppglbalStr); 
			  GL35Logger.logThis("ppbalancecol......"+ppbalancecol);
			  GL35Logger.logThis("ppst......"+ppst); 
			  GL35Logger.logThis("glst......"+glst);
			  if(ppst !=null && !(ppst.equalsIgnoreCase("")))
			  {
				  String[] pp_1 = ppst.split("#");
			       for(int j=0;j<pp_1.length;j++)
			       {
			    	
			    	  
			    	   String[] testppval = pp_1[j].split(":");
			    	   if(testppval.length>1)
			    		   ppstsMap.put(testppval[0], testppval[1]);
			    	   
			       }
				  
			  }
			 
			  if(glst !=null && !(glst.equalsIgnoreCase("")))
			  {
				  String[] gl_1 = glst.split("#");
			       for(int j=0;j<gl_1.length;j++)
			       {
			    	  System.out.println("iii...."+gl_1[j]) ;
			    	  
			    	   String[] testglval = gl_1[j].split(":");
			    	   if(testglval.length>1)
			    		   glstsMap.put(testglval[0], testglval[1]);  
			    	   
			       }
				  
			  } 
			  
			  ppQry = gdao.getPPinsertQry(ppstsMap, ppdetails, ppglbalStr, ppbalancecol);
			  glQry = gdao.getGLinsertQry(infodom,glstsMap, gldetails);
			
			 
	
			 
			  if(ppQry!=null && glQry !=null)
			  {
				  qryVector.addAll(ppQry);
			      qryVector.addAll(glQry); 
			  }
			  if(mdimsts !=null && !(mdimsts.equalsIgnoreCase("")))
			  {
				  String[] pp_1 = mdimsts.split("#");
			       for(int j=0;j<pp_1.length;j++)
			       {
			    	
			    	  
			    	   String[] testppval = pp_1[j].split(":");
			    	   if(testppval.length>1)
			    		   mdimstsMap.put(testppval[0], testppval[1]);
			    	   
			       }
				  
			  }
			  if(rdimsts !=null && !(rdimsts.equalsIgnoreCase("")))
			  {
				  String[] pp_1 = rdimsts.split("#");
			       for(int j=0;j<pp_1.length;j++)
			       {
			    	
			    	  
			    	   String[] testppval = pp_1[j].split(":");
			    	   if(testppval.length>1)
			    		   rdimstsMap.put(testppval[0], testppval[1]);
			    	   
			       }
				  
			  }
			  String action="";
			 if(mrdyDims !=null && !(mrdyDims.equalsIgnoreCase("")))
			  {
				
				  String[] mDIms = mrdyDims.split(",");
				    for(int k=0;k<mDIms.length;k++)
				    {
				    	 String[] dmival = mDIms[k].split(":");
				    	 glqryStr = new StringBuffer();
				    	  GL35Logger.logThis("dim...."+dmival[1]+"map.."+mdimstsMap.toString()); 
				    	 if(mdimstsMap.containsKey(dmival[0]))
				    	 {
				    		
				    		 action = mdimstsMap.get(dmival[0]).toString();
				    		 
				    		  GL35Logger.logThis("action......"+action+"dim...."+dmival[1]); 
				    		     if(action.equalsIgnoreCase("new"))
				    		     {
									 glqryStr.append("INSERT INTO SETUP_GL_RECON_DIMENSIONS (V_DIMENSION_HCY_CODE,F_RECON_OR_MANDATORY,V_DIMENSION_LOOKUP_CD,V_DIMENSION_DESC,V_CREATED_USER,D_CREATED_DATE) VALUES ('");
									 glqryStr.append(dmival[1]+"','M','"+dmival[0]+"','"+dmival[2]+"','"+userid+"',sysdate)");
									 
									 qryVector.add(glqryStr.toString());
							     }else  if(action.equalsIgnoreCase("edit"))
						         {
							    	   qryVector.add("DELETE FROM SETUP_RECON_DIM_COL_MAP WHERE V_DIMENSION_HCY_CODE = '"+dmival[1]+"'");
							    	   qryVector.add("UPDATE SETUP_GL_RECON_DIMENSIONS SET V_DIMENSION_HCY_CODE = '"+dmival[1]+"' , V_DIMENSION_DESC = '"+dmival[2]+"' WHERE V_DIMENSION_LOOKUP_CD ='"+dmival[0]+"' AND F_RECON_OR_MANDATORY ='M'");
				    		    	
						         }
				    	 }
				    	 
				    }
				    
			  }
				    String key1="";
				    
				    if(mdimstsMap!=null)
				    {
				       Iterator iter = mdimstsMap.keySet().iterator();
				       
				       while(iter.hasNext())
				       {
				    	   key1 = iter.next().toString();
				    	   if(mdimstsMap.get(key1).equals("delete"))
				    	   {
				    		 
				    		   qryVector.add("DELETE FROM SETUP_RECON_DIM_COL_MAP WHERE V_DIMENSION_HCY_CODE = (SELECT V_DIMENSION_HCY_CODE FROM SETUP_GL_RECON_DIMENSIONS WHERE V_DIMENSION_LOOKUP_CD = '"+key1+"' AND F_RECON_OR_MANDATORY ='M' ) ");
				    		   qryVector.add("DELETE FROM SETUP_GL_RECON_DIMENSIONS WHERE V_DIMENSION_LOOKUP_CD = '"+key1+"' AND F_RECON_OR_MANDATORY ='M'");
			    		    	
					         }
				       }
				    }
				
			 
			 
			  GL35Logger.logThis("rrrrmap.."+rdimstsMap.toString()); 
			 if(recondims !=null && !(recondims.equalsIgnoreCase("")))
			  {
				 
				  String[] test1 = recondims.split(",");
				    for(int k=0;k<test1.length;k++)
				    {
				    	
				    	 glqryStr = new StringBuffer();
				    	  String[] t_1 = test1[k].split(":");
				    	  GL35Logger.logThis("rdim...."+t_1[0]+"map.."+rdimstsMap.toString()); 
				    	 
				    	 if(rdimstsMap.containsKey(t_1[0]))
				    	 {
				    		
				    		 action = rdimstsMap.get(t_1[0]).toString();
				    		  GL35Logger.logThis("raction......"+action+"dim...."+t_1[0]);
				    		     if(action.equalsIgnoreCase("new"))
				    		     {
									  glqryStr.append("INSERT INTO SETUP_GL_RECON_DIMENSIONS (V_DIMENSION_HCY_CODE,F_RECON_OR_MANDATORY,V_DIMENSION_LOOKUP_CD,V_DIMENSION_DESC,V_CREATED_USER,D_CREATED_DATE ) VALUES ('");
									  glqryStr.append(t_1[0]+"','R','','"+t_1[1]+"','"+userid+"',sysdate)");
							    	  
									  qryVector.add(glqryStr.toString());
				    		     }
						         
				    		     
				    	 }
				    	
				    }
			  }
				  
				      
				   if(rdimstsMap!=null)   
				   {
					   
					   key1="";
				 }
					   Iterator iter = rdimstsMap.keySet().iterator();
				  
				       while(iter.hasNext())
				       {
				    	   key1 = iter.next().toString();
				    	   if(rdimstsMap.get(key1).equals("delete"))
				    	   {
				    		  
				    		     qryVector.add("DELETE FROM SETUP_RECON_DIM_COL_MAP WHERE V_DIMENSION_HCY_CODE = '"+key1+"'");

			    		    	 qryVector.add("DELETE FROM SETUP_GL_RECON_DIMENSIONS WHERE V_DIMENSION_HCY_CODE = '"+key1+"' AND F_RECON_OR_MANDATORY ='R'");
					         }
				       }
				 
			 
			  
			 
			  if(ppgldimmap !=null && !(ppgldimmap.equalsIgnoreCase("")))
			  {
				  //qryVector.add("DELETE FROM SETUP_RECON_DIM_COL_MAP "); 
				  String mapQry ="";
				  String[] dimmap = ppgldimmap.split("#");
				  String mapsts ="";
				  String dimcolname="";
				  LinkedHashMap tets ;
		           for(int i=0;i<dimmap.length;i++)
		           {
		        	  System.out.println("test..."+dimmap[i]); 
		        	   //String[] dimdet = dimmap[i].split(",");
		        	   //for(int i1=0;i1<dimdet.length;i1++)
		              // {
		             tets = new LinkedHashMap();
		             
		              tets  = getDimmapvales(dimmap[i]);  
		             dimcolname = tets.get("colname").toString();
		             mapsts = tets.get("sts").toString();
		            String[] coldesc = dimcolname.split("-");
		            if(dimcolname.indexOf("-")!=-1)
		               { 	
		            if(mapsts.equalsIgnoreCase("new"))
		            {
		                  mapQry ="INSERT INTO SETUP_RECON_DIM_COL_MAP(V_DIMENSION_HCY_CODE,V_PP_GL_TABLE_NAME,V_PP_OR_GL,V_DIMENSION_COL_NAME,V_DIMENSION_LOGIC_COL_NAME,V_CREATED_USER,D_CREATED_DATE) values (  '"+
		                       tets.get("dimcode")+"','"+tets.get("TabName")+"','"+tets.get("TYPE")+"','"+coldesc[0]+"','"+coldesc[1]+"','"+userid+"',sysdate)";
		             
		                 qryVector.add(mapQry);
		            }else   if(mapsts.equalsIgnoreCase("edit"))
		            {
		            	 mapQry ="UPDATE SETUP_RECON_DIM_COL_MAP  SET  V_DIMENSION_COL_NAME = '"+coldesc[0]+"' ,V_DIMENSION_LOGIC_COL_NAME = '"+coldesc[1]+"' ,V_MODIFIED_USER ='"+userid+"' , D_MODIFIED_DATE = sysdate  WHERE " +
		            	 		" V_DIMENSION_HCY_CODE ='"+tets.get("dimcode")+"' AND V_PP_GL_TABLE_NAME = '"+tets.get("TabName")+"' AND V_PP_OR_GL ='"+tets.get("TYPE")+"'";
	                      
	                    qryVector.add(mapQry);
		             	
		            }else   if(mapsts.equalsIgnoreCase("del"))
		            {
		            	 mapQry ="DELETE FROM SETUP_RECON_DIM_COL_MAP   WHERE " +
		            	 		" V_DIMENSION_HCY_CODE ='"+tets.get("dimcode")+"' AND V_PP_GL_TABLE_NAME = '"+tets.get("TabName")+"' AND V_PP_OR_GL ='"+tets.get("TYPE")+"'";
	                      
	                    qryVector.add(mapQry);
		             	
		            }
		              
		           }
		           
		           }
			  }else
				  qryVector.add("DELETE FROM SETUP_RECON_DIM_COL_MAP "); 
			 if(qryVector.size()>0)
			 {
				 
				 for(int i=0;i<qryVector.size();i++)
					 GL35Logger.logThis(i+".."+qryVector.get(i).toString());
				 
			 }
			
			 
			 
			
			  
			  isSucccess = gdao.SaveDetails(infodom, qryVector);
			  out.print(isSucccess);
		 }catch(Exception e)
		{
			e.printStackTrace();
			return NONE; 
		}
		
		return NONE;	
	}
	
	
public static LinkedHashMap getDimmapvales(String val){
		
		
		LinkedHashMap dimmap = new LinkedHashMap();
		String[] dimdet = val.split(",");
		for(int i1=0;i1<dimdet.length;i1++)
            {
			   String tvals = dimdet[i1];
			   
			   if(tvals.indexOf(":")!=-1)
			   {
				   String[] dim_ins = tvals.split(":");				   
				   dimmap.put(dim_ins[0], dim_ins[1]);
				   
				   
			   }
				
            }
		
		return dimmap;
	
	}

	public String isDSDimused() throws Exception 
	{
		PrintWriter out = response.getWriter();
		int dimexist=0;
	    String ppname="";
	    String dscode ="";
	    String alldscode ="";
	    String slocale ="";
	          
	           slocale = request.getParameter("locale");
	           dscode = request.getParameter("dscodes");
	           alldscode = request.getParameter("allds");
	           infodom	 = request.getParameter("infodom");
		 GlobalSettingsDAO gdao = new GlobalSettingsDAO();
	   
		 dimexist =  gdao.getPPBookDSMap(infodom,dscode,alldscode,slocale);
	    
		 GL35Logger.logThis("mapExists.."+dimexist);
		
		out.print(dimexist);
		
		return NONE;
	   
	}
    public String isPPused() throws Exception 
    {
    	PrintWriter out = response.getWriter();
    	int mapExists=0;
	    String ppname="";
	    String dscode ="";
	    String alldscode ="";
	    String slocale ="";
	          
	           slocale = request.getParameter("locale");
	           ppname = request.getParameter("ppname");
	           dscode = request.getParameter("dscodes");
	           alldscode = request.getParameter("allds");
	           infodom	 = request.getParameter("infodom");
    	 GlobalSettingsDAO gdao = new GlobalSettingsDAO();
	   
    	 mapExists =  gdao.isPPmapexists(infodom,ppname,dscode,alldscode,slocale);
        
    	 GL35Logger.logThis("mapExists.."+mapExists);
    	
    	out.print(mapExists);
		
		return NONE;
	   
    }

    
    public String isBooktypeused() throws Exception 
    {
    	
    	PrintWriter out = response.getWriter();
    	int mapExists=0;
	    String book="";
	    String dscode ="";
	    String alldscode ="";
	    String slocale ="";
        
        slocale = request.getParameter("locale");
	    
	    book = request.getParameter("bookcode");
	    dscode = request.getParameter("dscodes");
	    alldscode = request.getParameter("allds");
	    
	    infodom	 = request.getParameter("infodom");
    	
	    GlobalSettingsDAO gdao = new GlobalSettingsDAO();
	   
    	 mapExists =  gdao.isGLbooktypeexists(infodom,book,dscode,alldscode,slocale);
        
    	 GL35Logger.logThis("booktypeExists.."+mapExists);
    	
    	out.print(mapExists);
		
		return NONE;
	   
    }
    public String isGLBookColumnused() throws Exception 
    {
    	
    	PrintWriter out = response.getWriter();
    	int mapExists=0;
	    String bookcol ="";
	    String glcodecol ="";
	    String ppname="";
        
    
	    
      //  bookcol = request.getParameter("bookcolumn");
	    glcodecol = request.getParameter("glcdcolumn");
	    ppname = request.getParameter("ppsource");
	    
	    infodom	 = request.getParameter("infodom");
    	
	    GlobalSettingsDAO gdao = new GlobalSettingsDAO();
	   
    	 mapExists =  gdao.isGLbookcolumnexists(infodom,glcodecol,ppname);
        
    	 GL35Logger.logThis("booktypeExists.."+mapExists);
    	
    	out.print(mapExists);
		
		return NONE;
	   
    }
    public String isBalanceused() throws Exception 
    {
    	
    	PrintWriter out = response.getWriter();
    	int balExists=0;
	    String table="";
	    String balcolumns="";
	    table = request.getParameter("tabname");
	    balcolumns = request.getParameter("balcol");
	    infodom	 = request.getParameter("infodom");
    	 GlobalSettingsDAO gdao = new GlobalSettingsDAO();
	   
    	 balExists =  gdao.isBalanceexists(infodom,table,balcolumns);
        
    	 GL35Logger.logThis("booktypeExists.."+balExists);
    	
    	out.print(balExists);
		
		return NONE;
	   
    }
    public String isDimensionused() throws Exception 
    {
    	
    	PrintWriter out = response.getWriter();
    	int mapExists=0;
	   
	   String dimcodes="";
	   dimcodes = request.getParameter("dimcodes");
	    
	    infodom	 = request.getParameter("infodom");
    	 GlobalSettingsDAO gdao = new GlobalSettingsDAO();
    	 Vector dimVec = new Vector();
    	        dimVec.add(dimcodes);
	   
    	 mapExists =  gdao.isDimesionexists(infodom,dimVec);
        
    	 GL35Logger.logThis("booktypeExists.."+mapExists);
    	
    	out.print(mapExists);
		
		return NONE;
	   
    }
    
    public String isLEhierused() throws Exception 
    {
    	
    	PrintWriter out = response.getWriter();
    	int mapExists=0;
	   
	   String dimcodes="";
	   dimcodes = request.getParameter("dimcodes");
	    
	    infodom	 = request.getParameter("infodom");
    	 GlobalSettingsDAO gdao = new GlobalSettingsDAO();
    	
    	 mapExists =  gdao.isLEhierexists(infodom,dimcodes);
        
    	 GL35Logger.logThis("booktypeExists.."+mapExists);
    	
    	out.print(mapExists);
		
		return NONE;
	   
    }
    public String isGLHierachyused() throws Exception 
    {
    	
    	PrintWriter out = response.getWriter();
    	int mapExists=0;
	   
	   String glhiercode="";
	   String glbook ="";
	  
	    glhiercode = request.getParameter("hiercode");
	    glbook = request.getParameter("bookcd");
	    infodom	 = request.getParameter("infodom");
    	 GlobalSettingsDAO gdao = new GlobalSettingsDAO();
    	
    	 mapExists =  gdao.isGLHierused(infodom,glhiercode,glbook);
        
    	 GL35Logger.logThis("booktypeExists.."+mapExists);
    	
    	out.print(mapExists);
		
		return NONE;
	   
    }
	public GlobalSettingsModel getGlbsModel() {
		return glbsModel;
	}
	
	/**
	 * @param sysModel The sysModel to set.
	 */
	public void setGlbsModel(GlobalSettingsModel glbsModel) {
		this.glbsModel = glbsModel;
	}
	
	
	
}
