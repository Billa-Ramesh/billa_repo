/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : CorrectionEditAction.java
* Title         :
* Description   :
* @author       : Sandeep 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.action;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringBufferInputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Priority;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

//import com.ofs.fsapps.gl.dao.AdjEntryEditDAO;
import com.ofs.erm.gl.global.GL35Logger;
//import com.ofs.erm.gl.dao.AdjEntryEditDAO;
//import com.ofs.erm.gl.dao.CorrEntryEditDao;
import com.ofs.erm.gl.dao.CorrectionEntryEditDAO;
import com.ofs.erm.gl.dao.EditPageDAO;
//import com.ofs.erm.gl.model.CorrEntryEditBean;
import com.ofs.erm.gl.model.CorrecEntryEditSummaryBean;
import com.ofs.erm.gl.model.EditPageEntryBean;
import com.ofs.erm.gl.model.EditPageSearchBean;
import com.ofs.erm.gl.model.EditPageSummaryBean;
import com.ofs.erm.gl.model.EleBrDimInputListBean;
import com.ofs.erm.gl.model.MapNameBean;
import com.ofs.erm.gl.model.PPListBean;
//import com.ofs.fsapps.gl.model.AdjEntryEditBean;
//import com.ofs.fsapps.gl.model.AdjEntryEditSearchBean;
//import com.ofs.fsapps.gl.model.AdjEntryEditSummaryBean;
//import com.ofs.fsapps.gl.model.EditPageSeachBean;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class CorrectionEditAction extends ActionSupport implements SessionAware,
ServletRequestAware, ServletResponseAware{
	 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private InputStream inputStream;
	//CorrecEntryEditSummaryBean cesb = new CorrecEntryEditSummaryBean();
    public InputStream getInputStream() {
        return inputStream;
    }

	private List<EditPageSummaryBean> adjustmentList;
	private List<CorrecEntryEditSummaryBean> correctionList;
	//private List<CorrecEntryEditSummaryBean> cList;

	//correctionList rowId transactionEntity balanceColumn attributeVal correctionExpsoureId originalAmt correctionAmt submissionComments
	private List<String> dimensionsArray;
	private List<String> dimensionsArrayOpt;
	private int recordCount;
	private List<com.ofs.erm.gl.model.MapNameBean> mapArray;
	private String sortOrder;
	private String sortCol;
	private String manDim;
	private String editExecutionId,editMapId,editGlDate,editVersionNumber;
//	private String execId;
//	private String glDate;
	private String methodName;
	private int startIndex,endIndex,currentPage;
	private String expAmountLowerBound,expAmountUpperBound;
	private String selectedPPs;
	private int paginationNumber;
	public int getPaginationNumber() {
		return paginationNumber;
	}
	public void setPaginationNumber(int paginationNumber) {
		this.paginationNumber = paginationNumber;
	}

	private int noOfPagesLoaded = 2;
	private String selectedAdjExposureId;
	private String selectedAdjExposureIds;//~ separated values
	private String sInfodom;
	private String sUserId;
	private String submitStatus;
	private String editedDefaultValues;
	private String selectedDimValues;
	//private String retStatus;
	private String correctionExposureId,adjustmentExposureId;
	private String page;
	private String authCorr_Values;
	private String authorization_Status;
	
	private List<com.ofs.erm.gl.model.PPListBean> ppList;
	private List<com.ofs.erm.gl.model.EleBrDimInputListBean> eleBrDimList;

	protected HttpServletRequest request;
	protected HttpServletResponse response;
	
	private static Map session;

	private PPListBean ppListBean;
	private EleBrDimInputListBean eleBrDimBean;
	
	@SuppressWarnings("finally")
	public String getAmountColumnValue(){
		PrintWriter pw;
		String retVal = "";
		try{
			pw = response.getWriter();
			String sInfodom = getsInfodom();
			//"correctionExposureId="+correctionExposureId+"&adjustmentExposureId="+adjustmentExposureId+"&sInfodom="+sInfodom
			String correctionExposureId = getCorrectionExposureId();
			String adjustmentExposureId = getAdjustmentExposureId();
			retVal = CorrectionEntryEditDAO.getAmountColumnVal(adjustmentExposureId, correctionExposureId, sInfodom);
			pw.print(retVal);
			/*if(retVal.equals("-")){
				pw.print("-");
			}else{
				pw
			}*/
			/*		PrintWriter pw = response.getWriter();
			if(updateStatus) pw.print("saved");
			else pw.print("failed");*/
			//return NONE;
		}catch (Exception e) {
			e.printStackTrace();
			GL35Logger.logThis("Exception occured : "+e.getLocalizedMessage(), Priority.ERROR_INT);
		}finally{
			return NONE;
		}
	}
	
	
	@SuppressWarnings("finally")
	public String submitMultipleAdjEntries(){
		PrintWriter pw;
		String retVal = "";
		String[] adjustmentExposureIdsAry = null;
		try{
			pw = response.getWriter();
			String sInfodom = getsInfodom();
			String adjustmentExposureIds = getSelectedAdjExposureIds();
			adjustmentExposureIdsAry=adjustmentExposureIds.split("~");
			retVal = CorrectionEntryEditDAO.setCorrectionEntrySpecMulti(adjustmentExposureIdsAry, sInfodom);
			GL35Logger.logThis(" return status (retVal) : "+retVal,Priority.INFO_INT);
			pw.print(retVal);
		}catch (Exception e) {
			e.printStackTrace();
			GL35Logger.logThis("Exception occured : "+e.getLocalizedMessage(), Priority.ERROR_INT);
		}finally{
			return NONE;
		}
	}
	
	@SuppressWarnings("finally")
	/*var sendStr = "authCorr_Values="+authCorr_Values+"&sUserId="+sUserId+"
	 * &sInfodom="+sInfodom+"&authorization_Status="+authorization_Status+"&selectedAdjExposureId="+selectedAdjExposureId;*/
	public String correctionEditAuth(){
		String retVal="";//
		String authCorr_Values = "";
		String[] authCorr_ValuesAry = null;
		PrintWriter pw;
		try{
			pw = response.getWriter();
			String sInfodom = getsInfodom();
			String sUserId = getsUserId();
			String selectedExposureId = getSelectedAdjExposureId();
			String selectedAdjExposureIds = getSelectedAdjExposureIds();
			String authStatus = getAuthorization_Status();
			if(sInfodom==null) sInfodom="";
			if(sUserId==null) sUserId="";
			if(selectedExposureId==null) selectedExposureId="";
			if(selectedAdjExposureIds==null) selectedAdjExposureIds="";
			if(authStatus==null) authStatus="";
			authCorr_Values = getAuthCorr_Values();
			if(!( (authCorr_Values == null) || (authCorr_Values.equals("")) ) ) {
				authCorr_ValuesAry = authCorr_Values.split("@@");
				GL35Logger.logThis("Correction Approval Array ="+authCorr_ValuesAry.toString(), Priority.INFO_INT);
			}
			else {
				authCorr_Values = "";
			}
			//authCorr_Values = getAuthCorr_Values().split("@@");
			if(selectedAdjExposureIds.indexOf("~")!=-1){
				retVal = CorrectionEntryEditDAO.authCorrectionEditMulti(sInfodom,sUserId,selectedAdjExposureIds,authStatus);
			}else{
				retVal = CorrectionEntryEditDAO.authCorrectionEdit(sInfodom,sUserId,authCorr_ValuesAry,selectedExposureId,authStatus);
			}
			
			
			GL35Logger.logThis(" return status (retVal-SUCCESS/FAIL/ERROR/CONTROLID) : "+retVal,Priority.INFO_INT);
			pw.print(retVal);
		}catch (Exception e) {
			e.printStackTrace();
			GL35Logger.logThis("Exception occured : "+e.getLocalizedMessage(), Priority.ERROR_INT);
		}finally{
			return NONE;	
		}
	}
	
	public String correctionEditAction() {
		String langCode = session.get("lclPostFix").toString();
		GL35Logger.logThis("Locale....."+langCode, Priority.INFO_INT);
	try{
	EditPageEntryBean EditBean = new EditPageEntryBean();
	System.out.println("Entering ACTION class");
	String methodName = getMethodName();
	GL35Logger.logThis("Entering CorrectionEditAction ACTION class, methodName= "+methodName, Priority.INFO_INT);
	String sInfodom = getsInfodom();
	String sUserId = getsUserId();
	String submitStatus = getSubmitStatus();//P-Save, S-Submit
	System.out.println("methodName= "+methodName);
	String editExecutionId = getEditExecutionId();
	String editMapId = getEditMapId();
	String editGlDate = getEditGlDate();
	String editVersionNumber = getEditVersionNumber();
	String editSortCol = getSortCol();
	String editSortOrder = getSortOrder();
	String searchExpAmountLowerBound = getExpAmountLowerBound();
	String searchExpAmountUpperBound = getExpAmountUpperBound();
	String filterSelectedPPs = getSelectedPPs();
	String selectedExposureId = getSelectedAdjExposureId();
	String[] selectedPPArray = {"Nill"};
	String selectedDimValuesString = getSelectedDimValues();
	int paginationNumber = getPaginationNumber();
	String page = getPage();//page=approveEdit or Edit
	
	if(paginationNumber == 0)
		paginationNumber = 5;
	
	if(page == null) page="";
	if(editSortCol == null)	editSortCol = "";
	if(editSortOrder == null) editSortOrder = "";
	if(selectedExposureId == null) selectedExposureId = "";
	//if(selectedExposureId == null) selectedExposureId = "";
	if(selectedDimValuesString == null)	selectedDimValuesString = "";
	if((searchExpAmountLowerBound == null))	searchExpAmountLowerBound = "-999999999999999";
	if((searchExpAmountUpperBound == null))	searchExpAmountUpperBound = "999999999999999";
	
	System.out.println("filterSelectedPPs="+filterSelectedPPs);
	GL35Logger.logThis("filterSelectedPPs="+filterSelectedPPs, Priority.INFO_INT);
	if(!( (filterSelectedPPs == null) || (filterSelectedPPs.equals("")) ) ) {
		selectedPPArray = filterSelectedPPs.split("@#");
		System.out.println("Created PP Array with length="+selectedPPArray.length);
		GL35Logger.logThis("Created PP Array with length="+selectedPPArray.length, Priority.INFO_INT);
	}
	else {
		filterSelectedPPs = "";
	}
	
	
	if(editExecutionId == null)
		editExecutionId = "";
	if(editMapId == null)
		editMapId = "";
	if(editGlDate == null)
		editGlDate = "";
	if(editVersionNumber == null)
		editVersionNumber = "";
	System.out.println(editExecutionId+":"+editMapId+":"+editGlDate);
	GL35Logger.logThis(editExecutionId+":"+editMapId+":"+editGlDate, Priority.INFO_INT);
	
	EditBean.setExecId(editExecutionId);
	EditBean.setMapId(editMapId);
	EditBean.setGlDate(editGlDate);
	EditBean.setVersionNumber(editVersionNumber);
	
	adjustmentList = new ArrayList<EditPageSummaryBean>();
	dimensionsArray = new ArrayList<String>();
	dimensionsArrayOpt = new ArrayList<String>();
	
	EditPageSearchBean searchBean = new EditPageSearchBean();
	searchBean.setExecutionId(editExecutionId);
	searchBean.setGlDate(editGlDate);
	searchBean.setMapId(editMapId);
	searchBean.setVersionNumber(editVersionNumber);
	searchBean.setSortCol(editSortCol);
	searchBean.setSortOrder(editSortOrder);
	searchBean.setRecordCountNeeded(false);
	searchBean.setSearchExpAmountLowerBound(searchExpAmountLowerBound);
	searchBean.setSearchExpAmountUpperBound(searchExpAmountUpperBound);
	searchBean.setSelectedPPArray(selectedPPArray);
	searchBean.setEntryStatus("A");
	searchBean.setContraGLCheckNeeded(true);
	searchBean.setCorrChk(true);
	
	//String page = getPage();//page=approveEdit or Edit
	if(page.equalsIgnoreCase("approveEdit")){
		searchBean.setCorrStatus(true);
	}else{
		//searchBean.setCorrStatus(" ");
	}
	
	

	if(methodName == null) {
		sortCol = "";
		sortOrder = ""; 
	}
	else if(methodName.equals("populatePPs")) {
		ppListBean = new PPListBean();
		ppListBean.setExecId(EditBean.getExecId());
		ppListBean.setMapName(EditBean.getMapId());
		ppListBean.setGlDate(EditBean.getGlDate());
		ppListBean.setVersionNumber(EditBean.getVersionNumber());
		ppList = new ArrayList<PPListBean>();
		ppList = EditPageDAO.getPPList(ppListBean,sInfodom);
		GL35Logger.logThis("RETURNING PPLIST with size : "+ppList.size(), Priority.INFO_INT);
		System.out.println("RETURNING PPLIST with size : "+ppList.size());
		//request.setAttribute("isSuccess", "pp_populated");
		return SUCCESS;
	}
	else if(methodName.equals("loadDimList")) {
		System.out.println("loading dim list");
		String version = request.getParameter("sVersion");
		String output = EditPageDAO.getDimensionArray(getManDim(),version,sInfodom);
		inputStream = new StringBufferInputStream(output);
		//request.setAttribute("isSuccess", "DimListLoaded"); 
		return SUCCESS;
	}
	else if(methodName.equals("loadAdjustmentData") || methodName.equals("getAdjDataFirstPage")) {
		System.out.println("loading adjustment Data");
		GL35Logger.logThis("loading adjustment Data", Priority.INFO_INT);
		startIndex = 1;
		endIndex = noOfPagesLoaded*paginationNumber;
		searchBean.setRecordCountNeeded(true);
		
	}
	else if(methodName.equals("loadCorrectionData")) {
		System.out.println("loading Correction Data");
		GL35Logger.logThis("loading Correction Data", Priority.INFO_INT);
		//correctionList = new LinkedList<CorrecEntryEditSummaryBean>();
		//startIndex = 1;
		//endIndex = noOfPagesLoaded*paginationNumber;
		//searchBean.setRecordCountNeeded(true);
		//CorrecEntryEditSummaryBean -> 
		setCorrectionList(CorrectionEntryEditDAO.getCorrectionData(selectedExposureId,sInfodom,page));
		//this.setcList(CorrectionEntryEditDAO.getCorrectionData(selectedExposureId,sInfodom));
		//request.setAttribute("isSuccess", "correctionDataloaded");
		return SUCCESS;
	}
	else if(methodName.equals("saveDefaultValues")) {
		System.out.println("Saving default Values with editedDefaultValues="+getEditedDefaultValues());
		GL35Logger.logThis("Saving default Values with editedDefaultValues="+getEditedDefaultValues(), Priority.INFO_INT);
		String[] editedCorrecEntrySpecArray = getEditedDefaultValues().split("@@");
		
		String updateStatus = (CorrectionEntryEditDAO.setCorrectionEntrySpec(selectedExposureId, editedCorrecEntrySpecArray,sInfodom,
				sUserId,submitStatus,editMapId,editVersionNumber));
		System.out.println("Returning from action class with returnStatus : "+updateStatus);
		GL35Logger.logThis("Returning from action class with returnStatus : "+updateStatus, Priority.INFO_INT);
		PrintWriter pw = response.getWriter();
		if(updateStatus.equals("true")) pw.print("saved");
		else if(updateStatus.equals("false")) pw.print("failed");
		else{
			pw.print(updateStatus);
		}
		return NONE;
	}
	/*else if(methodName.equals("getDefaultValues")) {
		System.out.println("loading default Values for selectedExposureId="+selectedExposureId);
		setDefaultValueList(AdjEntryEditDAO.getDefaultValues(selectedExposureId));
		
		setUserComments("");
		System.out.println("Returning with Default Value List with Size = "+defaultValueList.size());
		return SUCCESS;
	}*/
	//loadCorrectionData
	//setAdjustmentList(AdjEntryEditDAO.getAdjustmentData(searchBean));
	else if(methodName.equals("getAdjDataLastPage")) {
		System.out.println("loading adjustment Data - FirstPage");
		GL35Logger.logThis("loading adjustment Data - FirstPage", Priority.INFO_INT);
		if((currentPage % 2) == 0) { // 2 here in this if loop is no of pages to load
			startIndex = (paginationNumber * (currentPage - 2)) + 1; 
			endIndex = startIndex + (2*paginationNumber) - 1;
		}
		else {
			startIndex = (paginationNumber * (currentPage - 1)) + 1;
			endIndex = startIndex + ((2-1)*paginationNumber) - 1;
		}
		System.out.println("startIndex="+startIndex+"endIndex="+endIndex);
		GL35Logger.logThis("startIndex="+startIndex+"endIndex="+endIndex, Priority.INFO_INT);
	}
	else if(methodName.equals("getAdjDataNextPage")) {
		startIndex = (paginationNumber * currentPage) + 1;
		endIndex = startIndex + (2*paginationNumber) - 1;
		System.out.println("loading adjustment Data - NextPage -- startIndex="+startIndex+" endIndex="+endIndex);
		GL35Logger.logThis("loading adjustment Data - NextPage -- startIndex="+startIndex+" endIndex="+endIndex, Priority.INFO_INT);
	}
	else if(methodName.equals("getAdjDataPrevPage")) {
		startIndex = (paginationNumber * (currentPage-3)) + 1; // this line depends on number of pages loaded
		endIndex = startIndex + (2*paginationNumber) - 1;
		System.out.println("loading adjustment Data - PrevPage -- startIndex="+startIndex+" endIndex="+endIndex);
		GL35Logger.logThis("loading adjustment Data - PrevPage -- startIndex="+startIndex+" endIndex="+endIndex, Priority.INFO_INT);
	}
	else if(methodName.equals("getSortedAdjData")) {
		System.out.println("loading sorted adjustment Data");
		GL35Logger.logThis("loading sorted adjustment Data", Priority.INFO_INT);
		startIndex = 1;
		endIndex = noOfPagesLoaded*paginationNumber;
		System.out.println("Entering DAO with sortCol="+sortCol+" and sortOrder="+sortOrder);
		GL35Logger.logThis("Entering DAO with sortCol="+sortCol+" and sortOrder="+sortOrder, Priority.INFO_INT);
	}
	searchBean.setStartIndex(startIndex);
	searchBean.setEndIndex(endIndex);
	
	if(!(selectedDimValuesString.equals(""))) {
		searchBean.setDimSearchNeeded(true);
		searchBean.setSelectedDimValues(selectedDimValuesString);
		GL35Logger.logThis("Corr Edit Action: dim search needed = true and selectedDimValuesString="+selectedDimValuesString, Priority.DEBUG_INT);
	}
	
	
	setAdjustmentList(EditPageDAO.getAdjustmentData(searchBean,sInfodom,sUserId));
	if(adjustmentList.size() != 0) {
		setDimensionsArray(adjustmentList.get(0).getDimensionsArray());
		setDimensionsArrayOpt(adjustmentList.get(0).getDimensionsArrayOpt());
		adjustmentList.remove(0);
		setRecordCount(adjustmentList.get(0).getRecordCount());
		System.out.println("Returning ADJUSTMENT LIST with size: "+adjustmentList.size()+" and Dimension Array with size: "+dimensionsArray.size()+":: Record Count="+getRecordCount());
		GL35Logger.logThis("Returning ADJUSTMENT LIST with size: "+adjustmentList.size()+" and Dimension Array with size: "+dimensionsArray.size()+":: Record Count="+getRecordCount(), Priority.INFO_INT);
	}	
	//request.setAttribute("isSuccess", "SUCCESS");
	return SUCCESS;
	}catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		GL35Logger.logThis("Exception occured : "+e.getLocalizedMessage(), Priority.ERROR_INT);
		return ERROR;
	}
		
}

	/*public String loadDimList() {
		String manDim = "";

		if(!(this.getManDim() == null))
			manDim = getManDim();
		System.out.println("loading dim list");
		GL35Logger.logThis("loading dim list", Priority.INFO_INT);
		System.out.println("manDim="+manDim);
		GL35Logger.logThis("manDim="+manDim, Priority.INFO_INT);
		String output = EditPageDAO.getDimensionArray(manDim,sInfodom);
		inputStream = new StringBufferInputStream(output);
		return SUCCESS;
	}*/

	
	
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public List<String> getDimensionsArray() {
		return dimensionsArray;
	}
	public void setDimensionsArray(List<String> dimensionsArray) {
		this.dimensionsArray = dimensionsArray;
	}
	public List<String> getDimensionsArrayOpt() {
		return dimensionsArrayOpt;
	}
	public void setDimensionsArrayOpt(List<String> dimensionsArrayOpt) {
		this.dimensionsArrayOpt = dimensionsArrayOpt;
	}
	public List<EditPageSummaryBean> getAdjustmentList() {
		return adjustmentList;
	}
	public void setAdjustmentList(List<EditPageSummaryBean> adjustmentList) {
		this.adjustmentList = adjustmentList;
	}


	public String getManDim() {
		return manDim;
	}
	public void setManDim(String manDim) {
		this.manDim = manDim;
	}

	public String getExpAmountLowerBound() {
		return expAmountLowerBound;
	}
	public void setExpAmountLowerBound(String expAmountLowerBound) {
		this.expAmountLowerBound = expAmountLowerBound;
	}
	public String getExpAmountUpperBound() {
		return expAmountUpperBound;
	}
	public void setExpAmountUpperBound(String expAmountUpperBound) {
		this.expAmountUpperBound = expAmountUpperBound;
	}
	public String getSelectedPPs() {
		return selectedPPs;
	}
	public void setSelectedPPs(String selectedPPs) {
		this.selectedPPs = selectedPPs;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}


	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		this.setRequest(arg0);
	}
	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		this.setResponse(arg0);
	}

	public List<com.ofs.erm.gl.model.EleBrDimInputListBean> getEleBrDimList() {
		return eleBrDimList;
	}
	public void setEleBrDimList(List<com.ofs.erm.gl.model.EleBrDimInputListBean> eleBrDimList) {
		this.eleBrDimList = eleBrDimList;
	}

	public String getEditExecutionId() {
		return editExecutionId;
	}
	public void setEditExecutionId(String editExecutionId) {
		this.editExecutionId = editExecutionId;
	}
	public String getEditMapId() {
		return editMapId;
	}
	public void setEditMapId(String editMapId) {
		this.editMapId = editMapId;
	}
	public String getEditGlDate() {
		return editGlDate;
	}
	public void setEditGlDate(String editGlDate) {
		this.editGlDate = editGlDate;
	}

	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	//private AdjustmentSummaryBean adjSummBean;
//	private AdjEntrySearchBean adjSearchBean;
	


	
	public PPListBean getPpListBean() {
		return ppListBean;
	}
	public EleBrDimInputListBean getEleBrDimBean() {
		return eleBrDimBean;
	}
	public void setEleBrDimBean(EleBrDimInputListBean eleBrDimBean) {
		this.eleBrDimBean = eleBrDimBean;
	}
	public void setPpListBean(PPListBean ppListBean) {
		this.ppListBean = ppListBean;
	}

	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSortCol() {
		return sortCol;
	}
	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}
	public List<PPListBean> getPpList() {
		return ppList;
	}
	public void setPpList(List<PPListBean> ppList) {
		this.ppList = ppList;
	}
	public List<MapNameBean> getMapArray() {
		return mapArray;
	}
	public void setMapArray(List<MapNameBean> mapArray) {
		this.mapArray = mapArray;
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	public HttpServletResponse getResponse() {
		return response;
	}
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public String getsInfodom() {
		return sInfodom;
	}
	public void setsInfodom(String sInfodom) {
		this.sInfodom = sInfodom;
	}
	public String getSelectedAdjExposureId() {
		return selectedAdjExposureId;
	}
	public void setSelectedAdjExposureId(String selectedAdjExposureId) {
		this.selectedAdjExposureId = selectedAdjExposureId;
	}
	public List<CorrecEntryEditSummaryBean> getCorrectionList() {
		return correctionList;
	}
	public void setCorrectionList(List<CorrecEntryEditSummaryBean> correctionList) {
		this.correctionList = correctionList;
	}


	public String getEditVersionNumber() {
		return editVersionNumber;
	}

	public void setEditVersionNumber(String editVersionNumber) {
		this.editVersionNumber = editVersionNumber;
	}

	public String getEditedDefaultValues() {
		return editedDefaultValues;
	}

	public void setEditedDefaultValues(String editedDefaultValues) {
		this.editedDefaultValues = editedDefaultValues;
	}

	public String getsUserId() {
		return sUserId;
	}

	public void setsUserId(String sUserId) {
		this.sUserId = sUserId;
	}

	public String getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(String submitStatus) {
		this.submitStatus = submitStatus;
	}

	public String getSelectedDimValues() {
		return selectedDimValues;
	}

	public void setSelectedDimValues(String selectedDimValues) {
		this.selectedDimValues = selectedDimValues;
	}

	public String getCorrectionExposureId() {
		return correctionExposureId;
	}

	public void setCorrectionExposureId(String correctionExposureId) {
		this.correctionExposureId = correctionExposureId;
	}

	public String getAdjustmentExposureId() {
		return adjustmentExposureId;
	}

	public void setAdjustmentExposureId(String adjustmentExposureId) {
		this.adjustmentExposureId = adjustmentExposureId;
	}


	public String getSelectedAdjExposureIds() {
		return selectedAdjExposureIds;
	}


	public void setSelectedAdjExposureIds(String selectedAdjExposureIds) {
		this.selectedAdjExposureIds = selectedAdjExposureIds;
	}


	public String getPage() {
		return page;
	}


	public void setPage(String page) {
		this.page = page;
	}


	public String getAuthCorr_Values() {
		return authCorr_Values;
	}


	public void setAuthCorr_Values(String authCorr_Values) {
		this.authCorr_Values = authCorr_Values;
	}


	public String getAuthorization_Status() {
		return authorization_Status;
	}


	public void setAuthorization_Status(String authorization_Status) {
		this.authorization_Status = authorization_Status;
	}


	@Override
	public void setSession(Map session) {
		// TODO Auto-generated method stub
		this.session = session;
	}

	public static Map getSession() {
		return session;
	}

}
