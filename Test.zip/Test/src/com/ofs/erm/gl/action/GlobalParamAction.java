/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GlobalParamAction.java
* Title         :
* Description   :
* @author       : Deepak Dagar 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.action;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import umm.bi.ClsUEntHierarchy;
import umm.bi.ClsUEntHierarchyNode;

import com.iflex.fic.client.SecureBusinessMetaData;
import com.iflex.fic.ficml.JSPInitBean;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.GlobalParameters;
import com.ofs.erm.gl.dao.GlobalParamAddDAO;
import com.ofs.erm.gl.dao.GlobalParamDao;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.GlobalParamAddBean;
import com.ofs.erm.gl.model.GlobalParamSearchBean;
import com.ofs.erm.gl.model.GlobalParamSummaryBean;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Priority;
import com.ofs.erm.gl.global.GL35Logger;


public class GlobalParamAction extends ActionSupport implements
ServletRequestAware, ServletResponseAware ,SessionAware
{
	private List<GlobalParamSummaryBean> globalParamList;
	private boolean checkBox;
	private String paginationNumber,currentPage,actionId,status;
	static String selinfodom;
	private static String userId;
	private String searchLegalEntity;
	private String sortOrder;
	private String sortCol,methodName;
	private String LEConsolString;
	private int rowCount;
	protected HttpServletRequest request;
	protected HttpServletResponse response;
    private List<GlobalParamAddBean> legalEntityArray;
	private static String slocale;
	private int noOfPagesLoaded = 2;
	private static Map session;
	
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	public String getSelinfodom() {
		return selinfodom;
	}

	public void setSelinfodom(String infodom) {
		this.selinfodom = infodom;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSlocale() {
		return slocale;
	}

	public void setSlocale(String slocale) {
		this.slocale = slocale;
	}

	public List<GlobalParamAddBean> getLegalEntityArray() {
		return legalEntityArray;
	}

	public void setLegalEntityArray(List<GlobalParamAddBean> legalEntityArray) {
		this.legalEntityArray = legalEntityArray;
	}


	public List<GlobalParamSummaryBean> getGlobalParamList() {
		return globalParamList;
	}

	public void setGlobalParamList(List<GlobalParamSummaryBean> globalParamList) {
		this.globalParamList = globalParamList;
	}

	public boolean isCheckBox() {
		return checkBox;
	}

	public void setCheckBox(boolean checkBox) {
		this.checkBox = checkBox;
	}

	public String getPaginationNumber() {
		return paginationNumber;
	}

	public void setPaginationNumber(String paginationNumber) {
		this.paginationNumber = paginationNumber;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}


	public String getSearchLegalEntity() {
		return searchLegalEntity;
	}

	public void setSearchLegalEntity(String searchLegalEntity) {
		this.searchLegalEntity = searchLegalEntity;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getSortCol() {
		return sortCol;
	}

	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public String getLEConsolString() {
		return LEConsolString;
	}

	public void setLEConsolString(String consolString) {
		this.LEConsolString = consolString;
	}

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String globalParamSummaryAction() {
		
		int paginationNumber = 0;
		int currentPage = 0;
		String sortCol = getSortCol();
		String sortOrder = getSortOrder();
		String searchLegalEntity = getSearchLegalEntity();
		String methodName = getMethodName();
		String infodom = getSelinfodom();
		String userId = getUserId();
		String slocale=getSlocale();
		GL35Logger.logThis("methodName => "+methodName + ": infodom=" + infodom +": userId=" + userId, Priority.DEBUG_INT);
		
		int startIndex = 0;
		int endIndex = 0;
		GlobalParamSearchBean searchBean = new GlobalParamSearchBean();
		searchBean.setRecordCountNeeded(false);
		globalParamList = new ArrayList<GlobalParamSummaryBean>();
		
		if(!(getPaginationNumber() == null))
			paginationNumber = Integer.parseInt(getPaginationNumber());
		if(!(getCurrentPage() == null))
			currentPage = Integer.parseInt(getCurrentPage());
		if(sortCol == null)
			sortCol = "";
		if(sortOrder == null)
			sortOrder = "";
		if(searchLegalEntity == null)
			searchLegalEntity = "";
		
		if(methodName == null) {
			startIndex = 1;
			endIndex = 2*15;
			searchLegalEntity = "";
		
			sortCol = "";
			sortOrder = "";
			searchBean.setRecordCountNeeded(true);
			
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction - Reset method- "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		
		else if(methodName.equals("getNextPage")) {
			startIndex = (paginationNumber * currentPage) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction  - getNextPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getPrevPage")) {
			startIndex = (paginationNumber * (currentPage-3)) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction  - getPrevPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getFirstPage")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction  - getFirstPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getLastPage")) {
			if((currentPage % 2) == 0) { // 2 here in this if loop is no of pages to load
				startIndex = (paginationNumber * (currentPage - 2)) + 1; 
				endIndex = startIndex + (2*paginationNumber) - 1;
			}
			else {
				GL35Logger.logThis("INSIDE getLastPage loop currentPage="+currentPage+"paginationNumber="+paginationNumber+startIndex+endIndex, Priority.DEBUG_INT);
				startIndex = (paginationNumber * (currentPage - 1)) + 1;
				endIndex = startIndex + ((2-1)*paginationNumber) - 1;
			}
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction  - getLastPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("search")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			searchBean.setRecordCountNeeded(true);
			
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction  - search - "+startIndex+endIndex+paginationNumber+currentPage+searchLegalEntity, Priority.DEBUG_INT);
		}
		else if(methodName.equals("sort")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction  - sort - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("reset")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			searchLegalEntity = "";
		
			sortCol = "";
			sortOrder = "";
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction - reset - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getLegalEntityArray")) {
			String hiercode = GlobalUtil.getLegalHierCode(getSelinfodom()); 
			setLegalEntityArray(this.getHierNodes(getSelinfodom(),getUserId(),hiercode,"Search",slocale));
			GL35Logger.logThis("Action Class - GlobalParamSummaryAction - getLegalEntityArray! Returning from GlobalParamSummaryAction! LegalEntityArray size = "+legalEntityArray.size(), Priority.DEBUG_INT);
			return SUCCESS;
		}
		else if(methodName.equals("changePagination")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - GlobalParamSummaryActionAction - change Pagination - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		
			
		searchBean.setSearchLegalEntity(searchLegalEntity);
		searchBean.setSortCol(sortCol);
		searchBean.setSortOrder(sortOrder);
		searchBean.setStartIndex(startIndex);
		searchBean.setEndIndex(endIndex);
		GL35Logger.logThis("before calling ", Priority.DEBUG_INT);
		
		globalParamList =GlobalParamDao.getGlobalParamData(searchBean,infodom,userId,slocale);
		//System.out.println("After DAO");
		if((methodName == null) ||(methodName.equals("search")) || (methodName.equals("reset"))) {
			if(globalParamList.size() == 0) {
				GL35Logger.logThis("Zero length Record Set", Priority.DEBUG_INT);
				rowCount = 0;
			}
			else {
				rowCount = globalParamList.get(0).getRecordCount();
			}
		}
		//System.out.println("coming out of action");
		GL35Logger.logThis("Global Param Action Class -- returning from Action", Priority.DEBUG_INT);
		return SUCCESS;
	}
	
	public String delete()
	{
		String legalConsolString = getLEConsolString();
		String infodom = getSelinfodom();
		String userId = getUserId();
		String locale="";
		locale = getSlocale();
		GL35Logger.logThis("LEConsolSt ring => "+legalConsolString, Priority.DEBUG_INT);
		
			String[] legalConsolArray = legalConsolString.split("#");
			String[] legalEntityArray = new String[legalConsolArray.length];
		//	String[] consolTypeArray = new String[legalConsolArray.length];
			String[] tempArray;
			for(int i=0;i<legalConsolArray.length;i++)
			{
				//tempArray = legalConsolArray[i].split("-");
				legalEntityArray[i] =  legalConsolArray[i];
			//	consolTypeArray[i] = tempArray[1];
				
			}
			this.setStatus(GlobalParamDao.deleteRows(legalEntityArray,infodom,userId,locale));
			GL35Logger.logThis("Status of delete function - " + this.status, Priority.DEBUG_INT);
			
			return SUCCESS;
	}
	
	
	static List<GlobalParamAddBean> getHierNodes(String sel_infodom,String userid ,String hiercode,String mode,String locale)
	{
		GL35Logger.logThis("In getHierNodes Function of GlobalParamSummaryAction"+hiercode+":"+sel_infodom+":"+userid, Priority.DEBUG_INT);
		LinkedHashMap hierMap = new LinkedHashMap();
		List<GlobalParamAddBean> legalEntityArray = new ArrayList<GlobalParamAddBean>();
		String nodecode ="";
		Cargo cr ;
		Vector levector = new Vector();
		if(mode.equalsIgnoreCase("add"))
		{
			
			levector = GlobalParamDao.getExistingLEs(sel_infodom,userid);
			GL35Logger.logThis("levector...."+levector.toString(), Priority.DEBUG_INT);
			
			
			
		}
		 cr = SecureBusinessMetaData.getMetaDataObjectFromServer(sel_infodom,userid, hiercode, GlobalParameters.BMD_SERVICE_TYPE_HIERARCHY,new Locale(locale));
		if (cr != null && !cr.getErrorFlag())
		{
			ClsUEntHierarchy hierarchy = (ClsUEntHierarchy) cr.getPayLoadObject();
			if(hierarchy!=null)
			{
				Vector vecHierarchyNodes = null;
				vecHierarchyNodes = hierarchy.getHierarchyNode();
				if(vecHierarchyNodes.size()>0)
				{
					ClsUEntHierarchyNode rootNode = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(0);
				}
				ClsUEntHierarchyNode node;
				int sizeOfHierarchyNodes = vecHierarchyNodes.size();
				if(mode.equalsIgnoreCase("add"))
				{
						for (int i = 1; i < sizeOfHierarchyNodes; i++)
						{
							node = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(i);
							nodecode = node.getUniqueCode();
							GL35Logger.logThis("getHierNodes...."+nodecode+"node.getShortDescription().."+node.getShortDescription(), Priority.DEBUG_INT);
							if(levector!=null && levector.size()>0)
							{
								 if((levector.contains(nodecode)))
								 {
									  GlobalParamAddBean tempbean = new GlobalParamAddBean();
									  tempbean.setLegEntityCode(nodecode);
									  tempbean.setLegEntityName(node.getShortDescription());
									  legalEntityArray.add(tempbean);
									  hierMap.put(nodecode,node.getShortDescription());
								 }else
									 hierMap.put(nodecode,node.getShortDescription());
							}else
							{
								//GlobalParamAddBean tempbean = new GlobalParamAddBean();
								//tempbean.setLegEntityCode(nodecode);
								//tempbean.setLegEntityName(node.getShortDescription());
							//	legalEntityArray.add(tempbean);
								hierMap.put(nodecode,node.getShortDescription());
							
								
							}
						}
				}else{for (int i = 1; i < sizeOfHierarchyNodes; i++)
				{
					node = (ClsUEntHierarchyNode) vecHierarchyNodes.elementAt(i);
					nodecode = node.getUniqueCode();
					GL35Logger.logThis("getHierNodes...."+nodecode+"node.getShortDescription().."+node.getShortDescription(), Priority.DEBUG_INT);
					GlobalParamAddBean tempbean = new GlobalParamAddBean();
					tempbean.setLegEntityCode(nodecode);
					tempbean.setLegEntityName(node.getShortDescription());
					legalEntityArray.add(tempbean);
					hierMap.put(nodecode,node.getShortDescription());
				}
				}

			}
		}
		return legalEntityArray;
	}

	public void setSession(Map session) {
		// TODO Auto-generated method stub
		session = session;
	}
	public static Map getSession() {
		// TODO Auto-generated method stub
		return session;
	}
}

