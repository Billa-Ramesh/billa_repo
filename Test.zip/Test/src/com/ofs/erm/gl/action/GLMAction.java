/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : GLMAction.java
Created By            : Rahul M 
Created On            : Jul 2, 2012
Application Name      : General Ledger 
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/

package com.ofs.erm.gl.action;

import java.io.InputStream;
import java.io.StringBufferInputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Priority;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.ofs.erm.gl.dao.GLMUtil;

import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.GLMModel;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class GLMAction extends ActionSupport implements
ServletRequestAware, ServletResponseAware, SessionAware,ModelDriven{

	private static Map session;
	HttpServletRequest request;
	HttpServletResponse response;
	private InputStream inputStream;

	public InputStream getInputStream() {
	    return inputStream;
	   }
	@Override
	public void setSession(Map session) {
		// TODO Auto-generated method stub
		this.session = session;
	}

	public static Map getSession() {
		return session;
	}
	@Override
	public void setServletResponse(HttpServletResponse response) {
		// TODO Auto-generated method stub
		this.response = response;
	}

	public HttpServletResponse getResponse() {
		// TODO Auto-generated method stub
		return ServletActionContext.getResponse();
	}
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	GLMModel glmModel = new GLMModel();
	@Override
	public Object getModel() {
		// TODO Auto-generated method stub
		return glmModel;
	}

	private Map glTypeMap;
	private Map intraGrpMap,isAutoApproveMap;
	private String glBookHierCode;
	private String glCodeHierCode;
	
	public static String userId;
	
	public Map getGlTypeMap() {
		return glTypeMap;
	}

	public void setGlTypeMap(Map glTypeMap) {
		this.glTypeMap = glTypeMap;
	}

	public Map getIntraGrpMap() {
		return intraGrpMap;
	}

	public void setIntraGrpMap(Map intraGrpMap) {
		this.intraGrpMap = intraGrpMap;
	}

	public Map getIsAutoApproveMap() {
		return isAutoApproveMap;
	}
	public void setIsAutoApproveMap(Map isAutoApproveMap) {
		this.isAutoApproveMap = isAutoApproveMap;
	}
	public String getGlBookHierCode() {
		return glBookHierCode;
	}

	public void setGlBookHierCode(String glBookHierCode) {
		this.glBookHierCode = glBookHierCode;
	}

	public String getGlCodeHierCode() {
		return glCodeHierCode;
	}

	public void setGlCodeHierCode(String glCodeHierCode) {
		this.glCodeHierCode = glCodeHierCode;
	}

	public String openGLM(){
		try{
			
		
		String langCode = session.get("lclPostFix").toString(); 
		String infoDom = request.getParameter("infoDom");
		userId = request.getParameter("userName");
		
		String glTypeCode = GlobalUtil.getParamValue("GL_TYPE_HIERCODE", infoDom); 
		glTypeMap = GlobalUtil.getHierNodeDesc(infoDom, userId, glTypeCode);
		
		intraGrpMap = GlobalUtil.getLookUpData("17",langCode,infoDom);
		isAutoApproveMap = GlobalUtil.getLookUpData("17",langCode,infoDom);
		
		String glBookCd = GlobalUtil.getParamValue("GLBOOK_TYPE_HIERCODE", infoDom);
		this.setGlBookHierCode(glBookCd);
		
		String glHierCd = GlobalUtil.getParamValue("GL_CODE_HIERCODE", infoDom);
		this.setGlCodeHierCode(glHierCd);
		
		java.text.SimpleDateFormat sd = new java.text.SimpleDateFormat("MM-dd-yy");
		String sCreatedDate = sd.format(new java.util.Date());		
		
		glmModel.setCreatedBy(userId);
		glmModel.setCreatedDate(sCreatedDate);
		
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				GL35Logger.logThis("Exiting Page Open Action - Failure...",Priority.DEBUG_INT);
				request.setAttribute("isSuccess", "false");
				return ERROR;
			}
			GL35Logger.logThis("Exiting Page Open Action - Success...",Priority.DEBUG_INT);
			request.setAttribute("isSuccess", "true");
			return SUCCESS;
		
	}
	
	public String editGLM(){
		
		try{
			
			String retVal = "";
			
			openGLM();
			
			String glAcntCode = request.getParameter("glAcntCode");
			GLMUtil glmUtil = new GLMUtil();
			glmModel.setGlCode(glAcntCode);
			retVal = glmUtil.getFormData(glmModel,request.getParameter("infoDom"),this);

			if(retVal.equals(SUCCESS)){
				request.setAttribute("isSuccess", "true");
				GL35Logger.logThis("Exiting Edit Page Open Action - Success...",Priority.DEBUG_INT);
				return SUCCESS;
			}
			else{
				request.setAttribute("isSuccess", "false");
				GL35Logger.logThis("Exiting Edit Page Open Action - Failure...",Priority.DEBUG_INT);
				return ERROR;
			}

			
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				GL35Logger.logThis("Exiting Edit Page Open Action - Failure...",Priority.DEBUG_INT);
				request.setAttribute("isSuccess", "false");
				return ERROR;
			}
	}

	public String saveGLM(){
		
		try{
			
			String retVal = "";
			userId = request.getParameter("userId");			
			
			String pgMode = glmModel.getPgMode();
			GLMUtil glmUtil = new GLMUtil();
			
			if(pgMode.equals("CREATE")){

				java.text.SimpleDateFormat sd = new java.text.SimpleDateFormat("MM-dd-yy");
				String sCreatedDate = sd.format(new java.util.Date());		
				
				glmModel.setCreatedBy(userId);
				glmModel.setCreatedDate(sCreatedDate);
				retVal = glmUtil.createGLM(glmModel,request.getParameter("infoDom"),this);	
			}
			else if(pgMode.equals("EDIT")){
				glmModel.setModifiedBy(userId);
				java.text.SimpleDateFormat sd = new java.text.SimpleDateFormat("MM-dd-yy");
				String sModDate = sd.format(new java.util.Date());		
				

				glmModel.setModifiedDate(sModDate);
				retVal = glmUtil.updateGLM(glmModel,request.getParameter("infoDom"),this);
			}

			if(retVal.equals(SUCCESS)){
				request.setAttribute("isSuccess", "true");
				GL35Logger.logThis("Exiting Edit Page Open Action - Success...",Priority.DEBUG_INT);
				return SUCCESS;
			}
			else{
				request.setAttribute("isSuccess", "false");
				GL35Logger.logThis("Exiting Edit Page Open Action - Failure...",Priority.DEBUG_INT);
				return ERROR;
			}

			
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				GL35Logger.logThis("Exiting Edit Page Open Action - Failure...",Priority.DEBUG_INT);
				request.setAttribute("isSuccess", "false");
				return ERROR;
			}
	}

	@SuppressWarnings("deprecation")
	public String genericAjax(){
		
		GL35Logger.logThis("Entering genericAjax for GLM...",Priority.DEBUG_INT);
		int mode;		
		
		String infoDom = request.getParameter("infoDom");

		try{
			mode = Integer.parseInt(request.getParameter("mode").toString());
		}
		catch(NumberFormatException ne){
			GL35Logger.logThis("Number Format Exception...",Priority.ERROR_INT);
			mode = 0;
		}
		GLMUtil gu = new GLMUtil();
		String retVal = "";
		retVal = gu.processAjax(infoDom,mode,this,request);
		
		inputStream = new StringBufferInputStream(retVal);
		request.setAttribute("isSuccess", "true");

		return SUCCESS;
		}		
}

