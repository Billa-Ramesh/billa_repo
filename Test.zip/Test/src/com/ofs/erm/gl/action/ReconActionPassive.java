/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : ReconActionPassive.java
Created By            : Manoj Cherukumalli 
Created On            : April 26th, 2012
Application Name      : General Ledger 
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/
package com.ofs.erm.gl.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Priority;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.ofs.erm.gl.dao.PassiveReconSummaryDAO;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GLCommon;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.ConsolidationBean;
import com.ofs.erm.gl.model.LegalEntityBean;
import com.ofs.erm.gl.model.ReconSearchBean;
import com.ofs.erm.gl.model.ReconSummaryBean;
import com.opensymphony.xwork2.ActionSupport;

public class ReconActionPassive extends ActionSupport implements
		ServletRequestAware, ServletResponseAware, SessionAware
{
	private static Map session;
	private List<ReconSummaryBean> reconList;
	private boolean checkBox;
	private String paginationNumber,currentPage,actionId;
	private String searchName;
	private String searchConsolType;
	private String searchReconType;
	private String searchLegalEntity;
	private String sortOrder;
	private String sortCol,methodName;
	private String selinfodom,infodom,userId,status;
	private int rowCount;
	protected HttpServletRequest request;
	protected HttpServletResponse response;
	private int noOfPagesLoaded = 2;
	private List<ConsolidationBean> consolArray;
	private List<LegalEntityBean> legalEntityArray;
	
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		
	}

	public List<LegalEntityBean> getLegalEntityArray() {
		return legalEntityArray;
	}

	public void setLegalEntityArray(List<LegalEntityBean> legalEntityArray) {
		this.legalEntityArray = legalEntityArray;
	}

	public List<ConsolidationBean> getConsolArray() {
		return consolArray;
	}

	public void setConsolArray(List<ConsolidationBean> consolArray) {
		this.consolArray = consolArray;
	}

	public List<ReconSummaryBean> getReconList() {
		return reconList;
	}

	public void setReconList(List<ReconSummaryBean> reconList) {
		this.reconList = reconList;
	}

	public boolean isCheckBox() {
		return checkBox;
	}

	public void setCheckBox(boolean checkBox) {
		this.checkBox = checkBox;
	}

	public String getPaginationNumber() {
		return paginationNumber;
	}

	public void setPaginationNumber(String paginationNumber) {
		this.paginationNumber = paginationNumber;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public String getSearchName() {
		return searchName;
	}

	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}

	public String getSearchConsolType() {
		return searchConsolType;
	}

	public void setSearchConsolType(String searchConsolType) {
		this.searchConsolType = searchConsolType;
	}

	public String getSearchReconType() {
		return searchReconType;
	}

	public void setSearchReconType(String searchReconType) {
		this.searchReconType = searchReconType;
	}

	public String getSearchLegalEntity() {
		return searchLegalEntity;
	}

	public void setSearchLegalEntity(String searchLegalEntity) {
		this.searchLegalEntity = searchLegalEntity;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getSortCol() {
		return sortCol;
	}

	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getSelinfodom() {
		return selinfodom;
	}

	public void setSelinfodom(String infodom) {
		this.selinfodom = infodom;
	}

	public String getInfodom() {
		return infodom;
	}

	public void setInfodom(String infodom) {
		this.infodom = infodom;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public String reconSummaryPassiveAction() {
		GL35Logger.logThis("In Recon Summary Passive Action", Priority.DEBUG_INT);
		int paginationNumber = 0;
		int currentPage = 0;
		String sortCol = getSortCol();
		String sortOrder = getSortOrder();
		String searchName = getSearchName();
		String searchLegalEntity = getSearchLegalEntity();
		String searchConsolType = getSearchConsolType();
		String searchReconType = getSearchReconType();
		String methodName = getMethodName();
		String infodom = getSelinfodom();
		int startIndex = 0;
		int endIndex = 0;
		ReconSearchBean searchBean = new ReconSearchBean();
		searchBean.setRecordCountNeeded(false);
		reconList = new ArrayList<ReconSummaryBean>();
		
//		setConsolArray(GlobalParamAddDAO.getConsolidationArray(getInfodom()));
//		if(getConsolArray().get(1).getConsolDesc() == "Error")
//		{
//			setStatus("false");
//			GL35Logger.logThis("Status = " + getStatus(), Priority.DEBUG_INT);
//			return SUCCESS;
//		}
		
		if(!(getPaginationNumber() == null))
			paginationNumber = Integer.parseInt(getPaginationNumber());
		if(!(getCurrentPage() == null))
			currentPage = Integer.parseInt(getCurrentPage());
		if(sortCol == null)
			sortCol = "";
		if(sortOrder == null)
			sortOrder = "";
		if(searchName == null)
			searchName = "";
		if(searchLegalEntity == null)
			searchLegalEntity = "";
		if(searchConsolType == null)
			searchConsolType = "";
		if(searchReconType == null)
			searchReconType = "";
		if(infodom == null)
			infodom = "";

		if(methodName == null) {
			startIndex = 1;
			endIndex = 2*15;
			searchName = "";
			searchLegalEntity = "";
			searchConsolType = "";
			searchReconType = "";
			sortCol = "";
			sortOrder = "";
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - reconSummaryAction - reset - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getNextPage")) {
			startIndex = (paginationNumber * currentPage) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			GL35Logger.logThis("Action Class - reconSummaryAction  - getNextPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getPrevPage")) {
			startIndex = (paginationNumber * (currentPage-3)) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			GL35Logger.logThis("Action Class - reconSummaryAction  - getPrevPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getFirstPage")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - reconSummaryAction  - getFirstPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getLastPage")) {
			if((currentPage % 2) == 0) { // 2 here in this if loop is no of pages to load
				startIndex = (paginationNumber * (currentPage - 2)) + 1; 
				endIndex = startIndex + (2*paginationNumber) - 1;
			}
			else {
				GL35Logger.logThis("INSIDE getLastPage loop currentPage="+currentPage+"paginationNumber="+paginationNumber+startIndex+endIndex, Priority.DEBUG_INT);
				startIndex = (paginationNumber * (currentPage - 1)) + 1;
				endIndex = startIndex + ((2-1)*paginationNumber) - 1;
			}
			GL35Logger.logThis("Action Class - reconSummaryAction  - getLastPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("search")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - reconSummaryAction  - search - "+startIndex+endIndex+paginationNumber+currentPage+searchName+searchLegalEntity+searchConsolType+searchReconType, Priority.DEBUG_INT);
		}
		else if(methodName.equals("sort")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - reconSummaryAction  - sort - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("reset")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			searchName = "";
			searchLegalEntity = "";
			searchConsolType = "";
			searchReconType = "";
			sortCol = "";
			sortOrder = "";
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - reset - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getMapArray")) {
		}
		else if(methodName.equals("changePagination")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - adjustmentSummaryAction - change Pagination - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getConsolArray")) {
			setConsolArray(getConsolidationArray(getInfodom(),16));
			GL35Logger.logThis("Action class- ReconAction - get consol array with size="+getConsolArray().size(), Priority.DEBUG_INT);
			
			if(getConsolArray().get(1).getConsolDesc() == "Error")
			{
				setStatus("false");
			}
			GL35Logger.logThis("Status = " + getStatus(), Priority.DEBUG_INT);
			return SUCCESS;
		}
		else if(methodName.equals("getLegalEntityArray")) {
			String hiercode = GlobalUtil.getLegalHierCode(getInfodom()); 
			GL35Logger.logThis("hiercode="+hiercode+"infodom="+getInfodom(), Priority.DEBUG_INT);
			setLegalEntityArray(GLCommon.getHierNodesList(getInfodom(),getUserId(),hiercode));
			GL35Logger.logThis("returning from ReconAction"+legalEntityArray.size(), Priority.DEBUG_INT);
			return SUCCESS;
		}
			
		searchBean.setSearchName(searchName);
		searchBean.setSearchLegalEntity(searchLegalEntity);
		searchBean.setSearchConsolType(searchConsolType);
		searchBean.setSearchReconType(searchReconType);
		searchBean.setSortCol(sortCol);
		searchBean.setSortOrder(sortOrder);
		searchBean.setStartIndex(startIndex);
		searchBean.setEndIndex(endIndex);
		
		reconList =PassiveReconSummaryDAO.getReconData(searchBean,infodom,userId);
		
		if((methodName == null) ||(methodName.equals("search")) || (methodName.equals("reset"))) {
			if(reconList.size() == 0) {
				GL35Logger.logThis("Zero length Record Set", Priority.DEBUG_INT);
				rowCount = 0;
			}
			else {
				rowCount = reconList.get(0).getRecordCount();
			}
		}
		
		if(!(reconList.size() == 0)) {
			if(reconList.get(0).getMapId() == null) {
				GL35Logger.logThis("Infodom Error..", Priority.DEBUG_INT);
				setStatus("false");
				GL35Logger.logThis("Status = " + getStatus(), Priority.DEBUG_INT);
				return SUCCESS;
			}
		}
		
		GL35Logger.logThis("Recon Action Class -- returning from Action", Priority.DEBUG_INT);
		return SUCCESS;
	}
	
	public static List<ConsolidationBean> getConsolidationArray(String infodom,int lookupCode) {
		
		String langCode = session.get("lclPostFix").toString();
		//System.out.println("Entering logger dao! getConsolidationArray of GlobalParamAddDAO");
		String query = "SELECT B.V_CATEGORY_ID, B.V_CATEGORY_DESC, C.N_SORT_ORDER from FSI_GL_LOOKUP_TL A, FSI_GL_LOOKUP_MASTER B, FSI_GL_LOOKUP_B C WHERE A.V_LOOKUP_CD = '"+lookupCode+"' AND A.V_CATEGORY_ID = B.V_CATEGORY_ID AND A.V_LANG_CODE = 'en_US' AND A.V_LOOKUP_CD = B.V_LOOKUP_CD AND C.V_LOOKUP_CD = '"+lookupCode+"' AND A.V_CATEGORY_ID = C.V_CATEGORY_ID ORDER BY C.N_SORT_ORDER";
		List<ConsolidationBean> consolArray = new ArrayList<ConsolidationBean>();
		ConsolidationBean tempBean1 = new ConsolidationBean();
	    tempBean1.setConsolId("");
		tempBean1.setConsolDesc("");
		consolArray.add(tempBean1);
		Cargo FindCountCargo = (Cargo) SMSServices.executeQuery(infodom,query,false);
		
		if(FindCountCargo.getErrorFlag())
		{
			GL35Logger.logThis("Error while retrieving from Database - Inside ReconActionActive", Priority.DEBUG_INT);
			ConsolidationBean tempBean = new ConsolidationBean();
			tempBean.setConsolId("1");
			tempBean.setConsolDesc("Error");
			consolArray.add(tempBean);
		}
		else
		{
			DACRecordSet resultSet = (DACRecordSet) FindCountCargo.getPayLoadObject();
		
			while(!resultSet.EOF()) {
				ConsolidationBean tempBean = new ConsolidationBean();
				tempBean.setConsolId(resultSet.fetchElement(1));
				tempBean.setConsolDesc(resultSet.fetchElement(2));
				consolArray.add(tempBean);
				resultSet.moveNext();
			}
		}
		return consolArray;
	}

	@Override
	public void setSession(Map session) {
		// TODO Auto-generated method stub
		this.session = session;
	}

	public static Map getSession() {
		// TODO Auto-generated method stub
		return session;
	}
}
