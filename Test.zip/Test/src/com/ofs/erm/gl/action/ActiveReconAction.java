/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : ActiveReconAction.java
Created By            : Rahul Manoharan 
Created On            : April 20th, 2012
Application Name      : General Ledger v3.5
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/

package com.ofs.erm.gl.action;

import java.io.InputStream;
import java.io.StringBufferInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Priority;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.iflex.fic.client.SMSServices;
import com.iflex.fic.global.Cargo;
import com.iflex.fic.global.DACRecordSet;
import com.ofs.erm.gl.dao.ReconUtil;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GlobalUtil;
import com.ofs.erm.gl.model.ReconModel;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/*
 * The central action class for Active and 
 * Passive Reconciliation Definition Screens
 * 
 * @author  Rahul M
 */

public class ActiveReconAction extends ActionSupport implements SessionAware,
		ServletRequestAware, ServletResponseAware, ModelDriven {

	/**
	 *  
	 */
	private static final long serialVersionUID = 10L;

	/*Request should Carry Infodom*/
	HttpServletRequest request;
	HttpServletResponse response;
	private static Map session;
	
	
	
	ReconModel reconModel = new ReconModel(); 
	@Override
	public ReconModel getModel() {
		// TODO Auto-generated method stub
		return reconModel;
	}
	
	private InputStream inputStream;
	  public InputStream getInputStream() {
	    return inputStream;
	   }
	//Maps to populate drop-down's
	private Map consolType;
	private Map balType;
	private Map glType;
	private Map currVal;
	private Map thrshldSpec;
	private Map amtCol;
	private Map tpList;
	private Map glColForTp;
	
	//Maps to populate radioButtons
	private Map adjReq;
	private Map reconDefTyp;
	private Map adjAlloc;
	private Map adjPostTo;
	
	//ArrayLists to populate Tables in Edit/View Modes
	private ArrayList tpTabList;
	private ArrayList allocTabList;
	private ArrayList tpFilterList;
	private ArrayList glFilterList;
	private ArrayList dimTabList;
	private ArrayList allDimsList;
	private ArrayList defValList;
	
	//Strings to hold hiercodes
	private String legHierCode;
	private String glBookCode;
	
	//Dummy placeholders for misc. Data
	private String dummyStr1;
	private Map dummyMap1;
	private ArrayList dummyAl1;
	
	public ArrayList getDefValList() {
		return defValList;
	}

	public void setDefValList(ArrayList defValList) {
		this.defValList = defValList;
	}

	public ArrayList getDimTabList() {
		return dimTabList;
	}

	public void setDimTabList(ArrayList dimTabList) {
		this.dimTabList = dimTabList;
	}

	public String getLegHierCode() {
		return legHierCode;
	}

	public void setLegHierCode(String legHierCode) {
		this.legHierCode = legHierCode;
	}

	public String getGlBookCode() {
		return glBookCode;
	}

	public void setGlBookCode(String glBookCode) {
		this.glBookCode = glBookCode;
	}

	public ArrayList getTpTabList() {
		return tpTabList;
	}

	public void setTpTabList(ArrayList tpTabList) {
		this.tpTabList = tpTabList;
	}

	public ArrayList getAllDimsList() {
		return allDimsList;
	}

	public void setAllDimsList(ArrayList allDimsList) {
		this.allDimsList = allDimsList;
	}

	public ArrayList getAllocTabList() {
		return allocTabList;
	}

	public void setAllocTabList(ArrayList allocTabList) {
		this.allocTabList = allocTabList;
	}

	public ArrayList getTpFilterList() {
		return tpFilterList;
	}

	public void setTpFilterList(ArrayList tpFilterList) {
		this.tpFilterList = tpFilterList;
	}

	public ArrayList getGlFilterList() {
		return glFilterList;
	}

	public void setGlFilterList(ArrayList glFilterList) {
		this.glFilterList = glFilterList;
	}

	public Map getConsolType() {
		return consolType;
	}

	public void setConsolType(Map consolType) {
		this.consolType = consolType;
	}

	public Map getBalType() {
		return balType;
	}

	public void setBalType(Map balType) {
		this.balType = balType;
	}

	public Map getGlType() {
		return glType;
	}

	public void setGlType(Map glType) {
		this.glType = glType;
	}

	public Map getCurrVal() {
		return currVal;
	}

	public void setCurrVal(Map currVal) {
		this.currVal = currVal;
	}

	public Map getThrshldSpec() {
		return thrshldSpec;
	}

	public void setThrshldSpec(Map thrshldSpec) {
		this.thrshldSpec = thrshldSpec;
	}

	public Map getAmtCol() {
		return amtCol;
	}

	public void setAmtCol(Map amtCol) {
		this.amtCol = amtCol;
	}


	public ReconModel getReconModel() {
		return reconModel;
	}

	public void setReconModel(ReconModel reconModel) {
		this.reconModel = reconModel;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		// TODO Auto-generated method stub
		this.response = response;
	}

	public HttpServletResponse getResponse() {
		// TODO Auto-generated method stub
		return ServletActionContext.getResponse();
	}

	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	@Override
	public void setSession(Map session) {
		// TODO Auto-generated method stub
		this.session = session;
	}
	
	public static Map getSession() {
		// TODO Auto-generated method stub
		return session;
	}

	public Map getAdjReq() {
		return adjReq;
	}

	public void setAdjReq(Map adjReq) {
		this.adjReq = adjReq;
	}

	public Map getReconDefTyp() {
		return reconDefTyp;
	}

	public void setReconDefTyp(Map reconDefTyp) {
		this.reconDefTyp = reconDefTyp;
	}

	public Map getAdjAlloc() {
		return adjAlloc;
	}

	public void setAdjAlloc(Map adjAlloc) {
		this.adjAlloc = adjAlloc;
	}

	public Map getAdjPostTo() {
		return adjPostTo;
	}

	public void setAdjPostTo(Map adjPostTo) {
		this.adjPostTo = adjPostTo;
	}

	/**This method opens the Active Recon Definition screen.
	 * @return String
	 * 			Returns a String as Result.
	 * @throws Exception
	 * @mode CREATE
	 */
	
	public String openActRecon(){
		
		//	RequestParam KeySet = [method, versionNumber, pageMode, infoDom, userName, screenName, mapId]
		ReconUtil reconUtil = new ReconUtil();
		GlobalUtil globalUtil = new GlobalUtil();
		String infoDom = request.getParameter("infoDom");
		String userId = request.getParameter("userName");
		String isActOrPass = request.getParameter("screenName");
		
		// String langCode = "US";
		String langCode = session.get("lclPostFix").toString();
		
		GL35Logger.logThis("Entering Page Open Action...",Priority.DEBUG_INT);
		
		try {
			
			if(isActOrPass.equals("PASSIVE")){ 
				consolType = GlobalUtil.getLookUpData("16",langCode,infoDom);
			}
			else //Active
				consolType = GlobalUtil.getLookUpData("15",langCode,infoDom);

			if(isActOrPass.equals("PASSIVE")){ 
				balType = GlobalUtil.getLookUpData("2",langCode,infoDom); //populate all only in Passive case.
			}
			
			currVal = reconUtil.getCurrVal(infoDom);
			thrshldSpec = GlobalUtil.getLookUpData("5",langCode,infoDom);

			tpList = reconUtil.getTpList(infoDom);
			
			String glBookCd = GlobalUtil.getParamValue("GLBOOK_TYPE_HIERCODE", infoDom);
			this.setGlBookCode(glBookCd);
			
			this.setLegHierCode(GlobalUtil.getLegalHierCode(infoDom));
			
			glColForTp = new HashMap();
			glColForTp.put("a","b");
			
			adjReq = GlobalUtil.getLookUpData("3",langCode,infoDom);
			reconDefTyp = GlobalUtil.getLookUpData("4",langCode,infoDom);
			adjAlloc = GlobalUtil.getLookUpData("7",langCode,infoDom);
			adjPostTo = GlobalUtil.getLookUpData("8",langCode,infoDom);
			
			String glTypeCode = GlobalUtil.getParamValue("GL_TYPE_HIERCODE", infoDom); 
			glType = GlobalUtil.getHierNodeDesc(infoDom, userId, glTypeCode);
			
			//DIMENSIONS Data --> In Create Mode Fetch only Mandatory Dim's.
			GL35Logger.logThis("Fetching Mandatory Dimensions...",Priority.DEBUG_INT);
			StringBuffer sqlQuery1 = new StringBuffer("SELECT A.V_DIMENSION_HCY_CODE,A.V_DIMENSION_DESC "); 
			sqlQuery1.append(" FROM SETUP_GL_RECON_DIMENSIONS A");
			sqlQuery1.append(" WHERE A.F_RECON_OR_MANDATORY='M'");
			
			DACRecordSet resultSet1;
			ArrayList dimList = new ArrayList();
			Cargo cargo1;
			
			cargo1 = (Cargo) SMSServices.executeQuery(infoDom, sqlQuery1.toString(), false);
			resultSet1 = (DACRecordSet) cargo1.getPayLoadObject();
			while (!resultSet1.EOF() && resultSet1.getRowCount() > 0) {
				ReconModel recMod = new ReconModel();
				
				String tabName = GlobalUtil.getHierTable(infoDom,userId, resultSet1.fetchElement(1));
				recMod.setReconDimCode(resultSet1.fetchElement(1));
				recMod.setReconDim(resultSet1.fetchElement(2));
				recMod.setDesc(tabName);
				dimList.add(recMod);
				resultSet1.moveNext();
			}
			this.setAllDimsList(dimList);
			
			
			this.setConsolType(consolType);
			this.setBalType(balType);
			this.setGlType(glType);
			this.setCurrVal(currVal);
			this.setThrshldSpec(thrshldSpec);
			this.setAmtCol(amtCol);
			this.setAdjReq(adjReq);
			this.setAdjAlloc(adjAlloc);
			this.setReconDefTyp(reconDefTyp);
			this.setAdjPostTo(adjPostTo);
			this.setTpList(tpList);
			this.setGlColForTp(glColForTp);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			GL35Logger.logThis("Exiting Page Open Action - Failure...",Priority.DEBUG_INT);
			request.setAttribute("isSuccess", "false");
			return ERROR;
		}
		GL35Logger.logThis("Exiting Page Open Action - Success...",Priority.DEBUG_INT);
		request.setAttribute("isSuccess", "true");
		return SUCCESS;
	}
	@SuppressWarnings("deprecation")
	public String getGlCol(){
		
		GL35Logger.logThis("Entering getGlCol...", Priority.DEBUG_INT);
		
		ReconUtil reconUtil = new ReconUtil();
		
		String ppPhyColName = request.getParameter("txnEntityName");
		String infoDom = request.getParameter("infoDom");
		Map<String, String> glColMap = reconUtil.getGlCol(ppPhyColName,infoDom);
		String outHTML = "";
		outHTML += "<select name=\"selGlColForTp\" id=\"selGlColForTp\" class=\"option\" onchange=\"changeIsChangedFlag()\">";
		outHTML += "<option value= \"\">Select</option>";
		// outHTML += "<option value= \"-1\">Select</option>";
		
		for (Map.Entry entry : glColMap.entrySet())
		{
		   outHTML += "<option value= \"" +entry.getKey()+ "\">" + entry.getValue() + "</option>";
		}
		 
		 outHTML += "</select>";

		 //Get GlCol
		 Map<String,String> amtColMap = reconUtil.getAmtCol(ppPhyColName, infoDom);
			 
			 outHTML += "{*}";
		outHTML += "<select name=\"selAmtCol\" id=\"selAmtCol\" class=\"option\"  onchange=\"tpRowClick(this);changeIsChangedFlag()\" >";
		outHTML += "<option value= \"\">Select</option>";
		// outHTML += "<option value= \"-1\">Select</option>";
			
			 for (Map.Entry entry : amtColMap.entrySet())
				{
				   outHTML += "<option value= \"" +entry.getKey()+ "\">" + entry.getValue() + "</option>";
				}
				 
				 outHTML += "</select>";
	 
			// System.out.println(entry.getKey() + "/" + entry.getValue());
		 GL35Logger.logThis("Populating Stream...",Priority.DEBUG_INT);
		 inputStream = new StringBufferInputStream(outHTML);
		return SUCCESS;
	}
	
	
	@SuppressWarnings("deprecation")
	public String genericAjax(){
		
		GL35Logger.logThis("Entering genericAjax...",Priority.DEBUG_INT);
		
		ReconUtil reconUtil = new ReconUtil();
		int mode;
		String infoDom = request.getParameter("infoDom");
		try{
			mode = Integer.parseInt(request.getParameter("mode").toString());
		}
		catch(NumberFormatException ne){
			GL35Logger.logThis("Number Format Exception...",Priority.ERROR_INT);
			mode = 0;
		}

		String retVal = reconUtil.processAjax(infoDom,mode,this,request);
		inputStream = new StringBufferInputStream(retVal);
		request.setAttribute("isSuccess", "true");
		return SUCCESS;
		
	}
	public String saveActRecon() {

		GL35Logger.logThis("Entering saveActRecon...",Priority.DEBUG_INT);
		ArrayList alQueryList = new ArrayList();
		String result = ERROR;
	
		try {

			ReconUtil reconUtil = new ReconUtil();
			result = reconUtil.createRecon(reconModel,request.getParameter("infoDom"));

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			GL35Logger.logThis(e.getMessage(),Priority.ERROR_INT);
			request.setAttribute("isSuccess", "false");
			return ERROR;
		}
		if(result.equals("error"))
			request.setAttribute("isSuccess", "false");
		else
			request.setAttribute("isSuccess", "true");
		return result;
	}

	public String editActRecon(){
		
		GL35Logger.logThis("Entering editActRecon...",Priority.DEBUG_INT);
		
		String retVal = "";
		try{
			ReconUtil reconUtil = new ReconUtil();
			openActRecon();
			reconModel.setVersionNum(request.getParameter("versionNumber"));
			retVal = reconUtil.getFormData(reconModel,request.getParameter("infoDom"),this);
		}
		catch(Exception e){
			e.printStackTrace();
			GL35Logger.logThis(e.getMessage(),Priority.ERROR_INT);
			request.setAttribute("isSuccess", "false");
			return ERROR;
		}
		if(retVal.equals(SUCCESS)){
			request.setAttribute("isSuccess", "true");
			return SUCCESS;
		}
		else{
			request.setAttribute("isSuccess", "false");
			return ERROR;
		}
	}
	
	public String deleteActRecon(){
		
		GL35Logger.logThis("Entering deleteActRecon...",Priority.DEBUG_INT);
		
		String retStr = "";
		try{
			ReconUtil reconUtil = new ReconUtil();
			
			//deletedEntriesString=MAP006~0.1~@~MAP002 ~0.1~@~
			
			String delEntryStr = request.getParameter("deletedEntriesString").toString();
			String[] entry = delEntryStr.split("~@~");
			for(String s: entry){
				reconModel.setMapId(s.split("~")[0]);
				reconModel.setVersionNum(s.split("~")[1]);
				retStr = reconUtil.deleteMapping(reconModel,request.getParameter("infoDom"));
				
				if (retStr.equals(ERROR)) {
					this.inputStream = new StringBufferInputStream(retStr);
					return SUCCESS;
				}
 else if (retStr.equals("CannotDel")) {
					this.inputStream = new StringBufferInputStream(retStr);
					return SUCCESS;
				}
					
			}
		}
		catch(Exception e){
			e.printStackTrace();
			GL35Logger.logThis(e.getMessage(),Priority.ERROR_INT);
			this.inputStream = new StringBufferInputStream(ERROR);
			return SUCCESS;
		}
		this.inputStream = new StringBufferInputStream(SUCCESS);
		return SUCCESS;
	}
	
	/*Methods for Passive Recon. They mostly call the active recon methods */
	public String openPasRecon(){
		GL35Logger.logThis("Entering openActRecon...",Priority.DEBUG_INT);
		String retStr = openActRecon();
		return retStr;
	}
	
	public String editPasRecon(){
		GL35Logger.logThis("Entering editPasRecon...",Priority.DEBUG_INT);
		String retStr = editActRecon();
		return retStr;
		
	}
	
	public String savePasRecon(){
		GL35Logger.logThis("Entering savePasRecon...",Priority.DEBUG_INT);
		String retStr = saveActRecon();
		return retStr;
		
	}
	
	public String deletePasRecon(){
		GL35Logger.logThis("Entering deletePasRecon...",Priority.DEBUG_INT);
		String retStr = deleteActRecon();
		return retStr;
	}

	public Map getTpList() {
		return tpList;
	}

	public void setTpList(Map tpList) {
		this.tpList = tpList;
	}

	public Map getGlColForTp() {
		return glColForTp;
	}

	public void setGlColForTp(Map glColForTp) {
		this.glColForTp = glColForTp;
	}

	public String getDummyStr1() {
		return dummyStr1;
	}

	public void setDummyStr1(String dummyStr1) {
		this.dummyStr1 = dummyStr1;
	}

	public Map getDummyMap1() {
		return dummyMap1;
	}

	public void setDummyMap1(Map dummyMap1) {
		this.dummyMap1 = dummyMap1;
	}

	public ArrayList getDummyAl1() {
		return dummyAl1;
	}

	public void setDummyAl1(ArrayList dummyAl1) {
		this.dummyAl1 = dummyAl1;
	}
	
}
