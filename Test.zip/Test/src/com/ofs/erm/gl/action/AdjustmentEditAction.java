/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : AdjustmentEditAction.java
* Title         :
* Description   :
* @author       : Manoj Cherukumalli 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

package com.ofs.erm.gl.action;

import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringBufferInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Priority;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ofs.erm.gl.dao.AdjEntryEditDAO;
import com.ofs.erm.gl.dao.EditPageDAO;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.model.AdjDefaultValueBean;
import com.ofs.erm.gl.model.EditPageEntryBean;
import com.ofs.erm.gl.model.EditPageSearchBean;
import com.ofs.erm.gl.model.EditPageSummaryBean;
import com.ofs.erm.gl.model.EleBrDimInputListBean;
import com.ofs.erm.gl.model.MapNameBean;
import com.ofs.erm.gl.model.PPListBean;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.inject.util.Function;

public class AdjustmentEditAction extends ActionSupport implements
ServletRequestAware, ServletResponseAware{

	private InputStream inputStream;
	public InputStream getInputStream() {
		return inputStream;
	}

	private List<com.ofs.erm.gl.model.MapNameBean> mapArray;
	private List<EditPageSummaryBean> adjustmentList;
	private List<AdjDefaultValueBean> defaultValueList;
	private List<String> dimensionsArray;
	private List<String> dimensionsArrayOpt;
	private String sortOrder;
	private String sortCol;
	private int startIndex,endIndex,currentPage;
	private int recordCount;
	private int paginationNumber;
	public int getPaginationNumber() {
		return paginationNumber;
	}
	public void setPaginationNumber(int paginationNumber) {
		this.paginationNumber = paginationNumber;
	}

	private int noOfPagesLoaded = 2;
	private String expAmountLowerBound,expAmountUpperBound;
	private String manDim;
	private String selectedPPs;
	private String selectedAdjExposureId;
	private String editedDefaultValues;
	private String userComments;
	private String submissionComments;
	private String submittedExposureIds;
	private String selectedDimValues;
	private boolean submissionStatus;
	private boolean saveStatus;
	private boolean saveStatusApp;
	private String approvalStatus;
	private String adjEntryStatus;
	private boolean multipleDefEdit;
	private String fetchStatus;
	public String getManDim() {
		return manDim;
	}
	public void setManDim(String manDim) {
		this.manDim = manDim;
	}

	private String editExecutionId,editMapId,editGlDate,editVersionNumber;
	private String methodName;
	private String infodom,userId;


	private List<com.ofs.erm.gl.model.PPListBean> ppList;

	private List<com.ofs.erm.gl.model.EleBrDimInputListBean> eleBrDimList;

	protected HttpServletRequest request;
	protected HttpServletResponse response;

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		this.setRequest(arg0);
	}
	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		this.setResponse(arg0);
	}

	public List<com.ofs.erm.gl.model.EleBrDimInputListBean> getEleBrDimList() {
		return eleBrDimList;
	}
	public void setEleBrDimList(List<com.ofs.erm.gl.model.EleBrDimInputListBean> eleBrDimList) {
		this.eleBrDimList = eleBrDimList;
	}


	public String adjustmentEditAction() {

try{
		EditPageEntryBean adjEditBean = new EditPageEntryBean();
		GL35Logger.logThis("Entering ACTION class", Priority.DEBUG_INT);
		String methodName = getMethodName();
		GL35Logger.logThis("methodName= "+methodName, Priority.DEBUG_INT);
		String infodom = getInfodom();
		String editExecutionId = getEditExecutionId();
		String editMapId = getEditMapId();
		String editGlDate = getEditGlDate();
		String editVersionNumber = getEditVersionNumber();
		String editSortCol = getSortCol();
		String editSortOrder = getSortOrder();
		String searchExpAmountLowerBound = getExpAmountLowerBound();
		String searchExpAmountUpperBound = getExpAmountUpperBound();
		String filterSelectedPPs = getSelectedPPs();
		String selectedExposureId = getSelectedAdjExposureId();
		String[] selectedPPArray = {"Nill"};
		String submittedExposureIdsString = getSubmittedExposureIds();
		String selectedDimValuesString = getSelectedDimValues();
		int paginationNumber = getPaginationNumber();
		int editStartIndex = getStartIndex();
		int editEndIndex = getEndIndex();


		if(paginationNumber == 0)
			paginationNumber = 5;

		if(editExecutionId == null)
			editExecutionId = "";
		if(editMapId == null)
			editMapId = "";
		if(editGlDate == null)
			editGlDate = "";
		if(editVersionNumber == null)
			editVersionNumber = "";
		if(editSortCol == null)
			editSortCol = "";
		if(editSortOrder == null)
			editSortOrder = "";
		if(infodom == null)
			infodom = "";
		if(selectedExposureId == null)
			selectedExposureId = "";
		if(submittedExposureIdsString == null)
			submittedExposureIdsString = "";
		if(selectedDimValuesString == null)
			selectedDimValuesString = "";
		if((searchExpAmountLowerBound == null))
			searchExpAmountLowerBound = "-999999999999999";
		if((searchExpAmountUpperBound == null))
			searchExpAmountUpperBound = "999999999999999";
		GL35Logger.logThis("filterSelectedPPs="+filterSelectedPPs, Priority.DEBUG_INT);
		if(!( (filterSelectedPPs == null) || (filterSelectedPPs.equals("")) ) ) {
			selectedPPArray = filterSelectedPPs.split("@#");
			GL35Logger.logThis("Created PP Array with length="+selectedPPArray.length, Priority.DEBUG_INT);
		}
		else {
			filterSelectedPPs = "";
		}


		GL35Logger.logThis(editExecutionId+":"+editMapId+":"+editGlDate, Priority.DEBUG_INT);
		GL35Logger.logThis("selectedPPArray String = "+filterSelectedPPs, Priority.DEBUG_INT);
		GL35Logger.logThis("Adj Edit Action -- "+searchExpAmountLowerBound+":"+searchExpAmountUpperBound, Priority.DEBUG_INT);

		adjEditBean.setExecId(editExecutionId);
		adjEditBean.setMapId(editMapId);
		adjEditBean.setGlDate(editGlDate);
		adjEditBean.setVersionNumber(editVersionNumber);

		adjustmentList = new ArrayList<EditPageSummaryBean>();
		dimensionsArray = new ArrayList<String>();
		dimensionsArrayOpt = new ArrayList<String>();
		
		EditPageSearchBean searchBean = new EditPageSearchBean();
		searchBean.setExecutionId(editExecutionId);
		searchBean.setGlDate(editGlDate);
		searchBean.setMapId(editMapId);
		searchBean.setVersionNumber(editVersionNumber);
		searchBean.setSortCol(editSortCol);
		searchBean.setSortOrder(editSortOrder);
		searchBean.setRecordCountNeeded(false);
		searchBean.setSearchExpAmountLowerBound(searchExpAmountLowerBound);
		searchBean.setSearchExpAmountUpperBound(searchExpAmountUpperBound);
		searchBean.setSelectedPPArray(selectedPPArray);
		GL35Logger.logThis("Adj Entry Status = "+getAdjEntryStatus(), Priority.DEBUG_INT);
		searchBean.setEntryStatus(getAdjEntryStatus());

		if(methodName == null) {
			sortCol = "";
			sortOrder = "";
		}
		else if(methodName.equals("populatePPs")) {
			ppListBean = new PPListBean();
			ppListBean.setExecId(adjEditBean.getExecId());
			ppListBean.setMapName(adjEditBean.getMapId());
			ppListBean.setGlDate(adjEditBean.getGlDate());
			ppListBean.setVersionNumber(adjEditBean.getVersionNumber());
			ppList = new ArrayList<PPListBean>();
			ppList = EditPageDAO.getPPList(ppListBean,infodom);

			GL35Logger.logThis("RETURNING PPLIST with size : "+ppList.size(), Priority.DEBUG_INT);
			return SUCCESS;
		}
		else if(methodName.equals("loadDimList")) {
			GL35Logger.logThis("loading dim list", Priority.DEBUG_INT);
			String version = request.getParameter("sVersion");
			String output = EditPageDAO.getDimensionArray(getManDim(),version,infodom);
			inputStream = new StringBufferInputStream(output);
			return SUCCESS;
		}
		else if(methodName.equals("loadAdjustmentData") || methodName.equals("getAdjDataFirstPage")) {
			GL35Logger.logThis("loading adjustment Data", Priority.DEBUG_INT);
			startIndex = 1;
			endIndex = noOfPagesLoaded*paginationNumber;
			searchBean.setRecordCountNeeded(true);

		}
		else if(methodName.equals("getAdjDataLastPage")) {
			GL35Logger.logThis("loading adjustment Data - FirstPage", Priority.DEBUG_INT);
			if((currentPage % 2) == 0) { // 2 here in this if loop is the no of pages to load
				startIndex = (paginationNumber * (currentPage - 2)) + 1; 
				endIndex = startIndex + (2*paginationNumber) - 1;
			}
			else {
				startIndex = (paginationNumber * (currentPage - 1)) + 1;
				endIndex = startIndex + ((2-1)*paginationNumber) - 1;
			}
			GL35Logger.logThis("startIndex="+startIndex+"endIndex="+endIndex, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getAdjDataNextPage")) {
			startIndex = (paginationNumber * currentPage) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			GL35Logger.logThis("loading adjustment Data - NextPage -- startIndex="+startIndex+" endIndex="+endIndex, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getAdjDataPrevPage")) {
			startIndex = (paginationNumber * (currentPage-3)) + 1; // this line depends on number of pages loaded
			endIndex = startIndex + (2*paginationNumber) - 1;
			GL35Logger.logThis("loading adjustment Data - PrevPage -- startIndex="+startIndex+" endIndex="+endIndex, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getSortedAdjData")) {
			GL35Logger.logThis("loading sorted adjustment Data", Priority.DEBUG_INT);
			startIndex = 1;
			endIndex = noOfPagesLoaded*paginationNumber;
			GL35Logger.logThis("Entering DAO with sortCol="+sortCol+" and sortOrder="+sortOrder, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getDefaultValues")) {
			GL35Logger.logThis("loading default Values for selectedExposureId="+selectedExposureId, Priority.DEBUG_INT);
			setDefaultValueList(AdjEntryEditDAO.getDefaultValues(selectedExposureId,infodom));

			setUserComments("");
			GL35Logger.logThis("Returning with Default Value List with Size = "+defaultValueList.size(), Priority.DEBUG_INT);
			return SUCCESS;
		}
		else if(methodName.equals("saveDefaultValues")) {/*save adjustment entries*/
			GL35Logger.logThis("Saving default Values with editedDefaultValues="+getEditedDefaultValues()+"&submittedExposureIdsString="+submittedExposureIdsString, Priority.DEBUG_INT);
			String[] editedDefValueArray = getEditedDefaultValues().split("@@");
			String[] submittedExposureIdsArray = submittedExposureIdsString.split("@#");
			GL35Logger.logThis("getMultipleDefEdit()="+getMultipleDefEdit(), Priority.DEBUG_INT);
			//boolean updateStatus = AdjEntryEditDAO.setDefaultValues(submittedExposureIdsArray, editedDefValueArray,infodom,userId,getMultipleDefEdit());
			setSaveStatus(AdjEntryEditDAO.setDefaultValues(submittedExposureIdsArray, editedDefValueArray,infodom,userId,getMultipleDefEdit(),false));
			GL35Logger.logThis("Returning from action class with updateStatus="+isSaveStatus(), Priority.DEBUG_INT);
			return SUCCESS;
		}
		else if(methodName.equals("submitAdjEntries")) {/*submit adjustment entries*/
			GL35Logger.logThis("Submitting Adj entries for authorisation with editedDefaultValues="+getEditedDefaultValues()+"&submittedExposureIdsString="+submittedExposureIdsString, Priority.DEBUG_INT);
			String[] editedDefValueArray = getEditedDefaultValues().split("@@");
			String[] submittedExposureIdsArray = submittedExposureIdsString.split("@#");
			GL35Logger.logThis("getMultipleDefEdit()="+getMultipleDefEdit(), Priority.DEBUG_INT);
			setSubmissionStatus(AdjEntryEditDAO.setDefaultValues(submittedExposureIdsArray, editedDefValueArray,infodom,userId,getMultipleDefEdit(),true));
			//setSubmissionStatus(AdjEntryEditDAO.submitAdjustmentData(submittedExposureIdsArray,infodom,userId,"S"));
			GL35Logger.logThis("Returning from action class with updateStatus="+getSubmissionStatus(), Priority.DEBUG_INT);
			return SUCCESS;
		}
		else if(methodName.equals("modifyApproverComments")) {/*save adjustment entries in approval window*/
			GL35Logger.logThis("Submitting Adj entries for approver comments with submittedExposureIdsString="+submittedExposureIdsString, Priority.DEBUG_INT);
			String[] submittedExposureIdsArray = submittedExposureIdsString.split("@#");

			boolean updateStatus = (AdjEntryEditDAO.modifyApproverComments(submittedExposureIdsArray,infodom,userId));
			request.setAttribute("saveStatusApp", getSaveStatusApp());
			GL35Logger.logThis("Returning from action class with updateStatus getSaveStatusApp()="+updateStatus, Priority.DEBUG_INT);
			try{
			PrintWriter pw = response.getWriter();
			if(updateStatus) pw.print("saved");
			else  pw.print("failed");
			}catch(Exception e){
				e.printStackTrace();
				GL35Logger.logThis("Exception occured : "+e.getLocalizedMessage(), Priority.DEBUG_INT);
			}
			return NONE;
			//return SUCCESS;
		}
		else if(methodName.equals("sendAdjEntries")) {/*Authorize adjustment entries in approval window*/
			GL35Logger.logThis("Approving/Rejecting Adj entries with submittedExposureIdsString="+submittedExposureIdsString, Priority.DEBUG_INT);
			String[] submittedExposureIdsArray = submittedExposureIdsString.split("@#");
			GL35Logger.logThis("Leaving Action - Entering Adj Entry Edit DAO", Priority.DEBUG_INT);
			//setApprovalStatus(AdjEntryEditDAO.authorizeAdjEntries(submittedExposureIdsArray,infodom,userId));
			String retVal = (AdjEntryEditDAO.authorizeAdjEntries(submittedExposureIdsArray,infodom,userId));
			PrintWriter pw = response.getWriter();
			GL35Logger.logThis(" return status (retVal-SUCCESS/FAIL and Error/exception) : "+retVal,Priority.INFO_INT);
			pw.print(retVal);
			//GL35Logger.logThis("Returning from action class with approvalStatus="+getApprovalStatus(), Priority.DEBUG_INT);
			return NONE;
		}

		searchBean.setStartIndex(startIndex);
		searchBean.setEndIndex(endIndex);
		if(!(selectedDimValuesString.equals(""))) {
			searchBean.setDimSearchNeeded(true);
			searchBean.setSelectedDimValues(selectedDimValuesString);
			GL35Logger.logThis("Adj Edit Action: dim search needed = true and selectedDimValuesString="+selectedDimValuesString, Priority.DEBUG_INT);
		}
		searchBean.setContraGLCheckNeeded(false);
		setAdjustmentList(EditPageDAO.getAdjustmentData(searchBean,infodom,userId));
		
		setFetchStatus("Success");
		if(adjustmentList.size() != 0) {
			if((adjustmentList.size() == 1) && (adjustmentList.get(0).getExposureId() == null)) {
				setFetchStatus(adjustmentList.get(0).getStatus());
				adjustmentList.remove(0);
				GL35Logger.logThis("Returning from action class with fetchStatus="+getFetchStatus(), Priority.DEBUG_INT);
			}
			else {
				setDimensionsArray(adjustmentList.get(0).getDimensionsArray());
				setDimensionsArrayOpt(adjustmentList.get(0).getDimensionsArrayOpt());
				adjustmentList.remove(0);
				setRecordCount(adjustmentList.get(0).getRecordCount());
				setFetchStatus("Success");
				GL35Logger.logThis("Returning ADJUSTMENT LIST with size: "+adjustmentList.size()+" and Dimension Array with size: "+dimensionsArray.size()+":: Record Count="+getRecordCount(), Priority.DEBUG_INT);
			}
		}
	}
	catch(Exception e){
		e.printStackTrace();
		GL35Logger.logThis("Exception Occured : "+e.getLocalizedMessage(), Priority.ERROR_INT);
	}
	return SUCCESS;
	}

	public String loadDimList() {
		String manDim = "";
		String infodom = getInfodom();
		if(!(this.getManDim() == null))
			manDim = getManDim();
		GL35Logger.logThis("loading dim list", Priority.DEBUG_INT);
		GL35Logger.logThis("manDim="+manDim, Priority.DEBUG_INT);
		String version = request.getParameter("sVersion");
		String output = EditPageDAO.getDimensionArray(manDim,version,infodom);
		inputStream = new StringBufferInputStream(output);
		return SUCCESS;
	}
	public boolean isSaveStatus() {
		return saveStatus;
	}
	public void setSaveStatus(boolean saveStatus) {
		this.saveStatus = saveStatus;
	}

	public String getEditExecutionId() {
		return editExecutionId;
	}
	public void setEditExecutionId(String editExecutionId) {
		this.editExecutionId = editExecutionId;
	}
	public String getEditMapId() {
		return editMapId;
	}
	public void setEditMapId(String editMapId) {
		this.editMapId = editMapId;
	}
	public String getEditGlDate() {
		return editGlDate;
	}
	public void setEditGlDate(String editGlDate) {
		this.editGlDate = editGlDate;
	}

	public String getEditVersionNumber() {
		return editVersionNumber;
	}
	public void setEditVersionNumber(String editVersionNumber) {
		this.editVersionNumber = editVersionNumber;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public String getInfodom() {
		return infodom;
	}
	public void setInfodom(String infodom) {
		this.infodom = infodom;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	private PPListBean ppListBean;
	private EleBrDimInputListBean eleBrDimBean;

	public PPListBean getPpListBean() {
		return ppListBean;
	}
	public EleBrDimInputListBean getEleBrDimBean() {
		return eleBrDimBean;
	}
	public void setEleBrDimBean(EleBrDimInputListBean eleBrDimBean) {
		this.eleBrDimBean = eleBrDimBean;
	}
	public void setPpListBean(PPListBean ppListBean) {
		this.ppListBean = ppListBean;
	}

	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSortCol() {
		return sortCol;
	}
	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}
	public List<PPListBean> getPpList() {
		return ppList;
	}
	public void setPpList(List<PPListBean> ppList) {
		this.ppList = ppList;
	}
	public List<MapNameBean> getMapArray() {
		return mapArray;
	}
	public void setMapArray(List<MapNameBean> mapArray) {
		this.mapArray = mapArray;
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	public HttpServletResponse getResponse() {
		return response;
	}
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	public List<EditPageSummaryBean> getAdjustmentList() {
		return adjustmentList;
	}
	public void setAdjustmentList(List<EditPageSummaryBean> adjustmentList) {
		this.adjustmentList = adjustmentList;
	}
	public List<AdjDefaultValueBean> getDefaultValueList() {
		return defaultValueList;
	}
	public void setDefaultValueList(List<AdjDefaultValueBean> defaultValueList) {
		this.defaultValueList = defaultValueList;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public List<String> getDimensionsArray() {
		return dimensionsArray;
	}
	public void setDimensionsArray(List<String> dimensionsArray) {
		this.dimensionsArray = dimensionsArray;
	}
	public List<String> getDimensionsArrayOpt() {
		return dimensionsArrayOpt;
	}
	public void setDimensionsArrayOpt(List<String> dimensionsArrayOpt) {
		this.dimensionsArrayOpt = dimensionsArrayOpt;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public String getExpAmountLowerBound() {
		return expAmountLowerBound;
	}
	public void setExpAmountLowerBound(String expAmountLowerBound) {
		this.expAmountLowerBound = expAmountLowerBound;
	}
	public String getExpAmountUpperBound() {
		return expAmountUpperBound;
	}
	public void setExpAmountUpperBound(String expAmountUpperBound) {
		this.expAmountUpperBound = expAmountUpperBound;
	}
	public String getSelectedPPs() {
		return selectedPPs;
	}
	public void setSelectedPPs(String selectedPPs) {
		this.selectedPPs = selectedPPs;
	}
	public String getSelectedAdjExposureId() {
		return selectedAdjExposureId;
	}
	public void setSelectedAdjExposureId(String selectedAdjExposureId) {
		this.selectedAdjExposureId = selectedAdjExposureId;
	}
	public String getEditedDefaultValues() {
		return editedDefaultValues;
	}
	public void setEditedDefaultValues(String editedDefaultValues) {
		this.editedDefaultValues = editedDefaultValues;
	}
	public String getUserComments() {
		return userComments;
	}
	public void setUserComments(String userComments) {
		this.userComments = userComments;
	}
	public String getSubmissionComments() {
		return submissionComments;
	}
	public void setSubmissionComments(String submissionComments) {
		this.submissionComments = submissionComments;
	}
	public String getSubmittedExposureIds() {
		return submittedExposureIds;
	}
	public void setSubmittedExposureIds(String submittedExposureIds) {
		this.submittedExposureIds = submittedExposureIds;
	}
	public String getSelectedDimValues() {
		return selectedDimValues;
	}
	public void setSelectedDimValues(String selectedDimValues) {
		this.selectedDimValues = selectedDimValues;
	}
	public boolean getSubmissionStatus() {
		return submissionStatus;
	}
	public void setSubmissionStatus(boolean submissionStatus) {
		this.submissionStatus = submissionStatus;
	}
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getAdjEntryStatus() {
		return adjEntryStatus;
	}
	public void setAdjEntryStatus(String adjEntryStatus) {
		this.adjEntryStatus = adjEntryStatus;
	}
	public boolean getMultipleDefEdit() {
		return multipleDefEdit;
	}
	public void setMultipleDefEdit(boolean multipleDefEdit) {
		this.multipleDefEdit = multipleDefEdit;
	}
	public String getFetchStatus() {
		return fetchStatus;
	}
	public void setFetchStatus(String fetchStatus) {
		this.fetchStatus = fetchStatus;
	}
	public boolean getSaveStatusApp() {
		return saveStatusApp;
	}
	public void setSaveStatusApp(boolean saveStatusApp) {
		this.saveStatusApp = saveStatusApp;
	}

}
