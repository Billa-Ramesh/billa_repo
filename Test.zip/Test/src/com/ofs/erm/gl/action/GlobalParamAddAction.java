/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

*===================================================================================================================================================
* Name          : GlobalParamAddAction.java
* Title         :
* Description   :
* @author       : Deepak Dagar 
* @createdDate  : April 26, 2012
* @version      : 1.0
*
* Modification Log
* 
* --------------------------------------------------------------------------------------------------------------------------------------------
* Modified By              Modified On     Details
* ---------------------------------------------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
package com.ofs.erm.gl.action;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Priority;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;



import com.ofs.erm.gl.dao.GlobalParamAddDAO;
import com.ofs.erm.gl.model.GlobalParamAddBean;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GlobalUtil;


import com.opensymphony.xwork2.ActionSupport;

public class GlobalParamAddAction extends ActionSupport implements
ServletRequestAware, ServletResponseAware
{
	private String methodName;
	private List<GlobalParamAddBean> legalEntityArray;
	private List<String> existingConsolArray;
	private String selectedLegalEntity;
	private String selectedConsolType;
	private String selectedDate;
	private String selectedMonth;
	private String createdUser,creationDate,modifiedUser,modificationDate;
	static String selinfodom;
	private static String slocale;
	static String userId;
	private String status;
	protected HttpServletRequest request;
	protected HttpServletResponse response;
	private static Map session;
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public String getSlocale() {
		return slocale;
	}
	
	public void setSlocale(String slocale) {
		this.slocale = slocale;
	}

	public static String getSelinfodom() {
		return selinfodom;
	}

	public static void setSelinfodom(String selinfodom) {
		GlobalParamAddAction.selinfodom = selinfodom;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSelectedMonth() {
		return selectedMonth;
	}

	public void setSelectedMonth(String selectedMonth) {
		this.selectedMonth = selectedMonth;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String createdDate) {
		this.creationDate = createdDate;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(String modificationDate) {
		this.modificationDate = modificationDate;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public List<GlobalParamAddBean> getLegalEntityArray() {
		return legalEntityArray;
	}

	public void setLegalEntityArray(List<GlobalParamAddBean> legalEntityArray) {
		this.legalEntityArray = legalEntityArray;
	}


	public String getSelectedLegalEntity() {
		return selectedLegalEntity;
	}

    public String getSelectedDate() {
		return selectedDate;
	}

	public void setSelectedDate(String selectedDate) {
		this.selectedDate = selectedDate;
	}

	public void setSelectedLegalEntity(String selectedLegalEntity) {
		this.selectedLegalEntity = selectedLegalEntity;
	}


	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void validate() {
//		if (getSelectedLegalEntity().length() == 0) {
//		addFieldError("userName", "User Name is required");
//		} else if (getSelectedConsolType().length() == 0) {
//		addFieldError("userName", "Invalid User");
//		}else if (getSelectedDate().equals("DD")) {
//		addFieldError("userName", "Invalid User");
//		}else if (getSelectedMonth().equals("MM")) {
//		addFieldError("userName", "Invalid User");
//		}
	}
	
	public String globalParamAddAction() {
		GL35Logger.logThis("IN globalParamAddAction  method.."+getMethodName(), Priority.DEBUG_INT);
		String methodName = getMethodName();
		String selectedLegalEntity = "";
		String selectedConsolType = "";
		String infodom = getSelinfodom();
		String userId = getUserId();
		String locale="";
		
	//	locale = request.getParameter("slocale");
		if(!(getSelectedLegalEntity() == null))
			selectedLegalEntity = getSelectedLegalEntity();
		
		if(!(getSlocale() == null))
			locale = getSlocale();
		//if(!(getSelectedConsolType() == null))
			//selectedConsolType = getSelectedConsolType();
		
		GL35Logger.logThis("methodName="+methodName+"selectedLegalEntity"+selectedLegalEntity, Priority.DEBUG_INT);
		
		if(methodName.equals("getLegalEntityArray")) {
		
			String hiercode = GlobalUtil.getLegalHierCode(getSelinfodom()); 
			setLegalEntityArray(GlobalParamAction.getHierNodes(getSelinfodom(),getUserId(),hiercode,"add",locale));
			GL35Logger.logThis("Action Class - GlobalParamAddAction - getLegalEntityArray! Returning from GlobalParamAddAction! LegalEntityArray size = "+legalEntityArray.size(), Priority.DEBUG_INT);
		}
	/**	else if(methodName.equals("getConsolArray")) {
			
			setConsolArray(GlobalParamAddDAO.getConsolidationArray(infodom,1));
			GL35Logger.logThis("now fetching existing consol array...", Priority.DEBUG_INT);
			
			setExistingConsolArray(GlobalParamAddDAO.getExistingConsolidationArray(selectedLegalEntity,infodom));
			
			for(int i=existingConsolArray.size()-1;i>=0;i--) {
				for(int j=consolArray.size()-1;j>=0;j--) {
					if(existingConsolArray.get(i).equals(consolArray.get(j).getConsolId())) {
						consolArray.remove(j);
					}
				}
			}
			GL35Logger.logThis("consolArray.size()="+consolArray.size(), Priority.DEBUG_INT);
		}**/
		else if(methodName.equals("insertGlobalParameter")) {
			String selectedDate = "";
			String selectedMonth = "";
			String createdUser = "";
			String creationDate = "";
			String modifiedUser = "";
			String modificationDate = "";
			
			if(!(getSelectedDate() == null))
				selectedDate = getSelectedDate();
			if(!(getSelectedMonth() == null))
				selectedMonth = getSelectedMonth();
			if(!(getCreatedUser() == null))
				createdUser = getCreatedUser();
			if(!(getCreationDate() == null))
				creationDate = getCreationDate();
			if(!(getModifiedUser() == null))
				modifiedUser = getModifiedUser();
			if(!(getModificationDate() == null))
				modificationDate = getModificationDate();
			
			GlobalParamAddBean addBean = new GlobalParamAddBean();
			addBean.setCreationDate(creationDate);
			addBean.setCreatedUser(createdUser);
			addBean.setLegEntityCode(selectedLegalEntity);
			addBean.setModificationDate(modificationDate);
			addBean.setModifiedUser(modifiedUser);
			addBean.setSelectedDate(selectedDate);
			addBean.setSelectedMonth(selectedMonth);

			GlobalParamAddDAO.insertGlobalParameter(addBean,infodom);
		}
		
		
	return SUCCESS;	
	}
	
	public String save() {
		setStatus("false");
		String infodom = getSelinfodom();
		String userId = getUserId();
		GL35Logger.logThis("In GlobalParamAddAction -- Save Method : "+selectedLegalEntity+selectedConsolType+selectedMonth+selectedDate, Priority.DEBUG_INT);
		
		GlobalParamAddBean addBean = new GlobalParamAddBean();
		addBean.setCreationDate(creationDate);
		addBean.setCreatedUser(createdUser);
		addBean.setLegEntityCode(selectedLegalEntity);
		addBean.setModificationDate("");
		addBean.setModifiedUser("");
		addBean.setSelectedDate(selectedDate);
		addBean.setSelectedMonth(selectedMonth);

		this.setStatus(GlobalParamAddDAO.insertGlobalParameter(addBean,infodom));
		return SUCCESS;
	}
	
	public String update() {
		setStatus("false");
		String infodom = getSelinfodom();
		String userId = getUserId();
		GL35Logger.logThis("In GlobalParamAddAction -- Update Method : "+selectedLegalEntity+selectedConsolType+selectedMonth+selectedDate, Priority.DEBUG_INT);
		
		GlobalParamAddBean addBean = new GlobalParamAddBean();
		addBean.setCreationDate("");
		addBean.setCreatedUser("");
		addBean.setLegEntityCode(selectedLegalEntity);
		addBean.setModificationDate(modificationDate);
		addBean.setModifiedUser(modifiedUser);
		addBean.setSelectedDate(selectedDate);
		addBean.setSelectedMonth(selectedMonth);
		GL35Logger.logThis("In GlobalParamAddAction -- Update Method :before sstus ", Priority.DEBUG_INT);
		this.setStatus(GlobalParamAddDAO.updateGlobalParameter(addBean,infodom));
		return SUCCESS;
	}
	public void setSession(Map session) {
		// TODO Auto-generated method stub
		session = session;
	}
	public static Map getSession() {
		// TODO Auto-generated method stub
		return session;
	}
}
