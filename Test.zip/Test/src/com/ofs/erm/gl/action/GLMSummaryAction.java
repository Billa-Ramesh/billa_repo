/****************************************************************************************************
*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
--------------------------------------------------------------------------------------------------------
File Name             : GLMSummaryAction.java
Created By            : Rahul M 
Created On            : Jul 2, 2012
Application Name      : General Ledger 
Modification History  : 
Modification On          Modified By           Modification Details
---------------------------------------------------------------------------------------------------------

*********************************************************************************************************/
package com.ofs.erm.gl.action;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Priority;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;


import com.ofs.erm.gl.dao.GLMSummaryDAO;
import com.ofs.erm.gl.model.GLMSearchBean;
import com.ofs.erm.gl.model.GLMSummaryBean;
import com.ofs.erm.gl.global.GL35Logger;
import com.ofs.erm.gl.global.GlobalUtil;
import com.opensymphony.xwork2.ActionSupport;

public class GLMSummaryAction extends ActionSupport implements
ServletRequestAware, ServletResponseAware, SessionAware 
{

	private static final long serialVersionUID = -1186821476634982078L;
	private List<GLMSummaryBean> GLMList;
	private boolean checkBox;
	private String paginationNumber,currentPage,actionId;
	private String searchglAcntName;
	private String searchparentGLAcntName;
	private String searchGLBook;
	private String searchGLType;
	private String searchIntraGrp;
	private String sortOrder;
	private String sortCol,methodName;
	private String selinfodom,infodom,userId,status;
	private int rowCount;
	private HttpServletRequest request;
	private HttpServletResponse response;
	private Map session;
	private int noOfPagesLoaded = 2;
	private String glBookHierCode;
	private String glCodeHierCode;
	private Map glTypeMap,intraGrpMap,isAutoApproveMap;
	

	public Map getIsAutoApproveMap() {
		return isAutoApproveMap;
	}

	public void setIsAutoApproveMap(Map isAutoApproveMap) {
		this.isAutoApproveMap = isAutoApproveMap;
	}

	public String getGlCodeHierCode() {
		return glCodeHierCode;
	}

	public void setGlCodeHierCode(String glCodeHierCode) {
		this.glCodeHierCode = glCodeHierCode;
	}



	public String getGlBookHierCode() {
		return glBookHierCode;
	}

	public void setGlBookHierCode(String glBookHierCode) {
		this.glBookHierCode = glBookHierCode;
	}


	public Map getGlTypeMap() {
		return glTypeMap;
	}

	public void setGlTypeMap(Map glTypeMap) {
		this.glTypeMap = glTypeMap;
	}

	public Map getIntraGrpMap() {
		return intraGrpMap;
	}

	public void setIntraGrpMap(Map intraGrpMap) {
		this.intraGrpMap = intraGrpMap;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub

	}

	public List<GLMSummaryBean> getGLMList() {
		return GLMList;
	}

	public void setGLMList(List<GLMSummaryBean> gLMList) {
		GLMList = gLMList;
	}

	public boolean isCheckBox() {
		return checkBox;
	}

	public void setCheckBox(boolean checkBox) {
		this.checkBox = checkBox;
	}

	public String getPaginationNumber() {
		return paginationNumber;
	}

	public void setPaginationNumber(String paginationNumber) {
		this.paginationNumber = paginationNumber;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public String getSearchglAcntName() {
		return searchglAcntName;
	}

	public void setSearchglAcntName(String searchglAcntName) {
		this.searchglAcntName = searchglAcntName;
	}

	public String getSearchparentGLAcntName() {
		return searchparentGLAcntName;
	}

	public void setSearchparentGLAcntName(String searchparentGLAcntName) {
		this.searchparentGLAcntName = searchparentGLAcntName;
	}

	public String getSearchGLBook() {
		return searchGLBook;
	}

	public void setSearchGLBook(String searchGLBook) {
		this.searchGLBook = searchGLBook;
	}

	public String getSearchGLType() {
		return searchGLType;
	}

	public void setSearchGLType(String searchGLType) {
		this.searchGLType = searchGLType;
	}

	public String getSearchIntraGrp() {
		return searchIntraGrp;
	}

	public void setSearchIntraGrp(String searchIntraGrp) {
		this.searchIntraGrp = searchIntraGrp;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getSortCol() {
		return sortCol;
	}

	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getSelinfodom() {
		return selinfodom;
	}

	public void setSelinfodom(String selinfodom) {
		this.selinfodom = selinfodom;
	}

	public String getInfodom() {
		return infodom;
	}

	public void setInfodom(String infodom) {
		this.infodom = infodom;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public int getNoOfPagesLoaded() {
		return noOfPagesLoaded;
	}

	public void setNoOfPagesLoaded(int noOfPagesLoaded) {
		this.noOfPagesLoaded = noOfPagesLoaded;
	}

	public String GLMSummaryAction() {
		GL35Logger.logThis("In GLM Summary Action", Priority.DEBUG_INT);
		int paginationNumber = 0;
		int currentPage = 0;
		String sortCol = getSortCol();
		String sortOrder = getSortOrder();
		String searchGlAcntName = getSearchglAcntName();
		String searchPrntGLAcntName = getSearchparentGLAcntName();
		String searchGLBook = getSearchGLBook();
		String searchGLType = getSearchGLType();
		String searchIntraGrp = getSearchIntraGrp();
		String methodName = getMethodName();
		String infoDom = getSelinfodom();
		int startIndex = 0;
		int endIndex = 0;
		GLMSearchBean searchBean = new GLMSearchBean();
		searchBean.setRecordCountNeeded(false);
		GLMList = new ArrayList<GLMSummaryBean>();

//		setConsolArray(GlobalParamAddDAO.getConsolidationArray(getInfodom()));
//		
//		GL35Logger.logThis("Action class- ReconAction - get consol array with size="+getConsolArray().size(), Priority.DEBUG_INT);
//		
//		if(getConsolArray().get(1).getConsolDesc() == "Error")
//		{
//			setStatus("false");
//			GL35Logger.logThis("Status = " + getStatus(), Priority.DEBUG_INT);
//			return SUCCESS;
//		}

		if(!(getPaginationNumber() == null))
			paginationNumber = Integer.parseInt(getPaginationNumber());
		if(!(getCurrentPage() == null))
			currentPage = Integer.parseInt(getCurrentPage());
		if(sortCol == null)
			sortCol = "";
		if(sortOrder == null)
			sortOrder = "";
		if(searchGlAcntName == null)
			searchGlAcntName = "";
		if(searchPrntGLAcntName == null)
			searchPrntGLAcntName = "";
		if(searchGLBook == null)
			searchGLBook = "";
		if(searchGLType == null)
			searchGLType = "";
		if(searchIntraGrp == null)
			searchIntraGrp = "";
		if(infoDom == null)
			infoDom = "";

		String langCode = session.get("lclPostFix").toString();
		
		String glTypeCode = GlobalUtil.getParamValue("GL_TYPE_HIERCODE", infoDom); 
		glTypeMap = GlobalUtil.getHierNodeDesc(infoDom, userId, glTypeCode);
		
		intraGrpMap = GlobalUtil.getLookUpData("17",langCode,infoDom);
		isAutoApproveMap = GlobalUtil.getLookUpData("17",langCode,infoDom);
		
		String glBookCd = GlobalUtil.getParamValue("GLBOOK_TYPE_HIERCODE", infoDom);
		this.setGlBookHierCode(glBookCd);
		
		String glHierCd = GlobalUtil.getParamValue("GL_CODE_HIERCODE", infoDom);
		this.setGlCodeHierCode(glHierCd);
		
		if(methodName == null) {
			startIndex = 1;
			endIndex = 2*15; 
			searchGlAcntName = "";
			searchPrntGLAcntName = "";
			searchGLBook = "";
			searchGLType = "";
			searchIntraGrp = "";
			sortCol = "";
			sortOrder = "";
			searchBean.setRecordCountNeeded(true);			
			GL35Logger.logThis("Action Class - GLMSummaryAction - reset - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getNextPage")) {
			startIndex = (paginationNumber * currentPage) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			GL35Logger.logThis("Action Class - GLMSummaryAction  - getNextPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getPrevPage")) {
			startIndex = (paginationNumber * (currentPage-3)) + 1;
			endIndex = startIndex + (2*paginationNumber) - 1;
			GL35Logger.logThis("Action Class - GLMSummaryAction  - getFirstPage", Priority.DEBUG_INT);
		}
		else if(methodName.equals("getFirstPage")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - GLMSummaryAction  - getFirstPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getLastPage")) {
			if((currentPage % 2) == 0) { // 2 here in this if loop is no of pages to load
				startIndex = (paginationNumber * (currentPage - 2)) + 1; 
				endIndex = startIndex + (2*paginationNumber) - 1;
			}
			else {
				GL35Logger.logThis("INSIDE getLastPage loop currentPage="+currentPage+"paginationNumber="+paginationNumber+startIndex+endIndex, Priority.DEBUG_INT);
				startIndex = (paginationNumber * (currentPage - 1)) + 1;
				endIndex = startIndex + ((2-1)*paginationNumber) - 1;
			}
			GL35Logger.logThis("Action Class - GLMSummaryAction  - getLastPage - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("search")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - GLMSummaryAction  - search - "+startIndex+endIndex+paginationNumber+currentPage+searchGlAcntName+searchPrntGLAcntName+searchGLBook+searchGLType, Priority.DEBUG_INT);
		}
		else if(methodName.equals("sort")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - GLMSummaryAction  - sort - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("reset")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			searchGlAcntName = "";
			searchPrntGLAcntName = "";
			searchGLBook = "";
			searchGLType = "";
			searchIntraGrp = "";
			sortCol = "";
			sortOrder = "";
			searchBean.setRecordCountNeeded(true);
			GL35Logger.logThis("Action Class - GLMSummaryAction - reset - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}
		else if(methodName.equals("getMapArray")) {
		}
		else if(methodName.equals("changePagination")) {
			startIndex = 1;
			endIndex = 2*paginationNumber;
			GL35Logger.logThis("Action Class - GLMSummaryAction - change Pagination - "+startIndex+endIndex+paginationNumber+currentPage, Priority.DEBUG_INT);
		}

		searchBean.setSearchGLAcntName(searchGlAcntName);
		searchBean.setSearchparentGLAcntName(searchPrntGLAcntName);
		searchBean.setSearchGLBook(searchGLBook);
		searchBean.setSearchGLType(searchGLType);
		searchBean.setSearchIntraGrp(searchIntraGrp);
		searchBean.setSortCol(sortCol);
		searchBean.setSortOrder(sortOrder);
		searchBean.setStartIndex(startIndex);
		searchBean.setEndIndex(endIndex);

		GLMList =GLMSummaryDAO.getGLMData(searchBean,infoDom,userId);

		if((methodName == null) ||(methodName.equals("search")) || (methodName.equals("reset"))) {
			if(GLMList.size() == 0) {
				GL35Logger.logThis("Zero length Record Set", Priority.DEBUG_INT);
				rowCount = 0;
			}
			else {
				rowCount = GLMList.get(0).getRecordCount();
			}
		}
		
		if(!(GLMList.size() == 0)) {
			if(GLMList.get(0).getGlAcntName() == null) {
				GL35Logger.logThis("Infodom Error..", Priority.DEBUG_INT);
				setStatus("false");
				GL35Logger.logThis("Status = " + getStatus(), Priority.DEBUG_INT);
				return SUCCESS;
			}
		}
		
		GL35Logger.logThis("GLMSummaryAction Action Class -- returning from Action", Priority.DEBUG_INT);
		return SUCCESS;
	}

	@Override
	public void setSession(Map session) {
		// TODO Auto-generated method stub
		this.session = session;
	}

}
