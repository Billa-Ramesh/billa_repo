
public class TEST {
	
	public static void main(String args[]){
		
		StringBuffer sb=new StringBuffer();
		sb.append("{\"title\":\""+"kazipet"+"\", \"hcycode\":\""+"wgl1"+"\"},");
		sb.append("{\"title\":\""+"warangal"+"\", \"hcycode\":\""+"wgl2"+"\"},");
		//System.out.println(sb.toString() +"dfdf"+sb.indexOf("title")+sb.lastIndexOf("title"));
		String s=sb.toString();
		String[] arr = s.split("\":\"");
		for (int k = 0; k < arr.length; k++) {
			System.out.println(arr[k]);//
			//String[] second = arr[k].split("\",");
		//	for (int j = 0; j < second.length; j++) {
				
			//System.out.println(second[j]);
		//}
		}  
		//sb.append("");

	}
}
