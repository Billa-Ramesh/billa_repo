import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


public class Maptest {

	private static List<String> allow;

	public static void main(String args[]){
		

	    Map<String, List<String>> returnvalue = new HashMap<String, List<String>>();
	    

		for (int i = 1; i <=5;i++){
			allow = new ArrayList<String>();
			returnvalue.put("table"+i, allow);
			for(int j=1;j<=3 ;j++){
				
				
				allow.add(""+j);
				
			}
		}
		
	    
	 
	    for (Entry<String, List<String>> entry :returnvalue.entrySet()) {
	    	System.out.println("Key : " + entry.getKey() +"\n");
	    	Iterator iterator = entry.getValue().iterator();
            while(iterator.hasNext()){
                    System.out.println( iterator.next() );
            }
	       		
	    }

	}
}
