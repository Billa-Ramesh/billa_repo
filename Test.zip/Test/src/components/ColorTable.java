package components;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ColorTable extends JFrame {
  ColorName colors[] = {
    new ColorName("Red"), new ColorName("Green"), new ColorName("Blue"),
    new ColorName("Black"), new ColorName("White")
  };

  public ColorTable( ) {
    super("Table With DefaultCellEditor Example");
    setSize(500,300);
    setDefaultCloseOperation(EXIT_ON_CLOSE);

    JTable table = new JTable(new AbstractTableModel( ) {
        ColorName data[] = {
          colors[0], colors[1], colors[2], colors[3], colors[4],
          colors[0], colors[1], colors[2], colors[3], colors[4]
        };
        public int getColumnCount( ) { return 3; }
        public int getRowCount( ) { return 10;  }
        public Object getValueAt(int r, int c) {
          switch (c) {
          case 0:  return (r + 1) + ".";
          case 1:  return "Some pithy quote #" + r;
          case 2:  return data[r];
          }
          return "Bad Column";
        }
        public Class getColumnClass(int c) {
          if (c == 2) return String.class;
          return String.class;
        }
        // Make Column 2 editable.
        public boolean isCellEditable(int r, int c) {
          return c == 2;
        }
        public void setValueAt(Object value, int r, int c) {
         String s = (String)value;
         Object o=  getValueAt(r, c);
         System.out.println(s+o);
        fireTableDataChanged();
        }
      });

    table.setDefaultEditor(String.class,
                           new DefaultCellEditor(new JTextField()));
    table.setDefaultRenderer(String.class, new DefaultTableCellRenderer( ));
        table.setRowHeight(20);
    getContentPane( ).add(new JScrollPane(table));
  }

  public static void main(String args[]) {
    ColorTable ex = new ColorTable( );
    ex.setVisible(true);
  }

  public class ColorName {
    String cname;
    public ColorName(String name) { cname = name; }
    public String toString( ) { return cname; }


  }
}
