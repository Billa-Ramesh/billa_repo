package components;

import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
class StartCellEditorListener implements CellEditorListener {
    JTable table;
   // TrackModel model;
 
    public StartCellEditorListener(JTable table) {
    this.table = table;
   
    }
 
    public void editingCanceled(ChangeEvent e) {  
    }
 
    public void editingStopped(ChangeEvent e) {  
    int row = table.getSelectedRow();
    int col = table.getSelectedColumn();
    try {
        DefaultCellEditor ce = (DefaultCellEditor) e.getSource();
        JTextField c = (JTextField) ce.getComponent();
       // model.setStartTime(row, c.getText());
    } catch (Exception ex) {
        ex.printStackTrace();
        System.out.println(ex.getClass().getName());
    }
    }
}
class RadioButtonRenderer implements TableCellRenderer {
  public Component getTableCellRendererComponent(JTable table, Object value,
      boolean isSelected, boolean hasFocus, int row, int column) {
    if (value == null)
      return null;
    return (Component) value;
  }
}

class RadioButtonEditor extends DefaultCellEditor implements ItemListener {
  private JTextField textField;

  public RadioButtonEditor(JTextField textField) {
    super(textField);
  }

  public Component getTableCellEditorComponent(JTable table, Object value,
      boolean isSelected, int row, int column) {
    if (value == null)
      return null;
  value =textField.getText();
    return (Component) value;
  }

  public Object getCellEditorValue() {

    return null;
  }

  public void itemStateChanged(ItemEvent e) {
    super.fireEditingStopped();
  }
}

public class JRadioButtonTableExample extends JFrame {

  public JRadioButtonTableExample() {
    super("JRadioButtonTable Example");
    UIDefaults ui = UIManager.getLookAndFeel().getDefaults();
    UIManager.put("RadioButton.focus", ui.getColor("control"));

    DefaultTableModel dm = new DefaultTableModel();
    dm.setDataVector(new Object[][] { { "Group 1", new JRadioButton("A") },
        { "Group 1", new JRadioButton("B") },
        { "Group 1", new JRadioButton("C") },
        { "Group 2", new JRadioButton("a") },
        { "Group 2", new JRadioButton("b") } }, new Object[] {
        "String", "JRadioButton" });

    JTable table = new JTable(dm) {
      public void tableChanged(TableModelEvent e) {
        super.tableChanged(e);
        repaint();
      }
    };
    ButtonGroup group1 = new ButtonGroup();
    group1.add((JRadioButton) dm.getValueAt(0, 1));
    group1.add((JRadioButton) dm.getValueAt(1, 1));
    group1.add((JRadioButton) dm.getValueAt(2, 1));
    ButtonGroup group2 = new ButtonGroup();
    group2.add((JRadioButton) dm.getValueAt(3, 1));
    group2.add((JRadioButton) dm.getValueAt(4, 1));
    table.getColumn("String").setCellRenderer(
        new RadioButtonRenderer());
    table.getColumn("String").setCellEditor(
        new RadioButtonEditor(new JTextField()));
       JScrollPane scroll = new JScrollPane(table);
    getContentPane().add(scroll);
    setSize(200, 140);
    setVisible(true);
  }

  public static void main(String[] args) {
    JRadioButtonTableExample frame = new JRadioButtonTableExample();
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
}

           
         
