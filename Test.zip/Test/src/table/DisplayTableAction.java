package table;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import javax.swing.table.*;
import javax.swing.event.*;

public class DisplayTableAction {
	JTextField text5 = null;

	public static void main(String arg[]) {
		DisplayTableAction action = new DisplayTableAction();
	}

	public DisplayTableAction() {
		ListSelectionModel listSelectionModel;
		final Vector columnNames = new Vector();
		final Vector data = new Vector();
		try {
			Connection con = null;
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/test",
					"root", "root");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("Select * from person");
			ResultSetMetaData md = rs.getMetaData();

			int columns = md.getColumnCount();
			for (int i = 1; i <= columns; i++) {
				columnNames.addElement(md.getColumnName(i));
			}
			while (rs.next()) {
				Vector row = new Vector(columns);
				for (int i = 1; i <= columns; i++) {
					row.addElement(rs.getObject(i));
				}
				data.addElement(row);
			}
			rs.close();
			st.close();
		} catch (Exception e) {
		}
		JFrame frame = new JFrame();
		frame.setLayout(null);
		final JLabel lab1 = new JLabel("ID");
		final JTextField text1 = new JTextField(20);

		final JLabel lab2 = new JLabel("Name");
		final JTextField text2 = new JTextField(20);

		final JLabel lab3 = new JLabel("Address");
		final JTextField text3 = new JTextField(20);

		final JLabel lab4 = new JLabel("Email");
		final JTextField text4 = new JTextField(20);
		text5 = new JTextField(20);
		lab1.setBounds(10, 230, 100, 20);
		text1.setBounds(70, 230, 100, 20);

		lab2.setBounds(10, 250, 100, 20);
		text2.setBounds(70, 250, 100, 20);

		lab3.setBounds(10, 270, 100, 20);
		text3.setBounds(70, 270, 100, 20);

		lab4.setBounds(10, 290, 100, 20);
		text4.setBounds(70, 290, 100, 20);
		text5.setBounds(70, 320, 100, 20);

		final JTable table = new JTable(data, columnNames);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 10, 700, 200);
		frame.add(lab1);
		frame.add(text1);

		frame.add(lab2);
		frame.add(text2);

		frame.add(lab3);
		frame.add(text3);

		frame.add(lab4);
		frame.add(text4);
		frame.add(text5);
		frame.add(scrollPane);
		frame.setVisible(true);
		frame.setSize(800, 500);
		/*
		 * lab1.setVisible(false); text1.setVisible(false);
		 * 
		 * lab2.setVisible(false); text2.setVisible(false);
		 * 
		 * lab3.setVisible(false); text3.setVisible(false);
		 * 
		 * lab4.setVisible(false); text4.setVisible(false);
		 */
		table.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				System.out.println("release");

			}

			@SuppressWarnings("static-access")
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

				// sysdata.lastElement();

				int is = e.getKeyCode();
				System.out.println(is);
				Object obj1 = null, obj2 = null, obj3 = null, obj4 = null;
				// String q="";
				int i = table.getSelectedRow();
				if (e.getKeyCode() == 40) {
					i++;
				}
				// int keyCode=e.get;
				// System.out.println(keyCode);
				// System.out.println(KeyEvent.VK_KP_UP);
				// System.out.println(e.VK_KP_DOWN);

				/*
				 * if(224==KeyEvent.VK_KP_UP){
				 * 
				 * i=i+1; System.out.println(i+"inup"); }
				 */
				/*
				 * System.out.println(i); if(i==0){ counter1++;
				 * q=Integer.toString(counter1); System.out.println(q+counter1);
				 * } if(i==1){ counter2++; q=Integer.toString(counter2);
				 * System.out.println(q+counter1); } if(i==2){ counter3++;
				 * q=Integer.toString(counter3); System.out.println(q+counter1);
				 * } if(i==3){ counter4++; q=Integer.toString(counter4);
				 * System.out.println(q+counter1); }
				 */
				obj1 = GetData(table, i, 0);
				obj2 = GetData(table, i, 1);
				obj3 = GetData(table, i, 2);
				obj4 = GetData(table, i, 3);

				lab1.setVisible(true);
				text1.setVisible(true);

				lab2.setVisible(true);
				text2.setVisible(true);

				lab3.setVisible(true);
				text3.setVisible(true);

				lab4.setVisible(true);
				text4.setVisible(true);
				text1.setText(obj1.toString());
				text2.setText(obj2.toString());
				text3.setText(obj3.toString());
				text4.setText(obj4.toString());

			}
		});
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {

				Object obj1 = null, obj2 = null, obj3 = null, obj4 = null;
				// String q="";
				int i = table.getSelectedRow();
				/*
				 * System.out.println(i); if(i==0){ counter1++;
				 * q=Integer.toString(counter1); System.out.println(q+counter1);
				 * } if(i==1){ counter2++; q=Integer.toString(counter2);
				 * System.out.println(q+counter1); } if(i==2){ counter3++;
				 * q=Integer.toString(counter3); System.out.println(q+counter1);
				 * } if(i==3){ counter4++; q=Integer.toString(counter4);
				 * System.out.println(q+counter1); }
				 */
				obj1 = GetData(table, i, 0);
				obj2 = GetData(table, i, 1);
				obj3 = GetData(table, i, 2);
				obj4 = GetData(table, i, 3);

				lab1.setVisible(true);
				text1.setVisible(true);

				lab2.setVisible(true);
				text2.setVisible(true);

				lab3.setVisible(true);
				text3.setVisible(true);

				lab4.setVisible(true);
				text4.setVisible(true);
				text1.setText(obj1.toString());
				text2.setText(obj2.toString());
				text3.setText(obj3.toString());
				text4.setText(obj4.toString());

			}
		});

	}

	public Object GetData(JTable table, int row_index, int col_index) {

		String s = table.getColumnName(col_index);
		// System.out.println(s);
		if (s.equalsIgnoreCase("name"))
			// System.out.println(table.getModel().getValueAt(row_index,
			// col_index));
			text5.setText(table.getModel().getValueAt(row_index, col_index)
					.toString());
		return table.getModel().getValueAt(row_index, col_index);
	}
}