package table;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.table.TableModel;

public class CCellEditor extends DefaultCellEditor {

    private JTable m_Table = null;

    public CCellEditor(JFrame parentFrame, JTable table) { 
        super(new JTextField());
        super.setClickCountToStart(1);
        m_Table = table;
    }
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, final int row, int column){

        if(row==0) // comBoBox for First row
        {
            Object[] objectArray = {"3D","2D"};
            JComboBox comboBox = new JComboBox(objectArray);
            comboBox.setEditable(true);
            comboBox.setSelectedItem(value);

            ItemListener itemListener = new ItemListener() {
                public void itemStateChanged(ItemEvent e) {
                    if(e.getStateChange() == ItemEvent.SELECTED) {
                        if(null != m_Table.getCellEditor()){ 
                            m_Table.getCellEditor().stopCellEditing();
                        }

                        m_Table.setValueAt(e.getItem(), row, 1);
                    }
                }
            };
            comboBox.addItemListener(itemListener);

            PopupMenuListener popMenuEvent = new PopupMenuListener() {

                public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
                }

                public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
                    String sValue = (String)m_Table.getValueAt(row, 1);
                    System.out.println(sValue);
                    if(null != m_Table.getCellEditor()){ 
                        m_Table.getCellEditor().stopCellEditing();
                    }
                    m_Table.setValueAt(sValue, row, 1);
                }

                public void popupMenuCanceled(PopupMenuEvent e) {   
                }

            };
            comboBox.addPopupMenuListener(popMenuEvent);

            return comboBox;

        }

        else  if(row==1)  // fileChooser for Second row
        {
            JFileChooser fileChooser;
            fileChooser = new JFileChooser("c:\\");
            fileChooser.setFileSelectionMode( JFileChooser.DIRECTORIES_ONLY );
            fileChooser.setVisible(true);
            int returnVal = fileChooser.showOpenDialog(null);

            JTextField textField = (JTextField)super.getTableCellEditorComponent(table, value, isSelected, row, column);
            textField.setBackground(Color.yellow);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File m_fFirmware= fileChooser.getSelectedFile();

                textField.setText(m_fFirmware.getPath());
                return textField;

            }else
            {
                return textField; 

            }
        }
                                // for any other rows
        JTextField textField = (JTextField)super.getTableCellEditorComponent(table, value, isSelected, row, column);
        return textField;

    }

    public static void main(String[] a) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        String[] columnTitles = { "Name", "Value"};
        Object[][] dataEntries = {
                { "Movie Type:", "3D" }, {"Folder:","C:"}, {"# of Movies requested:","5"}};
        TableModel model = new EditableTableModel(columnTitles, dataEntries);
        JTable table = new JTable(model);
        table.createDefaultColumnsFromModel();
        table.setDefaultEditor(Object.class, new CCellEditor(frame, table));
      
        frame.add(new JScrollPane(table));
        frame.setSize(300, 200);
        frame.setVisible(true);
    }

}