/* This source is part of the Oracle Financial Services Software System and is copyrighted by i-flex Solutions
Limited. All rights reserved.  No part of this work may be reproduced, stored in a retrieval
system, adopted or transmitted in any form or by any means, electronic, mechanical, photographic,
graphic, optic recording or otherwise, translated in any language or computer language, without
the prior written permission of i-flex Solutions Limited.

i-flex Solutions Limited. 10-11, SDF I, SEEPZ, Andheri (East), Mumbai - 400 096. India

Copyright ? 1998 - 2007 i-flex Solutions Limited.

----------------------------------------------------------------------------------------------------
 * @author Shirali Shah
 * @version 1.0
 * @since
 * ----------------------------------------CHANGE HISTORY-----------------------------------
 * -----------------------------------------------------------------------------------------
*/

//Pager.js

function Pager(tableID, pageSize, totalCols, checkAllBoxID)
{
	this.tableID = tableID;
	this.tableObj = document.getElementById(this.tableID);

	this.checkAllBoxID = checkAllBoxID;

	this.totalCols = totalCols;
	this.totalRows = 0;
	this.curPage = 1;
	this.pageCnt = 0;
	this.pageSize = pageSize;

	this.navBarVar = '';
	this.navBarID = '';

	this.setRecordCount();

	this.dataArr = new Array();
	this.rowIDArr = new Array();
	this.cellIDArr = new Array();
	this.chkBoxSelArr = new Array(this.totalRows);
	for(var i = 0; i < this.chkBoxSelArr.length; i++)
		this.chkBoxSelArr[i] = 0;
	this.colFormatOptions = new Array(3);

	if(this.totalRows > 0)
		this.getFormatOptions();

	this.populateRecords();
}

Pager.prototype.display = function()
{
	this.fetchRecords();
};

Pager.prototype.getFormatOptions = function()
{
	/* This is array of 3 rows each of which corresponds to one formatting option.
	Each row is itself an array.
	First - Column widths in percentage
	Second - Alignment options
	Third - Style for the row

	More rows can be added for other formatting options.
	*/
	for(var i = 0; i < 3; i++)
	{
		this.colFormatOptions[i] = new Array(this.totalCols);
	}

	for(var i = 0; i < this.totalCols; i++)
	{
		this.colFormatOptions[0][i] = this.tableObj.rows[0].cells[i].width;
		this.colFormatOptions[1][i] = this.tableObj.rows[0].cells[i].align;
		this.colFormatOptions[2][i] = this.tableObj.rows[0].cells[i].className;
	}
};

Pager.prototype.setRecordCount = function()
{
	this.totalRows = (this.tableObj && this.tableObj.rows ? this.tableObj.rows.length : 0);
	this.setPageCount();
};

Pager.prototype.setPageCount = function()
{
	this.pageCnt = Math.ceil(this.totalRows / this.pageSize);
};

Pager.prototype.populateRecords = function()
{
	for(var i = 0; i < this.totalRows; i++)
	{
		this.dataArr[i] = new Array(this.totalCols);
		this.cellIDArr[i] = new Array(this.totalCols);
		this.rowIDArr[i] = this.tableObj.rows[i].id;

		for(var j = 0; j < this.totalCols; j++)
		{
			this.dataArr[i][j] = this.tableObj.rows[i].cells[j].innerHTML;
			this.cellIDArr[i][j] = this.tableObj.rows[i].cells[j].id;
		}
	}
};

Pager.prototype.moveFirst = function()
{
	if(this.curPage != 1)
	{
		this.updateRecordsOnNavigation();
		this.curPage = 1;
		this.fetchRecords();
	}else {
			alert(firstPageMessage);
		}
};

Pager.prototype.movePrev =  function()
{
	if(this.curPage != 1)
	{
		this.updateRecordsOnNavigation();
		this.curPage--;
		this.fetchRecords();
	}else {
			alert(firstPageMessage);
		}
};

Pager.prototype.moveNext = function()
{
	if(this.curPage != this.pageCnt)
	{
		this.updateRecordsOnNavigation();
		this.curPage++;
		this.fetchRecords();
	}else {
			alert(lastPageMessage);
		}
};

Pager.prototype.moveLast = function()
{
	if(this.curPage != this.pageCnt)
	{
		this.updateRecordsOnNavigation();
		this.curPage = this.pageCnt;
		this.fetchRecords();
	}else {
			alert(lastPageMessage);
		}
};

Pager.prototype.getFirstRecPage = function()
{
	var lastRec = this.getLastRecPage();

	if (lastRec == 0)
		return (0);
	else if (lastRec <= this.pageSize)
		return (1);
	else
	{
		var firstRec = this.pageSize * (this.curPage - 1) + 1;
		return(firstRec);
	}
};

Pager.prototype.getLastRecPage = function()
{
	if(this.totalRows > 0)
	{
		var lastRec = this.curPage * this.pageSize;
		if(lastRec > this.totalRows)
			lastRec = this.totalRows;
		return(lastRec);
	}
	else
		return (0);
};

Pager.prototype.getTotalRecordCount = function()
{
	return this.totalRows;
};

Pager.prototype.navBar = function(varName, navBarID)
{
	var e = document.getElementById(navBarID);
	if (!e)
		return;

	this.navBarVar = varName;
	this.navBarID = navBarID;

	var s = '';

	s += '<table width=195>';
	s += '<tr>';
	s += '<td class=vcrInfo valign=middle align=right>';
	s += this.getFirstRecPage();
	s += ' to ';
	s += this.getLastRecPage();
	s += ' of ';
	s += this.getTotalRecordCount();
	s += '</td>';
	s += '<td width=5><a style=cursor:pointer onClick="' + this.navBarVar + '.moveFirst()"><img src=images/vcr_buttons_first.gif border=0></a></td>';
	s += '<td width=5><a style=cursor:pointer onClick="' + this.navBarVar + '.movePrev()"><img src=images/vcr_buttons_back.gif border=0></a></td>';
	s += '<td width=5><a style=cursor:pointer onClick="' + this.navBarVar + '.moveNext()"><img src=images/vcr_buttons_next.gif border=0></a></td>';
	s += '<td width=5><a style=cursor:pointer onClick="' + this.navBarVar + '.moveLast()"><img src=images/vcr_buttons_last.gif border=0></a></td>';
	s += '</tr>';
	s += '</table>';

	e.innerHTML = s;
};

Pager.prototype.fetchRecords = function()
{
	if(this.totalRows > 0)
	{
		this.deleteRows();

		var fIndex = this.getFirstRecPage();
		var lIndex = this.getLastRecPage();

		for(var i = fIndex; i <= lIndex; i++)
		{
			var newRow = this.tableObj.insertRow();
			newRow.id = this.rowIDArr[i-1];

			/**if( (i % 2) == 0)
				newRow.className = "row3";
			else	
			newRow.className = "row2";  **/

			for(var j = 0; j < this.totalCols; j++)
			{
				var newCell = newRow.insertCell();

				newCell.width = this.colFormatOptions[0][j];
				newCell.align = this.colFormatOptions[1][j];
				newCell.className = this.colFormatOptions[2][j];
				newCell.id = this.cellIDArr[i-1][j];
				newCell.innerHTML = this.dataArr[i-1][j];
			}
		}

		if(this.checkAllBoxID != 'NA')
			this.showSelectedRows(fIndex, lIndex);
		this.navBar(this.navBarVar, this.navBarID);
	}
};

Pager.prototype.showSelectedRows = function(fIndex, lIndex)
{
	var checkAllCount = 0;

	for(var i = fIndex; i <= lIndex; i++)
	{
		if (this.chkBoxSelArr[i-1] == 1)
		{
			document.getElementById('CHK' + i).checked = true;
			checkAllCount++;
		}
	}

	var pageRecCnt = lIndex - fIndex + 1;

	if(checkAllCount == pageRecCnt)
		document.getElementById(this.checkAllBoxID).checked = true;
	else
		document.getElementById(this.checkAllBoxID).checked = false;
}

Pager.prototype.deleteRows = function()
{
	var lastRow = this.tableObj.rows.length;

	for(var i = 1; i <= lastRow; i++)
		this.tableObj.deleteRow();
};

Pager.prototype.updateRecordsOnNavigation = function()
{
	var fRec = this.getFirstRecPage();
	var lRec = this.getLastRecPage();

	var cnt = 0;

	if(fRec != 0)
	{
		for(var i = fRec; i <= lRec; i++)
		{
			if(this.checkAllBoxID != 'NA')
			{
				var chkBox = document.getElementById('CHK' + i);
				if(chkBox.checked == true)
					this.chkBoxSelArr[i-1] = 1;
				else
					this.chkBoxSelArr[i-1] = 0;
			}

			for(var j = 0; j < this.totalCols; j++)
			{
				this.dataArr[i-1][j] = this.tableObj.rows[cnt].cells[j].innerHTML;
			}

			cnt++;
		}
	}
}