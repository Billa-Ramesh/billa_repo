/********************************************************************************************************************
*   This source is part of the Liqidity Risk Management Software System and is copyrighted by Oracle Financial 		*
*	Services Software Limited.All rights reserved. No part of this work may be reproduced, stored in a retrieval	*
*	system, adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic,		*
*	optic recording or otherwise, translated in any language or computer language, without the prior written 		*
*	permission of Oracle Financial Services Software Limited.														*
*																													*
*	Oracle Financial Services Software Limited.																		*
*	10-11, SDF I, SEEPZ, Andheri (East),																			*
*	Mumbai - 400 096. 																								*
*	India																											*
*																													*
*	Copyright � 2011 Oracle Financial Services Software Limited. All rights reserved. 								*
*	--------------------------------------------------------------------------------------------------------		*
*	Module Name           :   CommonFunctions.js																	*
*	Created By            :   Shirali Shah																			*
*	Created On            :   																						*
*	Description           :   									 													*
*																													*
*	Modification History																							*
*	---------------------------------------------------------------------------------------------------------		*
*	Modification On:          Modified By:                Modifcation Details										*
*	---------------------------------------------------------------------------------------------------------		*
*																													*
********************************************************************************************************************/

//CommonFunctions.js
function validate_negative_decimal_nummbers(obj,decimalPlaces,allowNegative)
{
	var temp = document.getElementById(obj).value;
	var reg0Str = '[0-9]*';

	if (decimalPlaces > 0)	{
				reg0Str += '\\.?[0-9]{0,' + decimalPlaces + '}';
	}
	else if (decimalPlaces < 0)	{
				reg0Str += '\\.?[0-9]*';
	}
	reg0Str = allowNegative ? '^-?' + reg0Str : '^' + reg0Str;
	reg0Str = reg0Str + '$';

	var reg0 = new RegExp(reg0Str);
	if (reg0.test(temp))	{
				return true;
	}

	var reg1Str = '[^0-9' + (decimalPlaces != 0 ? '.' : '') + (allowNegative ? '-' : '') + ']';
	var reg1 = new RegExp(reg1Str, 'g');

	temp = temp.replace(reg1, '');
	var hasNegative = temp.length > 0 && temp.charAt(0) == '-';
	var reg2 = /-/g;
	temp = temp.replace(reg2, '');

	if (hasNegative)	{
				temp = '-' + temp;
	}

	if (decimalPlaces != 0)	{
				var reg3 = /\./g;
				var reg3Array = reg3.exec(temp);

				if (reg3Array != null)				{
							var reg3Right = temp.substring(reg3Array.index + reg3Array[0].length);
							reg3Right = reg3Right.replace(reg3, '');
							reg3Right = decimalPlaces > 0 ? reg3Right.substring(0, decimalPlaces) : reg3Right;
							temp = temp.substring(0,reg3Array.index) + '.' + reg3Right;
				}
	}
	document.getElementById(obj).value = temp;
}

function noEnter()
{
	var characterCode = window.event.keyCode;
	if(characterCode == 13)
		window.event.keyCode=0;
}

function openCenteredWindow(width,height,resizable,scroll)
{
	if((width>(screen.availWidth-10))||(height>(screen.availHeight-30)))
	{
		scroll = 'yes';
		var Width = parseInt(screen.availWidth-10);
		var Height = parseInt(screen.availHeight-30);
		var left = 0;
		var top = 0;

	}
    else
	{
		var Width = width;
		var Height = height;
		var left = parseInt(((screen.availWidth-10)/2) - (width/2));
	    var top = parseInt(((screen.availHeight-30)/2) - (height/2));
	}
    var windowFeatures = "width=" + Width + ",height=" + Height + ",resizable=" + resizable + ",scrollbars=" + scroll + ",left=" + left + ",top=" + top + ",screenX=" + left + ",screenY=" + top ;
	return windowFeatures;
}

function trimAll(sString)
{
	if(sString != null && sString != '')
	{
		while (sString.substring(0,1) == ' ')
		{
			sString = sString.substring(1, sString.length);
		}
		while (sString.substring(sString.length-1, sString.length) == ' ')
		{
			sString = sString.substring(0,sString.length-1);
		}
	}
	return sString;
}

function trimLeft(sString)
{
	if(sString != null && sString != '')
	{
		while (sString.substring(0,1) == ' ')
		{
			sString = sString.substring(1, sString.length);
		}
	}
	return sString;
}

function trimRight(sString)
{
	if(sString != null && sString != '')
	{
		while (sString.substring(sString.length-1, sString.length) == ' ')
		{
			sString = sString.substring(0,sString.length-1);
		}
	}
	return sString;
}

function cleanInput(varStr)
{
	if(varStr != null && varStr != '')
	{
	   var newVarStr = trimAll(varStr.replace(/\r|\n/g,''));
	   newVarStr = newVarStr.replace(/\s/g, '+');
	   return newVarStr;
	}
	else
	{
		return varStr;
	}
}

//Creates a new window as Model Dialog.
//theURL 	- URL for the new window.
//winObject	- object passed to new window.
//features	- pass window size arguments [eg. "dialogWidth:700px; dialogHeight:550px; status:no; center:yes"]
function openModalWindow(theURL,winObject,features)
{
	window.showModalDialog(theURL,winObject,features);
}

function splitString(sName, sLength)
{
   if(sName.length <= sLength)
      return sName;

   var sNameArr = sName.split('');
   var sNameArrNew = new Array();
   var cnt = -1;

   for(var i = 0; i < sNameArr.length; i++)
   {
      if((i != 0) && (i % sLength == 0))
      {
         sNameArrNew[++cnt] = '</br>';
      }
      sNameArrNew[++cnt] = sNameArr[i];
   }

   return sNameArrNew.join('');
}

function checkForSpecialCharacters(paramString){
	paramString = paramString.replace(/\:/g,"{COLN}");
	paramString = paramString.replace(/\$/g,"{DOLR}");
	paramString = paramString.replace(/\%/g,"{PERC}");
	paramString = paramString.replace(/\&/g,"{AMBD}");
	paramString = paramString.replace(/\@/g,"{ARTE}");
	paramString = paramString.replace(/\#/g,"{HASH}");
	paramString = paramString.replace(/\!/g,"{EXCN}");	
	paramString = paramString.replace(/\(/g,"{ANBTO}");
	paramString = paramString.replace(/\)/g,"{ANBTC}");
	paramString = paramString.replace(/\*/g,"{STAR}");
	paramString = paramString.replace(/\+/g,"{PLUS}");
	paramString = paramString.replace(/\,/g,"{COMA}");
	paramString = paramString.replace(/\;/g,"{SMCLN}");
	paramString = paramString.replace(/\=/g,"{EQTO}");
	paramString = paramString.replace(/\?/g,"{QTMK}");
	paramString = paramString.replace(/\[/g,"{SQBTO}");
	paramString = paramString.replace(/\]/g,"{SQBTC}");
	paramString = paramString.replace(/\^/g,"{CAROT}");
	paramString = paramString.replace(/\|/g,"{PIPE}");
	return paramString;
}

function replaceSpecialCharacters(paramString){
	paramString = paramString.replace(/\{COLN\}/g,":");
	paramString = paramString.replace(/\{DOLR\}/g,"$");
	paramString = paramString.replace(/\{PERC\}/g,"%");
	paramString = paramString.replace(/\{AMBD\}/g,"&");
	paramString = paramString.replace(/\{ARTE\}/g,"@");
	paramString = paramString.replace(/\{HASH\}/g,"#");
	paramString = paramString.replace(/\{EXCN\}/g,"!");	
	paramString = paramString.replace(/\{ANBTO\}/g,"(");
	paramString = paramString.replace(/\{ANBTC\}/g,")");
	paramString = paramString.replace(/\{STAR\}/g,"*");
	paramString = paramString.replace(/\{PLUS\}/g,"+");
	paramString = paramString.replace(/\{COMA\}/g,",");
	paramString = paramString.replace(/\{SMCLN\}/g,";");
	paramString = paramString.replace(/\{EQTO\}/g,"=");
	paramString = paramString.replace(/\{QTMK\}/g,"?");
	paramString = paramString.replace(/\{SQBTO\}/g,"[");
	paramString = paramString.replace(/\{SQBTC\}/g,"]");
	paramString = paramString.replace(/\{CAROT\}/g,"^");
	paramString = paramString.replace(/\{PIPE\}/g,"|");
	return paramString;
}

function downloadFile(servletName, dsn, userID, fileName)
{	
	var destURL = servletName;
	destURL += '?dsn=' + dsn;
	destURL += '&userID=' + userID;
	destURL += '&fileName=' + fileName;
	
	if(document.getElementById("downloadDiv") == null)
    {
        downloadDiv = document.createElement("div");
        document.getElementsByTagName("body")[0].appendChild(downloadDiv);
        downloadDiv.style.width = "0px";
        downloadDiv.style.height = "0px";
        downloadDiv.id = "downloadDiv";
    }
    else
    {
        downloadDiv = document.getElementById("downloadDiv");
    }
    if(document.getElementById("downloadFrame") == null)
    {
        downloadFrame = document.createElement("iframe");
        downloadFrame.id = "downloadFrame";
        downloadFrame.src = destURL; 
        downloadFrame.scrolling = "no";
        downloadFrame.style.width = "0px";
        downloadFrame.style.height = "0px";
        downloadDiv.innerHTML = downloadFrame.outerHTML;
    }
    else
    {
        downloadFrame = document.getElementById("downloadFrame");
        downloadFrame.src = destURL;
    }
}

function popUpAlert(messageTitle,popUpMessage,messageType,shouldPrompt){
	if(shouldPrompt=="true"||shouldPrompt==""||shouldPrompt==null){
	var retVal = window.showModalDialog(glbl_contextPath+'/lrst/common/PopupAlert.jsp?alrtVal='+messageTitle, popUpMessage+'~'+messageType,'dialogHeight:190px;dialogWidth:686px;status:no;help:no');	
	return retVal;
}
}

function checkForSpecialCharsForSearch(searchStr)
{
	searchStr = searchStr.replace(/%/g,'{PERC}');	
   	searchStr = searchStr.replace(/\+/g,'{PLUS}');
   	searchStr = searchStr.replace(/\&/g,'{AMBD}');
   	return searchStr;
}

function replaceHTMLCodes(htmlStr)
{
	htmlStr = htmlStr.replace(/\</g,'&lt');	
   	return htmlStr;
}

function checkForSpace(textObject){
	var name = textObject.value;
	if(name != null){
		var cntrlkey=String.fromCharCode(window.event.keyCode);
		if(name.length > 0){
			nameArray = name.slice(name.length-1,name.length);			
			if(nameArray == " " && cntrlkey == " ")
				window.event.keyCode=0;
		}
		if(name.length == 0 && cntrlkey == " "){
			window.event.keyCode=0;
		}
	}
}

function fn_checkforEsc(evt){
	evt = (evt)? evt : ((event)? event : null); 
	if (evt) { 
		if (event.keyCode == 27) {
			return true;
		}
	}
}

function validateLastChar(textObject){
	var name = textObject.value;
	if(name != null){
		lastChar = name.slice(name.length-1,name.length);
		if(lastChar == " "){
			textObject.value = name.substring(0,name.length-1);
		}
	}
}

function fn_checkDescLength(textObject,length)
{
	if(textObject.value.length > length){		
		window.event.keyCode=0;
	}
}

function cursorPosition(textarea){	
	textarea.focus();
	// get selection in firefox, opera,
	if (typeof(textarea.selectionStart) == 'number'){ 
		return textarea.selectionStart;
	}else if(document.selection){
		var selection_range = document.selection.createRange().duplicate();		
		if (selection_range.parentElement().tagName == "INPUT"){
			var oSel = document.selection.createRange ();
			//before_range.moveToElementText(textarea); 
			// Move selection start to 0 position
			oSel.moveStart ('character', -textarea.value.length);
			// The caret position is selection length
			iCaretPos = oSel.text.length;
			var cntrlkey=String.fromCharCode(window.event.keyCode);		
			if(iCaretPos == 0  && cntrlkey == " ")
				window.event.keyCode=0;
			nameArray = textarea.value.slice(iCaretPos-1,iCaretPos);			
			if(nameArray == " " && cntrlkey == " ")
				window.event.keyCode=0;
			nameArray = textarea.value.slice(iCaretPos,iCaretPos+1);
			if(nameArray != null && nameArray == " " && cntrlkey == " ")
				window.event.keyCode=0;						
		}else if (selection_range.parentElement() == textarea) { 		
		    // Check that the selection is actually in our textarea
			// Create three ranges, one containing all the text before the selection,
			// one containing all the text in the selection (this already exists), and one containing all
			// the text after the selection.
			var before_range = document.body.createTextRange();
			before_range.moveToElementText(textarea); // Selects all the text
			before_range.setEndPoint('EndToStart', selection_range); // Moves the end where we need it
	
			var after_range = document.body.createTextRange();
			after_range.moveToElementText(textarea); // Selects all the text
			after_range.setEndPoint('StartToEnd', selection_range); // Moves the start where we need it
	
			var before_finished = false, selection_finished = false, after_finished = false;
			var before_text, untrimmed_before_text, selection_text, untrimmed_selection_text, after_text, untrimmed_after_text;
	
			// Load the text values we need to compare
			before_text = untrimmed_before_text = before_range.text;
			selection_text = untrimmed_selection_text = selection_range.text;
			after_text = untrimmed_after_text = after_range.text;
	
			// Check each range for trimmed newlines by shrinking the range by 1 character and seeing
			// if the text property has changed. If it has not changed then we know that IE has trimmed
			// a \r\n from the end.
			do {
				if (!before_finished) {
					if (before_range.compareEndPoints('StartToEnd', before_range) == 0) {
						before_finished = true;
					} else {
						before_range.moveEnd('character', -1)
						if (before_range.text == before_text) {
							untrimmed_before_text += '\r\n';
						} else {
							before_finished = true;
						}
					}
				}
				if (!selection_finished) {
					if (selection_range.compareEndPoints('StartToEnd', selection_range) == 0) {
						selection_finished = true;
					} else {
						selection_range.moveEnd('character', -1)
						if (selection_range.text == selection_text) {
							untrimmed_selection_text += '\r\n';
						} else {
							selection_finished = true;
						}
					}
				}
				if (!after_finished) {
					if (after_range.compareEndPoints('StartToEnd', after_range) == 0) {
						after_finished = true;
					} else {
						after_range.moveEnd('character', -1)
						if (after_range.text == after_text) {
							untrimmed_after_text += '\r\n';
						} else {
							after_finished = true;
						}
					}
				}
			} while ((!before_finished || !selection_finished || !after_finished));
					
			var startPoint = untrimmed_before_text.length;						
			var cntrlkey=String.fromCharCode(window.event.keyCode);		
			if(startPoint == 0  && cntrlkey == " ")
				window.event.keyCode=0;
			nameArray = textarea.value.slice(startPoint-1,startPoint);			
			if(nameArray == " " && cntrlkey == " ")
				window.event.keyCode=0;
			nameArray = textarea.value.slice(startPoint,startPoint+1);
			if(nameArray != null && nameArray == " " && cntrlkey == " ")
				window.event.keyCode=0;
		}
	}
}	