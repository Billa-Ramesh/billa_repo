/* 

*
* This source is part of the General Ledger Software Product. 
* Copyright � 2009 , 2012, Oracle and/or its affiliates.  All rights reserved. 

* No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical, * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of  
* Oracle and/or its affiliates. 

* Oracle Financial Services Software Limited.
* Oracle Park, Off Western Express Highway,
* Goregaon (East), 
* Mumbai - 400 063, India.
* Copyright � 1997, 2012, Oracle and/or its affiliates. All rights reserved.

* JS Script PAGE for Recon Management Screen
*
*Created   19/03/2012   Rahul M  
*
*
*
*/

var isRefresh = true;
var allocSel = false;
var isVldnReqd = true;
	var hierParentNodeMap = new Map();
	var hierCodeTypeMap = new Map();
	var hierFilterStatMap = new Map();

	var hierParentNodeMapForTp  = new Map();
	var hierCodeTypeMapForTp = new Map();
	var hierFilterStatMapForTp = new Map();

	var hierParentNodeMapForDim  = new Map();
	var hierCodeTypeMapForDim = new Map();
	var hierFilterStatMapForDim = new Map();

	var hiercddescMap  = new Map();
	
var mandatoryflds  = new Array();
var excludeflds  = new Array();
var dynamicparmArry  = new Array();
var dynamichierMap = new Map();
var leBasedMap = new Map();
var predifedval="";
var hierlist="";
var xmlHttp;
var paramtypeMap = new Map();
var hiernodeMap = new Map();
var fldidDescMap = new Map();


var hiernodedescArry  = new Array();
var hiernodecodeArry  = new Array();


/*Added by Rahul*/

document.getElementsByClassName = function(cl) {

	var retnode = [];
	var myclass = new RegExp('\\b'+cl+'\\b');
	var elem = this.getElementsByTagName('td');

	for (var i = 0; i < elem.length; i++) {
		var classes = elem[i].className;
		if (myclass.test(classes)) retnode.push(elem[i]);
	}
	return retnode;
}; 

function onLoadBody(){

if(!isRefresh)
	return true;

//Set the first value of all Radio buttons
var elem = document.getElementsByTagName('input');
	for (var i = 0; i < elem.length; i++) {
		if(elem[i].type == "radio"){
			if(i%2 == 0)
			{
				document.getElementById(elem[i].id).checked = true;
			}	
		}
	}
//Call Radio Button behaviour functions	
	adjAlloc();
	adjPostedTo();
	selectGLMap();
	allocReqd();
	
	document.getElementById("infoDom").value = "<%=sInfodom%>";
	document.getElementById("mapId").value = "<%=sMapId%>";
	document.getElementById("versionNum").value = "<%=sVersionNum%>";
	document.getElementById("pageMode").value =  "<%=sPageMode%>";
	document.getElementById("isActOrPass").value = "<%=sScrName%>";

	
	isRefresh = false;
}

function saveFunction(){

	/* var arr1 = document.getElementsByName("tpFilterHierCode");
	var arr2 = document.getElementsByName("glFilterHierCode");
	
	for(var i=0;i<arr1.length;i++){
		arr1[i].nextSibling.click();
	}
	
	for(var i=0;i<arr2.length;i++){
		arr2[i].nextSibling.click();
	}
	 */
	 
	 // Get Filter Values and prepare for backend
	var keySet1 = hierParentNodeMapForTp.getKeySet();
	var str1 = "";
	
	for(var k=0;k<keySet1.length;k++){
		
		
		var sArr1 =  hierParentNodeMapForTp.get(keySet1[k]).split("{*}");
		for(var i=0;i<sArr1.length;i++){
			var sArr2 = sArr1[i].split("~")
				for(var j=0;j<sArr2.length;j++){
					if(j%2 == 0){
						if(sArr2[j] != ""){
							str1 += keySet1[k].split("~")[0];
							str1 += "~@~";
							str1 += sArr2[j];
							str1 += "~~";
						}
					}
				}
		}
		
		
		str1 += "#@#";
		
	}
	
	var keySet2 = hierParentNodeMap.getKeySet();
	var str2="";
	
	for(var k=0;k<keySet2.length;k++){
		
		
		var sArr1 =  hierParentNodeMap.get(keySet2[k]).split("{*}");
		for(var i=0;i<sArr1.length;i++){
			var sArr2 = sArr1[i].split("~")
				for(var j=0;j<sArr2.length;j++){
					if(j%2 == 0){
						if(sArr2[j] != ""){
							str2 += keySet2[k].split("~")[0];
							str2 += "~@~";
							str2 += sArr2[j];
							str2 += "~~";
						}
					}
				}
		}
		
		
		str2 += "#@#";
		
	}

	
	document.getElementById("tpFilterHierCode").value = str1;
	document.getElementById("glFilterHierCode").value = str2;
	
	//Set Dimension Desc and Code
	var dimTable =  document.getElementById("dimTable");
	var rows = dimTable.rows;
	var reconDim = document.getElementById("reconDim").value;
	var reconDimCode = document.getElementById("reconDimCode").value;
	
	for(var i=0;i<rows.length;i++){
	
		reconDim = reconDim + "," + rows[i].lastChild.innerHTML;
		reconDimCode = reconDimCode + "," + rows[i].lastChild.id;
		
	}
	document.getElementById("reconDim").value = reconDim;
	document.getElementById("reconDimCode").value = reconDimCode;
	
	//Set User
	document.getElementById("createdUser").value = document.getElementById("userTd").innerHTML; 
	
	//Disabled Fields are not submitted with the form. Hence remove the property !!!!
	for(var i=2;i<document.getElementById("allocTable").rows.length;i++){
		if(document.getElementById("balAmtAlloc")+i)
			document.getElementById("balAmtAlloc" + i).removeAttribute("disabled");
			
		document.getElementById("ppTableAlloc" + i).removeAttribute("disabled");
		
		if(document.getElementById("selGlColForAllocTp"))
			document.getElementById("selGlColForAllocTp" + i).removeAttribute("disabled");
			
		if(document.getElementById("targetOrAdjusted"+i).disabled)
			document.getElementById("targetOrAdjusted"+i).removeAttribute("disabled");			

	if(document.getElementById("glAmtCol"+i)){
		if(document.getElementById("glAmtCol"+i).disabled)
			document.getElementById("glAmtCol"+i).removeAttribute("disabled");
		}
		document.getElementById("glCol"+i).value = document.getElementById("glColForAllocDiv"+i).firstChild.value; //Select Box value set to Text Field glCol
	}
	
	document.actReconEntry.submit();
	
	return false;
}

function allocReqd(){
	return true;
}
function adjAlloc(){

	var disabled = document.getElementsByClassName("disabled");
	if(document.getElementById("radAdjAlloc").checked == true) { //Automatic

		for(var i=0; i<disabled.length; i++) {
						disabled[i].disabled = true;
						disabled[i].childNodes[0].readOnly = "true";
					}
	}
	else if(document.getElementById("radAdjAlloc").checked == false){
			for(var i=0; i<disabled.length; i++) {
						disabled[i].disabled = false;
						disabled[i].childNodes[0].removeAttribute("readOnly");						
			}
		}
}

function adjPostedTo(){

	if(document.getElementById("radAdjPostTo").checked == true) { //Product Processor
	
		var tbl = document.getElementById("allocTable");
		var numOfRows = tbl.rows.length;
		
		for(var i = 2;i<numOfRows;i++){
		
			document.getElementById("targetOrAdjusted"+i).value =  document.getElementById("ppTableAlloc" + i).value;
			document.getElementById("targetOrAdjusted"+i).disabled = "true";
			document.getElementById("glColForAllocDiv"+i).style.display = 'block';
			document.getElementById("glAmtColValueDiv"+i).style.display = 'block';
						
			document.getElementById("glColForAllocDiv" + i).innerHTML =  document.getElementById("glColForTpDiv1" + i).innerHTML ;	
			document.getElementById("glColForAllocDiv" + i).childNodes[0].id="selGlColForAllocTp"+i;
			document.getElementById("glColForAllocDiv" + i).childNodes[0].name="selGlColForAllocTp";
			document.getElementById("selGlColForAllocTp" + i).disabled = "true";		
			
			document.getElementById("glAmtColValueDiv" + i).innerHTML =  document.getElementById("amtColForTpDiv1" + i).innerHTML ;	
			document.getElementById("glAmtColValueDiv" + i).childNodes[0].id="glAmtCol"+i;
			document.getElementById("glAmtColValueDiv" + i).childNodes[0].name="glAmtCol";
			document.getElementById("glAmtCol" + i).disabled = "true";		
			
			document.getElementById("glCol"+i).value = document.getElementById("glColForAllocDiv"+i).firstChild.value; //Select Box value set to Text Field glCol
			
		}
	
	}
	else if(document.getElementById("radAdjPostTo").checked == false){ // Other
	
		var tbl = document.getElementById("allocTable");
		var numOfRows = tbl.rows.length;
		
		for(var i = 2;i<numOfRows;i++){
		
			document.getElementById("targetOrAdjusted"+i).removeAttribute("disabled");
			document.getElementById("glColForAllocDiv"+i).removeAttribute("disabled");
			//document.getElementById("glColForAllocDiv"+i).style.display = "none";
			document.getElementById("glAmtColValueDiv"+i).style.display = "block";
			//document.getElementById("glColForAllocValueDiv"+i).style.display = "block";
			document.getElementById("glCol"+i).value = ""; //Reset the select Box Value
			if(!allocSel)
				{
					document.getElementById("targetOrAdjusted"+i).value = "-1"; //Reset the select Box Value					
					document.getElementById("glColForAllocDiv" + i).innerHTML = "<select><option value=\"-1\">Select</option></select>";
				}
			var elem = document.getElementById("targetOrAdjusted"+i);
			getColsForTp(elem.value,elem.id,'glTab');
			document.getElementById("glCol"+i).value = document.getElementById("glColForAllocDiv"+i).firstChild.value; //Select Box value set to Text Field glCol
			
		}
	}
	
	allocSel = false;
}
function selectGLMap(){

	if(document.getElementById("radReconDefTyp").checked == true) { //GL Level Recon
			
			var hideGL = document.getElementsByClassName("hideGL");
			
			for(var i=0; i<hideGL.length; i++) {
						hideGL[i].style.display = "none";
					}
			
			var showGL = document.getElementsByClassName("showGL");
			
			for(var i=0; i<showGL.length; i++) {
						showGL[i].style.display = "block";
					}
	document.getElementById("TargetEntityColHdr").innerHTML = "Target Entity";
	}
	else {

		var hideGL = document.getElementsByClassName("hideGL");
		for(var i=0; i<hideGL.length; i++) {
						hideGL[i].style.display = "block";
					}
			var showGL = document.getElementsByClassName("showGL");
			for(var i=0; i<showGL.length; i++) {
						showGL[i].style.display = "none";
					}
					
		document.getElementById("TargetEntityColHdr").innerHTML = "Adjusted Entity";			
	}
}


function tpTableProcess(prcs){

		if(prcs == "Add"){
					//Enable Delete
					document.getElementById("gtb5").innerHTML = "<img src='../erm/images/gridtoolbar_delete.gif' border='0' alt='Delete'>";
					
					//Set the values in Allocation Table
					
					setAllocValues(document.getElementById("tpTable"));
					
					//Clone the dummyRow in tpTable
					var tblBody = document.getElementById("tpTable");
					var newNode = document.getElementById("dummyRow").cloneNode(true);
					var rowInd = getNumOfRows("tpTable") + 1;
					tblBody.insertBefore(newNode,null);
					
					newNode.id = "";
					newNode.style.display = "block";
					
					for(var i=0; i< newNode.childNodes.length;i++){
						newNode.childNodes[i].childNodes[0].value = "";
						if(newNode.childNodes[i].childNodes[0].id) {
						
							newNode.childNodes[i].childNodes[0].id  = newNode.childNodes[i].childNodes[0].id + rowInd;
						}
						
					}
					
					document.getElementById("tpTableDiv").innerHTML = document.getElementById("tpTableDiv").innerHTML;
					//Clone the dummyRow in tpTable Ends
						
					//Clone the dummy Row in allocation Table
					
					var tblBodyAlloc = document.getElementById("allocTable");
					var newNodeAlloc = document.getElementById("dummyRowAlloc").cloneNode(true);
					var rowIndAlloc = getNumOfRows("allocTable") + 1;
					tblBodyAlloc.insertBefore(newNodeAlloc,null);
					
					newNodeAlloc.id = "rowAlloc" + rowIndAlloc;
					newNodeAlloc.style.display = "block";
					
					for(var i=0; i< newNodeAlloc.childNodes.length;i++){
					
						newNodeAlloc.childNodes[i].childNodes[0].value = "";
						if(newNodeAlloc.childNodes[i].childNodes[0].id) {

							if("defaultValueTbl" == newNodeAlloc.childNodes[i].childNodes[0].id ) {
								newNodeAlloc.childNodes[i].childNodes[0].firstChild.firstChild.firstChild.firstChild.id = newNodeAlloc.childNodes[i].childNodes[0].firstChild.firstChild.firstChild.firstChild.id + rowInd;
							}
							
							if("glAmtColValueDiv" == newNodeAlloc.childNodes[i].childNodes[0].id ){
								newNodeAlloc.childNodes[i].childNodes[0].firstChild.id = newNodeAlloc.childNodes[i].childNodes[0].firstChild.id + rowInd;
							}	

							if("glColForAllocDiv" == newNodeAlloc.childNodes[i].childNodes[0].id){
								
									newNodeAlloc.childNodes[i].childNodes[0].nextSibling.id = newNodeAlloc.childNodes[i].childNodes[0].nextSibling.id + rowInd;
									newNodeAlloc.childNodes[i].childNodes[0].nextSibling.firstChild.id = newNodeAlloc.childNodes[i].childNodes[0].nextSibling.firstChild.id + rowInd;
								}
							
							newNodeAlloc.childNodes[i].childNodes[0].id  = newNodeAlloc.childNodes[i].childNodes[0].id + rowInd;
						}
						
					}
					document.getElementById("allocTableDiv").innerHTML = document.getElementById("allocTableDiv").innerHTML;
					//Clone the dummy Row in allocation Table Ends
					
		}
		else if(prcs == "Del"){
		
			var table = document.getElementById("tpTable");
			var allocTable = document.getElementById("allocTable");
            var rowCount = table.rows.length;
 
            for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
                var chkbox = row.cells[0].childNodes[0];
                if(null != chkbox && true == chkbox.checked) {
                    table.deleteRow(i);
					allocTable.deleteRow(i); //Delete corresponding row in Allocation Tab
                    rowCount--;
                    i--;
				}
			}
		}
}

function getcolumn_defaults(getcols,valid,primarycols)
{

	
	getcols = getcols.parentNode.parentNode.parentNode.parentNode.parentNode.previousSibling.childNodes[0].value;
	valid = valid.parentNode.parentNode.childNodes[0].childNodes[0].id;
	
	var retConditionVal = '';
   if(primarycols != document.getElementById(valid).value)
        retConditionVal =  window.open("formFilterScr_defaults.jsp?destInfodom="+infoDom+"&validate=0&tab_name="+getcols+"&fieldid="+valid+"&Primarycols="+document.getElementById(valid).value,'FilterWindow','height=430,width=900,top=200,left=30,resizable=0,length=1,scrollbars=1');
   else
        retConditionVal =  window.open("formFilterScr_defaults.jsp?destInfodom="+infoDom+"&validate=0&tab_name="+getcols+"&fieldid="+valid+"&Primarycols="+primarycols,'FilterWindow','height=430,width=900,top=200,left=30,resizable=0,length=1,scrollbars=1');

}


function getColumns(fId,msel,selFld)
{
	var id = selFld.parentNode.id;
	var rowId = id.substring(id.length-1,id.length);	
	
	
	var colurl = 'attrGrid.jsp?infodom='+"<%=sInfodom%>"+"&selEntity="+document.getElementById('ppTableAlloc'+rowId).value+"&fieldId="+fId+"&multiSel="+msel;
	var retVal = window.open(colurl,'htp','height=480,width=552');
	
}

function setglAmtColVal(fId,selFld){
	var id = selFld.parentNode.id;
	var rowId = id.substring(id.length-1,id.length);
	document.getElementById(id).firstChild.value = document.getElementById(fId).value;
}

function setAllocValues(tpTable){

	/*Set Values*/
	var lastRowInd  =  (tpTable.rows.length) -1;
	
	if(lastRowInd > 1){

		document.getElementById("ppTableAlloc" + lastRowInd).value =  document.getElementById("selTpTab1" + lastRowInd).value ;
		
		document.getElementById("amtColForAllocDiv" + lastRowInd).innerHTML =  document.getElementById("amtColForTpDiv1" + lastRowInd).innerHTML ;
		document.getElementById("amtColForAllocDiv" + lastRowInd).childNodes[0].id="balAmtAlloc"+lastRowInd;
		document.getElementById("amtColForAllocDiv" + lastRowInd).childNodes[0].name="balAmtAlloc";
		document.getElementById("balAmtAlloc" + lastRowInd).disabled = "true";		
	
		document.getElementById("glColForAllocDiv" + lastRowInd).innerHTML =  document.getElementById("glColForTpDiv1" + lastRowInd).innerHTML ;	
		document.getElementById("glColForAllocDiv" + lastRowInd).childNodes[0].id="selGlColForAllocTp"+lastRowInd;
		document.getElementById("glColForAllocDiv" + lastRowInd).childNodes[0].name="selGlColForAllocTp";
		document.getElementById("selGlColForAllocTp" + lastRowInd).disabled = "true";		
	}

}

function getNumOfRows(tableName){

	if (tableName=="")  
	  {  
	  	return;  
	  }   
	
	var tableRows = document.getElementById(tableName).rows.length;
	return --tableRows;
}

function getColsForTp(tpTableName,id,tab){
	
	/*Based on ID get RowIndex and update accordingly*/	
	var rowId = id.substring(id.length-1,id.length);	 
	if (tpTableName=="")  
	  {  
	  	return;  
	  }   
	if (window.XMLHttpRequest)  
	  {// code for IE7+, Firefox, Chrome, Opera, Safari  
	  	xmlhttp=new XMLHttpRequest();  
	  }  
	else  
	  {// code for IE6, IE5  
		  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");  
	  }  
	xmlhttp.onreadystatechange=function()  
	  {  
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)  
	    {
			 setResponseValues(tab,xmlhttp.responseText,rowId)
	    }
	  }  
	  
	
	xmlhttp.open("GET","getGlCol.action?txnEntityName="+tpTableName +"&infoDom="+infoDom,true);  
	xmlhttp.send(); 
	
}

function setResponseValues(tab,response,rowId) {

			var responseText = response.split("{*}");
						
			 if(tab == "tpTab"){
			 if(rowId > 1)
					document.getElementById("glColForTpDiv1" + rowId).innerHTML=responseText[0]; 
				else
					document.getElementById("glColForTpDiv1").innerHTML=responseText[0]; 
					
			 if(rowId > 1)
					document.getElementById("amtColForTpDiv1" + rowId).innerHTML=responseText[1]; 
				else
					document.getElementById("amtColForTpDiv1").innerHTML=responseText[1]; 
					
					
			}	
			else if(tab == "glTab"){
					var tbl = document.getElementById("allocTable");
					var numOfRows = tbl.rows.length;
					
					document.getElementById("glColForAllocDiv" + rowId).innerHTML=responseText[0]; 
					document.getElementById("glAmtColValueDiv" + rowId).innerHTML=responseText[1]; 
					for(var i =2; i<numOfRows;i++){
						document.getElementById("glColForAllocDiv" + i).childNodes[0].id="selGlColForAllocTp"+i;
						document.getElementById("glColForAllocDiv" + i).childNodes[0].name="selGlColForAllocTp";					
						document.getElementById("glAmtColValueDiv" + i).childNodes[0].id="glAmtCol"+i;
						document.getElementById("glAmtColValueDiv" + i).childNodes[0].name="glAmtCol";					
					}
			}
}

function openDimensionBrowser(dimTable){

	var retVal ='';
	var loc = "1";
	var val = "";
	var dimlist = "GL_MASTER~GLH0002,GL_MAPPING_MASTER~GLH0006,GL_LEGAL_ENTTIES~GLH0007,DIM_BRANCH~GLH0012";
	
	if(loc=='1')
	{
		if(dimlist=="-")
		{
			alert('NO Dimensions');
			return;
		}

		var launchURL = "";
		launchURL = "?infodom="+infoDom;
		launchURL = launchURL + "&strLocale="+"en_US";

		launchURL = launchURL + "&divtype=1";
		launchURL = launchURL + "&user="+"gluser";
		launchURL = launchURL + "&hierMode=1";
		launchURL = launchURL + "&hierType=allHierarchy";
		launchURL = launchURL + "&selectedNode="+document.actReconEntry.selectedHierForDim.value.replace(/&/g,"%26amp;");

		launchURL = launchURL + "&hierarchy="+dimlist;
		launchURL = launchURL + "&isReturnArr=N";
		
		retVal = window.showModalDialog("hierTree.jsp"+launchURL,"","dialogWidth:45em;dialogHeight:35em");
		
	}
	else if(loc=='2')
	{ 
		retVal=val
	}
	
	if(retVal != null )
	{
		
		hdescAry = retVal.split('{*}');
		finalhierAry = new Array();
		for(t=0;t<hdescAry.length-1;t++)
		{
			len = finalhierAry.length;
			var tmpCode  = hdescAry[t].split("~");
			
			finalhierAry[parseInt(len)] =tmpCode[0];
			hiercddescMap.remove(tmpCode[0]);
			hiercddescMap.put(tmpCode[0],tmpCode[1]);
		}
		document.actReconEntry.selectedHierForDim.value  = retVal;  
		removeRowsFromTable('dimTable');
		var tpTab = "dim";
		checkForRemovedHier(retVal,tpTab);
		setHierType(retVal,tpTab);
	}

}

/*Added by Rahul Ends*/


function openHierTree(hiercode,fId,fId2)
{
  var launchURL = "?infodom="+"<%=sInfodom%>";
		         launchURL = launchURL + "&strLocale="+"<%=sLocale%>";
			 launchURL = launchURL + "&divtype=2";
                         launchURL = launchURL + "&user="+"<%=sUserid%>";
			 launchURL = launchURL + "&hierType=hierLevels";
			 launchURL = launchURL + "&hierarchy="+hiercode;      //MRH0022;
			// launchURL = launchURL + "&title=Legal Entity";
                         launchURL = launchURL + "&selectedNode=";
               retVal = window.showModalDialog("../erm/jsp/hierTree.jsp"+launchURL,"","dialogWidth:45em;dialogHeight:35em");
      // alert(retVal);

       if(retVal!=null && retVal != undefined)
        {  var tempStr=retVal.split("{*}");
		
           

	   var StrTemp=tempStr[0].split("~");
	  
               document.getElementById(fId).value = StrTemp[1];
			   if(fId == 'LegEntityDesc'){				
			    var code = StrTemp[0].split(".");
				document.getElementById(fId2).value = code[1].substr(1,code[1].length-2);				
			   }
			   
			   if(fId == 'GLCodeDesc'){
				var code = StrTemp[0].split(",");		
				/*glCode = code[0].split("#");glCode[4]*/
				document.getElementById(fId2).value = code;
			   }

 			   if(fId == 'glBookTypeDesc'){
				var code = StrTemp[0].split(",");		
				/*glCode = code[0].split("#");glCode[4]*/
				document.getElementById(fId2).value = code;
			   }

	        // if(retVal=='')	{  	    selEntity_codes = ''; }

	 // alert('sel....'+retVal);
	}
	
}
 

function showHierarchies(hierLevel,id){

/**if(hierlist=="-")
{
 popUpAlert("Warning",'<revi18n:revmessage bundleRef="runexecution" key="RUNEXECUTION.MSG_NOHIER_INSETUP"/>',"Warning");
return;
}**/
var tpTab = "false";
var addStr = "";
if("tab_FLTRContentTP" == id){
	tpTab = "true";
	addStr = "TP";
}	

		var launchURL = "";
		launchURL = "?infodom="+"GLRINF";
		launchURL = launchURL + "&strLocale=en_US";
	//	launchURL = launchURL + "&segment="+"LLFSEG";
                             
    if(hierLevel != null && hierLevel == "hierarchy")
       {
            launchURL = launchURL + "&hierMode=1";
            launchURL = launchURL + "&hierType=allHierarchy";
            
			if(tpTab == "false"){
				launchURL = launchURL + "&selectedNode="+document.actReconEntry.selectedHier.value.replace(/&/g,"%26amp;");
				launchURL = launchURL + "&dataset=DS0135";
				}
			else{	
				launchURL = launchURL + "&selectedNode="+document.actReconEntry.selectedHierForTp.value.replace(/&/g,"%26amp;");
				launchURL = launchURL + "&dataset=DS0135";
				}
			launchURL = launchURL + "&titleIs=FILTER";
			launchURL = launchURL + "&hierarchy=";
		
       }else if(hierLevel == "hierMember")
			{
				launchURL = launchURL + "&hierMode=1";
				launchURL = launchURL + "&hierType=hierLevels";
				launchURL = launchURL + "&selection=1";
				launchURL = launchURL + "&hierarchy="+hierCode;
				
				if(tpTab == "false")
					launchURL = launchURL + "&selectedNode="+hierParentNodeMap.get(globalHierStr).toString().replace(/&/g,"%26amp;");
				else	
					launchURL = launchURL + "&selectedNode="+hierParentNodeMapForTp.get(globalHierStr).toString().replace(/&/g,"%26amp;");
					
				launchURL = launchURL + "&titleIs=FILTER_MEMBERS";
			}


 if(hierLevel=="Hierarchy")
	{
	// alert("Inside Hierarchy..");
	 
			launchURL = launchURL + "&hierMode=1";
			launchURL = launchURL + "&hierType=hierLevels";
			launchURL = launchURL + "&selectedNode=";
			launchURL = launchURL + "&titleIs="+"FILTER";
			launchURL = launchURL + "&selection=1";
			//launchURL = launchURL + "&hierarchy="+"HCOM026";selection
			launchURL = launchURL + "&hierarchy="+"H0007";
		//	alert('launch...'+launchURL);

	}
	
	//alert("launchURL..."+launchURL);
     var retVal = window.showModalDialog("../erm/jsp/hierTree.jsp"+launchURL,"","dialogWidth:45em;dialogHeight:35em");
	 
	    
	 if(retVal != null && hierLevel == "hierarchy")
	        {
				if(tpTab == "false"){
					document.actReconEntry.selectedHier.value= retVal;
				}
				else{
					document.actReconEntry.selectedHierForTp.value= retVal;
				}
			    document.getElementById('tab_FLTRContent' + addStr).style.display='block';
	        	document.getElementById("Disable_HrBr" + addStr).innerHTML    = "<img src='../erm/images/gridtoolbar_new_dis.gif' border='0' width='23' height='15' alt=\"<revi18n:revmessage bundleRef='global' key='GLOBAL.LBL_ADD'/>\">";
			
			
			var hierTableid;
			if(tpTab == "false")
				 hierTableid = "hierMemberTable";
			else	 
				hierTableid = "hierMemberTableTP";
				removeRowsFromTable(hierTableid);
	        	checkForRemovedHier(retVal,tpTab);
				  setHierType(retVal,tpTab);

	        }
 else if(retVal != null && hierLevel == "hierMember")
	        {
    			var hierTableid;
			if(tpTab == "false")
				 hierTableid = "hierMemberTable";
			else	 
				hierTableid = "hierMemberTableTP";
				removeRowsFromTable(hierTableid);

	        
			if(tpTab == "false"){
					hierParentNodeMap.remove(globalHierStr);
					hierParentNodeMap.put(globalHierStr,retVal);
					setHierElement(hierParentNodeMap.get(globalHierStr),hierTableid);
				}
				else {
					hierParentNodeMapForTp.remove(globalHierStr);
					hierParentNodeMapForTp.put(globalHierStr,retVal);
					setHierElement(hierParentNodeMapForTp.get(globalHierStr),hierTableid);
			
				}				

	        	
	        }

 
}

function setHierType(retVal,tpTab){

	if(retVal != "" || retVal != null){

		var selHier   = retVal.split("{*}");
		varHierCodes  = "";
		for(var i=0;i<selHier.length-1;i++)
		{
			var opCodeName  = selHier[i].split("~");
			varHierCodes   += opCodeName[0]+"~";
		}
		var hierHttp = setConnection();
		var myurl = 'hierarchy_type_service.jsp?type=HIERARCHY&hierCode='+varHierCodes+'&destInfodom=<%=sInfodom%>&USERID=<%=sUserid%>';
	  	hierHttp.open("GET", myurl, true);
	  	hierHttp.onreadystatechange = function(){
			if (hierHttp.readyState == 4) {
			    if(hierHttp.status == 200) {
					var hierTypeArray = hierHttp.responseText;
					var hierCodeType  = hierTypeArray.split("#");
					for(var i=0;i<hierCodeType.length-1;i++)
					{
						var hierCode  = hierCodeType[i].split("~")[0];
						var hierType  = hierCodeType[i].split("~")[1];
						if(tpTab == "false")
							hierCodeTypeMap.put(hierCode,hierType);
						else	if(tpTab == "true")
							hierCodeTypeMapForTp.put(hierCode,hierType);
						else if(tpTab == "dim")	
							hierCodeTypeMapForDim.put(hierCode,hierType);
					}
					
					
        			var hierTableid;
					if(tpTab == "false")
						 hierTableid = "hierarchyTable";
					else	if(tpTab == "true")
						hierTableid = "hierarchyTableTP";
					else if(tpTab == "dim")
						hierTableid = "dimTable";
							
				
					removeRowsFromTable(hierTableid);
					
					if(tpTab == "dim")
						setHierElementForDim(retVal,hierTableid);
					else	
						setHierElement(retVal,hierTableid);
				}
			}
		}
		hierHttp.send(null);
	}
}

function setHierElementForDim(retVal, tableId)
{

	if(retVal != null)
	{
		var tblMdls   = document.getElementById(tableId);
		var selHier   = retVal.split("{*}");
		for(var i=0;i<selHier.length-1;i++)
		{
			var opCodeName  = selHier[i].split("~");

			var lastRow     = tblMdls.rows.length;
			var newRow      = tblMdls.insertRow(lastRow);

			var oCell        = newRow.insertCell();
			oCell.width      = "2%";
			oCell.align      = "center";
			oCell.innerHTML  = "&nbsp;";
			
			var oCell            = newRow.insertCell();
			oCell.width      = "58%";
			oCell.id         = opCodeName[0];
			
			if(tableId == "dimTable")
			{
				oCell.innerHTML  = opCodeName[1];
				var checkedPDState = "";
				var checkedSBState = "";
				var enableSBState  = "";
				var enablePDState  = "";

				var hierType = hierCodeTypeMapForDim.get(opCodeName[0]);
                   hierFilterStatMapForDim.put(opCodeName[0],"B");
		
			}
		
		}

		if(tableId == "dimTable")
		{ 
/*			pager1 = new Pager('dimTable',3, 2, 'NA');
			pager1.navBar('pager1','hcyNavBar');
			pager1.display();*/
		}
		
		//showMapCont4();
	}

}

function setConnection()
{

	
	 try
	 {  
	 	xmlHttp=new XMLHttpRequest();

	 }
	 catch (e)
	 { 
		try
		{
			xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); 

		}
		catch (e)
		{
			try
			{
				xmlHtp=new ActiveXObject("Microsoft.XMLHTTP"); 

			}
			catch (e)
			{
				alert('<revi18n:revmessage bundleRef="modelfe" key="MODEL.FE.NOT_SUP_AJAX"/>');
				return false;
			}
		 }
	 }
	 
	 return(xmlHttp);
}

function removeRowsFromTable(tableID)
{//alert('from removeRowsFromTable');
	var tbl = document.getElementById(tableID);
	var lastRow = tbl.rows.length;
	for (var I = lastRow-1 ; I >= 0 ; I--)	{
		if(tbl.rows[I].id.indexOf("DEVARIABLE")== -1)
			tbl.deleteRow(I);
  	}
}


function checkForRemovedHier(selHierarchies,tpTab)
{
	if(selHierarchies != null && selHierarchies != "")
	{
		var hierElement = selHierarchies.split("{*}");
		var isInKeySet  = "T";
		var keySetArray = new Array();
		if(tpTab == "false")
			keySetArray     = hierParentNodeMap.getKeySet();
		else	if(tpTab == "true")
			keySetArray     = hierParentNodeMapForTp.getKeySet();
		else if(tpTab == "dim")
			keySetArray     = hierParentNodeMapForDim.getKeySet();
		
		for(var j=0;j<keySetArray.length;j++)
		{
			for(var i=0;i<hierElement.length-1;i++)
			{
				if(hierElement[i] == keySetArray[j])
				{
					isInKeySet = "T";
					break;
				}
				else
					isInKeySet = "F";
			}

			if(isInKeySet == "F")
			{
				if(tpTab == "false")
					hierParentNodeMap.replace(keySetArray[j],"");
				else if(tpTab == "true")
					hierParentNodeMapForTp.replace(keySetArray[j],"");	
				else if(tpTab == "dim")
					hierParentNodeMapForDim.replace(keySetArray[j],"");	
			}
		}
	}
	if(selHierarchies == "")
	{  
		if(tpTab == "false")
			hierParentNodeMap = new Map();		
		else	if(tpTab == "true")
			hierParentNodeMapForTp = new Map();		
		else if(tpTab == "dim")
			hierParentNodeMapForDim = new Map();		
	}
}


function setHierElement(hierarchies,tableID)
{
		var name;
		if(tableID == "hierarchyTable"){
			addStr = "";
			name = "glFilterHierCodeValue";
			}
		else {
			addStr = "TP";
			name = "tpFilterHierCodeValue";
			}

	if(hierarchies != null)
	{
		var tblMdls   = document.getElementById(tableID);
		var selHier   = hierarchies.split("{*}");
		for(var i=0;i<selHier.length-1;i++)
		{
			var opCodeName  = selHier[i].split("~");

			var lastRow     = tblMdls.rows.length;
			var newRow      = tblMdls.insertRow(lastRow);
			if(lastRow%2==0)
				newRow.className = "row3";
			else
				newRow.className = "row2";

			var oCell        = newRow.insertCell();
			oCell.className  = "rowCellThin";
			oCell.width      = "2%";
			oCell.align      = "center";
			oCell.innerHTML  = "&nbsp;";

			oCell            = newRow.insertCell();
			oCell.className  = "rowCell";
			oCell.width      = "58%";
			oCell.id         = opCodeName[0];
			oCell.name = name;
			
			if(tableID == "hierarchyTable"  || tableID == "hierarchyTableTP")
			{
				
				if(tableID == "hierarchyTable")
					hierTableid = "hierMemberTable";
				else	 
					hierTableid = "hierMemberTableTP";
				
				
				oCell.innerHTML  = "<input type='hidden' name = '"+name+"' value="+opCodeName[0]+">" + "<a href=\"#\" class=\"line\" onClick=\"setHierarchyMember('"+opCodeName[0]+"~"+opCodeName[1]+"', '"+ hierTableid + "')\">"+opCodeName[1]+"</a>";

				var checkedPDState = "";
				var checkedSBState = "";
				var enableSBState  = "";
				var enablePDState  = "";

				if(!tableID == "hierarchyTableTP"){
					var hierType = hierCodeTypeMap.get(opCodeName[0]);
					hierFilterStatMap.put(opCodeName[0],"B");
				}
				else if(tableID == "hierarchyTableTP"){
					var hierType = hierCodeTypeMapForTp.get(opCodeName[0]);
					hierFilterStatMapForTp.put(opCodeName[0],"B");
				}	
			}
			else if(tableID == "hierMemberTable" || tableID == "hierMemberTableTP"){
				
				oCell.innerHTML  = opCodeName[1];

				oCell            = newRow.insertCell();
				oCell.className  = "rowCell";
				oCell.width     = "10%";
				oCell.innerHTML  = "&nbsp;";

				oCell            = newRow.insertCell();
				oCell.className  = "rowCell";
				oCell.width      = "10%";
				oCell.innerHTML  = "&nbsp;";
			}
		}
        
		if(tableID == "hierarchyTable" || tableID == "hierarchyTableTP")
		{ 
			pager1 = new Pager(tableID,4, 2, 'NA');
			pager1.navBar('pager1','hcyNavBar'+addStr);
			pager1.display();
			
			
		}else if (tableID == "hierMemberTable" || tableID == "hierMemberTableTP"){
		
			hierMembpager = new Pager(tableID, 4, 4, 'NA');
			hierMembpager.navBar('hierMembpager','hcyMembNavBar'+addStr);
			hierMembpager.display();
		}
	}
}


function fn_setFilterStatus(hierCode){

	hierFilterStatMap.remove(hierCode);
	hierFilterStatMap.put(hierCode,"N");
}


function setHierarchyMember(hierCodeDesc,tableID)
{

	globalHierStr = hierCodeDesc;
	
	var hierArray = hierCodeDesc.split("~");
	hierCode      = hierArray[0];

	if(tableID == "hierMemberTableTP")
		addStr = "TP";
	else
		addStr = "";
	document.getElementById("hierarchyLabel"+addStr).innerHTML  = hierArray[1];
	document.getElementById("Disable_HrBr" + addStr).innerHTML = "<a style='cursor:pointer' onClick=\" showHierarchies('hierMember','tab_FLTRContent"+addStr+"') \"><img src='../erm/images/gridtoolbar_new.gif' border='0' width='23' height='15' alt=\"Add\">";
  	
	
	removeRowsFromTable(tableID);
	 
	
	if(addStr == "TP")
		setHierMemberNodes(hierParentNodeMapForTp.get(hierCodeDesc),tableID);
	else	
		setHierMemberNodes(hierParentNodeMap.get(hierCodeDesc),tableID);
}

function setHierMemberNodes(hierNode,tableID)
{
var name;
if(tableID == "hierMemberTableTP"){
		addStr = "TP";
		name = "tpFilterHierNodeValue";
		}
	else{
		addStr = "";
		name = "glFilterHierNodeValue";
		}
		
	if(hierNode != null && hierNode != "")
	{
		removeRowsFromTable('hierMemberTable' + addStr);
		var tblMdls   = document.getElementById(tableID);
		var selHier   = hierNode.split("{*}");

		for(var i=0;i<selHier.length-1;i++)
		{
			var opCodeName  = selHier[i].split("~");

			var lastRow     = tblMdls.rows.length;
			var newRow      = tblMdls.insertRow(lastRow);
		
		if(lastRow%2==0)
				newRow.className = "row3";
			else
				newRow.className = "row2";
			
			var oCell        = newRow.insertCell();
			oCell.className  = "rowCellThin";
			oCell.width      = "1%";
			oCell.align      = "center";
			oCell.innerHTML  = "&nbsp;";
			
			oCell            = newRow.insertCell();
			oCell.className  = "rowCell";
			oCell.id         = opCodeName[0];
			oCell.innerHTML  =  opCodeName[1];

			var oCell        = newRow.insertCell();
			oCell.className  = "rowCellThin";
			oCell.width      = "1%";
			oCell.align      = "center";
			oCell.innerHTML  = "<input type='hidden' name = '"+name+"' value="+opCodeName[0]+">" ;

			oCell            = newRow.insertCell();
			oCell.className  = "rowCell";
			oCell.innerHTML  = "&nbsp;";

			oCell            = newRow.insertCell();
			oCell.className  = "rowCell";
			oCell.innerHTML  = "&nbsp;";
		}
		
	}
	
	hierMembpager = new Pager('hierMemberTable'+addStr, 4, 4, 'NA');
	hierMembpager.navBar('hierMembpager','hcyMembNavBar');
	hierMembpager.display();
}

function showMapCont(idNm){
document.getElementById('mapContentDiv'+idNm).style.display='none';
document.getElementById('mapPlusDiv'+idNm).style.display='none';
document.getElementById('mapMinusDiv'+idNm).style.display='block';
if(document.getElementById('vcr1'+idNm)!=null){
	document.getElementById('vcr1'+idNm).style.display='none';
	document.getElementById('vcr2'+idNm).style.display='block';
}
}

function hideMapCont(idNm){
document.getElementById('mapContentDiv'+idNm).style.display='block';
document.getElementById('mapPlusDiv'+idNm).style.display='block';
document.getElementById('mapMinusDiv'+idNm).style.display='none';
if(document.getElementById('vcr1'+idNm)!=null){
	document.getElementById('vcr1'+idNm).style.display='block';
	document.getElementById('vcr2'+idNm).style.display='none';
}
}

function MM_changeProp(objName,x,theProp,theValue) {
var coll = document.all.tags("span");
for (i=0; i<coll.length; i++){
coll[i].className="nonselected"
}
  var obj = MM_findObj(objName);
  if (obj && (theProp.indexOf("style.")==-1 || obj.style))   eval("obj."+theProp+"='"+theValue+"'");
}

function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function showCont(){
document.getElementById('contentDiv').style.display='none';
document.getElementById('plusDiv').style.display='none';
document.getElementById('minusDiv').style.display='block';
}

function hideCont(){
document.getElementById('contentDiv').style.display='block';
document.getElementById('plusDiv').style.display='block';
document.getElementById('minusDiv').style.display='none';
}

function showCont100a(){
document.getElementById('contentDiv100a').style.display='none';
document.getElementById('plusDiv100a').style.display='none';
document.getElementById('minusDiv100a').style.display='block';
}

function hideCont100a(){
document.getElementById('contentDiv100a').style.display='block';
document.getElementById('plusDiv100a').style.display='block';
document.getElementById('minusDiv100a').style.display='none';
}

function showCont101(){
document.getElementById('contentDiv101').style.display='none';
document.getElementById('plusDiv101').style.display='none';
document.getElementById('minusDiv101').style.display='block';
}

function hideCont101(){
document.getElementById('contentDiv101').style.display='block';
document.getElementById('plusDiv101').style.display='block';
document.getElementById('minusDiv101').style.display='none';
}


function showCont102(){
document.getElementById('contentDiv102').style.display='none';
document.getElementById('plusDiv102').style.display='none';
document.getElementById('minusDiv102').style.display='block';
}

function hideCont102(){
document.getElementById('contentDiv102').style.display='block';
document.getElementById('plusDiv102').style.display='block';
document.getElementById('minusDiv102').style.display='none';
}


function showCont103(){
document.getElementById('contentDiv103').style.display='none';
document.getElementById('plusDiv103').style.display='none';
document.getElementById('minusDiv103').style.display='block';
}

function hideCont103(){
document.getElementById('contentDiv103').style.display='block';
document.getElementById('plusDiv103').style.display='block';
document.getElementById('minusDiv103').style.display='none';
}


function showCont104(){
document.getElementById('contentDiv104').style.display='none';
document.getElementById('plusDiv104').style.display='none';
document.getElementById('minusDiv104').style.display='block';
}

function hideCont104(){
document.getElementById('contentDiv104').style.display='block';
document.getElementById('plusDiv104').style.display='block';
document.getElementById('minusDiv104').style.display='none';
}

function showContInfo(){
document.getElementById('contentDivInfo').style.display='none';
document.getElementById('plusDivInfo').style.display='none';
document.getElementById('minusDivInfo').style.display='block';
}

function hideContInfo(){
document.getElementById('contentDivInfo').style.display='block';
document.getElementById('plusDivInfo').style.display='block';
document.getElementById('minusDivInfo').style.display='none';
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}


var running = false
function startNow() {
running = true;
}

function stopNow() {
	if(running){
	running = false;
}
}

 function Rtclick() {
      if (event.button==2 && running == true){
showMenu();
}
      if (event.button==2 && running == false){
hideMenu();
}
      if (event.button==1 && running == false){
hideMenu();
}

     }

function getmenuRtclk(){
document.onmousedown=Rtclick;
}

function showMenu(){
document.getElementById('addmenu').style.display='block';
addmenu.style.left = event.clientX + document.body.scrollLeft - 10;
addmenu.style.top = event.clientY + document.body.scrollTop + 7;
}

function hideMenu(){
//document.getElementById('addmenu').style.display='none';
//document.getElementById('col21').className='rowHead';
//document.getElementById('myltMenuSel').style.display='none';
document.getElementById('pageinitSelect').style.display='none';
}

function changeHeader(){
document.getElementById('col21').className='rowHead';
}

function showMapCont4(){
document.getElementById('MapcontentDiv4').style.display='none';
document.getElementById('MapplusDiv4').style.display='none';
document.getElementById('MapminusDiv4').style.display='block';
document.getElementById('vcr41').style.display='none';
document.getElementById('vcr42').style.display='block';
}

function hideMapCont4(){
document.getElementById('MapcontentDiv4').style.display='block';
document.getElementById('MapplusDiv4').style.display='block';
document.getElementById('MapminusDiv4').style.display='none';
document.getElementById('vcr41').style.display='block';
document.getElementById('vcr42').style.display='none';
}

function showMapCont3(){
document.getElementById('MapcontentDiv3').style.display='none';
document.getElementById('MapplusDiv3').style.display='none';
document.getElementById('MapminusDiv3').style.display='block';
document.getElementById('vcr31').style.display='none';
document.getElementById('vcr32').style.display='block';
}

function hideMapCont3(){
document.getElementById('MapcontentDiv3').style.display='block';
document.getElementById('MapplusDiv3').style.display='block';
document.getElementById('MapminusDiv3').style.display='none';
document.getElementById('vcr31').style.display='block';
document.getElementById('vcr32').style.display='none';
}


function tabComSel1(){
document.getElementById('TabCom1').className='selected';
document.getElementById('TabCom2').className='nonselected';
document.getElementById('tabCom1Content').style.display='block';
document.getElementById('tabCom2Content').style.display='none';
}


function tabComSel2(){
document.getElementById('TabCom1').className='nonselected';
document.getElementById('TabCom2').className='selected';
document.getElementById('tabCom1Content').style.display='none';
document.getElementById('tabCom2Content').style.display='block';
}


function showContCmts(){
document.getElementById('contentDivCmts').style.display='none';
document.getElementById('plusDivCmts').style.display='none';
document.getElementById('minusDivCmts').style.display='block';
}

function hideContCmts(){
document.getElementById('contentDivCmts').style.display='block';
document.getElementById('plusDivCmts').style.display='block';
document.getElementById('minusDivCmts').style.display='none';
}


function checkedC2(getClass,getCheck){
var selC=getCheck
var style1= getClass
if (document.getElementById(selC).checked==true){
document.getElementById(selC).checked=false;
document.getElementById(style1).className='row2';
return;
}

if (document.getElementById(selC).checked==false){
document.getElementById(selC).checked=true;
document.getElementById(style1).className='rowChecked';
return;
}
}

function resetRows(){
document.getElementById('G1c1').className='row2';
document.getElementById('cx11').checked=false;
document.getElementById('G2c1').className='row2';
document.getElementById('cx12').checked=false;
document.getElementById('G3c1').className='row2';
document.getElementById('cx13').checked=false;
document.getElementById('G4c1').className='row2';
document.getElementById('cx14').checked=false;
document.getElementById('G5c1').className='row2';
document.getElementById('cx15').checked=false;
document.getElementById('G6c1').className='row2';
document.getElementById('cx16').checked=false;
document.getElementById('G7c1').className='row2';
document.getElementById('cx17').checked=false;
}

function getMulti(multidiv){
document.getElementById('multiAddSelect1b').style.display='block';
}




function rtoChk(){
if(document.source_sel.ruleStepB.options[document.source_sel.ruleStepB.selectedIndex].text  == "Absolute"){
document.getElementById('rto1').style.display='none';
document.getElementById('rto2').style.display='none';
document.getElementById('rto3').style.display='none';
document.getElementById('rto4').style.display='none';
document.getElementById('rto5').style.display='none';
document.getElementById('rto6').style.display='none';
}
if(document.source_sel.ruleStepB.options[document.source_sel.ruleStepB.selectedIndex].text  == "Relative"){
document.getElementById('rto1').style.display='block';
document.getElementById('rto2').style.display='block';
document.getElementById('rto3').style.display='block';
document.getElementById('rto4').style.display='block';
document.getElementById('rto5').style.display='block';
document.getElementById('rto6').style.display='block';
}
}


function inptypSel(){
if(document.getElementById('InTySl1').checked==true){
document.getElementById('sg1').style.display='block';
document.getElementById('sg2').style.display='block';
document.getElementById('sg3').style.display='block';
document.getElementById('sg4').style.display='block';
document.getElementById('rg1').style.display='none';
document.getElementById('rg2').style.display='none';
document.getElementById('rg3').style.display='none';
document.getElementById('rg4').style.display='none';
return;
}
if(document.getElementById('InTySl2').checked==true){
document.getElementById('sg1').style.display='none';
document.getElementById('sg2').style.display='none';
document.getElementById('sg3').style.display='none';
document.getElementById('sg4').style.display='none';
document.getElementById('rg1').style.display='block';
document.getElementById('rg2').style.display='block';
document.getElementById('rg3').style.display='block';
document.getElementById('rg4').style.display='block';
return;
}
}

function check_all() {

if(document.getElementById('checkAll').checked==true){
for(var i=1;i<=7;i++){
document.getElementById('cx1'+i).checked=true;}
document.getElementById('sel1a').style.display='none';
document.getElementById('sel3a').style.display='none';
document.getElementById('sel1b').style.display='block';
document.getElementById('sel3b').style.display='block';
document.getElementById('rowCntV').value=1;
}else{
for(var i=1;i<=7;i++){
document.getElementById('cx1'+i).checked=false;}
document.getElementById('sel1a').style.display='block';
document.getElementById('sel3a').style.display='block';
document.getElementById('sel1b').style.display='none';
document.getElementById('sel3b').style.display='none';
document.getElementById('rowCntV').value=1;
}
}

function checkSelB(slG){
if(document.getElementById('cx1'+slG).checked==true){
document.getElementById('rowCntV').value=parseInt(document.getElementById('rowCntV').value)-1;
}else{
document.getElementById('rowCntV').value=parseInt(document.getElementById('rowCntV').value)+1;
}
if(document.getElementById('rowCntV').value>1){
document.getElementById('sel1a').style.display='none';
document.getElementById('sel3a').style.display='none';
document.getElementById('sel1b').style.display='block';
document.getElementById('sel3b').style.display='block';
}else{
document.getElementById('sel1a').style.display='block';
document.getElementById('sel3a').style.display='block';
document.getElementById('sel1b').style.display='none';
document.getElementById('sel3b').style.display='none';
}
}

function instTrns(){
if(document.getElementById('instr1').checked==true){
	document.getElementById('extInstr').style.display='block';
	document.getElementById('tranStr').style.display='none';
}else{
	document.getElementById('extInstr').style.display='none';
	document.getElementById('tranStr').style.display='block';
}
}

function chVals(){
if(document.source_sel.fltrVl.options[document.source_sel.fltrVl.selectedIndex].text  == "Filter 1"){
	document.getElementById('vals1').innerHTML="08";
	document.getElementById('vals2').innerHTML="500,000";
	document.getElementById('vals3').innerHTML="300,000";
	document.getElementById('vals4').innerHTML="7.5";
	document.getElementById('vals5').innerHTML="5.89";
	document.getElementById('vals6').innerHTML="6.27";}
else if(document.source_sel.fltrVl.options[document.source_sel.fltrVl.selectedIndex].text  == "Filter 2"){
	document.getElementById('vals1').innerHTML="09";
	document.getElementById('vals2').innerHTML="700,000";
	document.getElementById('vals3').innerHTML="100,000";
	document.getElementById('vals4').innerHTML="8.9";
	document.getElementById('vals5').innerHTML="8.12";
	document.getElementById('vals6').innerHTML="7.47";}
else if(document.source_sel.fltrVl.options[document.source_sel.fltrVl.selectedIndex].text  == "Filter 3"){
	document.getElementById('vals1').innerHTML="10";
	document.getElementById('vals2').innerHTML="900,000";
	document.getElementById('vals3').innerHTML="600,000";
	document.getElementById('vals4').innerHTML="6.1";
	document.getElementById('vals5').innerHTML="7.39";
	document.getElementById('vals6').innerHTML="8.65";}
else if(document.source_sel.fltrVl.options[document.source_sel.fltrVl.selectedIndex].text  == "Filter 4"){
	document.getElementById('vals1').innerHTML="08";
	document.getElementById('vals2').innerHTML="300,000";
	document.getElementById('vals3').innerHTML="700,000";
	document.getElementById('vals4').innerHTML="9.5";
	document.getElementById('vals5').innerHTML="7.09";
	document.getElementById('vals6').innerHTML="5.45";}
}

function msmtMthd(){
if(document.source_sel.msMtd.options[document.source_sel.msMtd.selectedIndex].text  == "Regression"){
	document.getElementById('selIncpEnb').style.display="block";
	document.getElementById('selIncpDis').style.display="none";
	document.getElementById('mdlStsEnb').style.display="block";
	document.getElementById('mdlStsDis').style.display="none";
}else if(document.source_sel.msMtd.options[document.source_sel.msMtd.selectedIndex].text  == "Critical Terms Match"){
	document.getElementById('selIncpEnb').style.display="none";
	document.getElementById('selIncpDis').style.display="block";
	document.getElementById('mdlStsEnb').style.display="none";
	document.getElementById('mdlStsDis').style.display="block";
}
}

function selwidg(){
document.getElementById('myltMenuSel').style.display='block';
}		

function replace(str, original, replacement) {
	if(str==null || str == undefined || str=="")
				return str;
	var result;
	result = "";
	while(str.indexOf(original) != -1) {
				if (str.indexOf(original) > 0)
					result = result + str.substring(0, str.indexOf(original)) + replacement;
				else
					result = result + replacement;
				str = str.substring(str.indexOf(original) + original.length, str.length);
	}
	return result + str;
}

function valAdd(){
var s = "";
var v=document.getElementById('myltMenuSel').getElementsByTagName("input");
for(i=0;i<v.length;i++){
	if(v[i].checked==true){
		s=s+v[i].value+", ";
	}
}
	s = s.substring(0,s.length-2);
	document.getElementById('selMltvl').value=s;
}	

function tabSel1(){
document.getElementById('Tab1').className='selected';
document.getElementById('Tab2').className='nonselected';
document.getElementById('Tab3').className='nonselected';
document.getElementById('Tab4a').className='nonselected';
document.getElementById('Tab4').className='nonselected';
document.getElementById('tab1Content').style.display='block';
document.getElementById('tab2Content').style.display='none';
document.getElementById('tab3Content').style.display='none';
document.getElementById('tab4aContent').style.display='none';
document.getElementById('tab4Content').style.display='none';
}	
function tabSel2(){
document.getElementById('Tab1').className='nonselected';
document.getElementById('Tab2').className='selected';
document.getElementById('Tab3').className='nonselected';
document.getElementById('Tab4a').className='nonselected';
document.getElementById('Tab4').className='nonselected';
document.getElementById('tab1Content').style.display='none';
document.getElementById('tab2Content').style.display='block';
document.getElementById('tab3Content').style.display='none';
document.getElementById('tab4aContent').style.display='none';
document.getElementById('tab4Content').style.display='none';
}	
function tabSel3(){
document.getElementById('Tab1').className='nonselected';
document.getElementById('Tab2').className='nonselected';
document.getElementById('Tab3').className='selected';
document.getElementById('Tab4a').className='nonselected';
document.getElementById('Tab4').className='nonselected';
document.getElementById('tab1Content').style.display='none';
document.getElementById('tab2Content').style.display='none';
document.getElementById('tab3Content').style.display='block';
document.getElementById('tab4aContent').style.display='none';
document.getElementById('tab4Content').style.display='none';
}
function tabSel4a(){
	
document.getElementById('Tab1').className='nonselected';
document.getElementById('Tab3').className='nonselected';
document.getElementById('Tab4a').className='selected';
document.getElementById('Tab4').className='nonselected';
document.getElementById('tab1Content').style.display='none';
document.getElementById('tab3Content').style.display='none';
document.getElementById('tab4aContent').style.display='block';
document.getElementById('tab4Content').style.display='none';
}	
function tabSel4(){
	
document.getElementById('Tab1').className='nonselected';
document.getElementById('Tab2').className='nonselected';
document.getElementById('Tab3').className='nonselected';
document.getElementById('Tab4a').className='nonselected';
document.getElementById('Tab4').className='selected';
document.getElementById('tab1Content').style.display='none';
document.getElementById('tab2Content').style.display='none';
document.getElementById('tab3Content').style.display='none';
document.getElementById('tab4aContent').style.display='none';
document.getElementById('tab4Content').style.display='block';
allocSel = true;
}	

function resetSel(){
document.getElementById('G2c1').className="row2";
document.getElementById('cx12').checked=false;
document.getElementById('G2c2').className="row2";
document.getElementById('cx13').checked=false;
document.getElementById('t5c1').className="row2";
document.getElementById('ax15').checked=false;
//document.getElementById('t5c2').className="row2";
//document.getElementById('ax16').checked=false;
}

function checkActvSt(){
if(document.getElementById('cnTyp1').checked==true){
	document.getElementById('chDsn1').disabled=true;
	document.getElementById('chDsn2').disabled=true;
	document.getElementById('chDsn3').disabled=true;
	document.getElementById('chDes1').disabled=true;
	document.getElementById('chDes2').disabled=true;
	return;
}
if(document.getElementById('cnTyp2').checked==true){
	document.getElementById('chDsn1').disabled=false;
	document.getElementById('chDsn2').disabled=false;
	document.getElementById('chDsn3').disabled=false;
	document.getElementById('chDes1').disabled=false;
	document.getElementById('chDes2').disabled=false;
	return;
}
}

function shtlDlg(url){
showModelessDialog(url,window,'dialogWidth:687px;dialogHeight:460px;scroll:no;status:no');
}

function shwDlg(url){
showModelessDialog(url,window,'dialogHeight:400px;dialogWidth:330px;scroll:no;status:no');
}

function prdPr2(){
if(document.getElementById('adjAlc1').checked==true && document.getElementById('adjPst1').checked==true){
	document.getElementById('othPP').disabled=true;
	document.getElementById('othLnch1').style.display="none";
	document.getElementById('othLnch2').style.display="block";
	document.getElementById('allc1').style.display="block";
	document.getElementById('allc2').style.display="none";
	document.getElementById('allc3').style.display="none";
	document.getElementById('allc4').style.display="none";
	return;
}
if(document.getElementById('adjAlc1').checked==true && document.getElementById('adjPst2').checked==true){
	document.getElementById('othPP').disabled=false;
	document.getElementById('othLnch1').style.display="block";
	document.getElementById('othLnch2').style.display="none";
	document.getElementById('allc1').style.display="none";
	document.getElementById('allc2').style.display="block";
	document.getElementById('allc3').style.display="none";
	document.getElementById('allc4').style.display="none";
	return;
}
if(document.getElementById('adjAlc2').checked==true && document.getElementById('adjPst1').checked==true){
	document.getElementById('othPP').disabled=true;
	document.getElementById('othLnch1').style.display="none";
	document.getElementById('othLnch2').style.display="block";
	document.getElementById('allc1').style.display="none";
	document.getElementById('allc2').style.display="none";
	document.getElementById('allc3').style.display="block";
	document.getElementById('allc4').style.display="none";
	return;
}
if(document.getElementById('adjAlc2').checked==true && document.getElementById('adjPst2').checked==true){
	document.getElementById('othPP').disabled=false;
	document.getElementById('othLnch1').style.display="block";
	document.getElementById('othLnch2').style.display="none";
	document.getElementById('allc1').style.display="none";
	document.getElementById('allc2').style.display="none";
	document.getElementById('allc3').style.display="none";
	document.getElementById('allc4').style.display="block";
	return;
}
}

var chk=0;
function checkPg(checkImg,num){
document.getElementById('check1').src='../erm/images/header_unchecked_icon.gif';
document.getElementById('check2').src='../erm/images/header_unchecked_icon.gif';
document.getElementById('check3').src='../erm/images/header_unchecked_icon.gif';
document.getElementById('check4').src='../erm/images/header_unchecked_icon.gif';
document.getElementById(checkImg).src='../erm/images/header_checked_icon.gif';
}

function display_row(){
document.getElementById('check1').src='../erm/images/header_unchecked_icon.gif';
document.getElementById('check2').src='../erm/images/header_unchecked_icon.gif';
document.getElementById('check3').src='../erm/images/header_unchecked_icon.gif';
document.getElementById('check4').src='../erm/images/header_checked_icon.gif';
}


function validateForm(){

return true;

}