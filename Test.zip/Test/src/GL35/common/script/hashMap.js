/* This source is part of the Oracle Financial Services Software System and is copyrighted by i-flex Solutions 
Limited. All rights reserved.  No part of this work may be reproduced, stored in a retrieval 
system, adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
graphic, optic recording or otherwise, translated in any language or computer language, without 
the prior written permission of i-flex Solutions Limited.

i-flex Solutions Limited. 10-11, SDF I, SEEPZ, Andheri (East), Mumbai - 400 096. India 

Copyright � 1998 - 2007 i-flex Solutions Limited. 

----------------------------------------------------------------------------------------------------
 * @author Shirali S, Renjith R
 * @version 1.0
 * @since
 * ----------------------------------------CHANGE HISTORY-----------------------------------
 * -----------------------------------------------------------------------------------------
*/

//HashMap.js

function KeyValue( key, value )
{
    this.key = key;
    this.value = value;
}

//Constructor
function Map()
{
    this.array = new Array();
    this.keySet = new Array();
}

//Putting value into map
Map.prototype.put = function( key, value )
{
    if( ( typeof key != "undefined" ) && ( typeof value != "undefined" ) )
    {
        this.array[this.array.length] = new KeyValue( key, value );
        this.keySet[this.keySet.length] = key;
    }
}

//Getting value from map
Map.prototype.get = function( key )
{
    for( var k = 0 ; k < this.array.length ; k++ )
    {
        if( this.array[k].key == key ) {
            return this.array[k].value;
        }
    }
    return "";
}

//Finding length of map
Map.prototype.length = function()
{
    return this.array.length;
}

//Replacing values based on key
Map.prototype.replace = function(key,value)
{
    for( var k = 0 ; k < this.array.length ; k++ )
    {
        if( this.array[k].key == key ) 
        {
	    	if( ( typeof key != "undefined" ) && ( typeof value != "undefined" ) )
	    	{
				this.array[k].value = value;
	    	}
		}
    }
}

//Removing entry based on key
Map.prototype.remove = function(key)
{
	var newArray = new Array();
	var newKeySet = new Array();
	var i = -1;
	
    for( var k = 0 ; k < this.array.length ; k++ )
    {
        if( this.array[k].key != key ) 
        {
	    	i = i + 1;
	    	newArray[i] = new KeyValue( this.array[k].key, this.array[k].value );
	    	newKeySet[i] = this.array[k].key;
		}
    }
    
    this.array = newArray;
    this.keySet = newKeySet;
}

//Getting set of keys from map
Map.prototype.getKeySet = function()
{
	return this.keySet;
}

//Getting key from map based on value
Map.prototype.getKey = function( value )
{
    for( var k = 0 ; k < this.array.length ; k++ )
    {
        if( this.array[k].value == value ) {
            return this.array[k].key;
        }
    }
    return "";
}

//Getting key from map based on index
Map.prototype.getKeyByIndex = function( index )
{
	if(this.array.length < index)
		return "";
	else
		return this.array[index].key;
}
