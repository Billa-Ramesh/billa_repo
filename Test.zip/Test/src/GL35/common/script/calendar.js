/** Copied from calendar.js...*/

/**
 * This source is part of the Oracle Financial Services Software System and is copyrighted by i-flex Solutions Limited.
 * All rights reserved.  No part of this work may be reproduced, stored in a retrieval system, adopted or transmitted in any form or by any means, electronic, mechanical,
 * photographic, graphic, optic recording or otherwise, translated in any language or computer language, without the prior written permission of i-flex Solutions Limited.
 * i-flex Solutions Limited.
 * 10-11, SDF I, SEEPZ, Andheri (East),
 * Mumbai - 400 096.
 * India
 *
 * Copyright ? 1998 - 2007 i-flex Solutions Limited.
 */

//***************************************************************
//
//Title : calendar.js
//Description : This file generates the popup calendar.
//
//@  LastModified On  :  02/02/2006
// @ Change           :   Modified for the bug #8-Australia for dateformat issue

//****************************************************************

// Global variables declared here.
var calendar;
var globalYear;
var globalMonth;
var globalDay;
var textBoxMonth;
var textBoxYear;
var xAxes = 490;
var yAxes = 315;
var objName;
var dayArr = new Array();
var monthArr = new Array();
var context_path = "";
var calClose ="";
var cellWidth = "36";
var cellHeight= "16";
var funcType; // 1 or 2, 1 is for return format dd/MM/yyyy and 2 is for return format dd-MMM-yyyy.
var isPastDateAvail; // true or false, indicates whether past date is available for selection.
var min;
var max;
var exception;
var tempdate;
var startyear='1900';
var startmonth='';
var startday='';
var endyear='2100';
var endmonth='';
var endday='';
var delimiter;
/* dateFormats array contains all possible Date Formats..This is used in function parseDateFormat()  */
var dateFormats = new Array();
dateFormats = ["dd-MM-yyyy","dd/MM/yyyy","MM-dd-yyyy","MM/dd/yyyy","dd-MMM-yyyy","dd/MMM/yyyy","MMM-dd-yyyy","MMM/dd/yyyy","dd-MON-yyyy","dd/MON/yyyy","MON-dd-yyyy","MON/dd/yyyy","dd-mm-yyyy","dd/mm/yyyy","mm-dd-yyyy","mm/dd/yyyy","dd-mon-yyyy","dd/mon/yyyy","mon-dd-yyyy","mon/dd/yyyy","dd-Mon-yyyy"];



// Function to display day names.
function day_title(day_name){
     calendar = calendar + "<TD width='"+cellWidth+"' align=center bgcolor='#666666'><font class='DatTitleLabel'>"+day_name+"</font></TD>";
}


// Function to display the entire month's days.
function fill_table(month,month_length){
	day=1;
/*	if(min != '') {
  		var tempdate = parseDateFormat(dateFormats[1],min);
		startday    =  tempdate.getDate();
  		startmonth  =  tempdate.getMonth()+1;
		startyear   =  tempdate.getFullYear();
  	}
  	if(max != ''){
  		var tempdate = parseDateFormat(dateFormats[1],max);
		endday    =  tempdate.getDate();
  		endmonth  =  tempdate.getMonth()+1;
		endyear   =  tempdate.getFullYear();
  	}*/

  	// begin the new month table
  	calendar = "<script></script>";
  	calendar = calendar +"<style>.DatTitleLabel{font-family: Verdana, 'Courier New'; font-size:10; font-weight:bold; color:#FFFFFF;}</style>";
  	calendar = calendar +"<style>.PastDateLabel{font-family: Verdana, 'Courier New'; font-size:10; font-weight:bold; color:#666666;}</style>";
  	calendar = calendar +"<style>.FutureDateLabel{font-family: Verdana, 'Courier New'; font-size:10; font-weight:bold; color:#336699;}</style>";
  	calendar = calendar +"<style>.TextLink{font-family: Verdana, 'Courier New'; font-size:10; color:#336699;}</style>";
  	calendar = calendar +"<style>.clsDropDown{font-family: Verdana, 'Courier New'; font-size:11; color:#000000;}</style>";
  	calendar = calendar +"<html><head><title>Calendar</title></head><body bgcolor='#FFFFFF' text='#000000' >";
  	calendar = calendar +"<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 width='100%'><TR>";

  	// for month select
  	calendar = calendar +"<TD align=left><TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0><TR>";
  	calendar = calendar +"<TD bgcolor='#FFFFFF'><img src='"+context_path+"/images/arrow_left.gif' onclick='Javascript:window.opener.IncrementDecrement(-1)' style='cursor:hand;'></TD>";
	calendar = calendar +"<TD bgcolor='#FFFFFF'>&nbsp;<select id='monthList' class='clsDropDown' onChange='Javascript:window.opener.onChangeMonth(this)'>";

  	for (var i=0; i<monthArr.length; i++)
  	{
  		if (monthArr[i]==month)
  			calendar = calendar + "<option value='"+i+"' selected>"+monthArr[i]+"</option>";
  		else
  			calendar = calendar + "<option value='"+i+"'>"+monthArr[i]+"</option>";
  	}

  	calendar = calendar +"</select>&nbsp;</TD>";
  	calendar = calendar +"<TD bgcolor='#FFFFFF'><img src='"+context_path+"/images/arrow_right.gif' onclick='Javascript:window.opener.IncrementDecrement(1)' style='cursor:hand;'></TD>";
  	calendar = calendar +"</TR></TABLE></TD>";

  	// for year select
  	calendar = calendar +"<TD align=right><TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0><TR>";
  	calendar = calendar +"<TD bgcolor='#FFFFFF'><img src='"+context_path+"/images/arrow_left.gif' onclick='Javascript:window.opener.IncrementDecrement(-2)' style='cursor:hand;'></TD>";
  	calendar = calendar +"<TD>&nbsp;<select id='yearList' class='clsDropDown'  onChange='Javascript:window.opener.onChangeYear(this)'>";
	endyear = '2100';
  	for (var i=startyear; i<=endyear; i++){
  		if (i == globalYear){
  			calendar = calendar +"<option value='"+i+"' selected>"+i+"</option>";
  		}else{
  			calendar = calendar +"<option value='"+i+"'>"+i+"</option>";
		}
  	}

  	calendar = calendar +"</select>&nbsp;</TD>";
  	calendar = calendar +"<TD bgcolor='#FFFFFF'><img src='"+context_path+"/images/arrow_right.gif' onclick='Javascript:window.opener.IncrementDecrement(2)' style='cursor:hand;'></TD>";
  	calendar = calendar +"</TR></TABLE></TD>";

  	calendar = calendar +"</TR><TR height=5><TD></TD></TR></TABLE>";

  	calendar = calendar +"<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 bgcolor='#666666'><TR><td bgcolor='#FFFFFF'>";

  	calendar = calendar +"<td rowspan='6'>";
  	calendar = calendar +"<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=0 bgcolor='#666666'><TR>";

  	// column headings
  	day_title(dayArr[0]); //day_title("Sun")
  	day_title(dayArr[1]); //day_title("Mon")
  	day_title(dayArr[2]); //day_title("Tue")
  	day_title(dayArr[3]); //day_title("Wed")
  	day_title(dayArr[4]); //day_title("Thu")
  	day_title(dayArr[5]); //day_title("Fri")
  	day_title(dayArr[6]); //day_title("Sat")

	// pad cells before first day of month
  	calendar = calendar +"</TR><TR>";
	for (var i=1;i<start_day;i++){
  		calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' bgcolor='#CCCCCC'><font class='PastDateLabel'></font></td>";
  	}

  	var returnMeth = "";

  	if (funcType == 1)
  		returnMeth = "returnDate";
  	else if (funcType == 2)
  		returnMeth = "returnDate2";
   	else if (funcType == 3)
  		returnMeth = "returnDate3";
     else if (funcType == 4)
  		returnMeth = "returnDate4";
	 else if (funcType == 5)
  		returnMeth = "returnDate5";

  	// fill the first week of days
  	for(var i=start_day;i<8;i++){
  		var bgColor;
		if (!isPastDateAvail){
			bgColor = "#FFFFFF";
			if (textBoxMonth == globalMonth && textBoxYear== globalYear && day == globalDay)
				bgColor = "#C6E7F7";

			calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='"+bgColor+"'><a href='Javascript:window.opener."+returnMeth+"("+day+")'><font class='FutureDateLabel' style='text-decoration:none'>"+day+"</font></a></TD>";
		}else{
			bgColor = "#FFFFFF";
			if(textBoxMonth == globalMonth && textBoxYear== globalYear && day == globalDay){
				bgColor = "#C6E7F7";
				calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='"+bgColor+"'><a href='Javascript:window.opener."+returnMeth+"("+day+")'><font class='FutureDateLabel' style='text-decoration:none'>"+day+"</font></a></TD>";
			}else if (textBoxYear<globalYear || (textBoxYear==globalYear && textBoxMonth<globalMonth) || (textBoxMonth==globalMonth && textBoxYear==globalYear && day>globalDay)){
				calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='"+bgColor+"'><a href='Javascript:window.opener."+returnMeth+"("+day+")'><font class='FutureDateLabel' style='text-decoration:none'>"+day+"</font></a></TD>";
			}else{
				bgColor = "#CCCCCC";
				calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='"+bgColor+"'><font class='PastDateLabel' style='text-decoration:none'>"+day+"</font></TD>";
			}
		}
        day++;
  	}

  	// fill the remaining weeks
  	var iCount = 0
  	while (day <= month_length) {
  		calendar = calendar +"<TR>";
  		iCount++;
		for (var i=1;i<=7 && day<=month_length;i++){
  			var bgColor;

  			if(!isPastDateAvail){
				bgColor = "#FFFFFF";
				if (textBoxMonth == globalMonth && textBoxYear == globalYear && day == globalDay)
					bgColor = "#C6E7F7";

				calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='"+bgColor+"'><a href='Javascript:window.opener."+returnMeth+"("+day+")'><font class='FutureDateLabel' style='text-decoration:none'>"+day+"</font></a></TD>";
			}else{
				bgColor = "#CCCCCC";

				if(textBoxMonth == globalMonth && textBoxYear== globalYear && day == globalDay){
					bgColor = "#C6E7F7";
					calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='"+bgColor+"'><a href='Javascript:window.opener."+returnMeth+"("+day+")'><font class='FutureDateLabel' style='text-decoration:none'>"+day+"</font></a></TD>";
				}else if (textBoxYear<globalYear || (textBoxYear==globalYear && textBoxMonth<globalMonth) || (textBoxMonth==globalMonth && textBoxYear==globalYear && day>globalDay)){
					bgColor = "#FFFFFF";
					calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='"+bgColor+"'><a href='Javascript:window.opener."+returnMeth+"("+day+")'><font class='FutureDateLabel' style='text-decoration:none'>"+day+"</font></a></TD>";
				}else{
					calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='"+bgColor+"'><font class='PastDateLabel' style='text-decoration:none'>"+day+"</font></TD>";
				}
			}
        	day++;
		}

		for (; i<=7 ; i++ ){
			calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='#CCCCCC'><font class='PastDateLabel'></font></TD>";
		}

		calendar = calendar +"</TR>";

		// the first day of the next month
		 start_day=i;
	} // end of while loop

	while (iCount < 5){
		calendar = calendar +"<TR>";

		for(var i=1 ; i<= 7 ; i++){
			calendar = calendar +"<td height = '"+cellHeight+"' width='"+cellWidth+"' ALIGN=center bgcolor='#CCCCCC'><font class='PastDateLabel'></font></font></TD>";
		}

		calendar = calendar +"</TR>";
		iCount++;
	}// end of while loop

	calendar = calendar +"</TABLE>";
	calendar = calendar +"</td></TR></TABLE>";

	// for calClose link
	calendar = calendar +"<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 width='100%'>";
	calendar = calendar +"<TR><TD align=right><a href='Javascript:window.close()'><font class='TextLink'>close</font></a></TD></TR>";
	calendar = calendar +"</TABLE>";

	calendar = calendar +"</body></html>";

}
// end hiding


// Function returns the date in the desired format.
function returnDate(d){

	objName.value = get2Digit(d)+delimiter+get2Digit(globalMonth).toString()+delimiter+globalYear;
	calWin.close();
}



// Function returns the date in dd-MMM-yyyy format.
function returnDate2(d){
	objName.value = get2Digit(d)+delimiter+monthArr[get2Digit(globalMonth)-1].toString().substr(0,3)+delimiter+globalYear;
	//onDisbursmentDateChange();
	//alert('DateChanged');
	calWin.close();
}


// Function returns the date in the MM/dd/yyyy format.
function returnDate3(d){
	objName.value = get2Digit(globalMonth).toString()+delimiter+get2Digit(d)+delimiter+globalYear;
	calWin.close();
}


// Function returns the date in the dd-MM-yyyy format.
function returnDate4(d){
	objName.value = get2Digit(d)+delimiter+get2Digit(globalMonth).toString()+delimiter+globalYear;

	calWin.close();
}


// Function returns the date in MMM-dd-yyyy format.
function returnDate5(d){
	objName.value = monthArr[get2Digit(globalMonth)-1].toString().substr(0,3)+delimiter+get2Digit(d)+delimiter+globalYear;
	calWin.close();
}


 // Function to get data in two digit format.
function get2Digit(val){
	val = val.toString();

	if(val.length == 1)
		val = "0"+val;
	return val;
}


 // Function when month is changed.
function onChangeMonth(monthList){
	for (var i=0; i<monthList.options.length; i++){
		if (monthList.options[i].selected == true){
			globalMonth = i+1;
			var m = getEnglishMonth(globalMonth - 1);
			today= new Date(m+" 1, "+globalYear);
			start_day = today.getDay() + 1;   // starts with 0

			fill_table(monthArr[globalMonth-1],getMonthDays());
			calWin.document.open();
		  	calWin.document.write(calendar);
		  	calWin.document.close();
			break;
		}
	}
}


// Function when year is changed.
function onChangeYear(yearList){
	for (var i=0; i<yearList.options.length; i++){
		if (yearList.options[i].selected == true){
			globalYear = yearList.options[i].value;

			var m = getEnglishMonth(globalMonth - 1);
			today= new Date(m+" 1, "+globalYear);
			start_day = today.getDay() + 1;   // starts with 0

			fill_table(monthArr[globalMonth-1],getMonthDays());
			calWin.document.open();
		  	calWin.document.write(calendar);
		  	calWin.document.close();
			break;
		}
	}
}


 // Function when increment or decrement buttons are pressed.
function IncrementDecrement(val){

	if (val == 1){ // increment month

		globalMonth++;
		if (globalMonth == 13){
			globalMonth = 1;
			globalYear++;
		}
		if((globalYear == endyear) && (endmonth == globalMonth))
			globalMonth--;

		if(globalYear > endyear){
			globalYear--;
		}
	}

	if (val == -1){ // decrement month

		globalMonth--;
		if (globalMonth == 0) {
			globalMonth = 12;
			globalYear--;
		}

		if((globalYear == startyear) && (startmonth == globalMonth))
			globalMonth++;

		if((startyear > globalYear) && (globalMonth > startmonth))
			globalMonth = startmonth;

		if(startyear > globalYear) {
			globalYear++;
		}
	}

	// for year
	if (val == 2){ // increment year

		globalYear++;
		if(globalYear > endyear) {
			globalYear--;
		}
	}

	if (val == -2){ // decrement year

		globalYear--;
		if(startyear > globalYear) {
			globalYear++;
		}
	}

	var m = getEnglishMonth(globalMonth - 1);
	today= new Date(m+" 1, "+globalYear)
	start_day = today.getDay() + 1;   // starts with 0

	fill_table(monthArr[globalMonth-1],getMonthDays());
	calWin.document.open();
    calWin.document.write(calendar);
    calWin.document.close();
}

 // Function to get the days in the month.
function getMonthDays(){
	var leapFlag = 0;
	if ((globalYear % 400 == 0) || (globalYear % 100 != 0 && globalYear % 4 == 0))
		leapFlag = 1;
	if (globalMonth == 2)
		return (parseInt(28+leapFlag));
	else if (globalMonth == 4 || globalMonth == 6 || globalMonth == 9 || globalMonth == 11)
		return (30);
	else
		return (31);
}


// Function takes a form field name in the format of MM/dd/yyyy and returns a value in the same format
function OpenCalendar(name, path, pda, monthsString,dayString, closeText,dateFormat, minVal, maxVal, exceptionVal){
	//alert("name="+name+"; path="+path+"; pda="+pda+"; monthsString="+monthsString);
	//alert("dayString="+dayString+"; closeText="+closeText+"; dateFormat="+dateFormat+"; minVal="+minVal);
		min = minVal;
		max = maxVal;
		exception = exceptionVal;

		if(dateFormat.indexOf("-")>-1){
		delimiter = "-";
		}else if(dateFormat.indexOf("/")>-1){
			delimiter = "/";
		}
		/* getting date & month format from dateFormat irrespective of the seperator */
		var date_month = dateFormat.substring(0,dateFormat.indexOf(delimiter));
		var tempdateFormat = dateFormat.substring(dateFormat.indexOf(delimiter)+1,dateFormat.length);
		var month_date = tempdateFormat.substring(0,tempdateFormat.indexOf(delimiter));

	//var splitFormat = dateFormat.split("-");

	context_path = path;
	calClose = closeText;
	setMonthsDayArray(monthsString,dayString);
	//alert("pda="+pda);
	isPastDateAvail = (pda != null && pda == true)?true:false;
	//alert("isPastDateAvail="+isPastDateAvail);

	objName =name;
	var tempDate = objName.value;
	var dispDate;
	dispDate = 	parseDateFormat(dateFormat,tempDate);
	if(min != '') {
		var tempdate = parseDateFormat(dateFormats[1],min);
		if(dispDate > tempdate) dispDate = tempdate;
	}


	var temp= new Array();
	temp = tempDate.split(delimiter);
	if (tempDate == ""){
		dispDate = new Date();
	}else{

		if((date_month == 'dd'||date_month == 'DD') && (month_date == 'MM'||month_date == 'mm')){
			dispDate = new Date(temp[2],temp[1]-1,temp[0]);
		}
		else  if((date_month == 'MM' || date_month == 'mm') && (month_date == 'dd' || month_date == 'DD')){
			dispDate = new Date(temp[2],temp[0]-1,temp[1]);
		}
		else if((date_month == 'dd' || date_month == 'DD') && (month_date == 'mon'||month_date == 'MON'||month_date == 'Mon')){
			temp[1] = numequivalent(temp[1]);
			dispDate = new Date(temp[2],temp[1],temp[0]);
		}else  if((date_month == 'mon' || date_month == 'MON' || date_month == 'Mon') && (month_date == 'dd' || month_date == 'DD')){
			temp[1] = numequivalent(temp[1]);
			dispDate = new Date(temp[2],temp[0],temp[1]);
		}
	}
	if((date_month == 'dd'||date_month == 'DD') && (month_date == 'MM'||month_date == 'mm')){
		funcType = 4;
	}else if((date_month == 'MM' || date_month == 'mm') && (month_date == 'dd' || month_date == 'DD')){
		funcType = 3;
	}else if((date_month == 'dd' || date_month == 'DD') && (month_date == 'mon'||month_date == 'MON'||month_date == 'Mon')){
		funcType = 2;
	}else if((date_month == 'mon' || date_month == 'MON' || date_month == 'Mon') && (month_date == 'dd' || month_date == 'DD')){
		funcType = 5;
	}

	globalYear = dispDate.getFullYear();
	globalMonth = dispDate.getMonth()+1;
	globalDay = dispDate.getDate();
	textBoxMonth = globalMonth;
	textBoxYear = globalYear;
	// first day of the week of the new year
	var m = getEnglishMonth(globalMonth -1);
	today= new Date(m+" 1, "+globalYear);
	start_day = today.getDay() + 1;   // starts with 0
	/*
	if(date_month == 'dd' && month_date == 'MM')
		  funcType = 4;
	else  if(date_month == 'MM' && month_date == 'dd')
		funcType = 3;
	*/
	fill_table(monthArr[globalMonth-1],getMonthDays());
	calWin = PopDis("","width=274 height=190 left="+xAxes+" top="+yAxes);
	//calWin = window.open("","win", "width=274 height=190 left="+xAxes+" top="+yAxes);
	calWin.document.open();
  	calWin.document.write(calendar);
	calWin.document.close();
}

function numequivalent(month){
	month=month.toUpperCase();
	if(month=='jan'||month=='JAN'||month=='Jan')
	return 0;
	else if(month=='feb'||month=='FEB'||month=='Feb')
	return 1;
	else if(month=='mar'||month=='MAR'||month=='Mar')
	return 2;
	else if(month=='apr'||month=='APR'||month=='Apr')
	return 3;
	else if(month=='may'||month=='MAY'||month=='May')
	return 4;
	else if(month=='jun'||month=='JUN'||month=='Jun')
	return 5;
	else if(month=='jul'||month=='JUL'||month=='Jul')
	return 6;
	else if(month=='aug'||month=='AUG'||month=='Aug')
	return 7;
	else if(month=='sep'||month=='SEP'||month=='Sep')
	return 8;
	else if(month=='oct'||month=='OCT'||month=='Oct')
	return 9;
	else if(month=='nov'||month=='NOV'||month=='Nov')
	return 10;
	else
	return 11;

}


// Function to parse dateFormat & return new date object on basis of the format
function parseDateFormat(dateFormat,tempDate){

	//dateFormats Array is defined at the top

	for(var i=0;i<dateFormats.length;i++){

		if(dateFormats[i] == dateFormat){
			switch(i){
				case 14://mm-dd-yyyy
				case 15:// mm/dd/yyyy
				case 3:	// MM/dd/yyyy
				case 2 ://MM-dd-yyyy
									funcType=3;
									if(tempDate == "")
									{
										return new Date();
									}else{
										/*
										var temp= new Array();
										temp = tempDate.split("-");
										return new Date(temp[2],temp[0]-1,temp[1]);
										*/
										var month = tempDate.substring(0,2);
										var day = tempDate.substring(3,5);
										var year = tempDate.substring(6,10);
										return new Date(year,month-1,day);
									}
									break;
				 case 12://dd-mm-yyyy
				 case 13://dd/mm/yyyy
				 case 1: //dd/MM/yyyy
                 case 0: //dd-MM-yyyy
									funcType=4;
									if(tempDate == "" || tempDate == null || tempDate =="undefined")
									{
										return new Date();
									}else{
										var month = tempDate.substring(3,5);
										var day = tempDate.substring(0,2);
										var year = tempDate.substring(6,10);
										return new Date(year,month-1,day);

									}
									break;
					case 5:   //dd/MMM/yyyy
					case 4:	//dd-MMM-yyyy
									funcType=2;
									if(tempDate == "")
									{
										return new Date();
									}else{
										/*
										var temp= new Array();
										temp = tempDate.split("-");
										*/
										var month = tempDate.substring(3,6);
										var day = tempDate.substring(0,2);
										var year = tempDate.substring(7,11);
										var monthIndex;
										for(var i=0;i<monthArr.length;i++){
											if(	monthArr[i].indexOf(month) != -1){
												monthIndex = i;
												break;
											}
										}
										return new Date(year,monthIndex,day);
									}
									break;
					case 7:   //MMM/dd/yyyy
					case 6:	//MMM-dd-yyyy
									funcType=5;
									if(tempDate == ""){
										return new Date();
									}else{
										/*
										var temp= new Array();
										temp = tempDate.split("-");
										*/
										var month = tempDate.substring(0,3);
										var day = tempDate.substring(4,6);
										var year = tempDate.substring(7,11);
										var monthIndex;
										for(var i=0;i<monthArr.length;i++)
										{
											if(	monthArr[i].indexOf(month) != -1)
											{
												monthIndex = i;
												break;
											}
										}
										return new Date(year,monthIndex,day);
									}
									break;
					case 16://dd/mon/yyyy
					case 17://dd-mon-yyyy
					case 9:   //dd/MON/yyyy
					case 8:	//dd-MON-yyyy
					case 20://dd-Mon-yyyy
									funcType=2;
									if(tempDate == ""){
										return new Date();
									}else{
										/*
										var temp= new Array();
										temp = tempDate.split("-");
										*/
										var month = tempDate.substring(3,6);
										var day = tempDate.substring(0,2);
										var year = tempDate.substring(7,11);
										var monthIndex;
										for(var i=0;i<monthArr.length;i++){
											if(	monthArr[i].indexOf(month) != -1){
												monthIndex = i;
												break;
											}
										}
										return new Date(year,monthIndex,day);
									}
									break;
					case 18://mon/dd/yyyy
					case 19://mon-dd-yyyy
					case 11:   //MON/dd/yyyy
					case 10:	//MON-dd-yyyy
									funcType=5;
									if(tempDate == ""){
										return new Date();
									}else{
										/*
										var temp= new Array();
										temp = tempDate.split("-");
										*/
										var month = tempDate.substring(0,3);
										var day = tempDate.substring(4,6);
										var year = tempDate.substring(7,11);
										var monthIndex;
										for(var i=0;i<monthArr.length;i++){
											if(	monthArr[i].indexOf(month) != -1){
												monthIndex = i;
												break;
											}
										}
										return new Date(year,monthIndex,day);
									}
									break;

			}
			break;
		}

	}
}
 // Function to populate the months and days array based on the argument passed.
function setMonthsDayArray(inputMonths,inputDays){
	monthArr = inputMonths.split(",");
	dayArr = inputDays.split(",");
}


 // Function takes a form field name in the format of dd-mon-yyyy and returns a value in the same format
function OpenCalendar2(name, path, pda, monthsString,dayString, closeText){
	context_path = path;
	calClose = closeText;
	setMonthsDayArray(monthsString,dayString);
    isPastDateAvail = (pda != null && pda == true)?true:false;
    objName =name;

    var tempDate = objName.value;
	var dispDate;
	var temp= new Array();
	if(tempDate.indexOf("-")>-1){
		delimiter = "-";
	}else if(tempDate.indexOf("/")>-1){
		delimiter = "/";
	}
	temp = tempDate.split(delimiter);
	if (tempDate == ""){
		dispDate = new Date();
	}else{
        var mon = temp[1];
        for(i = 0; i < monthArr.length; i++){
            if(mon.toUpperCase() == monthArr[i].substr(0,3).toUpperCase()){
                mon = i;
                break;
            }
        }

		dispDate = new Date(temp[2],mon, temp[0]);
    }

	globalYear = dispDate.getFullYear();
	globalMonth = dispDate.getMonth()+1;
	globalDay = dispDate.getDate();
	textBoxMonth = globalMonth;
	textBoxYear = globalYear;
	var m = getEnglishMonth(globalMonth -1);
	today= new Date(m+" 1, "+globalYear);
	start_day = today.getDay() + 1;
	funcType = 2;
	fill_table(monthArr[globalMonth-1],getMonthDays());
	calWin = PopDis("","width=284 height=175 left="+xAxes+" top="+yAxes);
	//calWin = window.open("","win", "width=284 height=175 left="+xAxes+" top="+yAxes);
	calWin.document.open();
  	calWin.document.write(calendar);
  	calWin.document.close();
}
var englishMonthsArray = new Array();
var englishMonths = "January,February,March,April,May,June,July,August,September,October,November,December";
englishMonthsArray = englishMonths.split(",");

 // Function to return english month names.
function getEnglishMonth(index){
	return englishMonthsArray[index];
}

//start for modal window
var popWindow;
function PopDis(loc,features) {
  popWindow = window.open(loc,'win' ,features);
  popWindow.opener = self;
  return popWindow;
}

function checkPop () {
  if ((popWindow) && (!popWindow.closed)) {
    popWindow.focus();
  }
}
//end for modal window


