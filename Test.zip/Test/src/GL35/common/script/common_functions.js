/********************************************************************************************************************
*   This source is part of the Liqidity Risk Management Software System and is copyrighted by Oracle Financial 		*
*	Services Software Limited.All rights reserved. No part of this work may be reproduced, stored in a retrieval 	*
*	system, adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic,		*
*	optic recording or otherwise, translated in any language or computer language, without the prior written 		*
*	permission of Oracle Financial Services Software Limited.														*
*																													*
*	Oracle Financial Services Software Limited.																		*
*	10-11, SDF I, SEEPZ, Andheri (East),																			*
*	Mumbai - 400 096. 																								*
*	India																											*
*																													*
*	Copyright � 2011 Oracle Financial Services Software Limited. All rights reserved. 								*
*	--------------------------------------------------------------------------------------------------------		*
*	Module Name           :   common_functions.js																	*
*	Created By            :   																						*
*	Created On            :   																						*
*	Description           :   									 													*
*																													*
*	Modification History																							*
*	---------------------------------------------------------------------------------------------------------		*
*	Modification On:          Modified By:                Modifcation Details										*
*	---------------------------------------------------------------------------------------------------------		*
*																													*
********************************************************************************************************************/


/* Function to disable the page */
function disablePage(){
	var blurDiv = document.createElement("div");
	blurDiv.id = "blurDiv";
	blurDiv.style.cssText = "position:absolute; top:0; right:0; width:" + screen.width + "px; height:" + screen.height + "px; background-color: #000000; opacity:0.5; filter:alpha(opacity=50)";
	document.getElementsByTagName("body")[0].appendChild(blurDiv);
	document.getElementById("blurDiv").style.cursor="wait";
	//setTimeout('enablePage()',10000);
}

/*Method to change state-tracker flag*/
function changeIsChangedFlag(){
   document.getElementById("isglChangedFlag").value=true;   
}

/*On Click of Cancel or Closing of window without Save*/
function fn_cancel(infoDom)
{
                if(document.getElementById("isglChangedFlag").value == "true"){
						var conf = MM_openBrWindowForAlert(infoDom,'', '{26108} ','Confirm');
                        if(conf){
                               window.close();
                        }
                }
				else{
					window.close();
                }
}

/* Function to enable the disabled page */
function enablePage(){
	var blurDiv = document.getElementById("blurDiv");
	blurDiv.style.cursor='default';
	blurDiv.parentNode.removeChild(blurDiv);
}

/*function to refresh the view mode*/
function refreshParent(){
	window.opener.location.reload();
}

String.prototype.startsWith = function(str){
    return (this.indexOf(str) === 0);
}

function getXmlHttpRequest(){
	var xmlHttpReq;
  	try{
    	// Firefox, Opera 8.0+, Safari
     	xmlHttpReq=new XMLHttpRequest();
  	}catch (e){
    	// Internet Explorer
     	try{
       		xmlHttpReq=new ActiveXObject("Msxml2.XMLHTTP");
     	}catch (e){
	       	try{
	        	xmlHttpReq=new ActiveXObject("Microsoft.XMLHTTP");
	        }catch (e){
	        	alert(noAjax);
	            return false;
	        }
    	}
 	}
 	return xmlHttpReq;
}

function expandCollapse(divID){	
	var detailsDiv=document.getElementById(divID);
	var imgCnt=document.getElementById('img'+divID);
	
	if (detailsDiv.style.display=='none'){
		imgCnt.src="../images/minus.gif";
		detailsDiv.style.display='block';
	}else{
		imgCnt.src="../images/plus.gif";
		detailsDiv.style.display='none';
	}	
}

function showDiv(divName){
	divToShow = divName + '_show';
	divToHide = divName + '_hide'; 
	
	document.getElementById(divToHide).style.display='none';  
	document.getElementById(divToShow).style.display='block';
}

function hideDiv(divName){
	divToShow = divName + '_hide';
	divToHide = divName + '_show';
	
	document.getElementById(divToHide).style.display='none';
	document.getElementById(divToShow).style.display='block';
}

function removeRowsFromTable(tableName) { 
	var tbl = document.getElementById(tableName);
	var lastRow = tbl.rows.length; 
	for (var I = lastRow-1 ; I > 0 ; I--)	{
  		tbl.deleteRow(I); 
  	}
}

function showHideDiv(divID){
	var divTag = document.getElementById(divID);
	var imgID  = document.getElementById('img'+divID);
	if(divTag.style.display == "block"){
		imgID.src="../images/menu_corner_plus.gif";
		divTag.style.display = "none";
	}else{
		imgID.src="../images/menu_corner_minus.gif";
		divTag.style.display = "block";
	}
}

function trimAll(sString) 
{
	if(sString != null && sString != ''){
		while (sString.substring(0,1) == ' '){
			sString = sString.substring(1, sString.length);
		}
		while (sString.substring(sString.length-1, sString.length) == ' '){
			sString = sString.substring(0,sString.length-1);
		}
	}
	return sString;
}

/* trim function added */
function trim(str){
    var regExp = /\s+/g;
    return str.replace(regExp,'');
}

/* function to restrict max length for textarea */
function countMaxlength(id){
	var lengthVal=document.getElementById(id).value;
	if(lengthVal.length>80){
		var tmp = document.getElementById(id).value;
		document.getElementById(id).value=tmp.substr(0,80);
	}
}

function limitText(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    } 
}


function fn_changeCheckBoxStatus(chkBox)
{
	var rID = rowIDMap.get('R' + chkBox.id.substring(3));
	var row = document.getElementById(rID);
	
	if(chkBox.checked == true){
		row.className = "rowChecked";
		rowFormulaID = rID;
	}
	else{	
		rowFormulaID = "";			
		if( (parseInt(chkBox.id.substring(3)) % 2) == 0)
			row.className = "row2";
		else
			row.className = "row3";
		
		if (document.getElementById('checkAll').checked == true){
			document.getElementById('checkAll').checked = false;
		}
		
	}
}


function fn_close(){
	//window.returnValue = "";
	window.close();
}

function checkForSpecialCharacters(paramString){
	paramString = paramString.replace(/\:/g,"{COLN}");
	paramString = paramString.replace(/\$/g,"{DOLR}");
	paramString = paramString.replace(/\%/g,"{PERC}");
	paramString = paramString.replace(/\&/g,"{AMBD}");
	paramString = paramString.replace(/\@/g,"{ARTE}");
	paramString = paramString.replace(/\#/g,"{HASH}");
	paramString = paramString.replace(/\!/g,"{EXCN}");	
	paramString = paramString.replace(/\(/g,"{ANBTO}");
	paramString = paramString.replace(/\)/g,"{ANBTC}");
	paramString = paramString.replace(/\*/g,"{STAR}");
	paramString = paramString.replace(/\+/g,"{PLUS}");
	paramString = paramString.replace(/\,/g,"{COMA}");
	paramString = paramString.replace(/\;/g,"{SMCLN}");
	paramString = paramString.replace(/\=/g,"{EQTO}");
	paramString = paramString.replace(/\?/g,"{QTMK}");
	paramString = paramString.replace(/\[/g,"{SQBTO}");
	paramString = paramString.replace(/\]/g,"{SQBTC}");
	paramString = paramString.replace(/\^/g,"{CAROT}");
	paramString = paramString.replace(/\|/g,"{PIPE}");
	return paramString;
}

function replaceSpecialCharacters(paramString){
	paramString = paramString.replace(/\{COLN\}/g,":");
	paramString = paramString.replace(/\{DOLR\}/g,"$");
	paramString = paramString.replace(/\{PERC\}/g,"%");
	paramString = paramString.replace(/\{AMBD\}/g,"&");
	paramString = paramString.replace(/\{ARTE\}/g,"@");
	paramString = paramString.replace(/\{HASH\}/g,"#");
	paramString = paramString.replace(/\{EXCN\}/g,"!");	
	paramString = paramString.replace(/\{ANBTO\}/g,"(");
	paramString = paramString.replace(/\{ANBTC\}/g,")");
	paramString = paramString.replace(/\{STAR\}/g,"*");
	paramString = paramString.replace(/\{PLUS\}/g,"+");
	paramString = paramString.replace(/\{COMA\}/g,",");
	paramString = paramString.replace(/\{SMCLN\}/g,";");
	paramString = paramString.replace(/\{EQTO\}/g,"=");
	paramString = paramString.replace(/\{QTMK\}/g,"?");
	paramString = paramString.replace(/\{SQBTO\}/g,"[");
	paramString = paramString.replace(/\{SQBTC\}/g,"]");
	paramString = paramString.replace(/\{CAROT\}/g,"^");
	paramString = paramString.replace(/\{PIPE\}/g,"|");
	return paramString;
}