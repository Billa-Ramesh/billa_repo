package com.app.trans.table;

public class test {
	 private LoginConnection loginCon = LoginConnection.getInstance();
	 
	 public void con(){
		System.out.println(loginCon.getConnection());
	 }
public static void main(String args[]){
	test t=new test();
	t.con();
	//System.out.println();
}
}
