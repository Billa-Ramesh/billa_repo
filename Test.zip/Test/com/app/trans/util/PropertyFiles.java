package com.app.trans.util;
//-----------------------------------------------------------------------------
//PropertyFiles.java
//-----------------------------------------------------------------------------

import java.util.Properties;
import java.util.Enumeration;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.net.URI;
import java.net.URL;

/**
* -----------------------------------------------------------------------------
* Used to provide an example of how to get/modify/save Properties files
* while preserving comments in the file.
* -----------------------------------------------------------------------------
*/

public class PropertyFiles {


	private static URL url;
	private static InputStream url2;


	private static void printProperties(Properties p, String s) {

		System.out.println();
		System.out.println();

		System.out.println(s);

		System.out.println();

		p.list(System.out);
		System.out.println();
	}


	private static void saveProperties(Properties p, InputStream url22) {

		OutputStream outPropFile;

		try {
		System.out.println(url22);
		//BufferedInputStream in = new BufferedInputStream(url22);
		//url22.toString();
		//URL U= PropertyFiles.class.GET(ConstantsAll.PROPERTY_FILENAME);
	//	System.out.println(U.getPath());
		File propertyFile = new File(url.getPath());
			outPropFile = new FileOutputStream(propertyFile);
			p.store(outPropFile, "Properties File to the Test Application");
			outPropFile.close();
		} catch (IOException ioe) {
			System.out.println("I/O Exception.");
			ioe.printStackTrace();
			System.exit(0);
		}

	}


	private static Properties loadProperties(InputStream url22) {

		InputStream inPropFile;
		Properties tempProp = new Properties();

		try {
		//	inPropFile = new FileInputStream(url22);
			tempProp.load(url22);
			url22.close();
		} catch (IOException ioe) {
			System.out.println("I/O Exception.");
			ioe.printStackTrace();
			System.exit(0);
		}

		return tempProp;

	}


	private static Properties alterProperties(Properties p) {

		Properties newProps = new Properties();
		Enumeration enumProps = p.propertyNames();
		String key = "";

		while ( enumProps.hasMoreElements() ) {

			key = (String) enumProps.nextElement();

			if (!key.equals("tool.versions")) {
				if (key.equals("tool.version")) {
					newProps.setProperty(key, "1.6");
				} else {
					newProps.setProperty(key, p.getProperty(key));
				}
			}

		}

		return newProps;

	}


	/**
	 * Sole entry point to the class and application.
	 * @param args Array of String arguments.
	 */
	public static void main(String[] args) {
		url= PropertyFiles.class.getResource(ConstantsAll.PROPERTY_FILENAME);
		url2= PropertyFiles.class.getResourceAsStream("/com/app/trans/util/Bootstarp.properties");
		
		//System.out.println(url2.toString());
		final String PROPFILE= "Application.properties";
		Properties myProp;
		Properties myNewProp;

		// Input Properties File
		myProp = loadProperties(url2);
		printProperties(myProp, "Loaded Properties");

		// Modified Properties File
		myNewProp = alterProperties(myProp);
		printProperties(myNewProp, "After Modifying Properties");
		saveProperties(myNewProp, url2);

	}

}


