package com.app.trans.util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * @author rameshbi
 * 
 */
public class DBConnection {
	private static Connection con = null;

	public static Connection getConnection() {

		try {

			String url, driver, username, password;

			url = TransloadPropertyFile.getLoadFile().getProperty(
					ConstantsAll.DATABASE_UTL);
			driver = TransloadPropertyFile.getLoadFile().getProperty(
					ConstantsAll.DATABASE_DRIVER);
			username = TransloadPropertyFile.getLoadFile().getProperty(
					ConstantsAll.DATABASE_USER_NAME);
			password = TransloadPropertyFile.getLoadFile().getProperty(
					ConstantsAll.DATABASE_PASSWORD);

			Class.forName(driver);

			con = DriverManager.getConnection(url, username, password);
			//System.out.println(con.toString());
		
		} catch (Exception ex) {
			System.out.println("Error getting  data base connection .please check the data base configaration " +ex.getMessage());
			
			
		}

		return con;

	}

}
