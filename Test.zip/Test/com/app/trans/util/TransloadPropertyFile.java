package com.app.trans.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;
import com.app.trans.util.ConstantsAll;
/**
 * @author rameshbi
 *
 */
public class TransloadPropertyFile {
	
	static URL url ;
	private static FileWriter writer;
public	static Properties getLoadFile(){
		Properties properties=null;
	
	//	url= TransloadPropertyFile.class.getResource(ConstantsAll.PROPERTY_FILENAME);

	//File propertyFile = new File(url.getPath());
	File propertyFile = new File(ConstantsAll.PROPERTY_FILENAME);
	  if(propertyFile.exists()){
		   properties = new Properties();
		  FileInputStream inStream = null;
		  try {
			  inStream = new FileInputStream(propertyFile);
			  properties.load(inStream);
				
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	   catch (IOException e1) {
			
			e1.printStackTrace();
		}
	  }
	return properties;
	
}
public static void main(String args[]){
	
	TransloadPropertyFile s=new TransloadPropertyFile();
	System.out.println(TransloadPropertyFile.getLoadFile());
	Properties prop = TransloadPropertyFile.getLoadFile();
	   //  prop.getProperty("url");
	  prop.setProperty("tool.version", "ramesh");
	  try {
		    writer = new FileWriter(url.getPath());
		    System.out.println(writer.toString());
		    
		    
		    prop.store(writer, null);
		    writer.flush();
			writer.close();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		

	 
	
}

}
