package com.app.trans.util;


public final class ConstantsAll {
	  public static final String TOOL_VERSION=TransloadPropertyFile.getLoadFile().getProperty("tool.version");
	  public static final String PROPERTY_FILENAME="Bootstarp.properties";
	  public static final String DROP_VERSION=TransloadPropertyFile.getLoadFile().getProperty("version");
	  
	  public static final String DATABASE_UTL ="url";
	  public static final String DATABASE_DRIVER="driver";
	  public static final String DATABASE_USER_NAME="username";
	  public static final String DATABASE_PASSWORD="password";
	  public static final boolean TOOLBAR_VISBLE=true;
	  public static final String TOOLBAR_VISBLE_PROPERTY=TransloadPropertyFile.getLoadFile().getProperty("visble_tool_bar");;
	  public static final String APP_NAME=TransloadPropertyFile.getLoadFile().getProperty("app_name");
	  public static final String MASTER_TABLE =APP_NAME+"_master";
	  public static final String META_DATA_TABLE=APP_NAME+"_info";
	  public static final String DUPLICATE_TABLE=APP_NAME+"_dupe";
	  public static final String FINAL_TABLE=APP_NAME+"_final";
	  
	  
	  public static final String UNIQ_TABLE_L=TransloadPropertyFile.getLoadFile().getProperty("uniq_lang");
	  public static final String MASTER_TABLE_L=TransloadPropertyFile.getLoadFile().getProperty("master_lang");;
	  public static String MLS_CODE="mls_cd";
	  private static String mlsCode;
	
	  public static final String LANG_UNIQ="uniq";
	  public static final String SHARED_CAPTION_TABLE="shared_table";
	 
	  public static final String XML_UPDATE_DESC="Select description from "+SHARED_CAPTION_TABLE+" where mls_cd='"+MLS_CODE+"'  AND path like ?";
	  public static final String XML_UPDATE_TEXT="Select text from "+SHARED_CAPTION_TABLE+" where mls_cd='"+MLS_CODE+"'  AND name like ?";
	  
	  //Data base Procedure ,it will insert all the tables data to update the source to target text
	 
	 
	  public static final String INSERT_MASTER="Insert into "+MASTER_TABLE+" values (?,?,?,?,?)";
	  public static final String SELECT_INFO="Select * from "+META_DATA_TABLE;
	  
	  public static final String INSERT_DUPLICATES=
		  	 "INSERT INTO "+DUPLICATE_TABLE+" SELECT MESSAGE_KEY, message_text, table_name,comments,flag FROM "+MASTER_TABLE
			+ " WHERE TRIM(LOWER(message_text)) IN ("
			+ "select TRIM(LOWER(message_text)) FROM "+MASTER_TABLE
			+ " GROUP BY TRIM(LOWER(message_text))" + "HAVING COUNT(*) >1)";
	      
		  
	  public static final String DELETE_DUPLICATES=
		     "delete  from "+DUPLICATE_TABLE+" A "
			+ "where rowid > (select min(rowid) "
			+ "from "+DUPLICATE_TABLE+" B "
			+ "where trim(lower(A.MESSAGE_TEXT))=trim(lower(B.MESSAGE_TEXT)))";
	  
		
	  public static final String INSERT_FINAL=
	  "insert into "+FINAL_TABLE
		+ " select MESSAGE_key,MESSAGE_TEXT,table_name,comments,flag from "+MASTER_TABLE
		+ " where TRIM(LOWER(MESSAGE_TEXT)) in ("
		+ "select TRIM(LOWER(MESSAGE_TEXT)) FROM "+MASTER_TABLE
		+ " GROUP BY TRIM(LOWER(MESSAGE_TEXT)) "
		+ "HAVING COUNT(*) = 1) "
		+ "UNION select MESSAGE_key,MESSAGE_TEXT,table_name,comments,flag FROM "+MASTER_TABLE
		+ " WHERE  MESSAGE_TEXT IS NULL "
		+ "UNION select  MESSAGE_key,MESSAGE_TEXT,table_name,comments,flag from "+DUPLICATE_TABLE;
      
	 
	 
	  public static final String UPDATE_MESSAGES=
			"Update "+MASTER_TABLE+" set Message_text = ? where Message_Key = ? and Table_Name = ?";
	 
	  
	  public static final String DB2_ALL_UPDATE_SELECT="select * from "+MLS_CODE+"MASTER_TABLE";
	  
	  public static final String XLIIF_EXPORT_QUEARY_INFO="Select table_name,TRANSLATABLE_FIELD1,TRANSLATABLE_FIELD2 from "+META_DATA_TABLE;
	  public static final String XLIIF_EXPORT_QUEARY_FINAL="select table_name from "+FINAL_TABLE+" where table_name=?";
	  public static final String XLIIF_EXPORT_QUEARY_METHOD2="select message_key,message_text,comments from "+FINAL_TABLE+" where table_name=";
	  
	  public static final String XLIIF_IMPORT_QUEARY_INFO="insert into "+mlsCode+"_"+MLS_CODE+"_"+LANG_UNIQ+" ( MESSAGE_KEY,SOURCE_TEXT,TARGET_TEXT,DROPNUM)"+"values(?,?,?,?)";
	  
	  public static final String INSERT_ALL_PROCEDURE="{call INSERT_ALL_OR_PRO_text(?,?)}";
	 // public static final String DB2_ALL_UPDATE_SELECT="select * from "+MLS_CODE+"MASTER_TABLE";
	  
	  
	}
