package com.app.trans.update;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import com.app.trans.util.ConstantsAll;

public class WptgDao {
	 static ResultSet rs;
	public static ResultSet searchData(Connection connection, String id, String txt, String catgory, String newstr) {
		
		try {
              
             
              connection = DriverManager.getConnection("jdbc:oracle:thin:@10.184.203.0:1521:REVEXAII","oreclang","oreclang");
              Statement stmt=connection.createStatement();
              String query="SELECT * FROM ANALYSIS_REPORT "  +
              		"WHERE STRING_ID like '%" + id + "%' and STRING LIKE '%"+txt+"%' and CATEGORY LIKE '%"+catgory+"%'"; 
              System.out.println(query);
            rs=stmt.executeQuery(query);
            
		} catch(SQLException sqlx) {
			JOptionPane.showMessageDialog(null, " \n *** SQLException ***  \n " +sqlx.getMessage() + "\n");
		}
	
		return rs;
		
		
	}

}
