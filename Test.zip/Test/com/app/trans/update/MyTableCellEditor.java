package com.app.trans.update;

import java.awt.Component;
import java.util.EventObject;

import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;

public class MyTableCellEditor implements TableCellEditor {
	 JComponent component = new JTextField();
	@Override
	public Component getTableCellEditorComponent(JTable arg0, Object value,
			boolean isSelected, int rowIndex, int vColIndex) {
		 if (isSelected) {
	            // cell (and perhaps other cells) are selected
	        }
             System.out.println(value+"--"+isSelected+"--"+rowIndex+"--"+vColIndex);
	        // Configure the component with the specified value
	        ((JTextField)component).setText((String)value);

	        // Return the configured component
	        return component;
		
	}

	@Override
	public void addCellEditorListener(CellEditorListener arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void cancelCellEditing() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object getCellEditorValue() {
		 return ((JTextField)component).getText();
	}

	@Override
	public boolean isCellEditable(EventObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void removeCellEditorListener(CellEditorListener arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean shouldSelectCell(EventObject arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean stopCellEditing() {
		// TODO Auto-generated method stub
		return false;
	}

}
