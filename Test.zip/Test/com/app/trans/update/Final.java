package com.app.trans.update;

import java.io.Serializable;

public class Final implements Serializable {
/**
	 * 
	 */
	

	private static final long serialVersionUID = 1L;

private String massagekey;
	
	/**
	 * 
	 */
	private String messageText;
	
	private String tablename;
private String comments;
	
	private String flag;
	public String getUpdateComment() {
		return updateComment;
	}

	public void setUpdateComment(String updateComment) {
		this.updateComment = updateComment;
	}

	private String updateText;
	private String updateComment;
	public String getUpdateText() {
		return updateText;
	}

	public void setUpdateText(String updateText) {
		this.updateText = updateText;
	}

	public String getMassagekey() {
		return massagekey;
	}

	public void setMassagekey(String massagekey) {
		this.massagekey = massagekey;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	public String getTablename() {
		return tablename;
	}

	public void setTablename(String tablename) {
		this.tablename = tablename;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	
}
