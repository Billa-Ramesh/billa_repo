package com.app.trans.update;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.SimpleDateFormat;
import java.util.Date;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.app.trans.core.Center;

import com.app.trans.util.DBConnection;






public class InfoPanel extends JFrame implements ActionListener,KeyListener
{
     private static JLabel           lblEmpHead,lblLine,lblcomments,lblfield1,lblfield2,lblversion
     ,lblnameflag,lbldescflag,lbltrans,lblkyefield,lbltable;
     private static JTextField       txtversion
     ,txtComments,txtnameflag,txtdescflag,txttrans,txtfield1,txtfield2,txtkyefield,txttable;
     private static JButton          cmdSave,cmdFind,cmdUpdate,cmdClear,cmdDelete;
     private static JPanel           mainPanel,lblPanel,btnPanel;
     private static info    		 infoObject;
     private static DBConnection          Conn;
     private static Center			 center;
  

   
     
     public InfoPanel() {
    	 
		 
    	 super("Info Panel");
        mainPanel=new JPanel();
        mainPanel.setLayout(null);
        //Label Panel

        lblPanel=new JPanel();
        lblPanel.setLayout(null);
       
       lblEmpHead     =new JLabel(" Info Table ");
       lblEmpHead.setFont(new Font("TimesRoman",Font.BOLD,22));
       lblEmpHead.setBounds(210,10,300,20);
       lblLine =new JLabel(" =================");
       lblLine.setBounds(210,23,300,20);
       lblLine.setForeground(Color.GREEN);

       lbltable  =new JLabel("TABLE_NAME :");
       lbltable.setFont(new Font("TimesRoman",Font.BOLD,12));
       lbltable.setBounds(25,40,200,20);
       txttable =new JTextField();
       txttable.setFont(new Font("TimesRoman",Font.BOLD,12));
       txttable.setBounds(200,40,350,20);
       txttable.addKeyListener(this);  

       lblkyefield  =new JLabel("KEY_FIELD :");
       lblkyefield.setFont(new Font("TimesRoman",Font.BOLD,12));
       lblkyefield.setBounds(25,70,200,20);
       txtkyefield  =new JTextField();
       txtkyefield.setFont(new Font("TimesRoman",Font.BOLD,12));       
       txtkyefield.setBounds(200,70,350,20);
       txtkyefield.addKeyListener(this);  
       
       
       lblfield1  =new JLabel("TRANSLATABLE_FIELD1 :");
       lblfield1.setFont(new Font("TimesRoman",Font.BOLD,12));
       lblfield1.setBounds(25,100,200,20);
       txtfield1 =new JTextField();
       txtfield1.setFont(new Font("TimesRoman",Font.BOLD,12));       
       txtfield1.setBounds(200,100,350,20);
       txtfield1.addKeyListener(this);  
      
       lblfield2  =new JLabel("TRANSLATABLE_FIELD2 : ");
       lblfield2.setFont(new Font("TimesRoman",Font.BOLD,12));
       lblfield2.setBounds(25,130,200,20);
       txtfield2=new JTextField();
       txtfield2.setFont(new Font("TimesRoman",Font.BOLD,12));
       txtfield2.setBounds(200,130,350,20);
       txtfield2.addKeyListener(this);

       
       lblversion  =new JLabel("VERSION_NUM :");
       lblversion.setFont(new Font("TimesRoman",Font.BOLD,12));
       lblversion.setBounds(25,160,200,20);
       txtversion=new JTextField();
       txtversion.setFont(new Font("TimesRoman",Font.BOLD,12));
       txtversion.setBounds(200,160,50,20);
       txtversion.addKeyListener(this);
       
       lblcomments  =new JLabel("COMMENTS :");
       lblcomments.setFont(new Font("TimesRoman",Font.BOLD,12));
       lblcomments.setBounds(25,190,200,20);
       txtComments=new JTextField();
       txtComments.setFont(new Font("TimesRoman",Font.BOLD,12));
       txtComments.setBounds(200,190,350,20);
       txtComments.addKeyListener(this);  
  
       
       lblnameflag  =new JLabel("TRANS_FLAG1 :");
       lblnameflag.setFont(new Font("TimesRoman",Font.BOLD,12));
       lblnameflag.setBounds(25,210,200,20);
       txtnameflag=new JTextField();
       txtnameflag.setFont(new Font("TimesRoman",Font.BOLD,12));
       txtnameflag.setBounds(200,210,50,20);
       txtnameflag.addKeyListener(this);
      
       lbldescflag  =new JLabel("TRANS_FLAG2 :");
       lbldescflag.setFont(new Font("TimesRoman",Font.BOLD,12));
       lbldescflag.setBounds(25,240,100,20);
       txtdescflag=new JTextField();
       txtdescflag.setFont(new Font("TimesRoman",Font.BOLD,12));
       txtdescflag.setBounds(200,240,50,20);
       txtdescflag.addKeyListener(this);
       
       lbltrans  =new JLabel("TRANS_FIELDS :");
       lbltrans.setFont(new Font("TimesRoman",Font.BOLD,12));
       lbltrans.setBounds(25,270,200,20);
       txttrans=new JTextField();
       txttrans.setFont(new Font("TimesRoman",Font.BOLD,12));
       txttrans.setBounds(200,270,450,20);
       txttrans.addKeyListener(this);
      

       lblPanel.add(lblEmpHead);
       lblPanel.add(lblLine);
       
       lblPanel.add(lbltable);
       lblPanel.add(txttable) ;
       
       lblPanel.add(lblkyefield);
       lblPanel.add(txtkyefield) ;
       
       lblPanel.add(lblfield1);
       lblPanel.add(txtfield1) ;
       
       lblPanel.add(lblfield2);
       lblPanel.add(txtfield2) ;
         
       
       lblPanel.add(lblversion);
       lblPanel.add(txtversion) ;
    
       lblPanel.add(lblcomments);
       lblPanel.add(txtComments);
      
       lblPanel.add(lblnameflag);
       lblPanel.add(txtnameflag);
       
       lblPanel.add(lbldescflag);
       lblPanel.add(txtdescflag);
       
       lblPanel.add(lbltrans);
       lblPanel.add(txttrans);
       //Button Panel
       btnPanel  =new JPanel();
       btnPanel.setLayout(null);

       cmdSave=new JButton("Save");
       cmdSave.setMnemonic('S');
       cmdSave.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdSave.setBounds(25,10,80,25);
       cmdSave.addActionListener(this);

       cmdFind=new JButton("Find");
       cmdFind.setMnemonic('F');
       cmdFind.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdFind.setBounds(125,10,80,25);
       cmdFind.addActionListener(this);

       cmdUpdate=new JButton("Update");
       cmdUpdate.setMnemonic('u');
       cmdUpdate.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdUpdate.setBounds(225,10,80,25);
       cmdUpdate.addActionListener(this);

       cmdDelete=new JButton("Delete");
       cmdDelete.setMnemonic('D');
       cmdDelete.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdDelete.setBounds(325,10,80,25);
       cmdDelete.addActionListener(this);

       cmdClear=new JButton("Clear");
       cmdClear.setMnemonic('C');
       cmdClear.setFont(new Font("TimesRoman",Font.BOLD,12));
       cmdClear.setBounds(425,10,80,25);
       cmdClear.addActionListener(this);

       btnPanel.add(cmdUpdate);
       btnPanel.add(cmdClear);
       btnPanel.add(cmdSave);
       btnPanel.add(cmdFind);
       btnPanel.add(cmdDelete);

       mainPanel.add(lblPanel);
       lblPanel.setBounds(0,0,600,300);
       mainPanel.add(btnPanel);
       btnPanel.setBounds(0,300,600,400);

       getContentPane().add(mainPanel);
       cmdUpdate.setEnabled(false);
       cmdDelete.setEnabled(false);
     }

     public void keyReleased(KeyEvent evt){}	

     public void keyTyped(KeyEvent evt){}	

     public void keyPressed(KeyEvent evt) {
    	 Object obj = evt.getSource();
    	 int key = evt.getKeyCode();
    	 if(key == KeyEvent.VK_ENTER){
    		 if(obj == txttable) {
    			 txtkyefield.requestFocus();
    			 BlankCheck(txttable);
    		 }
    		 if(obj == txtkyefield){
    			 txtfield1.requestFocus();
    			 BlankCheck(txtkyefield);
    		 }
    		 if(obj == txtfield1){
    			 txtfield2.requestFocus();
    			 BlankCheck(txtfield1);
    		 }
    		 if(obj == txtfield2){
    			 txtversion.requestFocus();
    			 BlankCheck(txtfield2);
    		 }
    		 if(obj == txtversion){
    			 txtComments.requestFocus();
    			 BlankCheck(txtversion);
    		 }
    		 if(obj == txtComments){
    			 txtnameflag.requestFocus();
    			 BlankCheck(txtComments);
    		 }
    		 if(obj == txtnameflag){
    			 txtdescflag.requestFocus();
    			 BlankCheck(txtnameflag);
    		 }
    		 if(obj == txtdescflag){
    			 txttrans.requestFocus();
    			 BlankCheck(txtdescflag);
    		 }
    		 if(obj == txttrans){
    			
    			 BlankCheck(txttrans);
    		 }
    		
    		
    	 }
     }

     public void actionPerformed(ActionEvent e) {
    	 
         Conn = new DBConnection();
         info infotable = new info();
         
         Object obj = e.getSource();
          if(obj == cmdClear) {            
        	  Clear();                            
          }
          if(obj == cmdSave) {
        	  setFinal();
        	  infoDao.Save(Conn.getConnection(), infoObject);
              Clear();
          }
          if(obj == cmdFind) {
        	  
        	  System.out.println("in find");
        	  setFinal();
        	  infotable =infoDao.GetInfo(Conn.getConnection(), infoObject);
        	  if (infotable.getTABLE_NAME() == null) {
        		  JOptionPane.showMessageDialog(null, "Your Phone No is not available..");
        	  } else {
        		  
        		  txttable.setText(infotable.getTABLE_NAME());
        		  txtkyefield.setText(infotable.getKEY_FIELD());
        		  txtfield1.setText(infotable.getTRANSLATABLE_FIELD1());
        		  txtfield2.setText(infotable.getTRANSLATABLE_FIELD2());
        		  txtversion.setText(infotable.getVERSION_NUM());
        		  txtComments.setText(infotable.getCOMMENTS());
        		  txtnameflag.setText(infotable.getNAME_FLAG());
        		  txtdescflag.setText(infotable.getDESC_FLAG());
        		  txttrans.setText(infotable.getTRANS_FIELDS());
        	  }
        	  cmdSave.setEnabled(true);
        	  cmdUpdate.setEnabled(true);
        	  cmdDelete.setEnabled(true);
          }
          if(obj == cmdDelete) {
        	  setFinal();
        	  
        	  infoDao.Delete(Conn.getConnection(), infoObject);
              Clear();
              cmdSave.setEnabled(true);
              cmdUpdate.setEnabled(false);
              cmdDelete.setEnabled(false);
         }
         if(obj == cmdUpdate) {
        	 setFinal();
        	 infoDao.Update(Conn.getConnection(), infoObject);
        	 Clear();
        	 cmdSave.setEnabled(true);
        	 cmdUpdate.setEnabled(false);
        	 cmdDelete.setEnabled(false);
         }
      }

      public void  Clear() {
    	  txttable.setText("");
    	  txtkyefield.setText("");
    	  txtfield1.setText("");
    	  txtfield2.setText("");
    	  txtversion.setText("");
    	  txtComments.setText("");
    	  txtnameflag.setText("");
    	  txtdescflag.setText("");
    	  txttrans.setText("");
      }

       public void BlankCheck(JTextField txt) {
    	   if (txt.getText().equals("")) {
    		   JOptionPane.showMessageDialog(null, "You Must Enter The Text  Box");
    		   txt.requestFocus();	
           }
        }

       //Set Phone Information
       public void setFinal() { 
    	   infoObject = new info();
    	   infoObject.setTABLE_NAME(txttable.getText().trim());
           infoObject.setKEY_FIELD(txtkyefield.getText().trim());
           infoObject.setTRANSLATABLE_FIELD1(txtfield1.getText().trim());
           infoObject.setTRANSLATABLE_FIELD2(txtfield2.getText().trim());
           infoObject.setVERSION_NUM(txtversion.getText().trim());
           infoObject.setCOMMENTS(txtComments.getText().trim());
           infoObject.setNAME_FLAG(txtnameflag.getText().trim());
           infoObject.setDESC_FLAG(txtnameflag.getText().trim());
           infoObject.setTRANS_FIELDS(txtdescflag.getText().trim());
          
    	   
	   
	  
       }

     //Main  Function
     public static void main(String[] args) {
         InfoPanel frmForm = new InfoPanel();
		 center = new Center(frmForm,700,500);
         frmForm.setVisible(true);
         frmForm.setResizable(false);
         frmForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     }
}