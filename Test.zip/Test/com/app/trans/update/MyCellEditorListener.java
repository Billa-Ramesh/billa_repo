package com.app.trans.update;

import java.awt.Component;

import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import com.app.trans.table.MyTableModel;

class MyCellEditorListener  extends MyTableModel implements CellEditorListener
{

    private JTable table;
    JTextField textField;

    public MyCellEditorListener(JTable table){
        this.table = table;
        textField = new JTextField();
        }

   

    @Override
    public void editingCanceled(ChangeEvent arg0) {
        //Do Nothing
    }

    @Override
    public void editingStopped(ChangeEvent e) {
    	
    	int row=table.getSelectedRow();
    	int col=table.getSelectedColumn();
    	
    	  
    
		
    	
    	
    //	column.setCellEditor(new MyTableCellEditor());
    	//System.out.println(column.getCellEditor().getCellEditorValue());
    	//column.setCellRenderer(new DefultTableCellRenderer());
    	//TableModel tm = this.table.getModel();
    	
    	//Object value = tm.getValueAt(row, col);
    //	table.setValueAt(value.toString(), row, col);
    	
    	//System.out.println(table.getSelectedRow()+"---"+table.getSelectedColumn()+"--"+o.toString());
    	System.out.println("editing stoped");
    
    	
    }

	


}
/*private class MyCellEditorListener implements CellEditorListener
{

    private JTable table;
    private String[][] datain;

    public MyCellEditorListener(JTable table){
        this.table = table;

        setupDataIn();


    }

    private void setupDataIn(){
        datain = new String[dataX][dataY];
        for(int i=0; i!=dataX; i++){
            for(int j=0; j!=dataY; j++){
                datain[i][j]=data[i][j];
            }
        }
    }

    @Override
    public void editingCanceled(ChangeEvent arg0) {
        //Do Nothing
    }

    @Override
    public void editingStopped(ChangeEvent e) {
        // Update DB
        printTable(data);
        printTable(datain);

        for(int i=0; i!=dataX; i++){
            for(int j=0; j!=dataY; j++){
                if(datain[i][j].equals(data[i][j])){
                    //DO Nothing
                } else {
                    //Update or add new field
                    if(i==dataX-1){
                        System.out.println("new field");
                        String com = "INSERT INTO "+tableName+" VALUES ("+(dataX-1)+", ";
                        for(int y=0;y!=dataY;y++){
                            if(y==j){
                                com += "'"+data[i][j]+"', ";
                            } else {
                                com += "'', ";
                            }
                        }
                        com = com.substring(0, com.length()-2);
                        com+=")";

                        System.out.println(com);
                        SQLCommands.SQLCommand(com);
                        initComponents();
                        loadDB();
                        setupDataIn();
                        displayTable();
                        tablePane.updateUI();
                        break;

                    } else {
                        System.out.println("UPDATE "+tableName+" SET "+columnNames[j]+"='"+data[i][j]+"' WHERE recID="+i);
                        SQLCommands.SQLCommand("UPDATE "+tableName+" SET "+columnNames[j]+"='"+data[i][j]+"' WHERE recID="+i);
                    }
                }
            }
        }

    }

}

private void printTable(String[][] t){
    for(String[] a : t){
        for(String b: a){
            System.out.print(b+" ");
        }
        System.out.println();
    }
}

public static void main(String[] args){
    String [] tableNames = SQLCommands.returnSQLCommand("SELECT name FROM sqlite_master");
    new ViewTable(tableNames[tableNames.length -1]);
}

}
*/