package com.app.trans.update;

public class info {

	private String TABLE_NAME;
	public String getTABLE_NAME() {
		return TABLE_NAME;
	}
	public void setTABLE_NAME(String table_name) {
		TABLE_NAME = table_name;
	}
	public String getKEY_FIELD() {
		return KEY_FIELD;
	}
	public void setKEY_FIELD(String key_field) {
		KEY_FIELD = key_field;
	}
	public String getTRANSLATABLE_FIELD1() {
		return TRANSLATABLE_FIELD1;
	}
	public void setTRANSLATABLE_FIELD1(String translatable_field1) {
		TRANSLATABLE_FIELD1 = translatable_field1;
	}
	public String getTRANSLATABLE_FIELD2() {
		return TRANSLATABLE_FIELD2;
	}
	public void setTRANSLATABLE_FIELD2(String translatable_field2) {
		TRANSLATABLE_FIELD2 = translatable_field2;
	}
	public String getVERSION_NUM() {
		return VERSION_NUM;
	}
	public void setVERSION_NUM(String version_num) {
		VERSION_NUM = version_num;
	}
	public String getCOMMENTS() {
		return COMMENTS;
	}
	public void setCOMMENTS(String comments) {
		COMMENTS = comments;
	}
	public String getNAME_FLAG() {
		return NAME_FLAG;
	}
	public void setNAME_FLAG(String name_flag) {
		NAME_FLAG = name_flag;
	}
	public String getDESC_FLAG() {
		return DESC_FLAG;
	}
	public void setDESC_FLAG(String desc_flag) {
		DESC_FLAG = desc_flag;
	}
	public String getTRANS_FIELDS() {
		return TRANS_FIELDS;
	}
	public void setTRANS_FIELDS(String trans_fields) {
		TRANS_FIELDS = trans_fields;
	}
	private String KEY_FIELD;
	private String TRANSLATABLE_FIELD1;
	private String TRANSLATABLE_FIELD2;
	private String VERSION_NUM;
	private String COMMENTS;
	private String NAME_FLAG;
	private String DESC_FLAG;
	private String TRANS_FIELDS;
	
	
}
