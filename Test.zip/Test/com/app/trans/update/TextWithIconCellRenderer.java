package com.app.trans.update;

import javax.swing.table.DefaultTableCellRenderer;

public class TextWithIconCellRenderer  extends DefaultTableCellRenderer{
	 protected void setValue(Object value) {
		 
		      if (value != null) {
		       
		        setText(value == null ? "" : value.toString());
		       
		      } else {
		        setText("");
		        setIcon(null);
		      }
		    
		  }
}
