package com.app.trans.update;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import com.app.trans.core.AnalysisReportUpdates;
import com.app.trans.util.ConstantsAll;




public class infoDao {
	
	public static final infoDao infoDao = new infoDao();
	
	public infoDao() {}
	
	public static void Save(Connection Conn, info infoObject) {

		try {
	          Statement stmt=Conn.createStatement();
	 
	          String query = "INSERT INTO "+ConstantsAll.META_DATA_TABLE+" VALUES ('"+infoObject.getTABLE_NAME()+"','"+infoObject.getKEY_FIELD()+ "','" + infoObject.getTRANSLATABLE_FIELD1() + 
	          					"','" + infoObject.getTRANSLATABLE_FIELD2() + "','" + infoObject.getVERSION_NUM()+ "','" +infoObject.getCOMMENTS()+ "','" +infoObject.getNAME_FLAG()+"','"+infoObject.getDESC_FLAG()+"','"+infoObject.getTRANS_FIELDS() + "')";
	          				System.out.println(query);	
	          int result=stmt.executeUpdate(query);
	          
	          if(result==1) {
	        	  JOptionPane.showMessageDialog(null, " \nSaving Successfully  \n");               
	          }
         } catch(SQLException sqlx) {
        	 JOptionPane.showMessageDialog(null, " \n SQLException \n " +sqlx.getMessage() + "\n");
         }
	}
	
	public static void Delete(Connection Conn, info infoObject) {
       String tablename = infoObject.getTABLE_NAME();
       try {
    	   
    	   
    	 int response=  JOptionPane.showConfirmDialog(null, "Do you want to continue?","Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
    	   if (response == JOptionPane.NO_OPTION) {
    		      System.out.println("No button clicked");
    		    } else if (response == JOptionPane.YES_OPTION) {
    		    	infoObject = new info();
    					Statement stmt=Conn.createStatement();
    					String query="DELETE FROM "+ConstantsAll.META_DATA_TABLE+" WHERE TABLE_NAME = '" + tablename + "' ";
    					stmt.executeUpdate(query);
    					stmt.close();
    		    } else if (response == JOptionPane.CLOSED_OPTION) {
    		      System.out.println("JOptionPane closed");
    		    }
    	  
         } catch(SQLException sqlx) {
        	 JOptionPane.showMessageDialog(null, " \n *** SQLException ***  \n " +sqlx.getMessage() + "\n");
         }
    }
	
	public static void Update(Connection Conn, info infoObject) {
	       String tablename = infoObject.getTABLE_NAME();
	       try {
	    	   int response = JOptionPane.showConfirmDialog(null, "Do you want to continue?", "Confirm",
	    		        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	    		    if (response == JOptionPane.NO_OPTION) {
	    		      System.out.println("No button clicked");
	    		    } else if (response == JOptionPane.YES_OPTION) {
	    		        Statement stmt=Conn.createStatement();
	    				String query="UPDATE "+ConstantsAll.META_DATA_TABLE+" SET " +
	    								" TABLE_NAME ='" + infoObject.getTABLE_NAME() + "', " +
	    								" KEY_FIELD ='" + infoObject.getKEY_FIELD() + "', " +
	    								" TRANSLATABLE_FIELD1 ='" + infoObject.getTRANSLATABLE_FIELD1() + "', " +
	    								" TRANSLATABLE_FIELD2 ='" + infoObject.getTRANSLATABLE_FIELD2() + "', " +
	    								" VERSION_NUM ='" + infoObject.getVERSION_NUM() + "', " +
	    								" COMMENTS ='" + infoObject.getCOMMENTS() + "', " +
	    								" NAME_FLAG ='" + infoObject.getNAME_FLAG() + "', " +
	    								" DESC_FLAG ='" + infoObject.getDESC_FLAG() + "', " +
	    								" TRANS_FIELDS ='" + infoObject.getTRANS_FIELDS() + "'" +
	    								" WHERE TABLE_NAME = '" + tablename + "'";
	    				System.out.println(query);
	    				stmt.executeUpdate(query);
	    				   				
	    				stmt.close();
	    				
	    		    } else if (response == JOptionPane.CLOSED_OPTION) {
	    		      System.out.println("JOptionPane closed");
	    		    }
	    	
	         } catch(SQLException sqlx) {
	        	 JOptionPane.showMessageDialog(null, " \n *** SQLException ***  \n " +sqlx.getMessage() + "\n");
	         }
    }

	public static info GetInfo(Connection Conn, info infoObject) {
		System.out.println("get Phone");
		  String tablename = infoObject.getTABLE_NAME();
		try {
              Statement stmt=Conn.createStatement();
             
              System.out.println("SELECT * FROM "+ConstantsAll.META_DATA_TABLE+" WHERE TABLE_NAME='" + tablename + "' ");
             
              String query="SELECT * FROM "+ConstantsAll.META_DATA_TABLE+" WHERE TABLE_NAME='" + tablename + "' ";
              System.out.println(query);
              ResultSet rs=stmt.executeQuery(query);
              while(rs.next()) {
            	  infoObject = new info();
            	
	              infoObject.setTABLE_NAME(rs.getString(1));
	              infoObject.setKEY_FIELD(rs.getString(2));
	              infoObject.setTRANSLATABLE_FIELD1(rs.getString(3));
	              infoObject.setTRANSLATABLE_FIELD2(rs.getString(4));
	              infoObject.setVERSION_NUM(rs.getString(5));
	              infoObject.setCOMMENTS(rs.getString(6));
	              infoObject.setNAME_FLAG(rs.getString(7));
	              infoObject.setDESC_FLAG(rs.getString(8));
	              infoObject.setTRANS_FIELDS(rs.getString(9));
	             
              }    
		} catch(SQLException sqlx) {
			JOptionPane.showMessageDialog(null, " \n *** SQLException ***  \n " +sqlx.getMessage() + "\n");
		}
		return infoObject;
	}	
        

	/**
	 * @return the phoneDAO
	 */
	public static infoDao getPhoneDAO() {
		return infoDao;
	}
}