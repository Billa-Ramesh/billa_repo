package com.app.trans.core;




import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import com.app.trans.util.ConstantsAll;
import com.app.trans.util.DBConnection;



/**
 * @author rameshbi
 *
 */

public class LangugeTablesProcedurs {

	
	
	static Connection conn;
	CallableStatement cstmt1=null,cstmt2=null;
	
	

	public static void main(String[] args) throws SQLException {
	LangugeTablesProcedurs runPro=new LangugeTablesProcedurs();
		runPro.insertLocaleType1("de_DE");
	}

/*public void insertLocaleType1(String mlsC1 ) throws SQLException{
		
		try{
			conn = DBConnection.getConnection();
			cstmt1 = conn.prepareCall("{call XXX_INSERT_ALL_BASEL_PRO(?,?,?)}");
			cstmt1.setString(1, mlsC1);
			cstmt1.registerOutParameter(2, java.sql.Types.VARCHAR);
			cstmt1.setString(3, ConstantsAll.META_DATA_TABLE);
			cstmt1.execute();
			String s = cstmt1.getString(2);
			//System.out.println(s.equals(null)? "sucessfully" ,"fail");
			
			
		}
		catch(Exception e)
		{
			System.out.println("Error while calling update procedure on "+ e.getMessage());
			
		}
		finally
		{
			cstmt1.close();
			conn.close();
		}
		
		
	}
*/
	
public void insertLocaleType1(String mlsC1 ) throws SQLException{
	PreparedStatement pstSelect = null, pstdelete = null, pstInsert = null;
	ResultSet rsSelect = null, rscreate=null;
		try{
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			pstSelect = conn.prepareStatement("select table_name,trans_fields from "+ConstantsAll.META_DATA_TABLE);
			rsSelect = pstSelect.executeQuery();
			while(rsSelect.next()){
				String tablename=rsSelect.getString("table_name");
				String transfields=rsSelect.getString("trans_fields");
				System.out.println(tablename+"-"+transfields);
				
						
				 DatabaseMetaData md = conn.getMetaData();
				 rscreate = md.getTables(null, null, tablename+"_t".toUpperCase(), null);
				 if (!rscreate.next()) {

						Statement stm = conn.createStatement();
						 stm.execute("CREATE TABLE "+ tablename+"_t as select "+transfields+",'"+mlsC1+"' as mls_cd from "+tablename);
					}
				 
				 System.out.println("delete from  "+ tablename+"_t where mls_cd='"+mlsC1+"'");
				 pstdelete=conn.prepareStatement("delete from "+ tablename+"_t where mls_cd='"+mlsC1+"'");
				 pstdelete.executeUpdate();
				 
				 
				 if (tablename.length() > 28)

					 tablename = tablename.substring(0, 28);
				 System.out.println("insert into "+tablename+"_t("+transfields+",mls_cd ) select "+transfields+",'"+mlsC1+"' as mls_cd from "+tablename);
				 pstInsert=conn.prepareStatement("insert into "+tablename+"_t("+transfields+",mls_cd ) select "+transfields+",'"+mlsC1+"' as mls_cd from "+tablename );
				 pstInsert.executeUpdate();
			//	while(rsSelectLevel)
				
				
			}
			rsSelect.close();
			pstSelect.close();
			pstdelete.close();
			pstInsert.close();
			 conn.commit();
			   conn.close();
		}
		catch(Exception e)
		{
			 conn.rollback(); 
			 
			System.out.println(""+ e.getMessage());
			
		}
		finally
		{
			
			conn.close();
		}
		
		
	}


public void createLangugeMaster(String mlsC1)throws SQLException{
	
	
	PreparedStatement pst = null;
	
	try {
		
		 

		conn = DBConnection.getConnection();
		CreateUseFulTables.mlstable(ConstantsAll.APP_NAME+"_"+mlsC1+"_master");
			String quary = "insert into "
					+ ConstantsAll.APP_NAME
					+ "_"
					+ mlsC1
					+ "_master "
					+ "select X.message_key,X.message_text,Y.target_text,Y.dropnum from "
					+ ConstantsAll.MASTER_TABLE
					+ " X,"
					+ ConstantsAll.APP_NAME
					+ "_"
					+ mlsC1
					+ "_uniq Y "
					+ "where lower(trim(X.message_text)) = lower(trim(Y.source_text)) AND Y.dropnum='"
					+ ConstantsAll.DROP_VERSION + "'";
			System.out.println(quary);
			
			
			
			pst = conn.prepareStatement(quary);
			int returnX = pst.executeUpdate();
			if (returnX > 0) {
				System.out.println("Final Table insertion is successful");
				JOptionPane.showMessageDialog(null,
						"Records in the final table are inserted successfully");
			}
 		   } 
	
	
	catch(Exception e)
	{
		System.out.println("Error while calling update procedure on "+ e.getMessage());
		JOptionPane.showMessageDialog(null, " \n *** SQLException ***  \n " +e.getMessage() + "\n");
	}
	finally
	{
		pst.close();
		conn.close();
	}


}
}
