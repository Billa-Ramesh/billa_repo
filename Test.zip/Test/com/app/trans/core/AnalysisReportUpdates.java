package com.app.trans.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.app.trans.util.ConstantsAll;
import com.app.trans.util.DBConnection;

/**
 * @author rameshbi
 *
 */
public class AnalysisReportUpdates {

	private static String fromText;
	private static String toUpdatetext;
	private static Connection con;
	private static ResultSet result;

	public void analysisUpdate(String messageText, String updateText,String updateComment) {
		
		System.out.println(messageText+" =and"+updateText+" =and"+updateComment);
		PreparedStatement stmFinalUpdate = null, stmMasterUpdate = null, stmSelect = null, stmIndividualTable = null;
		//String fromText = "This report displays the trend of the selected stock index.";
		//String toUpdatetext = "This report displays the trend of the selected stock index. ramesh";
		ResultSet result = null;
		
		try {
			con = DBConnection.getConnection();
			// stmFinalUpdate =
		//	 con.prepareStatement("update  "+ConstantsAll.FINAL_TABLE+" set message_text='"+toUpdatetext+"' where message_text='"+fromText+"'");

		//	stmFinalUpdate.execute();
	
			stmSelect = con.prepareStatement("select * from "
					+ ConstantsAll.MASTER_TABLE + " where message_text='"
					+ messageText + "'");
			System.out.println("select * from " + ConstantsAll.MASTER_TABLE
					+ " where message_text='" + messageText + "';");
			result = stmSelect.executeQuery();
			int count = 1;
			while (result.next()) {

				String keyId = result.getString(1);

				String keyIDs[] = keyId.split("~");

				String table_name = keyIDs[0];
				System.out.println("table name :   " + table_name);
				String c_name = keyIDs[1];

				String targetValue = result.getString(3);
				String sourceValue = result.getString(2);
                 getCommentColumn(table_name);
                
				System.out.println(targetValue + "=" + sourceValue);
				String updateCsv = "update " + table_name + " set " + c_name
						+ "='" + updateText + "',COMMENTS='"+updateComment+"' where " + c_name + "='"
						+ messageText + "'";
				System.out.println(updateCsv);
				try {

					stmIndividualTable = con.prepareStatement(updateCsv);

					  stmIndividualTable.execute();
					count = count + 1;
					System.out.println("count   :=" + count);
					
					/*
					 * if (x) { System.out.println("inserted");
					 * 
					 * }
					 */
				} catch (Exception e) {

				} finally {
					try {

						stmIndividualTable.close();
						
					} catch (Exception ex) {
					}
				}
			}
			
			stmMasterUpdate =
			con.prepareStatement("update  "+ConstantsAll.MASTER_TABLE+" set message_text='"+updateText+"',COMMENTS='"+updateComment+"' where message_text='"+messageText+"'");

			stmMasterUpdate.execute();


		} catch (SQLException e) {
		
			e.printStackTrace();
		} finally {
			try {
				result.close();
				stmSelect.close();
				
			
				con.commit();
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}

		}

	}

	private void getCommentColumn(String table_name) {
		int count = 0;
		con = DBConnection.getConnection();
		try {
			con = DBConnection.getConnection();
			Statement stComment = con.createStatement();
			System.out.println("alter table "+table_name +" add  comments  varchar2(500)");
			
			//boolean s=getColoumnPresent(table_name);
			//if(s)
			count=stComment.executeUpdate("alter table "+table_name +" add  comments  varchar2(500)");
					
			if(count>0){
				System.out.println("comment column added");
			}else{
				System.out.println("comment column already present");
			}
		} catch (SQLException e) {
			
			e.getCause();
		}
		
	}

	private boolean getColoumnPresent(String table_name) {

		boolean present=false;
		con = DBConnection.getConnection();
		try {
			con = DBConnection.getConnection();
			Statement stCommentCheck = con.createStatement();
			
			
			
			 ResultSet crs = stCommentCheck.executeQuery("select * from "+table_name);
			ResultSetMetaData meta = crs.getMetaData();
			int numCol = meta.getColumnCount();

			for (int i = 1; i < numCol+1; i++) 
			    if(meta.getColumnName(i).equals("COMMENTS".toUpperCase()))
			    	present= true;

			
			
		} catch (SQLException e) {
			
			e.getCause();
		}
		
	return present;
		
	}

	
}
