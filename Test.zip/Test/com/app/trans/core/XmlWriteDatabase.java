package com.app.trans.core;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * @author rameshbi
 *
 */
public class XmlWriteDatabase {
	static Connection con = com.app.trans.util.DBConnection.getConnection();
	PreparedStatement del_sql = null;

	public void method(String xmlFilename,String tablename) {
		try {

			String path = xmlFilename;
			DocumentBuilderFactory odbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder odb = odbf.newDocumentBuilder();
			Document odoc = odb.parse(xmlFilename);
			odoc.getDocumentElement().normalize();
			// MR - sharedcaptionsa.xml
			System.out.println("Root element of the doc is "
					+ odoc.getDocumentElement().getNodeName() + xmlFilename);
			NodeList LOP = odoc.getElementsByTagName("WebMessageTable");
			int totalPersons = LOP.getLength();
			// System.out.println("Total no of tables : " + totalPersons);
			for (int s = 0; s < LOP.getLength(); s++) {

				Node FPN = LOP.item(s);

				if (FPN.getNodeType() == Node.ELEMENT_NODE) {
					Element firstPElement = (Element) FPN;
					NamedNodeMap x = firstPElement.getAttributes();

					Node description = x.getNamedItem("description");

					Node l = x.getNamedItem("path");
					String pathvalue = l.getTextContent();
					// System.out.println( pathvalue);

					NodeList childNodes = firstPElement
							.getElementsByTagName("WebMessage");
					int childNodesLength = childNodes.getLength();

					for (int c = 0; c < childNodesLength; c++) {

						// System.out.println("on row");
						Node childNode = childNodes.item(c);

						if (childNode.getNodeType() == Node.ELEMENT_NODE) {

							Element webMessageElement = (Element) childNodes
									.item(c);
							// System.out.println(webMessageElement.getAttribute("name"));
							String keytext = webMessageElement
									.getAttribute("name");

							NodeList childNodess = webMessageElement
									.getChildNodes();
							for (int ch = 0; ch < childNodess.getLength(); ch++) {

								Node childNodesss = childNodess.item(ch);
								if (childNodesss.getNodeType() == Node.ELEMENT_NODE) {

									Element childNodesssElement = (Element) childNodess
											.item(ch);
									childNodesssElement.getNodeName();
									String source = childNodesssElement
											.getNodeName();

									String text = childNodesssElement
											.getTextContent();
									firstPElement.getParentNode()
											.getParentNode();

									System.out.println("source node"
											+ webMessageElement.getParentNode()
													.getNodeName());
									if (description != null) {

										 insertXmlData(keytext,description.getTextContent(),text,tablename);
									} else {
										 insertXmlData(keytext,text,tablename);
									}

									// insertXmlData(keytext,description,text);
									// System.out.println("source node"+source);

									// System.out.println(target);
									// System.out.println("tehe"+
									// methodGet(keytext));

									// System.out.println(":"+value+":"
									// +childNodesssElement.getNodeName()+":"+childNodesssElement.getTextContent());

								}

							}

						}

					}

				}

			}
			System.out.println("Faild to Completed");
		} catch (FileNotFoundException file) {
			JOptionPane.showMessageDialog(null,
					"please enter the correct Filename");
		} catch (SAXParseException err) {
			System.out.println(err.getMessage());
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		System.out.println("Success Fully Completed");
	}

	private synchronized static void insertXmlData(String keytext, String text,String tablename) {

		System.out.println("source node" + keytext);

		PreparedStatement ps;

		try {
			ps = con.prepareStatement("insert into "+tablename+" values(?,?,?)");
			ps.setString(1, keytext);
			ps.setString(2, "");
			ps.setString(3, text);
			ps.executeUpdate();

			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub

	}

	private synchronized static void insertXmlData(String keytext,
			String description, String text,String tablename) {

		System.out.println("source node" + keytext);

		PreparedStatement ps;
		ResultSet rs;

		try {
			ps = con.prepareStatement("insert into "+tablename+" values(?,?,?)");
			ps.setString(1, keytext);
			ps.setString(2, description);
			ps.setString(3, text);
			ps.executeUpdate();

			ps.close();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	
	}

	
}
