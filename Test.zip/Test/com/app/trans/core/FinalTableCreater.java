package com.app.trans.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.app.trans.util.ConstantsAll;
import com.app.trans.util.DBConnection;
import com.app.trans.util.TRANSLogger;

/**
 * @author rameshbi
 *
 */
public class FinalTableCreater {
	Connection con;
	int insertCount = 1;

	/**
	 * @param p1
	 */
	public void insert2Table(JPanel p1) {

		PreparedStatement pst1 = null, pst2 = null, pst3 = null;
		ResultSet rs1 = null, rs2 = null;

		try {

			con = DBConnection.getConnection();
			
			//CreateUseFulTables.createTabelmethod(null);
			
			// System.out.println(con.toString());
		//	CreateUseFulTables createTable=new CreateUseFulTables();
		//	CreateUseFulTables.tablescreate();

			String sqlQuery = new String();
			String insQuery = new String(ConstantsAll.INSERT_MASTER);
			System.out.println(insQuery);

			/*
			 * Get the records that contains details on tables and fields to be
			 * translated
			 */
			pst1 = con.prepareStatement(ConstantsAll.SELECT_INFO);
			System.out.println(ConstantsAll.SELECT_INFO);
			pst3 = con.prepareStatement(insQuery);
			rs1 = pst1.executeQuery();
			String tableName = null;
			String keyField = null;
			String translatableField1 = null;
			String translatableField2 = null;
			String comments = null;
			String flag_text = null;
			String flag_desc = null;
			while (rs1.next()) {
				tableName = rs1.getString("Table_Name");

				keyField = rs1.getString("Key_Field");

				translatableField1 = rs1.getString("Translatable_Field1");
				/*
				 * Few tables have 2 columns for translation, fetch this field
				 * anyways - if its null, it means only one field requires
				 * translation
				 */
				translatableField2 = rs1.getString("Translatable_Field2");
				/*
				 * Split keyfields to see if there are multiple key fields
				 */
				String keyFields[] = keyField.split(",");
				 System.out.println("Processing " + tableName);

				comments = rs1.getString("comments");

				flag_text = rs1.getString("NAME_FLAG");
				flag_desc = rs1.getString("DESC_FLAG");
				System.out.println("reading comments " + comments);

				if (comments != null && translatableField2 == null
						&& flag_desc == null) {

					sqlQuery = "Select " + keyField + "," + comments + ","
							+ flag_text + "," + translatableField1 + " from "
							+ tableName;

				} else {

					sqlQuery = "Select " + keyField + "," + comments + ","
							+ flag_text + "," + flag_desc + ","
							+ translatableField1 + "," + translatableField2
							+ " from " + tableName;
				}
				if (comments == null && translatableField2 == null
						&& flag_desc == null) {
					sqlQuery = "Select " + keyField + "," + comments + ","
							+ flag_text + "," + translatableField1 + " from "
							+ tableName;
				} else {
					sqlQuery = "Select " + keyField + "," + comments + ","
							+ flag_text + "," + flag_desc + ","
							+ translatableField1 + "," + translatableField2
							+ " from " + tableName;
				}

				try {
					System.out.println(sqlQuery);
					pst2 = con.prepareStatement(sqlQuery);
					rs2 = pst2.executeQuery();
				} catch (Exception ex1) {
					// logger.error(ex1.getMessage());
					TRANSLogger.logInfo(this, " insert2Table()", ex1
							.getMessage()
							+ "\n" + sqlQuery);
				}
				int count = 1;

				while (rs2.next()) {
					// Form key field as
					// tablename_listofkeys_TF1_reccount

					String transKey1 = tableName;
					StringBuffer stringBuffer1 = new StringBuffer(transKey1);

					String transKey2 = tableName;
					StringBuffer stringBuffer2 = new StringBuffer(transKey2);
					String transValue1 = null;
					String transValue2 = null;

					/*
					 * Loop to form the message key Message Key is formed as a
					 * combination of Table Name, key fields provided followed
					 * by a running sequence number to avoid duplication.
					 */

					transKey1 = stringBuffer1.append("~").append(
							translatableField1).toString();
					transKey2 = stringBuffer2.append("~").append(
							translatableField2).toString();
					for (int i = 1; i <= keyFields.length; i++) {
						stringBuffer1.append("~").append(rs2.getString(i));
						stringBuffer2.append("~").append(rs2.getString(i));
					}
					// stringBuffer.append("~").append(translatableField1);

					transKey1 = stringBuffer1.toString();
					// logger.info(transKey1);
					TRANSLogger.logInfo(this, " insert2Table()",
							" translatableField1 :" + transKey1 + "tablename :"
									+ tableName);
					// System.out.println(transKey1);
					// transKey1 = transKey1 + "~" + rs2.getString(i);
					// transKey1 = transKey1 + "~" + + "~" + count;
					transValue1 = rs2.getString(translatableField1);

					// Will get the fields after key fields

					/*
					 * Form the key value pair for the second translatable field
					 * (optional).
					 */
					String dev = null,flag1=null,flag2;
					if (translatableField2 != null) {

						transKey2 = stringBuffer2.toString();
						// System.out.println(transKey2);

						TRANSLogger.logInfo(this, " insert2Table()",
								" translatableField2 :" + transKey2
										+ "tablename :" + tableName);
						transValue2 = rs2.getString(translatableField2);
						//rs2.getString(flag_desc);
					}
					System.out.println(flag_text +"\n "+flag_desc);

					if (comments != null)
						dev = rs2.getString(comments);
					
					if(flag_text!=null){
						flag1=rs2.getString(flag_text);
						if(flag1==null)
							flag1="Y";
						System.out.println("in : "+flag1 );
					}else{
						flag1="Y";
						System.out.println("else : "+flag1 );
					}
					if(flag_desc!=null){
						flag2=rs2.getString(flag_desc);
						if(flag2==null)
							flag2="Y";
						System.out.println("in : "+flag2 );
					}
						
						else{
							flag2="Y";
							System.out.println("else : "+flag1 );
						}
					
					/*
					 * Insert the key value pair along with the respective table
					 * name in FSI_Translation_Messages table
					 */
				
					pst3.setString(1, transKey1);
					pst3.setString(2, transValue1);
					pst3.setString(3, tableName);
					pst3.setString(4, dev);
					pst3.setString(5, flag1);
					pst3.executeUpdate();
					insertCount++;
					if (translatableField2 != null) {
						System.out.println(new StringBuilder().append(transKey2).append(transValue2).append(flag_desc).append(dev).append(flag2));
						pst3.setString(1, transKey2);
						pst3.setString(2, transValue2);
						pst3.setString(3, tableName);
						pst3.setString(4, dev);
						pst3.setString(5, flag2);
						pst3.executeUpdate();
						insertCount++;
					}

					count++;

				}

				TRANSLogger.logInfo(this, " insert2Table()", "Inserted "
						+ (count - 1) + " records in Table " + tableName);
				// logger.info("Inserted " + (count - 1)
				// + " records in Table " + tableName);

			}

			JOptionPane.showMessageDialog(p1, "Insertion Completed "
					+ (insertCount - 1) + "", "",
					JOptionPane.INFORMATION_MESSAGE);

		} catch (Exception ex) {

			JOptionPane.showMessageDialog(null, FinalTableCreater.this,
					"Error in inserting data data!", JOptionPane.ERROR_MESSAGE);
			System.out.println("Error while iserting into the main Table");
			
		
			System.out.println(ex.getMessage());

			TRANSLogger.logError(null, ex, "Error in inserting data data!");

		} finally {
			try {
				rs1.close();
				rs2.close();
				pst1.close();
				pst2.close();
				con.close();
			} catch (Exception ex) {
			}
		}

	}

	public void insertDupliacates(JPanel p1) {

		PreparedStatement pstDup = null;

		try {

			con = DBConnection.getConnection();

			pstDup = con.prepareStatement(ConstantsAll.INSERT_DUPLICATES);
			int returnV = pstDup.executeUpdate();
			if (returnV > 0) {
				System.out.println("Duplicate Table insertion is successful");
				JOptionPane.showMessageDialog(p1,
						"Insertion of duplicate records are successful");
			} else {
				System.out.println("insertion Duplicates Faild");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());

		} finally {
			try {
				pstDup.close();
				con.close();
			} catch (Exception ex) {
			}

		}

	}

	public void deleteDuplicates(JPanel p1) {

		PreparedStatement pstDelDup = null;
		try {

			con = DBConnection.getConnection();

			System.out.println(ConstantsAll.DELETE_DUPLICATES);
			pstDelDup = con.prepareStatement(ConstantsAll.DELETE_DUPLICATES);
			int returnX = pstDelDup.executeUpdate();
			if (returnX > 0) {
				System.out.println("Duplicate Table Deletion is successful");
				JOptionPane.showMessageDialog(p1,
						"Duplicate records are deleted successfully");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());

		} finally {
			try {

				pstDelDup.close();
				con.close();
			} catch (Exception ex) {
			}

		}

	}

	public void insert2Final(JPanel p1) {

		PreparedStatement pstFinal = null;
		try {

			con = DBConnection.getConnection();

			pstFinal = con.prepareStatement(ConstantsAll.INSERT_FINAL);
			int returnX = pstFinal.executeUpdate();
			if (returnX > 0) {
				System.out.println("Final Table insertion is successful");
				JOptionPane.showMessageDialog(p1,
						"Records in the final table are inserted successfully");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());

		} finally {
			try {

				pstFinal.close();
				con.close();
			} catch (Exception ex) {
			}

		}

	}

	public void updateMessages(JPanel p1) {
		System.out.println("\n   updateMessages");
	}

}
