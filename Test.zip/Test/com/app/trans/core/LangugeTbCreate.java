package com.app.trans.core;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.Date;


import com.app.trans.util.ConstantsAll;
import com.app.trans.util.DBConnection;
import com.app.trans.util.TRANSLogger;



/**
 * @author rameshbi
 *
 */
public class LangugeTbCreate {
	Connection con;
	Date now = new Date();
	public void update2Table(String mls) {

		PreparedStatement pst1 = null, pst2 = null, pst3 = null;
		ResultSet rs1 = null, rs2 = null;

		try {
			
			
			con = DBConnection.getConnection();
        
			String sqlFinal = new String("select * from "+ConstantsAll.APP_NAME+"_"+mls+"_master");
			 System.out.println(sqlFinal);
			pst1 = con.prepareStatement(sqlFinal);

			rs1 = pst1.executeQuery();

			int count = 0;
			while (rs1.next()) {

				String keyId = rs1.getString(1);

				String keyIDs[] = keyId.split("~");

				String table_name = keyIDs[0];
				System.out.println("table name :   "+table_name);
				String c_name = keyIDs[1];
				StringBuffer stringBuffer = new StringBuffer();
				for (int i = 1; i <= keyIDs.length; i++) {
					if (i >= 3) {
						stringBuffer.append("'").append(keyIDs[i - 1]).append(
								"'").append(",");
					}
				}
				String targetValue = rs1.getString(3);
				String sourceValue = rs1.getString(2);
				String keyField = null;
				try {
					pst2 = con
							.prepareStatement("Select * from "+ConstantsAll.META_DATA_TABLE+" where table_name='"
									+ table_name + "'");
					rs2 = pst2.executeQuery();

					if (rs2.next()) {
						keyField = rs2.getString("Key_Field");
						
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				} finally {
					pst2.close();

				}
				String ss = stringBuffer.toString();

				int ivalue = ss.length();
				String finalval = ss.substring(0, ivalue - 1);

				StringBuffer strb = new StringBuffer();
				System.out.println("keyField"+keyField);
				String keyFields1[] = keyField.split(",");
				String finalvals[] = finalval.split(",");
				for (int i = 0; i < keyFields1.length; i++) {

					for (int j = 0; j < finalvals.length; j++) {

						String values = null;

						if (i == j) {
							values = keyFields1[i] + "=" + finalvals[j];
							strb.append(values);
							if (i < keyFields1.length - 1)
								strb.append(" and ");

						}
					}

				}
				String updateCsv = new String();
				try {
					/*
					 * 
					 * if (table_name.length() == 29) {
					 * 
					 * table_name = table_name.substring(0, 27);
					 * System.out.println("=29"); } else if (table_name.length()
					 * > 29) { table_name = table_name.substring(0, 28);
					 * System.out.println(">29"); }
					 */
					if (table_name.length() > 28)

						table_name = table_name.substring(0, 28);

					System.out.println(table_name);

					String targetValue1 = targetValue.replace("'", "''");
					String sourceValue1 = sourceValue.replace("'", "''");
					updateCsv = "update " + table_name + "_T set " + c_name
							+ "='" + targetValue1 + "' where "
							+ strb.toString() + " and " + c_name + "='"
							+ sourceValue1 +  "' and MLS_CD='" + mls + "'";

					System.out.println(updateCsv);

		/*			TRANSLogger.logInfo(this,
							" \n insert2Table()--Db2 all updates \n", now
									.toString()
									+ "\n Record is updated in the table  " +updateCsv +":"
									+ table_name + "_T");
*/
					pst3 = con.prepareStatement(updateCsv);

					boolean x = pst3.execute();
					count = count + 1;
					System.out.println("count   :="+count);
					con.setAutoCommit(true);
					if (x) {
						System.out.println("inserted");
						
					}

				} catch (Exception eu) {
					eu.printStackTrace();
					System.out.println("errro while Updating the ");
					TRANSLogger.logError(this, null, eu.getMessage() + "\n "
							+ now.toString() + "\n" + updateCsv + "\t"
							+ "for the table " + table_name + "_T");
					// con.rollback();
				} finally {
					pst3.close();
					con.commit();
				}

			}
			System.out.println(count);

		} catch (Exception ex) {

			System.out.println("Error");
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		} finally {
			try {
				rs1.close();
				pst1.close();
				con.close();
			} catch (Exception ex) {
			}
		}

		System.out
				.println(" >>>>>>>>All Update Completed SuccessFully .<<<<<<<");
	}
	
}
