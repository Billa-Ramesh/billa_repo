package com.app.trans.core;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Enumeration;
import java.util.Properties;

import com.app.trans.util.DBConnection;



/**
 * @author rameshbi
 *
 */
public class CSVFileCreater {
	File f = null;
	// Second version 1.1   1 line
	File f2=null;
	Object f1 = null;
	static Connection con = null;
	CSVWriter csv;
	String table_name = null;
	//static String mls_cd = "zh_TW";
	String table_name1 = null;

	public void writetable(String mls_cd) {

		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		try {
			Properties properties = new Properties();
			try {
				//properties.load(new FileInputStream("index_5_6.properties"));
				properties.load(new FileInputStream("import.properties"));

			} catch (IOException e) {
			}

			Enumeration x = properties.propertyNames();
			boolean success = (
					  new File("c:/"+mls_cd)).mkdir();
					  if (success) {
					  System.out.println("Directory: " 
					   + mls_cd + " created");
					  } 
			while (x.hasMoreElements()) {
				
				table_name = properties.getProperty((String) x.nextElement());

				System.out.println(table_name);
				String sql=null;
				if (table_name.length()>28){

					table_name1 = table_name.substring(0, 28);
					 sql = "select * from " + table_name1 + "_T where MLS_CD='"
					+ mls_cd + "'";
				}else{
					sql = "select * from " + table_name + "_T where MLS_CD='"
					+ mls_cd + "'";
				}
//				System.out.print("table:"+table_name1);
				con = DBConnection.getConnection();

//				String sql = "select * from " + table_name1 + "_T where MLS_CD='"
//						+ mls_cd + "'";
				System.out.println(sql);
				
				
			 String sval="c:/" +mls_cd+"/"+ table_name + ".csv";
			 System.out.println(sval);
				f = new File("c:/"+mls_cd+"/"+ table_name + ".csv");

				// Second version 1.1 2 lines
				f2 =new File("c:/"+"MASTER_COUNT_ALL_LANGUAGES.csv");
				 PrintWriter pw2 = new PrintWriter( new FileWriter(f2,true));
				 CSVWriter csv2 = new CSVWriter(pw2, false, ',', System
							.getProperty("line.separator"));
				preparedStmt = con.prepareStatement(sql);
				rs = preparedStmt.executeQuery();

				ResultSetMetaData sss = rs.getMetaData();

				int is = sss.getColumnCount();

				/*
				 * Principal Consultant for(int j=1;j<i;j++){ String
				 * cn1=ss.getColumnName(j); PrintWriter pw = new PrintWriter(
				 * new OutputStreamWriter( new BufferedOutputStream( new
				 * FileOutputStream( f,true ), 32768 ), "UTF-8" ) );
				 * //PrintWriter pw = new PrintWriter( new FileWriter(f,true));
				 * csv = new CSVWriter(pw, false, ',',
				 * System.getProperty("line.separator") ); csv.write(cn1);
				 * csv.close(); System.out.println(cn1); }
				 */
				ResultSetMetaData ss = rs.getMetaData();

				int i = ss.getColumnCount();
				//int l = table_name.length();
				//table_name.substring(0, l - 2);
				//System.out.println(table_name.substring(0, l - 2));
				PrintWriter pw = new PrintWriter(new OutputStreamWriter(
						new BufferedOutputStream(new FileOutputStream(f, true),
								32768), "UTF-8"));
				CSVWriter csv = new CSVWriter(pw, false, ',', System
						.getProperty("line.separator"));
				int count=0;
				csv2.write(mls_cd);
				csv2.write(table_name);
				StringBuilder sb=new StringBuilder();
				for (int k = 1; k < i; k++) {
					
					sb.append(ss.getColumnName(k)).append(",");;
				}
			 csv2.write(sb.toString());
			 if(i==10){


					//csv.write(table_name.substring(0, l - 2));
					csv.write(table_name);
					
					csv.writeln();
					for (int j = 1; j < i; j++) {
						csv.write(ss.getColumnName(j));
						
					}
					csv.writeln();
					
					while (rs.next()) {
						String s1 = rs.getString(1);
						String s2 = rs.getString(2);
						String s3 = rs.getString(3);
						String s4 = rs.getString(4);
						String s5 = rs.getString(5);
						String s6 = rs.getString(6);
						String s7 = rs.getString(7);
						String s8 = rs.getString(8);
						String s9 = rs.getString(9);
						String s10 = rs.getString(10);
						

						// PrintWriter pw = new PrintWriter( new
						// OutputStreamWriter( new BufferedOutputStream( new
						// FileOutputStream( f,true ), 32768 ), "UTF-8" ) );
						// PrintWriter pw = new PrintWriter( new
						// FileWriter(f,true));
						// CSVWriter csv = new CSVWriter(pw, false, ',',
						// System.getProperty("line.separator") );

						csv.write(s1);
						csv.write(s2);
						csv.write(s3);
						csv.write(s4);
						csv.write(s5);
						csv.write(s6);
						csv.write(s7);
						csv.write(s8);
						csv.write(s9);
						csv.write(s10);
						

						csv.writeln();
count=count+1;
					}

					csv.close();
				
			 }
				if (i == 4) {

					//csv.write(table_name.substring(0, l - 2));
					csv.write(table_name);
					
					csv.writeln();
					for (int j = 1; j < i; j++) {
						csv.write(ss.getColumnName(j));
						
					}
					csv.writeln();
					
					while (rs.next()) {
						String s1 = rs.getString(1);
						String s2 = rs.getString(2);
						String s3 = rs.getString(3);

						// PrintWriter pw = new PrintWriter( new
						// OutputStreamWriter( new BufferedOutputStream( new
						// FileOutputStream( f,true ), 32768 ), "UTF-8" ) );
						// PrintWriter pw = new PrintWriter( new
						// FileWriter(f,true));
						// CSVWriter csv = new CSVWriter(pw, false, ',',
						// System.getProperty("line.separator") );

						csv.write(s1);
						csv.write(s2);
						csv.write(s3);

						csv.writeln();
count=count+1;
					}

					csv.close();
				}
				if (i == 6) {

					//csv.write(table_name.substring(0, l - 2));
					csv.write(table_name);
					csv.writeln();
					for (int j = 1; j < i; j++) {
						csv.write(ss.getColumnName(j));

					}
					csv.writeln();
					while (rs.next()) {
						String s1 = rs.getString(1);
						String s2 = rs.getString(2);
						String s3 = rs.getString(3);
						String s4 = rs.getString(4);
						String s5 = rs.getString(5);

						csv.write(s1);
						csv.write(s2);
						csv.write(s3);
						csv.write(s4);
						csv.write(s5);

						csv.writeln();
						count=count+1;
					}

					csv.close();
				}
				if (i == 7) {

					
//					csv.write(table_name.substring(0, l - 2));
					csv.write(table_name);
					csv.writeln();
					for (int j = 1; j < i; j++) {
						csv.write(ss.getColumnName(j));

					}
					csv.writeln();
					while (rs.next()) {
						String s1 = rs.getString(1);
						String s2 = rs.getString(2);
						String s3 = rs.getString(3);
						String s4 = rs.getString(4);
						String s5 = rs.getString(5);
						String s6 = rs.getString(6);

						csv.write(s1);
						csv.write(s2);
						csv.write(s3);
						csv.write(s4);
						csv.write(s5);
						csv.write(s6);

						csv.writeln();
						count=count+1;
					}

					csv.close();
				}
				if (i == 8) {

//					csv.write(table_name.substring(0, l - 2));
					csv.write(table_name);
					csv.writeln();
					for (int j = 1; j < i; j++) {
						csv.write(ss.getColumnName(j));

					}
					csv.writeln();
					while (rs.next()) {
						String s1 = rs.getString(1);
						String s2 = rs.getString(2);
						String s3 = rs.getString(3);
						String s4 = rs.getString(4);
						String s5 = rs.getString(5);
						String s6 = rs.getString(6);
						String s7 = rs.getString(7);

						csv.write(s1);
						csv.write(s2);
						csv.write(s3);
						csv.write(s4);
						csv.write(s5);
						csv.write(s6);
						csv.write(s7);

						csv.writeln();
						count=count+1;
					}

					csv.close();
				}
				if (i == 3) {

//					csv.write(table_name.substring(0, l - 2));
					csv.write(table_name);
					csv.writeln();
					for (int j = 1; j < i; j++) {
						csv.write(ss.getColumnName(j));

					}
					csv.writeln();
					while (rs.next()) {
						String s1 = rs.getString(1);
						String s2 = rs.getString(2);

						csv.write(s1);
						csv.write(s2);

						csv.writeln();
						count=count+1;
					}

					csv.close();
				}
				if (i == 5) {

//					csv.write(table_name.substring(0, l - 2));
					csv.write(table_name);
					csv.writeln();
					for (int j = 1; j < i; j++) {
						csv.write(ss.getColumnName(j));

					}
					csv.writeln();
					while (rs.next()) {
						String s1 = rs.getString(1);
						String s2 = rs.getString(2);
						String s3 = rs.getString(3);
						String s4 = rs.getString(4);

						csv.write(s1);
						csv.write(s2);
						csv.write(s3);
						csv.write(s4);

						csv.writeln();
						count=count+1;
					}

					csv.close();
				}
				/**
				 * while(rs.next()){
				 * 
				 * 
				 * 
				 * 
				 * 
				 * if(i==8){ String s1= rs.getString(1); String s2=
				 * rs.getString(2); String s3= rs.getString(3); String s4=
				 * rs.getString(4); String s5= rs.getString(5); String s6=
				 * rs.getString(6); String s7= rs.getString(7); String s8=
				 * rs.getString(8);
				 * 
				 * 
				 * csv.write(s1); csv.write(s2); csv.write(s3); csv.write(s4);
				 * csv.write(s5); csv.write(s6); csv.write(s7); csv.write(s8);
				 * csv.writeln(); csv.close();
				 * 
				 * 
				 * }else if(i==5){ String s1= rs.getString(1); String s2=
				 * rs.getString(2); String s3= rs.getString(3); String s4=
				 * rs.getString(4);
				 * 
				 * // PrintWriter pw = new PrintWriter( new OutputStreamWriter(
				 * new BufferedOutputStream( new FileOutputStream( f,true ),
				 * 32768 ), "UTF-8" ) ); //PrintWriter pw = new PrintWriter( new
				 * FileWriter(f,true)); // CSVWriter csv = new CSVWriter(pw,
				 * false, ',', System.getProperty("line.separator") );
				 * 
				 * 
				 * 
				 * csv.write(s1); csv.write(s2); csv.write(s3); csv.write(s4);
				 * 
				 * csv.writeln(); csv.close();
				 * 
				 * }else if(i==3){ String s1= rs.getString(1); String s2=
				 * rs.getString(2); String s3= rs.getString(3);
				 * 
				 * 
				 * // PrintWriter pw = new PrintWriter( new OutputStreamWriter(
				 * new BufferedOutputStream( new FileOutputStream( f,true ),
				 * 32768 ), "UTF-8" ) ); //PrintWriter pw = new PrintWriter( new
				 * FileWriter(f,true)); // CSVWriter csv = new CSVWriter(pw,
				 * false, ',', System.getProperty("line.separator") );
				 * 
				 * 
				 * csv.write(s1); csv.write(s2); csv.write(s3);
				 * 
				 * 
				 * csv.writeln(); csv.close();
				 * 
				 * }else if(i==5){ String s1= rs.getString(1); String s2=
				 * rs.getString(2); String s3= rs.getString(3); String s4=
				 * rs.getString(4); String s5= rs.getString(5);
				 * 
				 * // PrintWriter pw = new PrintWriter( new OutputStreamWriter(
				 * new BufferedOutputStream( new FileOutputStream( f,true ),
				 * 32768 ), "UTF-8" ) ); //PrintWriter pw = new PrintWriter( new
				 * FileWriter(f,true)); // CSVWriter csv = new CSVWriter(pw,
				 * false, ',', System.getProperty("line.separator") );
				 * 
				 * 
				 * 
				 * csv.write(s1); csv.write(s2); csv.write(s3); csv.write(s4);
				 * csv.write(s5); csv.writeln(); csv.close();
				 * 
				 * }
				 * 
				 * 
				 * 
				 * 
				 * }
				 **/
        csv2.write(""+count);
        csv2.writeln();
        csv2.close();
			}
		} catch (Exception e) {

		}
       System.out.println(" >>>>>>>>CSV files creation  Completed SuccessFully .<<<<<<<");
	}
}
