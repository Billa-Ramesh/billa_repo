package com.app.trans.core;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import com.app.trans.core.CSVWriter;
import com.app.trans.util.ConstantsAll;
import com.app.trans.util.DBConnection;


public class ExportCSV {
	CSVWriter csv;
	static Connection con;

	public   void ExportCsvMethod(String mls, String path) {
		PreparedStatement preparedStmt = null,selectStm;
		ResultSet rs = null,rsSelect=null;
		try {
			con = DBConnection.getConnection();
			
			selectStm=con.prepareStatement("select table_name,trans_fields from "+ConstantsAll.META_DATA_TABLE);
			rsSelect = selectStm.executeQuery();
			while(rsSelect.next()){
				
				
				String tablename = rsSelect.getString("table_name");
				String keyField = rsSelect.getString("trans_fields");
				
				String sql = "select "+keyField+" from " + tablename+"_t where mls_cd='"+mls+"'";
									
				System.out.println(sql);

				
				String DIF = path+"/"+mls;

				boolean success = (new File(DIF)).mkdir();
				if (success) {
					 System.out.println("Directory: " + DIF + " created");
				}

			

				preparedStmt = con.prepareStatement(sql);
				rs = preparedStmt.executeQuery();

				ResultSetMetaData ss = rs.getMetaData();

				int i = ss.getColumnCount();

				File f2 = new File(DIF+"/"+"COUNT.csv");

				PrintWriter pw2 = new PrintWriter(new FileWriter(f2, true));
				CSVWriter csv2 = new CSVWriter(pw2, false, ',', System
						.getProperty("line.separator"));

				int count = 0;
				csv2.write(DIF);
				csv2.write(tablename);
				StringBuilder sb = new StringBuilder();
				for (int k = 1; k <= i; k++) {

					sb.append(ss.getColumnName(k)).append(",");
					;
				}
				csv2.write(sb.toString());
				if (rs.next()) {
					File f = new File(DIF + "/" + tablename + ".csv");
					PrintWriter pw = new PrintWriter(new OutputStreamWriter(
							new BufferedOutputStream(new FileOutputStream(f,
									true), 32768), "UTF-8"));
					CSVWriter csv = new CSVWriter(pw, false, ',', System
							.getProperty("line.separator"));
					csv.write(tablename);
					csv.writeln();
					for (int j = 1; j <= i; j++) {
						csv.write(ss.getColumnName(j));
					}
					csv.writeln();

					do {
						for (int j = 1; j <= i; j++) {
							// System.out.println(rs.getString(j));
							csv.write(rs.getString(j));
						}
						csv.writeln();
						count = count + 1;

					} while (rs.next());

					

					csv.close();
				}
				csv2.write("" + count);
				csv2.writeln();
				csv2.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				rs.close();
				preparedStmt.close();

				con.close();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}

		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
}
