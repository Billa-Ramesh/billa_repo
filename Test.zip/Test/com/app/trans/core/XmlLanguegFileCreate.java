package com.app.trans.core;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.app.trans.util.ConstantsAll;

/**
 * @author rameshbi
 *
 */
public class XmlLanguegFileCreate {
	static Connection con = com.app.trans.util.DBConnection.getConnection();
	PreparedStatement del_sql = null;

	public void method(String mlscode, String filename,String tablename) {
		try {
			StringBuilder langFilename =new StringBuilder() ;
			     langFilename.append(filename).append(mlscode);
			DocumentBuilderFactory odbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder odb = odbf.newDocumentBuilder();
			Document odoc = odb.parse(filename);
			odoc.getDocumentElement().normalize();

			System.out.println("Root element of the doc is "
					+ odoc.getDocumentElement().getNodeName());
			NodeList LOP = odoc.getElementsByTagName("WebMessageTable");
			int totalPersons = LOP.getLength();
			// System.out.println("Total no of tables : " + totalPersons);
			for (int s = 0; s < LOP.getLength(); s++) {

				Node FPN = LOP.item(s);

				if (FPN.getNodeType() == Node.ELEMENT_NODE) {
					Element firstPElement = (Element) FPN;
					NamedNodeMap x = firstPElement.getAttributes();
			               
	                  Node n = x.getNamedItem("description");
	                  
	                  
	                 Node l= x.getNamedItem("path");
	                 String pathvalue = l.getTextContent();
	             // System.out.println( pathvalue);
	                  if(n!=null && pathvalue!=null){
	                	  
	                	  n.setTextContent(methodGetDesc(l.getTextContent(), tablename,mlscode));
	                     //      System.out.println(l.getTextContent()+":"+n.getTextContent());
	                  }      		  
             		
					
					NodeList childNodes = firstPElement
							.getElementsByTagName("WebMessage");
					int childNodesLength = childNodes.getLength();

					for (int c = 0; c < childNodesLength; c++) {

						// System.out.println("on row");
						Node childNode = childNodes.item(c);

						if (childNode.getNodeType() == Node.ELEMENT_NODE) {

						

							Element webMessageElement = (Element) childNodes
									.item(c);
					//		System.out.println(webMessageElement.getAttribute("name"));
					String	keytext=webMessageElement.getAttribute("name");
					
							NodeList childNodess = webMessageElement
									.getChildNodes();
							for (int ch = 0; ch < childNodess.getLength(); ch++) {

								Node childNodesss = childNodess.item(ch);
								if (childNodesss.getNodeType() == Node.ELEMENT_NODE) {

									Element childNodesssElement = (Element) childNodess
											.item(ch);
									childNodesssElement.getNodeName();
									String source = childNodesssElement
											.getNodeName();
						//		System.out.println("source node"+source);
									String target = childNodesssElement
											.getTextContent();

								//	System.out.println(target);
                                   //System.out.println("tehe"+   methodGet(keytext));
                                   
                                   if (methodGet(keytext, tablename,mlscode).contains("###"))
                                   {
                                	   FileOutputStream fileout=new FileOutputStream("error.txt",true);
                                	   fileout.write("update <table_name> set text='".getBytes());
                                	   fileout.write(childNodesssElement.getTextContent().getBytes());
                                	   
                                	   String one="' \n where name='";
                                	   fileout.write(one.getBytes());
                                	                   	   fileout.write( webMessageElement.getAttribute("name").getBytes());
                                	      fileout.write("';\n".getBytes());             	  
                                	   
                                	   System.out.println(childNodesssElement.getTextContent());
                                   }
                                   if (! methodGet(keytext,tablename,mlscode).contains("###")&&source.equals(childNodesssElement.getNodeName())&& webMessageElement.getAttribute("name").equals(keytext)) {
                                //	   System.out.println( "in if ");
                                	   childNodesssElement.setTextContent(methodGet(keytext,tablename,mlscode));
                                	   
                                	   
                           		   }

                                
									// System.out.println(":"+value+":"
									// +childNodesssElement.getNodeName()+":"+childNodesssElement.getTextContent());

								}

							}

						}

					}

				}
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				DOMSource source = new DOMSource(odoc);
				StreamResult result = new StreamResult(new File(langFilename.toString()));
				transformer.transform(source, result);
		 
				//System.out.println("Done");

			}
			System.out.println("Success Fully Completed");
		} catch (SAXParseException err) {
			System.out.println(err.getMessage());
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		System.out.println("Success Fully Completed");
	}

	private synchronized  static String methodGet(String textvalue,String tablename,String mlscode ) {
		PreparedStatement ps;
		ResultSet rs;
		String text = null;
		try {
			ps = con.prepareStatement("Select text from "+tablename+" where mls_cd='"+mlscode+"'  AND name like ?");
			ps.setString(1,textvalue);
			 rs = ps.executeQuery();
		
					while (rs.next()) {
				//System.out.println("Within while");
				text = rs.getString(1);
		//	System.out.println(key);
			} 
					 rs.close();
					ps.close();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return text;
		
	}

	private synchronized  static String methodGetDesc(String path,String tablename ,String mlscode) {
		
		PreparedStatement ps;
		ResultSet rs;
		String desc = null;
		try {
			ps = con.prepareStatement("Select description from "+tablename+" where mls_cd='"+mlscode+"'  AND name like ?");
			ps.setString(1,path);
			 rs = ps.executeQuery();
			int count=1;
					while (rs.next()) {
				//System.out.println("Within while");
				desc = rs.getString(1);
		//	System.out.println(key);
			} 
					 rs.close();
					ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return desc;
		
		
		
	}
}
