package com.app.trans.core;
import javax.swing.*;

import com.app.trans.update.FinalPanel;

import java.awt.*;
import java.awt.event.*;
 
/**
 * @author rameshbi
 *
 */
public class LoginPanel extends JFrame implements ActionListener
{
 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
JButton SUBMIT;
 JPanel panel;
 JLabel label1,label2;
 final JTextField  text1,text2;
private JFrame up;
private Center center;
 public LoginPanel()
  {
  label1 = new JLabel();
  label1.setText("Username:");
  text1 = new JTextField();

  label2 = new JLabel();
  label2.setText("Password:");
  text2 = new JPasswordField();
 
  SUBMIT=new JButton("SUBMIT");
  
  panel=new JPanel(new GridLayout(3,1));
  panel.add(label1);
  panel.add(text1);
  panel.add(label2);
  panel.add(text2);
  panel.add(SUBMIT);
  add(panel,BorderLayout.CENTER);
  SUBMIT.addActionListener(this);
  setTitle("LOGIN FORM");
  }
 public void actionPerformed(ActionEvent ae)
  {
  String value1=text1.getText();
  String value2=text2.getText();
  if (value1.equals("admin") && value2.equals("admin")) {
	  FinalPanel page=new FinalPanel();
  page.setVisible(true);
  center = new Center(page,600,400);
  page.setVisible(true);
  page.setResizable(false);
  }
  else{
  System.out.println("enter the valid username and password");
  JOptionPane.showMessageDialog(this,"Incorrect login or password",
  "Error",JOptionPane.ERROR_MESSAGE);
  }
}

 }