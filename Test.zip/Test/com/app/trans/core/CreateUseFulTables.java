package com.app.trans.core;


import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JOptionPane;

import com.app.trans.util.ConstantsAll;
import com.app.trans.util.DBConnection;

/**
 * @author rameshbi
 *
 */
public class CreateUseFulTables {

	
	
	public  String tablescreate(){
		 Connection con=null;
		Map<String, String> map = new HashMap<String, String>();

		map.put("meta", ConstantsAll.META_DATA_TABLE);
		map.put("master", ConstantsAll.MASTER_TABLE);
		map.put("dupe", ConstantsAll.DUPLICATE_TABLE);
		map.put("uniq", ConstantsAll.FINAL_TABLE);
		DatabaseMetaData dom;
		Iterator<Entry<String, String>> iterator = map.entrySet().iterator();
         StringBuilder tableBuffer = null;
         int response;
		while (iterator.hasNext()) {

			Entry<String, String> table_name = iterator.next();

			try {
				tableBuffer=new StringBuilder();
				con=DBConnection.getConnection();
				dom = con.getMetaData();
 
				ResultSet result = dom.getTables(null, null, table_name
						.getValue(), null);
				if (!result.next()) {

					Statement stm = con.createStatement();

					if (table_name.getValue() == ConstantsAll.META_DATA_TABLE) {
						
						
						
						
						response = JOptionPane.showConfirmDialog(null, "This will create table "+table_name.getValue()
								 +" \n If table is not  present.\nDo you want to continue?", "Confirm",
							        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
						
						
							    if (response == JOptionPane.NO_OPTION) {
							     // System.out.println("No button clicked");
							    } else if (response == JOptionPane.YES_OPTION) {
						
						
						boolean tableStatus1 = stm.execute("CREATE TABLE "
								+ table_name.getValue()
								+ "(TABLE_NAME VARCHAR2(50),"
								+ "KEY_FIELD VARCHAR2(50),"
								+ "TRANSLATABLE_FIELD1 VARCHAR2(50),"
								+ "TRANSLATABLE_FIELD2 VARCHAR2(50),"
								+ "VERSION_NUM VARCHAR2(5),"
								+ "COMMENTS VARCHAR2(15),"
								+ "NAME_FLAG VARCHAR2(20),"
								+ "DESC_FLAG VARCHAR2(20),"
								+ "TRANS_FIELDS VARCHAR2(500))");
						
						if (!tableStatus1) {
							
							tableBuffer.append(table_name.getValue());
							
						}
							    } else if (response == JOptionPane.CLOSED_OPTION) {
							        System.out.println("JOptionPane closed");
							      }
						
					} else {
						
						response = JOptionPane.showConfirmDialog(null, "This will create table "+table_name.getValue()
								 +"If table is not  present.\nDo you want to continue?", "Confirm",
							        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
						
						
							    if (response == JOptionPane.NO_OPTION) {
							     // System.out.println("No button clicked");
							    } else if (response == JOptionPane.YES_OPTION) {
						boolean tableStatus1 = stm
								.execute("CREATE TABLE "
										+ table_name.getValue()
										+ "(	MESSAGE_KEY VARCHAR2(1000),"
										+ "MESSAGE_TEXT VARCHAR2(1000),TABLE_NAME VARCHAR2(1000 BYTE), COMMENTS VARCHAR2(500 BYTE),FLAG VARCHAR2(10))");

						if (!tableStatus1) {
						
							tableBuffer.append("\n").append(table_name.getValue());
							System.out.println(table_name.getValue());
						}
							    } else if (response == JOptionPane.CLOSED_OPTION) {
							        System.out.println("JOptionPane closed");
							      }
						
					}

				}
			} catch (SQLException e) {
				e.getMessage();
			}

		}
		
	//	System.out.println("dfdf");
		System.out.println(tableBuffer.toString());
		return tableBuffer.toString();
		

	}
	
	public static void mlstable(String mlstablemaster){
		
		DatabaseMetaData dom;
		ResultSet result = null;
		 Connection con = null;
			int response;
			
	
			response = JOptionPane.showConfirmDialog(null, "This will create table "+mlstablemaster
					 +" \n If table is not  present.\nDo you want to continue?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
			
			
				    if (response == JOptionPane.NO_OPTION) {
				     // System.out.println("No button clicked");
				    } else if (response == JOptionPane.YES_OPTION) {
				try {
					con=DBConnection.getConnection();
					
					
					dom = con.getMetaData();
					result = dom.getTables(null, null, mlstablemaster, null);
					if (!result.next()) {

						Statement stm = con.createStatement();
						 stm.execute("CREATE TABLE "+ mlstablemaster+"(MESSAGE_KEY VARCHAR2(300)," +
						 		"SOURCE_TEXT VARCHAR2(2000),TARGET_TEXT VARCHAR2(1000),"+
											"DROPNUM VARCHAR2(10))");
					}
					
					
					
				} catch (SQLException e) {
					
					e.printStackTrace();
				}finally{
					try {
						result.close();
						con.close();
					} catch (SQLException e) {
					
						e.printStackTrace();
					}
				
				}
				    } else if (response == JOptionPane.CLOSED_OPTION) {
				        System.out.println("JOptionPane closed");
				      }
				
				
	}
	
	
}
