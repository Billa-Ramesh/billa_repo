package com.app.trans.core;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * @author rameshbi
 *
 */
public class Lhsmenu {
	static Connection con = com.app.trans.util.DBConnection.getConnection();

	
	
	public  void lhsMenu(String mlscode, String xmlfilename, String xmltablename, boolean status ) {
		try {
			DocumentBuilderFactory odbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder odb = odbf.newDocumentBuilder();
			Document odoc = odb.parse("LHSMenuen_US.xml");
			odoc.getDocumentElement().normalize();

			System.out.println("Root element of the doc is "
					+ odoc.getDocumentElement().getNodeName());
			NodeList LOP = odoc.getElementsByTagName("MENU");
			int totalPersons = LOP.getLength();
			 System.out.println("Total no of tables : " + totalPersons);
			for (int s = 0; s < LOP.getLength(); s++) {

				Node FPN = LOP.item(s);

				String lhsmenuFilename = null;
				if (FPN.getNodeType() == Node.ELEMENT_NODE) {
					Element firstPElement = (Element) FPN;
			//		NamedNodeMap x = firstPElement.getAttributes();
			               
	                 
					
					NodeList childNodes = firstPElement
							.getElementsByTagName("MENUITEM");
					int childNodesLength = childNodes.getLength();

					for (int c = 0; c < childNodesLength; c++) {

						
						Node childNode = childNodes.item(c);
					
				
						if (childNode.getNodeType() == Node.ELEMENT_NODE) {

							
							NamedNodeMap nodevalues = childNode.getAttributes();
							
							Node id = nodevalues.getNamedItem("ID");
							Node link = nodevalues.getNamedItem("LINK_TEXT");
							
							
						  
						 
							Node tooltip = nodevalues.getNamedItem("TOOLTIP_TEXT");
							
							  System.out.println("link  : "+id.getTextContent()+"=="+link.getTextContent()+"==="+tooltip.getTextContent());
							lhsmenuFilename="LHSMenu";
							StringBuffer linkID=new StringBuffer();
							linkID.append(lhsmenuFilename).append("_").append("LINK_TEXT").append("_").append(id.getTextContent());
							
							if(!status){
							String transLink=methodGet(linkID.toString(),xmltablename,mlscode);
							  
								link.setTextContent(transLink);
							}  
				                 
							
							
							
							StringBuffer tooltipID=new StringBuffer();
							tooltipID.append(lhsmenuFilename).append("_").append("TOOLTIP_TEXT").append("_").append(id.getTextContent());  
							if(!status){
							String transTooltip=methodGet(tooltipID.toString(),xmltablename,mlscode);
							tooltip.setTextContent(transTooltip);
							System.out.println(linkID.toString());
							}
							
							    if(status){
							    	methodInsert(xmltablename,linkID.toString(), link.getTextContent().toString() );
							    	methodInsert(xmltablename,tooltipID.toString(), tooltip.getTextContent().toString());
							    }
							
						/*

							Element webMessageElement = (Element) childNodes
									.item(c);
							
							
							//System.out.println(childNode.getNodeName());
							
					//		System.out.println(webMessageElement.getAttribute("name"));
					String	ID=webMessageElement.getAttribute("ID");
					String	linkText=webMessageElement.getAttribute("LINK_TEXT");
					
					String lhsmenuFilename="LHSMenu";
					
					StringBuffer linkID=new StringBuffer();
					linkID.append(lhsmenuFilename).append("_").append("LINK_TEXT").append("_").append(ID);
				//	System.out.println(methodGet(linkID.toString()));
					
					
					
					 
					
					StringBuffer tooltipID=new StringBuffer();
					tooltipID.append(lhsmenuFilename).append("~").append("TOOLTIP_TEXT").append("~").append(ID);
					String	tooltipText=webMessageElement.getAttribute("TOOLTIP_TEXT");
					System.out.println(linkID.toString()+"\n"+tooltipID.toString()+"\n"+tooltipText+";"+linkText);
							
					NamedNodeMap nodevalues = childNode.getAttributes();
					
					//nodevalues.setNamedItem(arg0)
					
					System.out.println(":"+nodevalues.getNamedItem("ID").getTextContent()+nodevalues.getNamedItem("LINK_TEXT")+nodevalues.getNamedItem("TOOLTIP_TEXT"));
					*/
							
					

						}

					}

				}
				if(!status){
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				DOMSource source = new DOMSource(odoc);
				StreamResult result = new StreamResult(new File(lhsmenuFilename+mlscode+".xml"));
				transformer.transform(source, result);
				}
				//System.out.println("Done");

			}
			System.out.println("Success Fully Completed");
		} catch (SAXParseException err) {
			System.out.println(err.getMessage());
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		System.out.println("Success Fully Completed");
	}

	private synchronized  static String methodGet(String link, String xmltablename, String mlscode) {
		PreparedStatement ps;
		ResultSet rs;
		String text = null;
		try {
			System.out.println("Select message_text from "+xmltablename+"_t where mls_cd='"+mlscode+"'  AND MESSAGE_KEY  like '"+link+"'?");
			ps = con.prepareStatement("Select message_text from "+xmltablename+"_t where mls_cd='"+mlscode+"'  AND MESSAGE_KEY  like ?");
			ps.setString(1,link);
			 rs = ps.executeQuery();
			int count=1;
					while (rs.next()) {
				//System.out.println("Within while");
				text = rs.getString(1);
		//	System.out.println(key);
			} 
					 rs.close();
					ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return text;
		
	}
	private synchronized  static void methodInsert(String tablename ,String id, String text) {

		
		PreparedStatement ps;
		ResultSet rs;

		try {
			System.out.println("tate : ="+text);
			ps = con.prepareStatement("insert into "+tablename+" values(?,?)");
			ps.setString(1, id);
			ps.setString(2, text);
			ps.executeUpdate();

			ps.close();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	
	}
	/*private synchronized  static String methodGetDesc(String path) {
		
		PreparedStatement ps;
		ResultSet rs;
		String desc = null;
		try {
			ps = con.prepareStatement("Select description from or_sharedcaptions_ol_T where mls_cd='heb'  AND path like ?");
			ps.setString(1,path);
			 rs = ps.executeQuery();
			int count=1;
					while (rs.next()) {
				//System.out.println("Within while");
				desc = rs.getString(1);
		//	System.out.println(key);
			} 
					 rs.close();
					ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return desc;
		
		// TODO Auto-generated method stub
		
	}*/
}
