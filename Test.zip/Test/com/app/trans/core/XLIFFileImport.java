package com.app.trans.core;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.JOptionPane;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Text;
import org.jdom.input.SAXBuilder;

import com.app.trans.util.ConstantsAll;
import com.app.trans.util.DBConnection;




/**
 * @author rameshbi
 *
 */
public class XLIFFileImport {
	static Connection con = null;
    private static String xliffFile;
    private static String mlsCode;
    private static String encoding;
   
    StringBuilder table=new StringBuilder();
	
    
public  Vector<String> run(Hashtable<String, String> params) {
		Vector<String> result = new Vector<String>();
 		xliffFile = params.get("xliff");
		setEncoding(params.get("encoding"));
		setMlsCode(params.get("mlsCode"));
		//System.out.println("Converting " + xliffFile + " to Java Properties");
		//System.out.println("Encoding:  " + encoding);
		System.out.println("Loading...  "+xliffFile+" onto Database.");
		try {
			loadSegments();
		
		} catch (Exception e) {
			result.add(0, "1");
			result.add(1, e.getMessage());
			return result;
		}
		result.add(0, "Successfully Comepleted.");
		return result;
    }
private  String extractText(Element target) {
		String result = "";
		List<?> content = target.getContent();
		Iterator<?> i = content.iterator();
		while (i.hasNext()) {
			Object o =  i.next();
			if ( o instanceof Element) {
				Element e = (Element) o;
				result = result + extractText(e);
			}
			if (o instanceof Text) {
                Text t = (Text) o;
        		result = result + t.getText();    			    
            }
		}
		return result;
	}
private  void loadSegments() throws JDOMException, IOException {
        SAXBuilder builder = new SAXBuilder();
        Document doc = builder.build(xliffFile);
        Element root = doc.getRootElement();
        Element body = root.getChild("file").getChild("body");
        List<?> units = body.getChildren("trans-unit");
        Iterator<?> i = units.iterator();
        while (i.hasNext()) {
            Element unit = (Element) i.next();
             readElement(unit);
            }
    }
private  void readElement(Element unit)throws IOException{
		String keyValue=unit.getAttributeValue("id");
		//writeString(keyValue+EQUAL);
		Element target = unit.getChild("target");
		Element source = unit.getChild("source");
		Element drop_num = unit.getChild("drop_num");
		
		if (target!=null && drop_num!=null){
			//writeString(extractText(target));
			insertDB(keyValue,extractText(source),extractText(target),extractText(drop_num));
		}else{
			//writeString(extractText(source));
			//insertDB(keyValue,extractText(source),extractText(source),extractText(drop_num));
		}
		//insertDB(extractText(source),keyValue);
	}
private  void insertDB(String key,String value ,String value2,String drop_num) {
 	try {

			con = DBConnection.getConnection();

		
			String sql = "insert into " + table
					+ " ( MESSAGE_KEY,SOURCE_TEXT,TARGET_TEXT,DROPNUM)"
					+ "values(?,?,?,?)";
			System.out.println(sql);

			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setEscapeProcessing(true);
			preparedStmt.setString(1, key);
			preparedStmt.setString(2, value);
			preparedStmt.setString(3, value2);
			preparedStmt.setString(4, ConstantsAll.DROP_VERSION);

			preparedStmt.execute();
			con.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "h",
					JOptionPane.ERROR_MESSAGE);

			System.err.println("Exception: " + e.getMessage());
		}
	}

	public void insert2DB(String argss, String encode, String mlsCode) {
		
		


		
		table.append(ConstantsAll.APP_NAME).append("_").append(mlsCode).append(
		"_uniq");

		
		System.out.println(table.toString());
        CreateUseFulTables.mlstable(table.toString());

				File file = new File(argss);
				File files[];
				files = file.listFiles();
				Arrays.sort(files);
				for (int i = 0, n = files.length; i < n; i++) {

					String tmp = files[i].toString();
					Hashtable<String, String> table = new Hashtable<String, String>();
					table.put("xliff", tmp);
					table.put("encoding", encode);
					table.put("mlsCode", mlsCode);
					System.out.println("Path  :" + tmp + "encoding :" + encode
							+ "mlsCode  :" + mlsCode);
					System.out.println(run(table));
				}
				System.out.println("Ended loading");

	


	}
	public static void setMlsCode(String mlsCode) {
		XLIFFileImport.mlsCode = mlsCode;
	}
	public static String getMlsCode() {
		return mlsCode;
	}
	public static void setEncoding(String encoding) {
		XLIFFileImport.encoding = encoding;
	}
	public static String getEncoding() {
		return encoding;
	}
}
