package com.app.trans.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.app.trans.core.LangugeTbCreate;
import com.app.trans.core.LangugeTablesProcedurs;

import com.app.trans.core.CSVFileCreater;
import com.app.trans.core.Center;
import com.app.trans.core.CreateUseFulTables;
import com.app.trans.core.ExportCSV;
import com.app.trans.core.FinalTableCreater;
import com.app.trans.core.Lhsmenu;
import com.app.trans.core.XLIFFFileExport;
import com.app.trans.core.XLIFFileImport;
import com.app.trans.core.XmlWriteDatabase;
import com.app.trans.core.XmlLanguegFileCreate;
import com.app.trans.update.InfoPanel;
import com.app.trans.update.FinalPanel;;

/**
 * @author rameshbi
 *
 */
public class DynamiComponets extends JPanel {

	public DynamiComponets(JComboBox filterType, JTextArea jtextArea) {
		this.filterType = filterType;
		this.jtextArea = jtextArea;

		// setPreferredSize(new Dimension(300, 0));
		// setBorder(BorderFactory.createLineBorder (Color.blue, 2));

	}

	ActionListener filePath = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			fc = new JFileChooser();
			fc.setCurrentDirectory(new java.io.File("."));
			fc.setDialogTitle("Select Direcotry");
			fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			//
			// disable the "All files" option.
			//
			fc.setAcceptAllFileFilterUsed(false);
			//    
			if (fc.showOpenDialog(selectFilePath) == JFileChooser.APPROVE_OPTION) {

				File path = fc.getSelectedFile();
				try {
					filepath = path.getCanonicalPath();
					if(dircreatxlif!=null )
					{
						
						dircreatxlif.setText(filepath);
					}
					if(directory!=null){
						directory.setText(filepath);
					}
					if(csvDirectory!=null){
						csvDirectory.setText(filepath);
					}
				
				} catch (IOException e1) {

					e1.printStackTrace();
				}
				System.out.println( filepath);
				jtextArea.setText(filepath);
			//	System.out.println(fc.getSelectedFile());
			} else {
				System.out.println("No Selection ");
			}
		}

	};
	ActionListener action = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JButton button = (JButton) e.getSource();
			System.out.println("You select button: " + button.getText());
		}
	};
	
	
	ActionListener createtablesAction = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			CreateUseFulTables createTable=new CreateUseFulTables();
			createTable.tablescreate();
		}
	};
	
	ActionListener masterAndFinal = new ActionListener() {
		

		public void actionPerformed(ActionEvent actionEvent) {

			String command = group.getSelection().getActionCommand();

			System.out.println("selected----------> " + command + " next "
					+ filterType.getSelectedItem());
			FinalTableCreater finalCreater = new FinalTableCreater();
		
			if (command.equals("INSERT_MASTER")) {
				JPanel p1 = null;
				finalCreater.insert2Table(p1);
			} else if (command.equals("UPDATE_PM_CHANGES")) {
				JPanel p1 = null;
				finalCreater.updateMessages(p1);
			} else if (command.equals("INSERT_DUPLICATE")) {
				JPanel p1 = null;
				finalCreater.insertDupliacates(p1);
			} else if (command.equals("DELETE_DUPLICATE")) {
				JPanel p1 = null;
				finalCreater.deleteDuplicates(p1);
			} else if (command.equals("INSERT_FINAL")) {
				JPanel p1 = null;
				finalCreater.insert2Final(p1);
			}

			// checkLog l = new checkLog(jtextArea);
			// l.loop();

		}
	};
	ActionListener createXLIFF = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String PattAppender = "/";
			XLIFFFileExport db2xliff = new XLIFFFileExport();
			db2xliff.method(filepath + PattAppender, jtextArea);
			/*
			 * com.app.trans.core.XmlInsert x=new XmlInsert(); x.method();
			 */
			// jtextArea.append("\n createXLIFF");
			JButton button = (JButton) e.getSource();
			System.out.println("You select button: " + button.getText());
		}
	};
	ActionListener xliff2DB = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			if (filepath != null) {
				String encode = "en";
				String PattAppender = "/";
				
				XLIFFileImport xliff2DB = new XLIFFileImport();
				System.out.println("xliff2Db"
						+ (String) filterType.getSelectedItem());
				xliff2DB.insert2DB(filepath + PattAppender, encode,
						(String) filterType.getSelectedItem());

			}

		}
	};
	ActionListener insertAll = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			LangugeTablesProcedurs run = new LangugeTablesProcedurs();
			try {
				int response=  JOptionPane.showConfirmDialog(null, "Do you want to continue?","Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		    	   if (response == JOptionPane.NO_OPTION) {
		    		      System.out.println("No button clicked");
		    		    } else if (response == JOptionPane.YES_OPTION) {
		    		    	System.out.println((String) filterType.getSelectedItem());
				run.insertLocaleType1((String) filterType.getSelectedItem());
		    		    } else if (response == JOptionPane.CLOSED_OPTION) {
		      		      System.out.println("JOptionPane closed");
		      		    }
			} catch (SQLException e1) {

				e1.printStackTrace();
			}

		}
	};
	ActionListener lngMaster = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			LangugeTablesProcedurs run = new LangugeTablesProcedurs();
			try {
				int response=  JOptionPane.showConfirmDialog(null, "Do you want to continue?","Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		    	   if (response == JOptionPane.NO_OPTION) {
		    		      System.out.println("No button clicked");
		    		    } else if (response == JOptionPane.YES_OPTION) {
				run.createLangugeMaster((String) filterType.getSelectedItem());
				
			} else if (response == JOptionPane.CLOSED_OPTION) {
  		      System.out.println("JOptionPane closed");
  		    }
			} catch (SQLException e1) {

				e1.printStackTrace();
			}

		}
	};
	ActionListener xmlUp = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			XmlLanguegFileCreate xmlup = new XmlLanguegFileCreate();
			int response=  JOptionPane.showConfirmDialog(null, "Do you want to continue?","Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	    	   if (response == JOptionPane.NO_OPTION) {
	    		      System.out.println("No button clicked");
	    		    } else if (response == JOptionPane.YES_OPTION) {
			xmlup.method((String) filterType.getSelectedItem(), xmlfiled
					.getText(),xmlfiledTable.getText());
	    		    } else if (response == JOptionPane.CLOSED_OPTION) {
	    	  		      System.out.println("JOptionPane closed");
	    	  		    }
		}
	};
	ActionListener xmlIn = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			XmlWriteDatabase xmlin = new XmlWriteDatabase();
           //  xmlfiledTable.setEnabled(false);
		
			int response=  JOptionPane.showConfirmDialog(null, "Do you want to continue?","Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	    	   if (response == JOptionPane.NO_OPTION) {
	    		      System.out.println("No button clicked");
	    		    } else if (response == JOptionPane.YES_OPTION) {
				xmlin.method(xmlfiled.getText(),xmlfiledTable.getText());
		} else if (response == JOptionPane.CLOSED_OPTION) {
		      System.out.println("JOptionPane closed");
		    }
		}
	};
	
	ActionListener xmllhsUp = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			Lhsmenu xmlLhsup = new Lhsmenu();
			int response=  JOptionPane.showConfirmDialog(null, "Do you want to continue?","Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	    	   if (response == JOptionPane.NO_OPTION) {
	    		      System.out.println("No button clicked");
	    		    } else if (response == JOptionPane.YES_OPTION) {
			xmlLhsup.lhsMenu((String) filterType.getSelectedItem(), xmlLhsfiled
					.getText(),xmlLhsfiledTable.getText(),false);
	    		    } else if (response == JOptionPane.CLOSED_OPTION) {
	    			      System.out.println("JOptionPane closed");
	    			    }
		}
	};
	ActionListener xmlLhsIn = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			Lhsmenu xmlLhsin = new Lhsmenu();
           //  xmlfiledTable.setEnabled(false);
			int response=  JOptionPane.showConfirmDialog(null, "Do you want to continue?","Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	    	   if (response == JOptionPane.NO_OPTION) {
	    		      System.out.println("No button clicked");
	    		    } else if (response == JOptionPane.YES_OPTION) {

				xmlLhsin.lhsMenu((String) filterType.getSelectedItem(), xmlLhsfiled
						.getText(),xmlLhsfiledTable.getText(),true);
		} else if (response == JOptionPane.CLOSED_OPTION) {
		      System.out.println("JOptionPane closed");
		    }
		}
	};

	ActionListener cavDrop = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			/*CSVFileCreater csvTables = new CSVFileCreater();
			System.out.println("Genearting CSV tables");
			csvTables.writetable((String) filterType.getSelectedItem());

			jtextArea.append("\n createXLIFF");
			JButton button = (JButton) e.getSource();
			System.out.println("You select button: " + button.getText());*/
			String PattAppender = "/";
			ExportCSV export=new ExportCSV();
			export.ExportCsvMethod((String) filterType.getSelectedItem(),filepath + PattAppender);
			
			
		}
	};
	ActionListener updateAll = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			LangugeTbCreate updateall = new LangugeTbCreate();
			updateall.update2Table((String) filterType.getSelectedItem());

		}
	};
	ActionListener INFOACTION = new ActionListener() {
	

		public void actionPerformed(ActionEvent e) {

			InfoPanel INSPANEL=new InfoPanel();
			
			 center = new Center(INSPANEL,600,400);
			 INSPANEL.setVisible(true);
			 INSPANEL.setResizable(false);

		}
	};
	

	public void masterAndFinal() {
		this.removeAll();
		System.out.println("in master");
		JRadioButton button1 = new JRadioButton("Insert into Master table :");
		button1.setActionCommand("INSERT_MASTER");

		/*JRadioButton button2 = new JRadioButton("Update with PM changes :");
		button2.setActionCommand("UPDATE_PM_CHANGES");
*/
		JRadioButton button3 = new JRadioButton("Insert Duplicates :");
		button3.setActionCommand("INSERT_DUPLICATE");

		JRadioButton button4 = new JRadioButton("Delete Duplicates :");
		button4.setActionCommand("DELETE_DUPLICATE");

		JRadioButton button5 = new JRadioButton(
		"Insert unique values into Final table :");
		button5.setActionCommand("INSERT_FINAL");
		Box masterAndFinalBox = Box.createHorizontalBox();
	
		
		 
		 JButton submit = new JButton("Submit");
		 JButton createtables = new JButton("Create Tables");
		 
		 
		 JButton INFO = new JButton("INFO");
		group = new ButtonGroup();
		group.add(button1);

		//group.add(button2);
		group.add(button3);
		group.add(button4);
		group.add(button5);
		masterAndFinalBox.add(button1);
		//masterAndFinalBox.add(button2);
		masterAndFinalBox.add(button3);
		masterAndFinalBox.add(button4);
		masterAndFinalBox.add(button5);
		masterAndFinalBox.add(submit);
		masterAndFinalBox.add(createtables);
		masterAndFinalBox.add(INFO);
		add(masterAndFinalBox, BorderLayout.CENTER);
		submit.addActionListener(masterAndFinal);
		createtables.addActionListener(createtablesAction);
		INFO.addActionListener(INFOACTION);
		revalidate();
		repaint();
		setVisible(true);
	}

	public void createXLIFF() {
		this.removeAll();

		JLabel createXLIFFLable = new JLabel(
		"Select Path For Storing the XLIFF FIles:  ");
		dircreatxlif=new JTextField();
		dircreatxlif.setPreferredSize(new Dimension(300,20));
		JButton createXLIFFbutton = new JButton("Browse");
		
		// createXLIFFBox1 = Box.createVerticalBox();
		JButton createXLIFFSubmit = new JButton("Create XLIFF");
		add(createXLIFFLable);
		add(dircreatxlif);
		add(createXLIFFbutton);
		add(createXLIFFSubmit);
		

		
		createXLIFFSubmit.addActionListener(createXLIFF);
		createXLIFFbutton.addActionListener(filePath);
		revalidate();
		repaint();
		setVisible(true);
	}

	public void xliff2DB() {
		this.removeAll();

		JLabel xliff2DBLable = new JLabel("Select The Path XLIFF FIles:  ");
		directory=new JTextField();
		directory.setPreferredSize(new Dimension(300,20));
		
	
		JButton xliff2DBbutton = new JButton("Browse");
		JButton xliff2DSubmit = new JButton("Import XLIFF TO DB");
		JButton createMasterLang = new JButton("Create Master Languge Table");
		add(xliff2DBLable);
		add(directory);
		add(xliff2DBbutton);
		add(xliff2DSubmit);
		add(createMasterLang);
		xliff2DSubmit.addActionListener(xliff2DB);
		xliff2DBbutton.addActionListener(filePath);
		createMasterLang.addActionListener(lngMaster);
		revalidate();
		repaint();
		setVisible(true);
	}

	public void insertAll() {
		this.removeAll();
		JLabel insertAllLable = new JLabel("Insert all the tables data : ");

		JButton insertAllSubmit = new JButton("Insert All");
		add(insertAllLable);
		add(insertAllSubmit);
		insertAllSubmit.addActionListener(insertAll);

		revalidate();
		repaint();
		setVisible(true);
	}

	public void cavDrop() {
		this.removeAll();
		JLabel csvLable = new JLabel("Create the CSV Files");
		//JLabel xliff2DBLable = new JLabel("Select The Path XLIFF FIles:  ");
		csvDirectory=new JTextField();
		csvDirectory.setPreferredSize(new Dimension(300,20));
		
	
		JButton csvBrowse = new JButton("Browse");
		JButton csvSubmit = new JButton("CSV");
		
		add(csvLable);
		add(csvDirectory);
		add(csvBrowse);
		add(csvSubmit);
		csvBrowse.addActionListener(filePath);
		csvSubmit.addActionListener(cavDrop);

		revalidate();
		repaint();
		setVisible(true);
	}

	public void xmlFile() {
		this.removeAll();
		JLabel xmlLable = new JLabel("Xml File name: ");
		xmlfiled = new JTextField();
		JLabel xmlLableTable = new JLabel("Data base Table name: ");
		xmlfiledTable = new JTextField();
		xmlfiled.setPreferredSize(new Dimension(200, 20));
		xmlfiledTable.setPreferredSize(new Dimension(200, 20));
		JButton xmlInsert = new JButton("XML Insert");
		JButton xmlupdate = new JButton("XML Update");

		add(xmlLable);
		add(xmlfiled);

		add(xmlLableTable);
		add(xmlfiledTable);
		
		add(xmlInsert);
		add(xmlupdate);
		xmlInsert.addActionListener(xmlIn);
		xmlupdate.addActionListener(xmlUp);
		revalidate();
		repaint();
		setVisible(true);

	}
	public void xmlLhsMenu() {
		this.removeAll();
		JLabel xmlLhsLable = new JLabel("Xml File name: ");
		xmlLhsfiled = new JTextField();
		JLabel xmllhsLableTable = new JLabel("Data base Table name: ");
		xmlLhsfiledTable = new JTextField();
		xmlLhsfiled.setPreferredSize(new Dimension(200, 20));
		xmlLhsfiledTable.setPreferredSize(new Dimension(200, 20));
		JButton xmlLhsInsert = new JButton("LHSMenu Insert");
		JButton xmlLhsupdate = new JButton("LHSMenu Update");

		add(xmlLhsLable);
		add(xmlLhsfiled);

		add(xmllhsLableTable);
		add(xmlLhsfiledTable);
		
		add(xmlLhsInsert);
		add(xmlLhsupdate);
		xmlLhsInsert.addActionListener(xmlLhsIn);
		xmlLhsupdate.addActionListener(xmllhsUp);
		revalidate();
		repaint();
		setVisible(true);

	}
	public void clear() {

		// TODO Auto-generated method stub

	}

	public void updateAll() {
		this.removeAll();
		JLabel updateLable = new JLabel("Update all the tables data : ");

		JButton updateSubmit = new JButton("Update");
		add(updateLable);
		add(updateSubmit);
		updateSubmit.addActionListener(updateAll);

		revalidate();
		repaint();
		setVisible(true);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 917627546250212907L;
	private JComboBox filterType;

	private ButtonGroup group;
	private JFileChooser fc;
	private String filepath;
	private JButton selectFilePath;
	private JTextArea jtextArea;
	private JTextField xmlfiled;
	private JTextField xmlLhsfiled;

	private JTextField xmlfiledTable;
	private JTextField xmlLhsfiledTable;
	private  JTextField directory;
	private  JTextField  csvDirectory;
	private  JTextField dircreatxlif;
	private Center center;
}
